/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.github.inflationx.calligraphy3;

public interface FontMapper {
    public String map(String var1);
}

