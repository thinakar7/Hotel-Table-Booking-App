/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 */
package io.github.inflationx.calligraphy3;

import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class ReflectionUtils {
    private static final String TAG = ReflectionUtils.class.getSimpleName();

    ReflectionUtils() {
    }

    static Method getMethod(Class class_, String string2) {
        for (Method method : class_.getMethods()) {
            if (!method.getName().equals((Object)string2)) continue;
            method.setAccessible(true);
            return method;
        }
        return null;
    }

    static /* varargs */ void invokeMethod(Object object, Method method, Object ... arrobject) {
        if (method == null) {
            return;
        }
        try {
            method.invoke(object, arrobject);
            return;
        }
        catch (InvocationTargetException invocationTargetException) {
            Log.d((String)TAG, (String)"Can't invoke method using reflection", (Throwable)invocationTargetException);
            return;
        }
        catch (IllegalAccessException illegalAccessException) {
            Log.d((String)TAG, (String)"Can't access method using reflection", (Throwable)illegalAccessException);
            return;
        }
    }
}

