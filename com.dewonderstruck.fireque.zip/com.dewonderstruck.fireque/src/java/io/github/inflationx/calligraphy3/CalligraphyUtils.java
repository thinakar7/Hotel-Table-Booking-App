/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.graphics.Typeface
 *  android.text.Editable
 *  android.text.Spannable
 *  android.text.SpannableString
 *  android.text.TextUtils
 *  android.text.TextWatcher
 *  android.util.AttributeSet
 *  android.util.TypedValue
 *  android.widget.TextView
 *  android.widget.TextView$BufferType
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.github.inflationx.calligraphy3;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.TextView;
import io.github.inflationx.calligraphy3.CalligraphyConfig;
import io.github.inflationx.calligraphy3.TypefaceUtils;

public final class CalligraphyUtils {
    public static final int[] ANDROID_ATTR_TEXT_APPEARANCE = new int[]{16842804};
    private static Boolean sAppCompatViewCheck;
    private static Boolean sToolbarCheck;

    static {
        sToolbarCheck = null;
        sAppCompatViewCheck = null;
    }

    private CalligraphyUtils() {
    }

    static void applyFontToTextView(Context context, TextView textView, CalligraphyConfig calligraphyConfig) {
        CalligraphyUtils.applyFontToTextView(context, textView, calligraphyConfig, false);
    }

    public static void applyFontToTextView(Context context, TextView textView, CalligraphyConfig calligraphyConfig, String string2) {
        CalligraphyUtils.applyFontToTextView(context, textView, calligraphyConfig, string2, false);
    }

    static void applyFontToTextView(Context context, TextView textView, CalligraphyConfig calligraphyConfig, String string2, boolean bl) {
        if (context != null && textView != null) {
            if (calligraphyConfig == null) {
                return;
            }
            if (!TextUtils.isEmpty((CharSequence)string2) && CalligraphyUtils.applyFontToTextView(context, textView, string2, bl)) {
                return;
            }
            CalligraphyUtils.applyFontToTextView(context, textView, calligraphyConfig, bl);
            return;
        }
    }

    static void applyFontToTextView(Context context, TextView textView, CalligraphyConfig calligraphyConfig, boolean bl) {
        if (context != null && textView != null) {
            if (calligraphyConfig == null) {
                return;
            }
            if (!calligraphyConfig.isFontSet()) {
                return;
            }
            CalligraphyUtils.applyFontToTextView(context, textView, calligraphyConfig.getFontPath(), bl);
            return;
        }
    }

    public static boolean applyFontToTextView(Context context, TextView textView, String string2) {
        return CalligraphyUtils.applyFontToTextView(context, textView, string2, false);
    }

    static boolean applyFontToTextView(Context context, TextView textView, String string2, boolean bl) {
        if (textView != null && context != null) {
            return CalligraphyUtils.applyFontToTextView(textView, TypefaceUtils.load(context.getAssets(), string2), bl);
        }
        return false;
    }

    public static boolean applyFontToTextView(TextView textView, Typeface typeface) {
        return CalligraphyUtils.applyFontToTextView(textView, typeface, false);
    }

    public static boolean applyFontToTextView(TextView textView, final Typeface typeface, boolean bl) {
        if (textView != null && typeface != null) {
            textView.setPaintFlags(1 | (128 | textView.getPaintFlags()));
            textView.setTypeface(typeface);
            if (bl) {
                textView.setText(CalligraphyUtils.applyTypefaceSpan(textView.getText(), typeface), TextView.BufferType.SPANNABLE);
                textView.addTextChangedListener(new TextWatcher(){

                    public void afterTextChanged(Editable editable) {
                        CalligraphyUtils.applyTypefaceSpan((CharSequence)editable, typeface);
                    }

                    public void beforeTextChanged(CharSequence charSequence, int n, int n2, int n3) {
                    }

                    public void onTextChanged(CharSequence charSequence, int n, int n2, int n3) {
                    }
                });
            }
            return true;
        }
        return false;
    }

    public static CharSequence applyTypefaceSpan(CharSequence charSequence, Typeface typeface) {
        if (charSequence != null && charSequence.length() > 0) {
            if (!(charSequence instanceof Spannable)) {
                charSequence = new SpannableString(charSequence);
            }
            ((Spannable)charSequence).setSpan((Object)TypefaceUtils.getSpan(typeface), 0, charSequence.length(), 33);
        }
        return charSequence;
    }

    static boolean canAddV7AppCompatViews() {
        if (sAppCompatViewCheck == null) {
            try {
                Class.forName((String)"androidx.appcompat.widget.AppCompatTextView");
                sAppCompatViewCheck = Boolean.TRUE;
            }
            catch (ClassNotFoundException classNotFoundException) {
                sAppCompatViewCheck = Boolean.FALSE;
            }
        }
        return sAppCompatViewCheck;
    }

    static boolean canCheckForV7Toolbar() {
        if (sToolbarCheck == null) {
            try {
                Class.forName((String)"androidx.appcompat.widget.Toolbar");
                sToolbarCheck = Boolean.TRUE;
            }
            catch (ClassNotFoundException classNotFoundException) {
                sToolbarCheck = Boolean.FALSE;
            }
        }
        return sToolbarCheck;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static String pullFontPathFromStyle(Context var0, AttributeSet var1_1, int[] var2_2) {
        if (var2_2 == null) return null;
        if (var1_1 == null) {
            return null;
        }
        var3_3 = var0.obtainStyledAttributes(var1_1, var2_2);
        if (var3_3 == null) return null;
        try {
            var6_4 = var3_3.getString(0);
            var7_5 = TextUtils.isEmpty((CharSequence)var6_4);
            ** if (var7_5) goto lbl-1000
        }
        catch (Throwable var5_6) {
            var3_3.recycle();
            throw var5_6;
        }
        catch (Exception var4_7) {
            // empty catch block
        }
lbl-1000: // 1 sources:
        {
            var3_3.recycle();
            return var6_4;
        }
lbl-1000: // 1 sources:
        {
        }
        var3_3.recycle();
        return null;
    }

    static String pullFontPathFromTextAppearance(Context context, AttributeSet attributeSet, int[] arrn) {
        if (arrn != null) {
            TypedArray typedArray;
            int n;
            if (attributeSet == null) {
                return null;
            }
            n = -1;
            TypedArray typedArray2 = context.obtainStyledAttributes(attributeSet, ANDROID_ATTR_TEXT_APPEARANCE);
            if (typedArray2 != null) {
                try {
                    int n2;
                    n = n2 = typedArray2.getResourceId(0, -1);
                }
                catch (Throwable throwable) {
                    typedArray2.recycle();
                    throw throwable;
                }
                catch (Exception exception) {
                    typedArray2.recycle();
                    return null;
                }
                typedArray2.recycle();
            }
            if ((typedArray = context.obtainStyledAttributes(n, arrn)) != null) {
                try {
                    String string2 = typedArray.getString(0);
                    return string2;
                }
                catch (Exception exception) {
                    return null;
                }
                finally {
                    typedArray.recycle();
                }
            }
            return null;
        }
        return null;
    }

    static String pullFontPathFromTheme(Context context, int n, int n2, int[] arrn) {
        if (n != -1) {
            int n3;
            block11 : {
                if (arrn == null) {
                    return null;
                }
                Resources.Theme theme = context.getTheme();
                TypedValue typedValue = new TypedValue();
                theme.resolveAttribute(n, typedValue, true);
                TypedArray typedArray = theme.obtainStyledAttributes(typedValue.resourceId, new int[]{n2});
                try {
                    n3 = typedArray.getResourceId(0, -1);
                    if (n3 != -1) break block11;
                    return null;
                }
                catch (Exception exception) {
                    return null;
                }
                finally {
                    typedArray.recycle();
                }
            }
            TypedArray typedArray = context.obtainStyledAttributes(n3, arrn);
            if (typedArray != null) {
                try {
                    String string2 = typedArray.getString(0);
                    return string2;
                }
                catch (Exception exception) {
                    return null;
                }
                finally {
                    typedArray.recycle();
                }
            }
            return null;
        }
        return null;
    }

    static String pullFontPathFromTheme(Context context, int n, int[] arrn) {
        if (n != -1) {
            if (arrn == null) {
                return null;
            }
            Resources.Theme theme = context.getTheme();
            TypedValue typedValue = new TypedValue();
            theme.resolveAttribute(n, typedValue, true);
            TypedArray typedArray = theme.obtainStyledAttributes(typedValue.resourceId, arrn);
            try {
                String string2 = typedArray.getString(0);
                return string2;
            }
            catch (Exception exception) {
                return null;
            }
            finally {
                typedArray.recycle();
            }
        }
        return null;
    }

    static String pullFontPathFromView(Context context, AttributeSet attributeSet, int[] arrn) {
        if (arrn != null) {
            String string2;
            String string3;
            if (attributeSet == null) {
                return null;
            }
            try {
                string3 = context.getResources().getResourceEntryName(arrn[0]);
            }
            catch (Resources.NotFoundException notFoundException) {
                return null;
            }
            int n = attributeSet.getAttributeResourceValue(null, string3, -1);
            String string4 = n > 0 ? context.getString(n) : attributeSet.getAttributeValue(null, string3);
            if (string4 != null && string4.startsWith("?") && string4.length() > 1 && TextUtils.isDigitsOnly((CharSequence)(string2 = string4.substring(1)))) {
                int n2 = Integer.parseInt((String)string2);
                TypedValue typedValue = new TypedValue();
                context.getTheme().resolveAttribute(n2, typedValue, true);
                if (typedValue.type == 3 && typedValue.string != null) {
                    string4 = typedValue.string.toString();
                }
            }
            return string4;
        }
        return null;
    }

}

