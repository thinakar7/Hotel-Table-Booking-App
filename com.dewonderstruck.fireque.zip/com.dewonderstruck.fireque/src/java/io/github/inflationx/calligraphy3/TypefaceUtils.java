/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.AssetManager
 *  android.graphics.Typeface
 *  android.util.Log
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 */
package io.github.inflationx.calligraphy3;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.util.Log;
import io.github.inflationx.calligraphy3.CalligraphyTypefaceSpan;
import java.util.HashMap;
import java.util.Map;

public final class TypefaceUtils {
    private static final Map<String, Typeface> sCachedFonts = new HashMap();
    private static final Map<Typeface, CalligraphyTypefaceSpan> sCachedSpans = new HashMap();

    private TypefaceUtils() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static CalligraphyTypefaceSpan getSpan(Typeface typeface) {
        Map<Typeface, CalligraphyTypefaceSpan> map;
        if (typeface == null) {
            return null;
        }
        Map<Typeface, CalligraphyTypefaceSpan> map2 = map = sCachedSpans;
        synchronized (map2) {
            if (map.containsKey((Object)typeface)) return (CalligraphyTypefaceSpan)((Object)map.get((Object)typeface));
            CalligraphyTypefaceSpan calligraphyTypefaceSpan = new CalligraphyTypefaceSpan(typeface);
            map.put((Object)typeface, (Object)calligraphyTypefaceSpan);
            return calligraphyTypefaceSpan;
        }
    }

    public static boolean isLoaded(Typeface typeface) {
        return typeface != null && sCachedFonts.containsValue((Object)typeface);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Typeface load(AssetManager assetManager, String string2) {
        Map<String, Typeface> map;
        Map<String, Typeface> map2 = map = sCachedFonts;
        synchronized (map2) {
            try {
                try {
                    if (map.containsKey((Object)string2)) return (Typeface)map.get((Object)string2);
                    Typeface typeface = string2.startsWith("/") ? Typeface.createFromFile((String)string2) : Typeface.createFromAsset((AssetManager)assetManager, (String)string2);
                    map.put((Object)string2, (Object)typeface);
                    return typeface;
                }
                catch (Exception exception) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Can't create asset from ");
                    stringBuilder.append(string2);
                    stringBuilder.append(". Make sure you have passed in the correct path and file name.");
                    Log.w((String)"Calligraphy", (String)stringBuilder.toString(), (Throwable)exception);
                    sCachedFonts.put((Object)string2, null);
                    return null;
                }
            }
            catch (Throwable throwable) {}
            throw throwable;
        }
    }
}

