/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  java.lang.Object
 */
package io.github.inflationx.calligraphy3;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import io.github.inflationx.calligraphy3.Calligraphy;
import io.github.inflationx.calligraphy3.CalligraphyConfig;
import io.github.inflationx.viewpump.InflateRequest;
import io.github.inflationx.viewpump.InflateResult;
import io.github.inflationx.viewpump.Interceptor;

public class CalligraphyInterceptor
implements Interceptor {
    private final Calligraphy calligraphy;

    public CalligraphyInterceptor(CalligraphyConfig calligraphyConfig) {
        this.calligraphy = new Calligraphy(calligraphyConfig);
    }

    @Override
    public InflateResult intercept(Interceptor.Chain chain) {
        InflateResult inflateResult = chain.proceed(chain.request());
        View view = this.calligraphy.onViewCreated(inflateResult.view(), inflateResult.context(), inflateResult.attrs());
        return inflateResult.toBuilder().view(view).build();
    }
}

