/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.github.inflationx.calligraphy3;

public final class BuildConfig {
    public static final String APPLICATION_ID = "io.github.inflationx.calligraphy3";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 32;
    public static final String VERSION_NAME = "3.1.1";
}

