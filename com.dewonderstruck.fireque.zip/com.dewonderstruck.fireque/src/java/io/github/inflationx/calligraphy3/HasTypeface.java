/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Typeface
 *  java.lang.Object
 */
package io.github.inflationx.calligraphy3;

import android.graphics.Typeface;

public interface HasTypeface {
    public void setTypeface(Typeface var1);
}

