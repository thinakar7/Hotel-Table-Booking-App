/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.graphics.Typeface
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewParent
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.widget.TextView
 *  androidx.appcompat.widget.Toolbar
 *  io.github.inflationx.calligraphy3.R
 *  io.github.inflationx.calligraphy3.R$id
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 *  java.lang.reflect.Method
 *  java.util.Map
 */
package io.github.inflationx.calligraphy3;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import io.github.inflationx.calligraphy3.CalligraphyConfig;
import io.github.inflationx.calligraphy3.CalligraphyUtils;
import io.github.inflationx.calligraphy3.FontMapper;
import io.github.inflationx.calligraphy3.HasTypeface;
import io.github.inflationx.calligraphy3.R;
import io.github.inflationx.calligraphy3.ReflectionUtils;
import io.github.inflationx.calligraphy3.TypefaceUtils;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.Map;

class Calligraphy {
    private static final String ACTION_BAR_SUBTITLE = "action_bar_subtitle";
    private static final String ACTION_BAR_TITLE = "action_bar_title";
    private final int[] mAttributeId;
    private final CalligraphyConfig mCalligraphyConfig;

    public Calligraphy(CalligraphyConfig calligraphyConfig) {
        this.mCalligraphyConfig = calligraphyConfig;
        int[] arrn = new int[]{calligraphyConfig.getAttrId()};
        this.mAttributeId = arrn;
    }

    private String applyFontMapper(String string2) {
        FontMapper fontMapper = this.mCalligraphyConfig.getFontMapper();
        if (fontMapper != null) {
            return fontMapper.map(string2);
        }
        return string2;
    }

    private Typeface getDefaultTypeface(Context context, String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = this.mCalligraphyConfig.getFontPath();
        }
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            return TypefaceUtils.load(context.getAssets(), string2);
        }
        return null;
    }

    protected static boolean isActionBarSubTitle(TextView textView) {
        if (Calligraphy.matchesResourceIdName((View)textView, ACTION_BAR_SUBTITLE)) {
            return true;
        }
        if (Calligraphy.parentIsToolbarV7((View)textView)) {
            return TextUtils.equals((CharSequence)((Toolbar)textView.getParent()).getSubtitle(), (CharSequence)textView.getText());
        }
        return false;
    }

    protected static boolean isActionBarTitle(TextView textView) {
        if (Calligraphy.matchesResourceIdName((View)textView, ACTION_BAR_TITLE)) {
            return true;
        }
        if (Calligraphy.parentIsToolbarV7((View)textView)) {
            return TextUtils.equals((CharSequence)((Toolbar)textView.getParent()).getTitle(), (CharSequence)textView.getText());
        }
        return false;
    }

    protected static boolean matchesResourceIdName(View view, String string2) {
        if (view.getId() == -1) {
            return false;
        }
        return view.getResources().getResourceEntryName(view.getId()).equalsIgnoreCase(string2);
    }

    protected static boolean parentIsToolbarV7(View view) {
        return CalligraphyUtils.canCheckForV7Toolbar() && view.getParent() != null && view.getParent() instanceof Toolbar;
    }

    private String resolveFontPath(Context context, AttributeSet attributeSet) {
        String string2 = CalligraphyUtils.pullFontPathFromView(context, attributeSet, this.mAttributeId);
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = CalligraphyUtils.pullFontPathFromStyle(context, attributeSet, this.mAttributeId);
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = CalligraphyUtils.pullFontPathFromTextAppearance(context, attributeSet, this.mAttributeId);
        }
        return string2;
    }

    protected int[] getStyleForTextView(TextView textView) {
        int[] arrn = new int[]{-1, -1};
        if (Calligraphy.isActionBarTitle(textView)) {
            arrn[0] = 16843470;
            arrn[1] = 16843512;
        } else if (Calligraphy.isActionBarSubTitle(textView)) {
            arrn[0] = 16843470;
            arrn[1] = 16843513;
        }
        if (arrn[0] == -1) {
            int n = this.mCalligraphyConfig.getClassStyles().containsKey((Object)textView.getClass()) ? (Integer)this.mCalligraphyConfig.getClassStyles().get((Object)textView.getClass()) : 16842804;
            arrn[0] = n;
        }
        return arrn;
    }

    public View onViewCreated(View view, Context context, AttributeSet attributeSet) {
        if (view != null && view.getTag(R.id.calligraphy_tag_id) != Boolean.TRUE) {
            this.onViewCreatedInternal(view, context, attributeSet);
            view.setTag(R.id.calligraphy_tag_id, (Object)Boolean.TRUE);
        }
        return view;
    }

    void onViewCreatedInternal(View view, Context context, AttributeSet attributeSet) {
        if (view instanceof TextView) {
            if (TypefaceUtils.isLoaded(((TextView)view).getTypeface())) {
                return;
            }
            String string2 = this.resolveFontPath(context, attributeSet);
            if (TextUtils.isEmpty((CharSequence)string2)) {
                int[] arrn = this.getStyleForTextView((TextView)view);
                string2 = arrn[1] != -1 ? CalligraphyUtils.pullFontPathFromTheme(context, arrn[0], arrn[1], this.mAttributeId) : CalligraphyUtils.pullFontPathFromTheme(context, arrn[0], this.mAttributeId);
            }
            String string3 = this.applyFontMapper(string2);
            boolean bl = Calligraphy.matchesResourceIdName(view, ACTION_BAR_TITLE) || Calligraphy.matchesResourceIdName(view, ACTION_BAR_SUBTITLE);
            CalligraphyUtils.applyFontToTextView(context, (TextView)view, this.mCalligraphyConfig, string3, bl);
        }
        if (CalligraphyUtils.canCheckForV7Toolbar() && view instanceof Toolbar) {
            Toolbar toolbar = (Toolbar)view;
            toolbar.getViewTreeObserver().addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)new ToolbarLayoutListener(this, context, toolbar));
        }
        if (view instanceof HasTypeface) {
            Typeface typeface = this.getDefaultTypeface(context, this.applyFontMapper(this.resolveFontPath(context, attributeSet)));
            if (typeface != null) {
                ((HasTypeface)view).setTypeface(typeface);
            }
        } else if (this.mCalligraphyConfig.isCustomViewTypefaceSupport() && this.mCalligraphyConfig.isCustomViewHasTypeface(view)) {
            Method method = ReflectionUtils.getMethod(view.getClass(), "setTypeface");
            Typeface typeface = this.getDefaultTypeface(context, this.applyFontMapper(this.resolveFontPath(context, attributeSet)));
            if (method != null && typeface != null) {
                ReflectionUtils.invokeMethod((Object)view, method, new Object[]{typeface});
                return;
            }
        }
    }

    private static class ToolbarLayoutListener
    implements ViewTreeObserver.OnGlobalLayoutListener {
        static String BLANK = " ";
        private final WeakReference<Calligraphy> mCalligraphyFactory;
        private final WeakReference<Context> mContextRef;
        private final WeakReference<Toolbar> mToolbarReference;
        private final CharSequence originalSubTitle;

        private ToolbarLayoutListener(Calligraphy calligraphy, Context context, Toolbar toolbar) {
            this.mCalligraphyFactory = new WeakReference((Object)calligraphy);
            this.mContextRef = new WeakReference((Object)context);
            this.mToolbarReference = new WeakReference((Object)toolbar);
            this.originalSubTitle = toolbar.getSubtitle();
            toolbar.setSubtitle((CharSequence)BLANK);
        }

        private void removeSelf(Toolbar toolbar) {
            if (Build.VERSION.SDK_INT < 16) {
                toolbar.getViewTreeObserver().removeGlobalOnLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
                return;
            }
            toolbar.getViewTreeObserver().removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
        }

        public void onGlobalLayout() {
            Toolbar toolbar = (Toolbar)this.mToolbarReference.get();
            Context context = (Context)this.mContextRef.get();
            Calligraphy calligraphy = (Calligraphy)this.mCalligraphyFactory.get();
            if (toolbar == null) {
                return;
            }
            if (calligraphy != null && context != null) {
                int n = toolbar.getChildCount();
                if (n != 0) {
                    for (int i = 0; i < n; ++i) {
                        calligraphy.onViewCreated(toolbar.getChildAt(i), context, null);
                    }
                }
                this.removeSelf(toolbar);
                toolbar.setSubtitle(this.originalSubTitle);
                return;
            }
            this.removeSelf(toolbar);
        }
    }

}

