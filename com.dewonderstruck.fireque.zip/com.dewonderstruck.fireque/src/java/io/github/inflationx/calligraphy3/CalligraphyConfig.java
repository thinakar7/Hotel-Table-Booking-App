/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.TextUtils
 *  android.view.View
 *  android.widget.AutoCompleteTextView
 *  android.widget.Button
 *  android.widget.CheckBox
 *  android.widget.EditText
 *  android.widget.MultiAutoCompleteTextView
 *  android.widget.RadioButton
 *  android.widget.TextView
 *  android.widget.ToggleButton
 *  androidx.appcompat.widget.AppCompatAutoCompleteTextView
 *  androidx.appcompat.widget.AppCompatButton
 *  androidx.appcompat.widget.AppCompatCheckBox
 *  androidx.appcompat.widget.AppCompatCheckedTextView
 *  androidx.appcompat.widget.AppCompatEditText
 *  androidx.appcompat.widget.AppCompatMultiAutoCompleteTextView
 *  androidx.appcompat.widget.AppCompatRadioButton
 *  androidx.appcompat.widget.AppCompatTextView
 *  io.github.inflationx.calligraphy3.R
 *  io.github.inflationx.calligraphy3.R$attr
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Map
 *  java.util.Set
 */
package io.github.inflationx.calligraphy3;

import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.ToggleButton;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatCheckedTextView;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatMultiAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.appcompat.widget.AppCompatTextView;
import io.github.inflationx.calligraphy3.CalligraphyUtils;
import io.github.inflationx.calligraphy3.FontMapper;
import io.github.inflationx.calligraphy3.R;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class CalligraphyConfig {
    private static final Map<Class<? extends TextView>, Integer> DEFAULT_STYLES;
    private final Set<Class<?>> hasTypefaceViews;
    private final int mAttrId;
    private final Map<Class<? extends TextView>, Integer> mClassStyleAttributeMap;
    private final boolean mCustomViewTypefaceSupport;
    private final FontMapper mFontMapper;
    private final String mFontPath;
    private final boolean mIsFontSet;

    static {
        HashMap hashMap;
        DEFAULT_STYLES = hashMap = new HashMap();
        hashMap.put(TextView.class, (Object)16842884);
        hashMap.put(Button.class, (Object)16842824);
        hashMap.put(EditText.class, (Object)16842862);
        Integer n = 16842859;
        hashMap.put(AutoCompleteTextView.class, (Object)n);
        hashMap.put(MultiAutoCompleteTextView.class, (Object)n);
        hashMap.put(CheckBox.class, (Object)16842860);
        hashMap.put(RadioButton.class, (Object)16842878);
        hashMap.put(ToggleButton.class, (Object)16842827);
        if (CalligraphyUtils.canAddV7AppCompatViews()) {
            CalligraphyConfig.addAppCompatViews();
        }
    }

    private CalligraphyConfig(Builder builder) {
        this.mIsFontSet = builder.isFontSet;
        this.mFontPath = builder.fontAssetPath;
        this.mAttrId = builder.attrId;
        this.mCustomViewTypefaceSupport = builder.customViewTypefaceSupport;
        HashMap hashMap = new HashMap(DEFAULT_STYLES);
        hashMap.putAll(builder.mStyleClassMap);
        this.mClassStyleAttributeMap = Collections.unmodifiableMap((Map)hashMap);
        this.hasTypefaceViews = Collections.unmodifiableSet((Set)builder.mHasTypefaceClasses);
        this.mFontMapper = builder.fontMapper;
    }

    private static void addAppCompatViews() {
        Map<Class<? extends TextView>, Integer> map = DEFAULT_STYLES;
        map.put(AppCompatTextView.class, (Object)16842884);
        map.put(AppCompatButton.class, (Object)16842824);
        map.put(AppCompatEditText.class, (Object)16842862);
        Integer n = 16842859;
        map.put(AppCompatAutoCompleteTextView.class, (Object)n);
        map.put(AppCompatMultiAutoCompleteTextView.class, (Object)n);
        map.put(AppCompatCheckBox.class, (Object)16842860);
        map.put(AppCompatRadioButton.class, (Object)16842878);
        if (Build.VERSION.SDK_INT >= 17) {
            map.put(AppCompatCheckedTextView.class, (Object)16843720);
        }
    }

    public int getAttrId() {
        return this.mAttrId;
    }

    Map<Class<? extends TextView>, Integer> getClassStyles() {
        return this.mClassStyleAttributeMap;
    }

    public FontMapper getFontMapper() {
        return this.mFontMapper;
    }

    public String getFontPath() {
        return this.mFontPath;
    }

    public boolean isCustomViewHasTypeface(View view) {
        return this.hasTypefaceViews.contains((Object)view.getClass());
    }

    public boolean isCustomViewTypefaceSupport() {
        return this.mCustomViewTypefaceSupport;
    }

    boolean isFontSet() {
        return this.mIsFontSet;
    }

    public static class Builder {
        public static final int INVALID_ATTR_ID = -1;
        private int attrId = R.attr.fontPath;
        private boolean customViewTypefaceSupport = false;
        private String fontAssetPath = null;
        private FontMapper fontMapper;
        private boolean isFontSet = false;
        private Set<Class<?>> mHasTypefaceClasses = new HashSet();
        private Map<Class<? extends TextView>, Integer> mStyleClassMap = new HashMap();

        public Builder addCustomStyle(Class<? extends TextView> class_, int n) {
            if (class_ != null) {
                if (n == 0) {
                    return this;
                }
                this.mStyleClassMap.put(class_, (Object)n);
                return this;
            }
            return this;
        }

        public Builder addCustomViewWithSetTypeface(Class<?> class_) {
            this.customViewTypefaceSupport = true;
            this.mHasTypefaceClasses.add(class_);
            return this;
        }

        public CalligraphyConfig build() {
            this.isFontSet = true ^ TextUtils.isEmpty((CharSequence)this.fontAssetPath);
            return new CalligraphyConfig(this);
        }

        public Builder setDefaultFontPath(String string2) {
            this.isFontSet = true ^ TextUtils.isEmpty((CharSequence)string2);
            this.fontAssetPath = string2;
            return this;
        }

        public Builder setFontAttrId(int n) {
            this.attrId = n;
            return this;
        }

        public Builder setFontMapper(FontMapper fontMapper) {
            this.fontMapper = fontMapper;
            return this;
        }
    }

}

