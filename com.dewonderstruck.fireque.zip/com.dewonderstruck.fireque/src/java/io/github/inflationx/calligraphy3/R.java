/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.github.inflationx.calligraphy3;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int fontPath = 2130903298;

        private attr() {
        }
    }

    public static final class id {
        public static final int calligraphy_tag_id = 2131230829;
        public static final int viewpump_tag_id = 2131231200;

        private id() {
        }
    }

}

