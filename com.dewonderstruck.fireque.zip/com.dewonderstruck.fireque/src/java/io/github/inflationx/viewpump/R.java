/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.github.inflationx.viewpump;

public final class R {
    private R() {
    }

    public static final class id {
        public static final int viewpump_layout_res = 2131231199;
        public static final int viewpump_tag_id = 2131231200;

        private id() {
        }
    }

}

