/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  dalvik.annotation.SourceDebugExtension
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  kotlin.Metadata
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package io.github.inflationx.viewpump;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import dalvik.annotation.SourceDebugExtension;
import io.github.inflationx.viewpump.FallbackViewCreator;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\b\u0018\u0000 !2\u00020\u0001:\u0002 !B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u00a2\u0006\u0002\u0010\fJ\t\u0010\u0012\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0013\u001a\u00020\u0005H\u00c6\u0003J\u000b\u0010\u0014\u001a\u0004\u0018\u00010\u0007H\u00c6\u0003J\u000b\u0010\u0015\u001a\u0004\u0018\u00010\tH\u00c6\u0003J\t\u0010\u0016\u001a\u00020\u000bH\u00c6\u0003J?\u0010\u0017\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\t2\b\b\u0002\u0010\n\u001a\u00020\u000bH\u00c6\u0001J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u001b\u001a\u00020\u001cH\u00d6\u0001J\u0006\u0010\u001d\u001a\u00020\u001eJ\t\u0010\u001f\u001a\u00020\u0003H\u00d6\u0001R\u0015\u0010\u0006\u001a\u0004\u0018\u00010\u00078\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\rR\u0013\u0010\u0004\u001a\u00020\u00058\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u000eR\u0013\u0010\n\u001a\u00020\u000b8\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000fR\u0013\u0010\u0002\u001a\u00020\u00038\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0010R\u0015\u0010\b\u001a\u0004\u0018\u00010\t8\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0011\u00a8\u0006\""}, d2={"Lio/github/inflationx/viewpump/InflateRequest;", "", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "parent", "Landroid/view/View;", "fallbackViewCreator", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;Landroid/view/View;Lio/github/inflationx/viewpump/FallbackViewCreator;)V", "()Landroid/util/AttributeSet;", "()Landroid/content/Context;", "()Lio/github/inflationx/viewpump/FallbackViewCreator;", "()Ljava/lang/String;", "()Landroid/view/View;", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "", "toBuilder", "Lio/github/inflationx/viewpump/InflateRequest$Builder;", "toString", "Builder", "Companion", "viewpump_release"}, k=1, mv={1, 1, 13})
public final class InflateRequest {
    public static final Companion Companion = new Companion(null);
    private final AttributeSet attrs;
    private final Context context;
    private final FallbackViewCreator fallbackViewCreator;
    private final String name;
    private final View parent;

    public InflateRequest(String string2, Context context, AttributeSet attributeSet, View view, FallbackViewCreator fallbackViewCreator) {
        Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        Intrinsics.checkParameterIsNotNull((Object)fallbackViewCreator, (String)"fallbackViewCreator");
        this.name = string2;
        this.context = context;
        this.attrs = attributeSet;
        this.parent = view;
        this.fallbackViewCreator = fallbackViewCreator;
    }

    public /* synthetic */ InflateRequest(String string2, Context context, AttributeSet attributeSet, View view, FallbackViewCreator fallbackViewCreator, int n, DefaultConstructorMarker defaultConstructorMarker) {
        AttributeSet attributeSet2 = (n & 4) != 0 ? (AttributeSet)null : attributeSet;
        View view2 = (n & 8) != 0 ? (View)null : view;
        this(string2, context, attributeSet2, view2, fallbackViewCreator);
    }

    @JvmStatic
    public static final Builder builder() {
        return Companion.builder();
    }

    public static /* synthetic */ InflateRequest copy$default(InflateRequest inflateRequest, String string2, Context context, AttributeSet attributeSet, View view, FallbackViewCreator fallbackViewCreator, int n, Object object) {
        if ((n & 1) != 0) {
            string2 = inflateRequest.name;
        }
        if ((n & 2) != 0) {
            context = inflateRequest.context;
        }
        Context context2 = context;
        if ((n & 4) != 0) {
            attributeSet = inflateRequest.attrs;
        }
        AttributeSet attributeSet2 = attributeSet;
        if ((n & 8) != 0) {
            view = inflateRequest.parent;
        }
        View view2 = view;
        if ((n & 16) != 0) {
            fallbackViewCreator = inflateRequest.fallbackViewCreator;
        }
        FallbackViewCreator fallbackViewCreator2 = fallbackViewCreator;
        return inflateRequest.copy(string2, context2, attributeSet2, view2, fallbackViewCreator2);
    }

    public final AttributeSet attrs() {
        return this.attrs;
    }

    public final String component1() {
        return this.name;
    }

    public final Context component2() {
        return this.context;
    }

    public final AttributeSet component3() {
        return this.attrs;
    }

    public final View component4() {
        return this.parent;
    }

    public final FallbackViewCreator component5() {
        return this.fallbackViewCreator;
    }

    public final Context context() {
        return this.context;
    }

    public final InflateRequest copy(String string2, Context context, AttributeSet attributeSet, View view, FallbackViewCreator fallbackViewCreator) {
        Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        Intrinsics.checkParameterIsNotNull((Object)fallbackViewCreator, (String)"fallbackViewCreator");
        InflateRequest inflateRequest = new InflateRequest(string2, context, attributeSet, view, fallbackViewCreator);
        return inflateRequest;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof InflateRequest)) break block3;
                InflateRequest inflateRequest = (InflateRequest)object;
                if (Intrinsics.areEqual((Object)this.name, (Object)inflateRequest.name) && Intrinsics.areEqual((Object)this.context, (Object)inflateRequest.context) && Intrinsics.areEqual((Object)this.attrs, (Object)inflateRequest.attrs) && Intrinsics.areEqual((Object)this.parent, (Object)inflateRequest.parent) && Intrinsics.areEqual((Object)this.fallbackViewCreator, (Object)inflateRequest.fallbackViewCreator)) break block2;
            }
            return false;
        }
        return true;
    }

    public final FallbackViewCreator fallbackViewCreator() {
        return this.fallbackViewCreator;
    }

    public int hashCode() {
        String string2 = this.name;
        int n = string2 != null ? string2.hashCode() : 0;
        int n2 = n * 31;
        Context context = this.context;
        int n3 = context != null ? context.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        AttributeSet attributeSet = this.attrs;
        int n5 = attributeSet != null ? attributeSet.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        View view = this.parent;
        int n7 = view != null ? view.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        FallbackViewCreator fallbackViewCreator = this.fallbackViewCreator;
        int n9 = 0;
        if (fallbackViewCreator != null) {
            n9 = fallbackViewCreator.hashCode();
        }
        return n8 + n9;
    }

    public final String name() {
        return this.name;
    }

    public final View parent() {
        return this.parent;
    }

    public final Builder toBuilder() {
        return new Builder(this);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("InflateRequest(name=");
        stringBuilder.append(this.name);
        stringBuilder.append(", context=");
        stringBuilder.append((Object)this.context);
        stringBuilder.append(", attrs=");
        stringBuilder.append((Object)this.attrs);
        stringBuilder.append(", parent=");
        stringBuilder.append((Object)this.parent);
        stringBuilder.append(", fallbackViewCreator=");
        stringBuilder.append((Object)this.fallbackViewCreator);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    @SourceDebugExtension(value="SMAP\nInflateRequest.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InflateRequest.kt\nio/github/inflationx/viewpump/InflateRequest$Builder\n*L\n1#1,78:1\n*E\n")
    @Metadata(bv={1, 0, 3}, d1={"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0010\u00a2\u0006\u0002\u0010\u0002B\u000f\b\u0010\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0002\u0010\u0005J\u0010\u0010\u0006\u001a\u00020\u00002\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007J\u0006\u0010\u0010\u001a\u00020\u0004J\u000e\u0010\b\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\n\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000bJ\u000e\u0010\f\u001a\u00020\u00002\u0006\u0010\f\u001a\u00020\rJ\u0010\u0010\u000e\u001a\u00020\u00002\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fR\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0011"}, d2={"Lio/github/inflationx/viewpump/InflateRequest$Builder;", "", "()V", "request", "Lio/github/inflationx/viewpump/InflateRequest;", "(Lio/github/inflationx/viewpump/InflateRequest;)V", "attrs", "Landroid/util/AttributeSet;", "context", "Landroid/content/Context;", "fallbackViewCreator", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "name", "", "parent", "Landroid/view/View;", "build", "viewpump_release"}, k=1, mv={1, 1, 13})
    public static final class Builder {
        private AttributeSet attrs;
        private Context context;
        private FallbackViewCreator fallbackViewCreator;
        private String name;
        private View parent;

        public Builder() {
        }

        public Builder(InflateRequest inflateRequest) {
            Intrinsics.checkParameterIsNotNull((Object)inflateRequest, (String)"request");
            this.name = inflateRequest.name();
            this.context = inflateRequest.context();
            this.attrs = inflateRequest.attrs();
            this.parent = inflateRequest.parent();
            this.fallbackViewCreator = inflateRequest.fallbackViewCreator();
        }

        public final Builder attrs(AttributeSet attributeSet) {
            this.attrs = attributeSet;
            return this;
        }

        public final InflateRequest build() {
            String string2 = this.name;
            if (string2 != null) {
                Context context = this.context;
                if (context != null) {
                    AttributeSet attributeSet = this.attrs;
                    View view = this.parent;
                    FallbackViewCreator fallbackViewCreator = this.fallbackViewCreator;
                    if (fallbackViewCreator != null) {
                        InflateRequest inflateRequest = new InflateRequest(string2, context, attributeSet, view, fallbackViewCreator);
                        return inflateRequest;
                    }
                    throw (Throwable)new IllegalStateException("fallbackViewCreator == null");
                }
                throw (Throwable)new IllegalStateException("context == null");
            }
            throw (Throwable)new IllegalStateException("name == null");
        }

        public final Builder context(Context context) {
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            this.context = context;
            return this;
        }

        public final Builder fallbackViewCreator(FallbackViewCreator fallbackViewCreator) {
            Intrinsics.checkParameterIsNotNull((Object)fallbackViewCreator, (String)"fallbackViewCreator");
            this.fallbackViewCreator = fallbackViewCreator;
            return this;
        }

        public final Builder name(String string2) {
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            this.name = string2;
            return this;
        }

        public final Builder parent(View view) {
            this.parent = view;
            return this;
        }
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007\u00a8\u0006\u0005"}, d2={"Lio/github/inflationx/viewpump/InflateRequest$Companion;", "", "()V", "builder", "Lio/github/inflationx/viewpump/InflateRequest$Builder;", "viewpump_release"}, k=1, mv={1, 1, 13})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @JvmStatic
        public final Builder builder() {
            return new Builder();
        }
    }

}

