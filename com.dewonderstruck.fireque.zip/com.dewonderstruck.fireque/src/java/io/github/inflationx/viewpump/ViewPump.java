/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  dalvik.annotation.SourceDebugExtension
 *  io.github.inflationx.viewpump.ViewPump$Companion$reflectiveFallbackViewCreator
 *  io.github.inflationx.viewpump.ViewPump$Companion$reflectiveFallbackViewCreator$2
 *  io.github.inflationx.viewpump.internal.-FallbackViewCreationInterceptor
 *  io.github.inflationx.viewpump.internal.-InterceptorChain
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  kotlin.Lazy
 *  kotlin.LazyKt
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.PropertyReference1
 *  kotlin.jvm.internal.PropertyReference1Impl
 *  kotlin.jvm.internal.Reflection
 *  kotlin.reflect.KDeclarationContainer
 *  kotlin.reflect.KProperty
 */
package io.github.inflationx.viewpump;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import dalvik.annotation.SourceDebugExtension;
import io.github.inflationx.viewpump.FallbackViewCreator;
import io.github.inflationx.viewpump.InflateRequest;
import io.github.inflationx.viewpump.InflateResult;
import io.github.inflationx.viewpump.Interceptor;
import io.github.inflationx.viewpump.ViewPump;
import io.github.inflationx.viewpump.internal.-FallbackViewCreationInterceptor;
import io.github.inflationx.viewpump.internal.-InterceptorChain;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.PropertyReference1;
import kotlin.jvm.internal.PropertyReference1Impl;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KDeclarationContainer;
import kotlin.reflect.KProperty;

@Metadata(bv={1, 0, 3}, d1={"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u00122\u00020\u0001:\u0002\u0011\u0012B-\b\u0002\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\tJ\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010R\u0019\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00038\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\nR\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0013\u0010\u0007\u001a\u00020\u00068\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\fR\u0013\u0010\u0005\u001a\u00020\u00068\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\fR\u0013\u0010\b\u001a\u00020\u00068\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\f\u00a8\u0006\u0013"}, d2={"Lio/github/inflationx/viewpump/ViewPump;", "", "interceptors", "", "Lio/github/inflationx/viewpump/Interceptor;", "isReflection", "", "isCustomViewCreation", "isStoreLayoutResId", "(Ljava/util/List;ZZZ)V", "()Ljava/util/List;", "interceptorsWithFallback", "()Z", "inflate", "Lio/github/inflationx/viewpump/InflateResult;", "originalRequest", "Lio/github/inflationx/viewpump/InflateRequest;", "Builder", "Companion", "viewpump_release"}, k=1, mv={1, 1, 13})
public final class ViewPump {
    public static final Companion Companion = new Companion(null);
    private static ViewPump INSTANCE;
    private static final Lazy reflectiveFallbackViewCreator$delegate;
    private final List<Interceptor> interceptors;
    private final List<Interceptor> interceptorsWithFallback;
    private final boolean isCustomViewCreation;
    private final boolean isReflection;
    private final boolean isStoreLayoutResId;

    static {
        reflectiveFallbackViewCreator$delegate = LazyKt.lazy((Function0)((Function0)Companion.reflectiveFallbackViewCreator.2.INSTANCE));
    }

    private ViewPump(List<? extends Interceptor> list, boolean bl, boolean bl2, boolean bl3) {
        this.interceptors = list;
        this.isReflection = bl;
        this.isCustomViewCreation = bl2;
        this.isStoreLayoutResId = bl3;
        this.interceptorsWithFallback = CollectionsKt.toMutableList((Collection)((Collection)CollectionsKt.plus((Collection)((Collection)list), (Object)new -FallbackViewCreationInterceptor())));
    }

    public /* synthetic */ ViewPump(List list, boolean bl, boolean bl2, boolean bl3, DefaultConstructorMarker defaultConstructorMarker) {
        this((List<? extends Interceptor>)list, bl, bl2, bl3);
    }

    public static final /* synthetic */ void access$setINSTANCE$cp(ViewPump viewPump) {
        INSTANCE = viewPump;
    }

    @JvmStatic
    public static final Builder builder() {
        return Companion.builder();
    }

    @JvmStatic
    public static final View create(Context context, Class<? extends View> class_) {
        return Companion.create(context, class_);
    }

    @JvmStatic
    public static final ViewPump get() {
        return Companion.get();
    }

    @JvmStatic
    public static final void init(ViewPump viewPump) {
        Companion.init(viewPump);
    }

    public final InflateResult inflate(InflateRequest inflateRequest) {
        Intrinsics.checkParameterIsNotNull((Object)inflateRequest, (String)"originalRequest");
        return new -InterceptorChain(this.interceptorsWithFallback, 0, inflateRequest).proceed(inflateRequest);
    }

    public final List<Interceptor> interceptors() {
        return this.interceptors;
    }

    public final boolean isCustomViewCreation() {
        return this.isCustomViewCreation;
    }

    public final boolean isReflection() {
        return this.isReflection;
    }

    public final boolean isStoreLayoutResId() {
        return this.isStoreLayoutResId;
    }

    @SourceDebugExtension(value="SMAP\nViewPump.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ViewPump.kt\nio/github/inflationx/viewpump/ViewPump$Builder\n*L\n1#1,196:1\n*E\n")
    @Metadata(bv={1, 0, 3}, d1={"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0007\b\u0000\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\f\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0007J\u0006\u0010\u000e\u001a\u00020\u000fJ\u000e\u0010\u0010\u001a\u00020\u00002\u0006\u0010\u0011\u001a\u00020\u0004J\u000e\u0010\u0012\u001a\u00020\u00002\u0006\u0010\u0011\u001a\u00020\u0004J\u000e\u0010\u0013\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u0014\u001a\u00020\u00002\u0006\u0010\u0011\u001a\u00020\u0004R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0015"}, d2={"Lio/github/inflationx/viewpump/ViewPump$Builder;", "", "()V", "customViewCreation", "", "interceptors", "", "Lio/github/inflationx/viewpump/Interceptor;", "reflection", "reflectiveFallbackViewCreator", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "storeLayoutResId", "addInterceptor", "interceptor", "build", "Lio/github/inflationx/viewpump/ViewPump;", "setCustomViewInflationEnabled", "enabled", "setPrivateFactoryInjectionEnabled", "setReflectiveFallbackViewCreator", "setStoreLayoutResId", "viewpump_release"}, k=1, mv={1, 1, 13})
    public static final class Builder {
        private boolean customViewCreation = true;
        private final List<Interceptor> interceptors = (List)new ArrayList();
        private boolean reflection = true;
        private FallbackViewCreator reflectiveFallbackViewCreator;
        private boolean storeLayoutResId;

        public final Builder addInterceptor(Interceptor interceptor) {
            Intrinsics.checkParameterIsNotNull((Object)interceptor, (String)"interceptor");
            this.interceptors.add((Object)interceptor);
            return this;
        }

        public final ViewPump build() {
            ViewPump viewPump = new ViewPump(CollectionsKt.toList((Iterable)((Iterable)this.interceptors)), this.reflection, this.customViewCreation, this.storeLayoutResId, null);
            return viewPump;
        }

        public final Builder setCustomViewInflationEnabled(boolean bl) {
            this.customViewCreation = bl;
            return this;
        }

        public final Builder setPrivateFactoryInjectionEnabled(boolean bl) {
            this.reflection = bl;
            return this;
        }

        public final Builder setReflectiveFallbackViewCreator(FallbackViewCreator fallbackViewCreator) {
            Intrinsics.checkParameterIsNotNull((Object)fallbackViewCreator, (String)"reflectiveFallbackViewCreator");
            this.reflectiveFallbackViewCreator = fallbackViewCreator;
            return this;
        }

        public final Builder setStoreLayoutResId(boolean bl) {
            this.storeLayoutResId = bl;
            return this;
        }
    }

    @SourceDebugExtension(value="SMAP\nViewPump.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ViewPump.kt\nio/github/inflationx/viewpump/ViewPump$Companion\n*L\n1#1,196:1\n*E\n")
    @Metadata(bv={1, 0, 3}, d1={"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u000b\u001a\u00020\fH\u0007J\"\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u000e\u0010\u0011\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000e0\u0012H\u0007J\b\u0010\u0013\u001a\u00020\u0004H\u0007J\u0012\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0004H\u0007R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001b\u0010\u0005\u001a\u00020\u00068BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\b\u00a8\u0006\u0017"}, d2={"Lio/github/inflationx/viewpump/ViewPump$Companion;", "", "()V", "INSTANCE", "Lio/github/inflationx/viewpump/ViewPump;", "reflectiveFallbackViewCreator", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "getReflectiveFallbackViewCreator", "()Lio/github/inflationx/viewpump/FallbackViewCreator;", "reflectiveFallbackViewCreator$delegate", "Lkotlin/Lazy;", "builder", "Lio/github/inflationx/viewpump/ViewPump$Builder;", "create", "Landroid/view/View;", "context", "Landroid/content/Context;", "clazz", "Ljava/lang/Class;", "get", "init", "", "viewPump", "viewpump_release"}, k=1, mv={1, 1, 13})
    public static final class Companion {
        static final /* synthetic */ KProperty[] $$delegatedProperties;

        static {
            KProperty[] arrkProperty = new KProperty[]{(KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl((KDeclarationContainer)Reflection.getOrCreateKotlinClass(Companion.class), "reflectiveFallbackViewCreator", "getReflectiveFallbackViewCreator()Lio/github/inflationx/viewpump/FallbackViewCreator;"))};
            $$delegatedProperties = arrkProperty;
        }

        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private final FallbackViewCreator getReflectiveFallbackViewCreator() {
            Lazy lazy = reflectiveFallbackViewCreator$delegate;
            $$delegatedProperties[0];
            return (FallbackViewCreator)lazy.getValue();
        }

        @JvmStatic
        public final Builder builder() {
            return new Builder();
        }

        @JvmStatic
        public final View create(Context context, Class<? extends View> class_) {
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            Intrinsics.checkParameterIsNotNull(class_, (String)"clazz");
            ViewPump viewPump = this.get();
            String string2 = class_.getName();
            Intrinsics.checkExpressionValueIsNotNull((Object)string2, (String)"clazz.name");
            InflateRequest inflateRequest = new InflateRequest(string2, context, null, null, this.getReflectiveFallbackViewCreator(), 12, null);
            return viewPump.inflate(inflateRequest).view();
        }

        @JvmStatic
        public final ViewPump get() {
            ViewPump viewPump = INSTANCE;
            if (viewPump != null) {
                return viewPump;
            }
            ViewPump viewPump2 = this.builder().build();
            ViewPump.access$setINSTANCE$cp(viewPump2);
            return viewPump2;
        }

        @JvmStatic
        public final void init(ViewPump viewPump) {
            ViewPump.access$setINSTANCE$cp(viewPump);
        }
    }

}

