/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.InstantiationException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.InvocationTargetException
 *  java.util.Arrays
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package io.github.inflationx.viewpump.internal;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import io.github.inflationx.viewpump.FallbackViewCreator;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u0000 \f2\u00020\u0001:\u0001\fB\u0005\u00a2\u0006\u0002\u0010\u0002J.\u0010\u0003\u001a\u0004\u0018\u00010\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0016\u00a8\u0006\r"}, d2={"Lio/github/inflationx/viewpump/internal/-ReflectiveFallbackViewCreator;", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "()V", "onCreateView", "Landroid/view/View;", "parent", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "Companion", "viewpump_release"}, k=1, mv={1, 1, 13})
public final class -ReflectiveFallbackViewCreator
implements FallbackViewCreator {
    private static final Class<? extends Object>[] CONSTRUCTOR_SIGNATURE_1;
    private static final Class<? extends Object>[] CONSTRUCTOR_SIGNATURE_2;
    public static final Companion Companion;

    static {
        Companion = new Object(null){
            {
                this();
            }
        };
        CONSTRUCTOR_SIGNATURE_1 = new Class[]{Context.class};
        CONSTRUCTOR_SIGNATURE_2 = new Class[]{Context.class, AttributeSet.class};
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public View onCreateView(View view, String string2, Context context, AttributeSet attributeSet) {
        Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        try {
            Object[] arrobject;
            Constructor constructor;
            Class class_ = Class.forName((String)string2).asSubclass(View.class);
            try {
                Object[] arrobject2 = CONSTRUCTOR_SIGNATURE_2;
                Constructor constructor2 = class_.getConstructor((Class[])Arrays.copyOf((Object[])arrobject2, (int)arrobject2.length));
                Intrinsics.checkExpressionValueIsNotNull((Object)constructor2, (String)"clazz.getConstructor(*CONSTRUCTOR_SIGNATURE_2)");
                constructor = constructor2;
                Object[] arrobject3 = new Object[]{context, attributeSet};
                arrobject = arrobject3;
            }
            catch (NoSuchMethodException noSuchMethodException) {
                Object[] arrobject4 = CONSTRUCTOR_SIGNATURE_1;
                Constructor constructor3 = class_.getConstructor((Class[])Arrays.copyOf((Object[])arrobject4, (int)arrobject4.length));
                Intrinsics.checkExpressionValueIsNotNull((Object)constructor3, (String)"clazz.getConstructor(*CONSTRUCTOR_SIGNATURE_1)");
                constructor = constructor3;
                arrobject = new Context[]{context};
            }
            constructor.setAccessible(true);
            return (View)constructor.newInstance(Arrays.copyOf((Object[])arrobject, (int)arrobject.length));
        }
        catch (Exception exception) {
            if (exception instanceof ClassNotFoundException) {
                exception.printStackTrace();
                return null;
            }
            if (exception instanceof NoSuchMethodException) {
                exception.printStackTrace();
                return null;
            }
            if (exception instanceof IllegalAccessException) {
                exception.printStackTrace();
                return null;
            }
            if (exception instanceof InstantiationException) {
                exception.printStackTrace();
                return null;
            }
            if (!(exception instanceof InvocationTargetException)) throw (Throwable)exception;
            exception.printStackTrace();
            return null;
        }
    }

}

