/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  dalvik.annotation.SourceDebugExtension
 *  io.github.inflationx.viewpump.Interceptor$Companion$invoke
 *  io.github.inflationx.viewpump.Interceptor$Companion$invoke$1
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package io.github.inflationx.viewpump;

import dalvik.annotation.SourceDebugExtension;
import io.github.inflationx.viewpump.InflateResult;
import io.github.inflationx.viewpump.Interceptor;
import io.github.inflationx.viewpump.ViewPump;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@SourceDebugExtension(value="SMAP\nViewPump.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ViewPump.kt\nio/github/inflationx/viewpump/ViewPumpKt\n+ 2 Interceptor.kt\nio/github/inflationx/viewpump/Interceptor$Companion\n*L\n1#1,196:1\n17#2,3:197\n*E\n*S KotlinDebug\n*F\n+ 1 ViewPump.kt\nio/github/inflationx/viewpump/ViewPumpKt\n*L\n193#1,3:197\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u001a2\u0010\u0000\u001a\u00020\u0001*\u00020\u00012#\b\u0004\u0010\u0002\u001a\u001d\u0012\u0013\u0012\u00110\u0004\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0003H\u0086\b\u00a8\u0006\t"}, d2={"addInterceptor", "Lio/github/inflationx/viewpump/ViewPump$Builder;", "block", "Lkotlin/Function1;", "Lio/github/inflationx/viewpump/Interceptor$Chain;", "Lkotlin/ParameterName;", "name", "chain", "Lio/github/inflationx/viewpump/InflateResult;", "viewpump_release"}, k=2, mv={1, 1, 13})
public final class ViewPumpKt {
    public static final ViewPump.Builder addInterceptor(ViewPump.Builder builder, Function1<? super Interceptor.Chain, InflateResult> function1) {
        Intrinsics.checkParameterIsNotNull((Object)builder, (String)"receiver$0");
        Intrinsics.checkParameterIsNotNull(function1, (String)"block");
        builder.addInterceptor((Interceptor)new Interceptor.Companion.invoke.1(function1));
        return builder;
    }
}

