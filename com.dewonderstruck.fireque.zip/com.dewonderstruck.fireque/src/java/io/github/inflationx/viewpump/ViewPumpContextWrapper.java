/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.ContextWrapper
 *  android.util.AttributeSet
 *  android.view.LayoutInflater
 *  android.view.View
 *  dalvik.annotation.SourceDebugExtension
 *  io.github.inflationx.viewpump.ViewPumpContextWrapper$inflater
 *  io.github.inflationx.viewpump.ViewPumpContextWrapper$inflater$2
 *  io.github.inflationx.viewpump.internal.-ViewPumpLayoutInflater
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  kotlin.Lazy
 *  kotlin.LazyKt
 *  kotlin.LazyThreadSafetyMode
 *  kotlin.Metadata
 *  kotlin.TypeCastException
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.PropertyReference1
 *  kotlin.jvm.internal.PropertyReference1Impl
 *  kotlin.jvm.internal.Reflection
 *  kotlin.reflect.KDeclarationContainer
 *  kotlin.reflect.KProperty
 */
package io.github.inflationx.viewpump;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import dalvik.annotation.SourceDebugExtension;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import io.github.inflationx.viewpump.internal.-ViewPumpActivityFactory;
import io.github.inflationx.viewpump.internal.-ViewPumpLayoutInflater;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.PropertyReference1;
import kotlin.jvm.internal.PropertyReference1Impl;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KDeclarationContainer;
import kotlin.reflect.KProperty;

@SourceDebugExtension(value="SMAP\nViewPumpContextWrapper.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ViewPumpContextWrapper.kt\nio/github/inflationx/viewpump/ViewPumpContextWrapper\n*L\n1#1,104:1\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u0000 \u000f2\u00020\u0001:\u0001\u000fB\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0012\u0010\u000b\u001a\u0004\u0018\u00010\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016R\u001b\u0010\u0005\u001a\u00020\u00068BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\b\u00a8\u0006\u0010"}, d2={"Lio/github/inflationx/viewpump/ViewPumpContextWrapper;", "Landroid/content/ContextWrapper;", "base", "Landroid/content/Context;", "(Landroid/content/Context;)V", "inflater", "Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;", "getInflater", "()Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;", "inflater$delegate", "Lkotlin/Lazy;", "getSystemService", "", "name", "", "Companion", "viewpump_release"}, k=1, mv={1, 1, 13})
public final class ViewPumpContextWrapper
extends ContextWrapper {
    static final /* synthetic */ KProperty[] $$delegatedProperties;
    public static final Companion Companion;
    private final Lazy inflater$delegate = LazyKt.lazy((LazyThreadSafetyMode)LazyThreadSafetyMode.NONE, (Function0)((Function0)new inflater.2(this)));

    static {
        KProperty[] arrkProperty = new KProperty[]{(KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl((KDeclarationContainer)Reflection.getOrCreateKotlinClass(ViewPumpContextWrapper.class), "inflater", "getInflater()Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;"))};
        $$delegatedProperties = arrkProperty;
        Companion = new Companion(null);
    }

    private ViewPumpContextWrapper(Context context) {
        super(context);
    }

    public /* synthetic */ ViewPumpContextWrapper(Context context, DefaultConstructorMarker defaultConstructorMarker) {
        this(context);
    }

    @JvmStatic
    public static final -ViewPumpActivityFactory get$viewpump_release(Activity activity) {
        return Companion.get$viewpump_release(activity);
    }

    private final -ViewPumpLayoutInflater getInflater() {
        Lazy lazy = this.inflater$delegate;
        $$delegatedProperties[0];
        return (-ViewPumpLayoutInflater)lazy.getValue();
    }

    @JvmStatic
    public static final View onActivityCreateView(Activity activity, View view, View view2, String string2, Context context, AttributeSet attributeSet) {
        return Companion.onActivityCreateView(activity, view, view2, string2, context, attributeSet);
    }

    @JvmStatic
    public static final ContextWrapper wrap(Context context) {
        return Companion.wrap(context);
    }

    public Object getSystemService(String string2) {
        Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
        if (Intrinsics.areEqual((Object)"layout_inflater", (Object)string2)) {
            return this.getInflater();
        }
        return super.getSystemService(string2);
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0015\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0001\u00a2\u0006\u0002\b\u0007J>\u0010\b\u001a\u0004\u0018\u00010\t2\u0006\u0010\u0005\u001a\u00020\u00062\b\u0010\n\u001a\u0004\u0018\u00010\t2\u0006\u0010\u000b\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0007J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u000fH\u0007\u00a8\u0006\u0015"}, d2={"Lio/github/inflationx/viewpump/ViewPumpContextWrapper$Companion;", "", "()V", "get", "Lio/github/inflationx/viewpump/internal/-ViewPumpActivityFactory;", "activity", "Landroid/app/Activity;", "get$viewpump_release", "onActivityCreateView", "Landroid/view/View;", "parent", "view", "name", "", "context", "Landroid/content/Context;", "attr", "Landroid/util/AttributeSet;", "wrap", "Landroid/content/ContextWrapper;", "base", "viewpump_release"}, k=1, mv={1, 1, 13})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @JvmStatic
        public final -ViewPumpActivityFactory get$viewpump_release(Activity activity) {
            Intrinsics.checkParameterIsNotNull((Object)activity, (String)"activity");
            if (activity.getLayoutInflater() instanceof -ViewPumpLayoutInflater) {
                LayoutInflater layoutInflater = activity.getLayoutInflater();
                if (layoutInflater != null) {
                    return (-ViewPumpActivityFactory)layoutInflater;
                }
                throw new TypeCastException("null cannot be cast to non-null type io.github.inflationx.viewpump.internal.`-ViewPumpActivityFactory`");
            }
            throw (Throwable)new RuntimeException("This activity does not wrap the Base Context! See ViewPumpContextWrapper.wrap(Context)");
        }

        @JvmStatic
        public final View onActivityCreateView(Activity activity, View view, View view2, String string2, Context context, AttributeSet attributeSet) {
            Intrinsics.checkParameterIsNotNull((Object)activity, (String)"activity");
            Intrinsics.checkParameterIsNotNull((Object)view2, (String)"view");
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            return this.get$viewpump_release(activity).onActivityCreateView(view, view2, string2, context, attributeSet);
        }

        @JvmStatic
        public final ContextWrapper wrap(Context context) {
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"base");
            return new ViewPumpContextWrapper(context, null);
        }
    }

}

