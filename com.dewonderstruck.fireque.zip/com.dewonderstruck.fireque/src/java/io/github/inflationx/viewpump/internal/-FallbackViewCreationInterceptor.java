/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package io.github.inflationx.viewpump.internal;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import io.github.inflationx.viewpump.FallbackViewCreator;
import io.github.inflationx.viewpump.InflateRequest;
import io.github.inflationx.viewpump.InflateResult;
import io.github.inflationx.viewpump.Interceptor;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016\u00a8\u0006\u0007"}, d2={"Lio/github/inflationx/viewpump/internal/-FallbackViewCreationInterceptor;", "Lio/github/inflationx/viewpump/Interceptor;", "()V", "intercept", "Lio/github/inflationx/viewpump/InflateResult;", "chain", "Lio/github/inflationx/viewpump/Interceptor$Chain;", "viewpump_release"}, k=1, mv={1, 1, 13})
public final class -FallbackViewCreationInterceptor
implements Interceptor {
    @Override
    public InflateResult intercept(Interceptor.Chain chain) {
        String string2;
        Class class_;
        Intrinsics.checkParameterIsNotNull((Object)chain, (String)"chain");
        InflateRequest inflateRequest = chain.request();
        View view = inflateRequest.fallbackViewCreator().onCreateView(inflateRequest.parent(), inflateRequest.name(), inflateRequest.context(), inflateRequest.attrs());
        if (view == null || (class_ = view.getClass()) == null || (string2 = class_.getName()) == null) {
            string2 = inflateRequest.name();
        }
        return new InflateResult(view, string2, inflateRequest.context(), inflateRequest.attrs());
    }
}

