/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  dalvik.annotation.SourceDebugExtension
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  kotlin.Metadata
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package io.github.inflationx.viewpump;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import dalvik.annotation.SourceDebugExtension;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\b\u0018\u0000 \u001d2\u00020\u0001:\u0002\u001c\u001dB-\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\t\u00a2\u0006\u0002\u0010\nJ\u000b\u0010\u000f\u001a\u0004\u0018\u00010\u0003H\u00c6\u0003J\t\u0010\u0010\u001a\u00020\u0005H\u00c6\u0003J\t\u0010\u0011\u001a\u00020\u0007H\u00c6\u0003J\u000b\u0010\u0012\u001a\u0004\u0018\u00010\tH\u00c6\u0003J5\u0010\u0013\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\tH\u00c6\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0017\u001a\u00020\u0018H\u00d6\u0001J\u0006\u0010\u0019\u001a\u00020\u001aJ\t\u0010\u001b\u001a\u00020\u0005H\u00d6\u0001R\u0015\u0010\b\u001a\u0004\u0018\u00010\t8\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u000bR\u0013\u0010\u0006\u001a\u00020\u00078\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\fR\u0013\u0010\u0004\u001a\u00020\u00058\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\rR\u0015\u0010\u0002\u001a\u0004\u0018\u00010\u00038\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u000e\u00a8\u0006\u001e"}, d2={"Lio/github/inflationx/viewpump/InflateResult;", "", "view", "Landroid/view/View;", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)V", "()Landroid/util/AttributeSet;", "()Landroid/content/Context;", "()Ljava/lang/String;", "()Landroid/view/View;", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toBuilder", "Lio/github/inflationx/viewpump/InflateResult$Builder;", "toString", "Builder", "Companion", "viewpump_release"}, k=1, mv={1, 1, 13})
public final class InflateResult {
    public static final Companion Companion = new Companion(null);
    private final AttributeSet attrs;
    private final Context context;
    private final String name;
    private final View view;

    public InflateResult(View view, String string2, Context context, AttributeSet attributeSet) {
        Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        this.view = view;
        this.name = string2;
        this.context = context;
        this.attrs = attributeSet;
    }

    public /* synthetic */ InflateResult(View view, String string2, Context context, AttributeSet attributeSet, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 1) != 0) {
            view = null;
        }
        if ((n & 8) != 0) {
            attributeSet = null;
        }
        this(view, string2, context, attributeSet);
    }

    @JvmStatic
    public static final Builder builder() {
        return Companion.builder();
    }

    public static /* synthetic */ InflateResult copy$default(InflateResult inflateResult, View view, String string2, Context context, AttributeSet attributeSet, int n, Object object) {
        if ((n & 1) != 0) {
            view = inflateResult.view;
        }
        if ((n & 2) != 0) {
            string2 = inflateResult.name;
        }
        if ((n & 4) != 0) {
            context = inflateResult.context;
        }
        if ((n & 8) != 0) {
            attributeSet = inflateResult.attrs;
        }
        return inflateResult.copy(view, string2, context, attributeSet);
    }

    public final AttributeSet attrs() {
        return this.attrs;
    }

    public final View component1() {
        return this.view;
    }

    public final String component2() {
        return this.name;
    }

    public final Context component3() {
        return this.context;
    }

    public final AttributeSet component4() {
        return this.attrs;
    }

    public final Context context() {
        return this.context;
    }

    public final InflateResult copy(View view, String string2, Context context, AttributeSet attributeSet) {
        Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        return new InflateResult(view, string2, context, attributeSet);
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof InflateResult)) break block3;
                InflateResult inflateResult = (InflateResult)object;
                if (Intrinsics.areEqual((Object)this.view, (Object)inflateResult.view) && Intrinsics.areEqual((Object)this.name, (Object)inflateResult.name) && Intrinsics.areEqual((Object)this.context, (Object)inflateResult.context) && Intrinsics.areEqual((Object)this.attrs, (Object)inflateResult.attrs)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        View view = this.view;
        int n = view != null ? view.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.name;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        Context context = this.context;
        int n5 = context != null ? context.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        AttributeSet attributeSet = this.attrs;
        int n7 = 0;
        if (attributeSet != null) {
            n7 = attributeSet.hashCode();
        }
        return n6 + n7;
    }

    public final String name() {
        return this.name;
    }

    public final Builder toBuilder() {
        return new Builder(this);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("InflateResult(view=");
        stringBuilder.append((Object)this.view);
        stringBuilder.append(", name=");
        stringBuilder.append(this.name);
        stringBuilder.append(", context=");
        stringBuilder.append((Object)this.context);
        stringBuilder.append(", attrs=");
        stringBuilder.append((Object)this.attrs);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public final View view() {
        return this.view;
    }

    @SourceDebugExtension(value="SMAP\nInflateResult.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InflateResult.kt\nio/github/inflationx/viewpump/InflateResult$Builder\n*L\n1#1,76:1\n*E\n")
    @Metadata(bv={1, 0, 3}, d1={"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0010\u00a2\u0006\u0002\u0010\u0002B\u000f\b\u0010\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0002\u0010\u0005J\u0010\u0010\u0006\u001a\u00020\u00002\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007J\u0006\u0010\u000e\u001a\u00020\u0004J\u000e\u0010\b\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\n\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000bJ\u0010\u0010\f\u001a\u00020\u00002\b\u0010\f\u001a\u0004\u0018\u00010\rR\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000f"}, d2={"Lio/github/inflationx/viewpump/InflateResult$Builder;", "", "()V", "result", "Lio/github/inflationx/viewpump/InflateResult;", "(Lio/github/inflationx/viewpump/InflateResult;)V", "attrs", "Landroid/util/AttributeSet;", "context", "Landroid/content/Context;", "name", "", "view", "Landroid/view/View;", "build", "viewpump_release"}, k=1, mv={1, 1, 13})
    public static final class Builder {
        private AttributeSet attrs;
        private Context context;
        private String name;
        private View view;

        public Builder() {
        }

        public Builder(InflateResult inflateResult) {
            Intrinsics.checkParameterIsNotNull((Object)inflateResult, (String)"result");
            this.view = inflateResult.view();
            this.name = inflateResult.name();
            this.context = inflateResult.context();
            this.attrs = inflateResult.attrs();
        }

        public final Builder attrs(AttributeSet attributeSet) {
            this.attrs = attributeSet;
            return this;
        }

        public final InflateResult build() {
            String string2 = this.name;
            if (string2 != null) {
                View view = this.view;
                if (view != null) {
                    View view2 = view;
                    if (!Intrinsics.areEqual((Object)string2, (Object)view2.getClass().getName())) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("name (");
                        stringBuilder.append(string2);
                        stringBuilder.append(") must be the view's fully qualified name (");
                        stringBuilder.append(view2.getClass().getName());
                        stringBuilder.append(')');
                        throw (Throwable)new IllegalStateException(stringBuilder.toString().toString());
                    }
                } else {
                    view = null;
                }
                Context context = this.context;
                if (context != null) {
                    return new InflateResult(view, string2, context, this.attrs);
                }
                throw (Throwable)new IllegalStateException("context == null");
            }
            throw (Throwable)new IllegalStateException("name == null".toString());
        }

        public final Builder context(Context context) {
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            this.context = context;
            return this;
        }

        public final Builder name(String string2) {
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            this.name = string2;
            return this;
        }

        public final Builder view(View view) {
            this.view = view;
            return this;
        }
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007\u00a8\u0006\u0005"}, d2={"Lio/github/inflationx/viewpump/InflateResult$Companion;", "", "()V", "builder", "Lio/github/inflationx/viewpump/InflateResult$Builder;", "viewpump_release"}, k=1, mv={1, 1, 13})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @JvmStatic
        public final Builder builder() {
            return new Builder();
        }
    }

}

