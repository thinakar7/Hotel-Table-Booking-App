/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.AttributeSet
 *  android.view.LayoutInflater
 *  android.view.LayoutInflater$Factory
 *  android.view.LayoutInflater$Factory2
 *  android.view.View
 *  android.view.ViewGroup
 *  androidx.core.os.BuildCompat
 *  dalvik.annotation.SourceDebugExtension
 *  io.github.inflationx.viewpump.internal.-ViewPumpLayoutInflater$Companion$CONSTRUCTOR_ARGS_FIELD
 *  java.lang.CharSequence
 *  java.lang.ClassNotFoundException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  java.util.Set
 *  kotlin.Lazy
 *  kotlin.LazyKt
 *  kotlin.Metadata
 *  kotlin.TypeCastException
 *  kotlin.collections.SetsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.PropertyReference1
 *  kotlin.jvm.internal.PropertyReference1Impl
 *  kotlin.jvm.internal.Reflection
 *  kotlin.reflect.KDeclarationContainer
 *  kotlin.reflect.KProperty
 *  kotlin.text.StringsKt
 *  org.xmlpull.v1.XmlPullParser
 */
package io.github.inflationx.viewpump.internal;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.os.BuildCompat;
import dalvik.annotation.SourceDebugExtension;
import io.github.inflationx.viewpump.FallbackViewCreator;
import io.github.inflationx.viewpump.InflateRequest;
import io.github.inflationx.viewpump.InflateResult;
import io.github.inflationx.viewpump.R;
import io.github.inflationx.viewpump.ViewPump;
import io.github.inflationx.viewpump.internal.-ReflectionUtils;
import io.github.inflationx.viewpump.internal.-ViewPumpActivityFactory;
import io.github.inflationx.viewpump.internal.-ViewPumpLayoutInflater;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.PropertyReference1;
import kotlin.jvm.internal.PropertyReference1Impl;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KDeclarationContainer;
import kotlin.reflect.KProperty;
import kotlin.text.StringsKt;
import org.xmlpull.v1.XmlPullParser;

@Metadata(bv={1, 0, 3}, d1={"\u0000j\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000e\b\u0000\u0018\u0000 /2\u00020\u00012\u00020\u0002:\n./01234567B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0001\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bJ\u0010\u0010\u000f\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J.\u0010\u0010\u001a\u0004\u0018\u00010\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00052\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0002J$\u0010\u0018\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001c2\u0006\u0010\u001d\u001a\u00020\u0007H\u0016J\"\u0010\u0018\u001a\u00020\u00112\u0006\u0010\u001e\u001a\u00020\u001f2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001c2\u0006\u0010\u001d\u001a\u00020\u0007H\u0016J6\u0010 \u001a\u0004\u0018\u00010\u00112\b\u0010!\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\"\u001a\u00020\u00052\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0016J&\u0010#\u001a\u0004\u0018\u00010\u00112\b\u0010!\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0013\u001a\u00020\u00142\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0014J\u001c\u0010#\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0013\u001a\u00020\u00142\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0014J\u0010\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020'H\u0016J\u0010\u0010(\u001a\u00020%2\u0006\u0010)\u001a\u00020*H\u0016J\b\u0010+\u001a\u00020%H\u0002J\u0010\u0010,\u001a\u00020%2\u0006\u0010\u0006\u001a\u00020\u0007H\u0002J&\u0010-\u001a\u0004\u0018\u00010\u00112\b\u0010!\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0013\u001a\u00020\u00142\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0002J\u001c\u0010-\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0013\u001a\u00020\u00142\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0002R\u000e\u0010\t\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00068"}, d2={"Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;", "Landroid/view/LayoutInflater;", "Lio/github/inflationx/viewpump/internal/-ViewPumpActivityFactory;", "original", "newContext", "Landroid/content/Context;", "cloned", "", "(Landroid/view/LayoutInflater;Landroid/content/Context;Z)V", "IS_AT_LEAST_Q", "nameAndAttrsViewCreator", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "parentAndNameAndAttrsViewCreator", "setPrivateFactory", "storeLayoutResId", "cloneInContext", "createCustomViewInternal", "Landroid/view/View;", "view", "name", "", "viewContext", "attrs", "Landroid/util/AttributeSet;", "inflate", "resource", "", "root", "Landroid/view/ViewGroup;", "attachToRoot", "parser", "Lorg/xmlpull/v1/XmlPullParser;", "onActivityCreateView", "parent", "context", "onCreateView", "setFactory", "", "factory", "Landroid/view/LayoutInflater$Factory;", "setFactory2", "factory2", "Landroid/view/LayoutInflater$Factory2;", "setPrivateFactoryInternal", "setUpLayoutFactories", "superOnCreateView", "ActivityViewCreator", "Companion", "NameAndAttrsViewCreator", "ParentAndNameAndAttrsViewCreator", "PrivateWrapperFactory2", "PrivateWrapperFactory2ViewCreator", "WrapperFactory", "WrapperFactory2", "WrapperFactory2ViewCreator", "WrapperFactoryViewCreator", "viewpump_release"}, k=1, mv={1, 1, 13})
public final class -ViewPumpLayoutInflater
extends LayoutInflater
implements -ViewPumpActivityFactory {
    private static final Set<String> CLASS_PREFIX_LIST;
    private static final Lazy CONSTRUCTOR_ARGS_FIELD$delegate;
    public static final Companion Companion;
    private final boolean IS_AT_LEAST_Q;
    private final FallbackViewCreator nameAndAttrsViewCreator;
    private final FallbackViewCreator parentAndNameAndAttrsViewCreator;
    private boolean setPrivateFactory;
    private boolean storeLayoutResId;

    static {
        Companion = new Object(null){
            static final /* synthetic */ KProperty[] $$delegatedProperties;

            static {
                KProperty[] arrkProperty = new KProperty[]{(KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl((KDeclarationContainer)Reflection.getOrCreateKotlinClass(Companion.class), "CONSTRUCTOR_ARGS_FIELD", "getCONSTRUCTOR_ARGS_FIELD()Ljava/lang/reflect/Field;"))};
                $$delegatedProperties = arrkProperty;
            }
            {
                this();
            }

            private final Field getCONSTRUCTOR_ARGS_FIELD() {
                Lazy lazy = CONSTRUCTOR_ARGS_FIELD$delegate;
                $$delegatedProperties[0];
                return (Field)lazy.getValue();
            }
        };
        CLASS_PREFIX_LIST = SetsKt.setOf((Object[])new String[]{"android.widget.", "android.webkit."});
        CONSTRUCTOR_ARGS_FIELD$delegate = LazyKt.lazy((Function0)CONSTRUCTOR_ARGS_FIELD.2.INSTANCE);
    }

    public -ViewPumpLayoutInflater(LayoutInflater layoutInflater, Context context, boolean bl) {
        Intrinsics.checkParameterIsNotNull((Object)layoutInflater, (String)"original");
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"newContext");
        super(layoutInflater, context);
        boolean bl2 = Build.VERSION.SDK_INT > 28 || BuildCompat.isAtLeastQ();
        this.IS_AT_LEAST_Q = bl2;
        this.nameAndAttrsViewCreator = new NameAndAttrsViewCreator(this);
        this.parentAndNameAndAttrsViewCreator = new ParentAndNameAndAttrsViewCreator(this);
        this.storeLayoutResId = ViewPump.Companion.get().isStoreLayoutResId();
        this.setUpLayoutFactories(bl);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private final View createCustomViewInternal(View view, String string2, Context context, AttributeSet attributeSet) {
        View view2;
        block6 : {
            Object[] arrobject;
            Companion companion;
            view2 = view;
            if (!ViewPump.Companion.get().isCustomViewCreation()) {
                return view2;
            }
            if (view2 != null || StringsKt.indexOf$default((CharSequence)string2, (char)'.', (int)0, (boolean)false, (int)6, null) <= -1) break block6;
            if (this.IS_AT_LEAST_Q) {
                return this.cloneInContext(context).createView(string2, null, attributeSet);
            }
            companion = Companion;
            Object object = companion.getCONSTRUCTOR_ARGS_FIELD().get((Object)this);
            if (object == null) {
                throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<kotlin.Any>");
            }
            arrobject = (Object[])object;
            Object object2 = arrobject[0];
            arrobject[0] = context;
            -ReflectionUtils.setValueQuietly(companion.getCONSTRUCTOR_ARGS_FIELD(), this, arrobject);
            try {
                View view3;
                view2 = view3 = this.createView(string2, null, attributeSet);
            }
            catch (Throwable throwable) {
                arrobject[0] = object2;
                -ReflectionUtils.setValueQuietly(-ViewPumpLayoutInflater.Companion.getCONSTRUCTOR_ARGS_FIELD(), this, arrobject);
                throw throwable;
            }
            catch (ClassNotFoundException classNotFoundException) {
                arrobject[0] = object2;
                companion = Companion;
            }
            arrobject[0] = object2;
            -ReflectionUtils.setValueQuietly(companion.getCONSTRUCTOR_ARGS_FIELD(), this, arrobject);
            return view2;
        }
        return view2;
    }

    private final void setPrivateFactoryInternal() {
        if (this.setPrivateFactory) {
            return;
        }
        if (!ViewPump.Companion.get().isReflection()) {
            return;
        }
        if (!(this.getContext() instanceof LayoutInflater.Factory2)) {
            this.setPrivateFactory = true;
            return;
        }
        Method method = -ReflectionUtils.getAccessibleMethod(LayoutInflater.class, "setPrivateFactory");
        Object[] arrobject = new Object[1];
        Context context = this.getContext();
        if (context != null) {
            arrobject[0] = new PrivateWrapperFactory2((LayoutInflater.Factory2)context, this);
            -ReflectionUtils.invokeMethod(method, this, arrobject);
            this.setPrivateFactory = true;
            return;
        }
        throw new TypeCastException("null cannot be cast to non-null type android.view.LayoutInflater.Factory2");
    }

    private final void setUpLayoutFactories(boolean bl) {
        if (bl) {
            return;
        }
        if (this.getFactory2() != null && !(this.getFactory2() instanceof WrapperFactory2)) {
            this.setFactory2(this.getFactory2());
        }
        if (this.getFactory() != null && !(this.getFactory() instanceof WrapperFactory)) {
            this.setFactory(this.getFactory());
        }
    }

    private final View superOnCreateView(View view, String string2, AttributeSet attributeSet) {
        try {
            View view2 = super.onCreateView(view, string2, attributeSet);
            return view2;
        }
        catch (ClassNotFoundException classNotFoundException) {
            return null;
        }
    }

    private final View superOnCreateView(String string2, AttributeSet attributeSet) {
        try {
            View view = super.onCreateView(string2, attributeSet);
            return view;
        }
        catch (ClassNotFoundException classNotFoundException) {
            return null;
        }
    }

    public LayoutInflater cloneInContext(Context context) {
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"newContext");
        return new -ViewPumpLayoutInflater(this, context, true);
    }

    public View inflate(int n, ViewGroup viewGroup, boolean bl) {
        View view = super.inflate(n, viewGroup, bl);
        if (view != null && this.storeLayoutResId) {
            view.setTag(R.id.viewpump_layout_res, (Object)n);
        }
        return view;
    }

    public View inflate(XmlPullParser xmlPullParser, ViewGroup viewGroup, boolean bl) {
        Intrinsics.checkParameterIsNotNull((Object)xmlPullParser, (String)"parser");
        this.setPrivateFactoryInternal();
        View view = super.inflate(xmlPullParser, viewGroup, bl);
        Intrinsics.checkExpressionValueIsNotNull((Object)view, (String)"super.inflate(parser, root, attachToRoot)");
        return view;
    }

    @Override
    public View onActivityCreateView(View view, View view2, String string2, Context context, AttributeSet attributeSet) {
        Intrinsics.checkParameterIsNotNull((Object)view2, (String)"view");
        Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        ViewPump viewPump = ViewPump.Companion.get();
        InflateRequest inflateRequest = new InflateRequest(string2, context, attributeSet, view, new ActivityViewCreator(this, view2));
        return viewPump.inflate(inflateRequest).view();
    }

    protected View onCreateView(View view, String string2, AttributeSet attributeSet) throws ClassNotFoundException {
        Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
        ViewPump viewPump = ViewPump.Companion.get();
        Context context = this.getContext();
        Intrinsics.checkExpressionValueIsNotNull((Object)context, (String)"context");
        InflateRequest inflateRequest = new InflateRequest(string2, context, attributeSet, view, this.parentAndNameAndAttrsViewCreator);
        return viewPump.inflate(inflateRequest).view();
    }

    protected View onCreateView(String string2, AttributeSet attributeSet) throws ClassNotFoundException {
        Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
        ViewPump viewPump = ViewPump.Companion.get();
        Context context = this.getContext();
        Intrinsics.checkExpressionValueIsNotNull((Object)context, (String)"context");
        InflateRequest inflateRequest = new InflateRequest(string2, context, attributeSet, null, this.nameAndAttrsViewCreator, 8, null);
        return viewPump.inflate(inflateRequest).view();
    }

    public void setFactory(LayoutInflater.Factory factory) {
        Intrinsics.checkParameterIsNotNull((Object)factory, (String)"factory");
        if (!(factory instanceof WrapperFactory)) {
            super.setFactory(new LayoutInflater.Factory(factory){
                private final FallbackViewCreator viewCreator;
                {
                    Intrinsics.checkParameterIsNotNull((Object)factory, (String)"factory");
                    this.viewCreator = new WrapperFactoryViewCreator(factory);
                }

                public View onCreateView(String string2, Context context, AttributeSet attributeSet) {
                    Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
                    Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
                    ViewPump viewPump = ViewPump.Companion.get();
                    InflateRequest inflateRequest = new InflateRequest(string2, context, attributeSet, null, this.viewCreator, 8, null);
                    return viewPump.inflate(inflateRequest).view();
                }
            });
            return;
        }
        super.setFactory(factory);
    }

    public void setFactory2(LayoutInflater.Factory2 factory2) {
        Intrinsics.checkParameterIsNotNull((Object)factory2, (String)"factory2");
        if (!(factory2 instanceof WrapperFactory2)) {
            super.setFactory2(new LayoutInflater.Factory2(factory2){
                private final WrapperFactory2ViewCreator viewCreator;
                {
                    Intrinsics.checkParameterIsNotNull((Object)factory2, (String)"factory2");
                    this.viewCreator = new WrapperFactory2ViewCreator(factory2);
                }

                public View onCreateView(View view, String string2, Context context, AttributeSet attributeSet) {
                    Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
                    Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
                    ViewPump viewPump = ViewPump.Companion.get();
                    InflateRequest inflateRequest = new InflateRequest(string2, context, attributeSet, view, this.viewCreator);
                    return viewPump.inflate(inflateRequest).view();
                }

                public View onCreateView(String string2, Context context, AttributeSet attributeSet) {
                    Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
                    Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
                    return this.onCreateView(null, string2, context, attributeSet);
                }
            });
            return;
        }
        super.setFactory2(factory2);
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J.\u0010\u0007\u001a\u0004\u0018\u00010\u00052\b\u0010\b\u001a\u0004\u0018\u00010\u00052\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000f"}, d2={"Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$ActivityViewCreator;", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "inflater", "Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;", "view", "Landroid/view/View;", "(Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;Landroid/view/View;)V", "onCreateView", "parent", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "viewpump_release"}, k=1, mv={1, 1, 13})
    private static final class ActivityViewCreator
    implements FallbackViewCreator {
        private final -ViewPumpLayoutInflater inflater;
        private final View view;

        public ActivityViewCreator(-ViewPumpLayoutInflater -ViewPumpLayoutInflater2, View view) {
            Intrinsics.checkParameterIsNotNull((Object)-ViewPumpLayoutInflater2, (String)"inflater");
            Intrinsics.checkParameterIsNotNull((Object)view, (String)"view");
            this.inflater = -ViewPumpLayoutInflater2;
            this.view = view;
        }

        @Override
        public View onCreateView(View view, String string2, Context context, AttributeSet attributeSet) {
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            return this.inflater.createCustomViewInternal(this.view, string2, context, attributeSet);
        }
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J.\u0010\u0005\u001a\u0004\u0018\u00010\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\u00062\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000e"}, d2={"Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$NameAndAttrsViewCreator;", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "inflater", "Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;", "(Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;)V", "onCreateView", "Landroid/view/View;", "parent", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "viewpump_release"}, k=1, mv={1, 1, 13})
    private static final class NameAndAttrsViewCreator
    implements FallbackViewCreator {
        private final -ViewPumpLayoutInflater inflater;

        public NameAndAttrsViewCreator(-ViewPumpLayoutInflater -ViewPumpLayoutInflater2) {
            Intrinsics.checkParameterIsNotNull((Object)-ViewPumpLayoutInflater2, (String)"inflater");
            this.inflater = -ViewPumpLayoutInflater2;
        }

        @Override
        public View onCreateView(View view, String string2, Context context, AttributeSet attributeSet) {
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            View view2 = null;
            for (String string3 : CLASS_PREFIX_LIST) {
                try {
                    View view3 = this.inflater.createView(string2, string3, attributeSet);
                    view2 = view3;
                    if (view2 == null) continue;
                    break;
                }
                catch (ClassNotFoundException classNotFoundException) {
                }
            }
            if (view2 == null) {
                view2 = this.inflater.superOnCreateView(string2, attributeSet);
            }
            return view2;
        }
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J.\u0010\u0005\u001a\u0004\u0018\u00010\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\u00062\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000e"}, d2={"Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$ParentAndNameAndAttrsViewCreator;", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "inflater", "Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;", "(Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;)V", "onCreateView", "Landroid/view/View;", "parent", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "viewpump_release"}, k=1, mv={1, 1, 13})
    private static final class ParentAndNameAndAttrsViewCreator
    implements FallbackViewCreator {
        private final -ViewPumpLayoutInflater inflater;

        public ParentAndNameAndAttrsViewCreator(-ViewPumpLayoutInflater -ViewPumpLayoutInflater2) {
            Intrinsics.checkParameterIsNotNull((Object)-ViewPumpLayoutInflater2, (String)"inflater");
            this.inflater = -ViewPumpLayoutInflater2;
        }

        @Override
        public View onCreateView(View view, String string2, Context context, AttributeSet attributeSet) {
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            return this.inflater.superOnCreateView(view, string2, attributeSet);
        }
    }

    @Metadata(bv={1, 0, 3}, d1={"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J.\u0010\t\u001a\u0004\u0018\u00010\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\n2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0012"}, d2={"Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$PrivateWrapperFactory2;", "Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$WrapperFactory2;", "factory2", "Landroid/view/LayoutInflater$Factory2;", "inflater", "Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;", "(Landroid/view/LayoutInflater$Factory2;Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;)V", "viewCreator", "Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$PrivateWrapperFactory2ViewCreator;", "onCreateView", "Landroid/view/View;", "parent", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "viewpump_release"}, k=1, mv={1, 1, 13})
    private static final class PrivateWrapperFactory2
    extends WrapperFactory2 {
        private final PrivateWrapperFactory2ViewCreator viewCreator;

        public PrivateWrapperFactory2(LayoutInflater.Factory2 factory2, -ViewPumpLayoutInflater -ViewPumpLayoutInflater2) {
            Intrinsics.checkParameterIsNotNull((Object)factory2, (String)"factory2");
            Intrinsics.checkParameterIsNotNull((Object)-ViewPumpLayoutInflater2, (String)"inflater");
            super(factory2);
            this.viewCreator = new PrivateWrapperFactory2ViewCreator(factory2, -ViewPumpLayoutInflater2);
        }

        @Override
        public View onCreateView(View view, String string2, Context context, AttributeSet attributeSet) {
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            ViewPump viewPump = ViewPump.Companion.get();
            InflateRequest inflateRequest = new InflateRequest(string2, context, attributeSet, view, this.viewCreator);
            return viewPump.inflate(inflateRequest).view();
        }
    }

    @Metadata(bv={1, 0, 3}, d1={"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u00012\u00020\u0002B\u0015\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007J.\u0010\b\u001a\u0004\u0018\u00010\t2\b\u0010\n\u001a\u0004\u0018\u00010\t2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0011"}, d2={"Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$PrivateWrapperFactory2ViewCreator;", "Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$WrapperFactory2ViewCreator;", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "factory2", "Landroid/view/LayoutInflater$Factory2;", "inflater", "Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;", "(Landroid/view/LayoutInflater$Factory2;Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater;)V", "onCreateView", "Landroid/view/View;", "parent", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "viewpump_release"}, k=1, mv={1, 1, 13})
    private static final class PrivateWrapperFactory2ViewCreator
    extends WrapperFactory2ViewCreator
    implements FallbackViewCreator {
        private final -ViewPumpLayoutInflater inflater;

        public PrivateWrapperFactory2ViewCreator(LayoutInflater.Factory2 factory2, -ViewPumpLayoutInflater -ViewPumpLayoutInflater2) {
            Intrinsics.checkParameterIsNotNull((Object)factory2, (String)"factory2");
            Intrinsics.checkParameterIsNotNull((Object)-ViewPumpLayoutInflater2, (String)"inflater");
            super(factory2);
            this.inflater = -ViewPumpLayoutInflater2;
        }

        @Override
        public View onCreateView(View view, String string2, Context context, AttributeSet attributeSet) {
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            return this.inflater.createCustomViewInternal(this.getFactory2().onCreateView(view, string2, context, attributeSet), string2, context, attributeSet);
        }
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0012\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J.\u0010\u0007\u001a\u0004\u0018\u00010\b2\b\u0010\t\u001a\u0004\u0018\u00010\b2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0016R\u0014\u0010\u0002\u001a\u00020\u0003X\u0084\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0010"}, d2={"Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$WrapperFactory2ViewCreator;", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "factory2", "Landroid/view/LayoutInflater$Factory2;", "(Landroid/view/LayoutInflater$Factory2;)V", "getFactory2", "()Landroid/view/LayoutInflater$Factory2;", "onCreateView", "Landroid/view/View;", "parent", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "viewpump_release"}, k=1, mv={1, 1, 13})
    private static class WrapperFactory2ViewCreator
    implements FallbackViewCreator {
        private final LayoutInflater.Factory2 factory2;

        public WrapperFactory2ViewCreator(LayoutInflater.Factory2 factory2) {
            Intrinsics.checkParameterIsNotNull((Object)factory2, (String)"factory2");
            this.factory2 = factory2;
        }

        protected final LayoutInflater.Factory2 getFactory2() {
            return this.factory2;
        }

        @Override
        public View onCreateView(View view, String string2, Context context, AttributeSet attributeSet) {
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            return this.factory2.onCreateView(view, string2, context, attributeSet);
        }
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J.\u0010\u0005\u001a\u0004\u0018\u00010\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\u00062\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000e"}, d2={"Lio/github/inflationx/viewpump/internal/-ViewPumpLayoutInflater$WrapperFactoryViewCreator;", "Lio/github/inflationx/viewpump/FallbackViewCreator;", "factory", "Landroid/view/LayoutInflater$Factory;", "(Landroid/view/LayoutInflater$Factory;)V", "onCreateView", "Landroid/view/View;", "parent", "name", "", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "viewpump_release"}, k=1, mv={1, 1, 13})
    private static final class WrapperFactoryViewCreator
    implements FallbackViewCreator {
        private final LayoutInflater.Factory factory;

        public WrapperFactoryViewCreator(LayoutInflater.Factory factory) {
            Intrinsics.checkParameterIsNotNull((Object)factory, (String)"factory");
            this.factory = factory;
        }

        @Override
        public View onCreateView(View view, String string2, Context context, AttributeSet attributeSet) {
            Intrinsics.checkParameterIsNotNull((Object)string2, (String)"name");
            Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
            return this.factory.onCreateView(string2, context, attributeSet);
        }
    }

}

