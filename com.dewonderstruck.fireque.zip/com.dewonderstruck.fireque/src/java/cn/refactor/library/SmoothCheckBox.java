/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Paint$Cap
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.Point
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.View$OnClickListener
 *  android.view.animation.LinearInterpolator
 *  android.widget.Checkable
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package cn.refactor.library;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Checkable;
import cn.refactor.library.CompatUtils;
import cn.refactor.library.R;

public class SmoothCheckBox
extends View
implements Checkable {
    private static final int COLOR_CHECKED = 0;
    private static final int COLOR_FLOOR_UNCHECKED = 0;
    private static final int COLOR_TICK = -1;
    private static final int COLOR_UNCHECKED = -1;
    private static final int DEF_ANIM_DURATION = 300;
    private static final int DEF_DRAW_SIZE = 25;
    private static final String KEY_INSTANCE_STATE = "InstanceState";
    private int mAnimDuration;
    private Point mCenterPoint;
    private boolean mChecked;
    private int mCheckedColor;
    private float mDrewDistance;
    private int mFloorColor;
    private Paint mFloorPaint;
    private float mFloorScale = 1.0f;
    private int mFloorUnCheckedColor;
    private float mLeftLineDistance;
    private OnCheckedChangeListener mListener;
    private Paint mPaint;
    private float mRightLineDistance;
    private float mScaleVal = 1.0f;
    private int mStrokeWidth;
    private boolean mTickDrawing;
    private Paint mTickPaint;
    private Path mTickPath;
    private Point[] mTickPoints;
    private int mUnCheckedColor;
    private int mWidth;

    static {
        COLOR_CHECKED = Color.parseColor((String)"#FB4846");
        COLOR_FLOOR_UNCHECKED = Color.parseColor((String)"#DFDFDF");
    }

    public SmoothCheckBox(Context context) {
        this(context, null);
    }

    public SmoothCheckBox(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SmoothCheckBox(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(attributeSet);
    }

    @TargetApi(value=21)
    public SmoothCheckBox(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.init(attributeSet);
    }

    private void drawBorder(Canvas canvas) {
        this.mFloorPaint.setColor(this.mFloorColor);
        int n = this.mCenterPoint.x;
        canvas.drawCircle((float)this.mCenterPoint.x, (float)this.mCenterPoint.y, (float)n * this.mFloorScale, this.mFloorPaint);
    }

    private void drawCenter(Canvas canvas) {
        this.mPaint.setColor(this.mUnCheckedColor);
        float f = (float)(this.mCenterPoint.x - this.mStrokeWidth) * this.mScaleVal;
        canvas.drawCircle((float)this.mCenterPoint.x, (float)this.mCenterPoint.y, f, this.mPaint);
    }

    private void drawTick(Canvas canvas) {
        if (this.mTickDrawing && this.isChecked()) {
            this.drawTickPath(canvas);
        }
    }

    private void drawTickDelayed() {
        this.postDelayed(new Runnable(){

            public void run() {
                SmoothCheckBox.this.mTickDrawing = true;
                SmoothCheckBox.this.postInvalidate();
            }
        }, (long)this.mAnimDuration);
    }

    private void drawTickPath(Canvas canvas) {
        this.mTickPath.reset();
        float f = this.mDrewDistance;
        float f2 = this.mLeftLineDistance;
        float f3 = 3.0f;
        if (f < f2) {
            int n = this.mWidth;
            if (!((float)n / 20.0f < f3)) {
                f3 = (float)n / 20.0f;
            }
            this.mDrewDistance = f + f3;
            float f4 = (float)this.mTickPoints[0].x + (float)(this.mTickPoints[1].x - this.mTickPoints[0].x) * this.mDrewDistance / this.mLeftLineDistance;
            float f5 = (float)this.mTickPoints[0].y + (float)(this.mTickPoints[1].y - this.mTickPoints[0].y) * this.mDrewDistance / this.mLeftLineDistance;
            this.mTickPath.moveTo((float)this.mTickPoints[0].x, (float)this.mTickPoints[0].y);
            this.mTickPath.lineTo(f4, f5);
            canvas.drawPath(this.mTickPath, this.mTickPaint);
            float f6 = this.mDrewDistance;
            float f7 = this.mLeftLineDistance;
            if (f6 > f7) {
                this.mDrewDistance = f7;
            }
        } else {
            this.mTickPath.moveTo((float)this.mTickPoints[0].x, (float)this.mTickPoints[0].y);
            this.mTickPath.lineTo((float)this.mTickPoints[1].x, (float)this.mTickPoints[1].y);
            canvas.drawPath(this.mTickPath, this.mTickPaint);
            if (this.mDrewDistance < this.mLeftLineDistance + this.mRightLineDistance) {
                float f8 = (float)this.mTickPoints[1].x + (float)(this.mTickPoints[2].x - this.mTickPoints[1].x) * (this.mDrewDistance - this.mLeftLineDistance) / this.mRightLineDistance;
                float f9 = (float)this.mTickPoints[1].y - (float)(this.mTickPoints[1].y - this.mTickPoints[2].y) * (this.mDrewDistance - this.mLeftLineDistance) / this.mRightLineDistance;
                this.mTickPath.reset();
                this.mTickPath.moveTo((float)this.mTickPoints[1].x, (float)this.mTickPoints[1].y);
                this.mTickPath.lineTo(f8, f9);
                canvas.drawPath(this.mTickPath, this.mTickPaint);
                int n = this.mWidth;
                if (n / 20 >= 3) {
                    f3 = n / 20;
                }
                this.mDrewDistance = f3 + this.mDrewDistance;
            } else {
                this.mTickPath.reset();
                this.mTickPath.moveTo((float)this.mTickPoints[1].x, (float)this.mTickPoints[1].y);
                this.mTickPath.lineTo((float)this.mTickPoints[2].x, (float)this.mTickPoints[2].y);
                canvas.drawPath(this.mTickPath, this.mTickPaint);
            }
        }
        if (this.mDrewDistance < this.mLeftLineDistance + this.mRightLineDistance) {
            this.postDelayed(new Runnable(){

                public void run() {
                    SmoothCheckBox.this.postInvalidate();
                }
            }, 10L);
        }
    }

    private static int getGradientColor(int n, int n2, float f) {
        int n3 = Color.alpha((int)n);
        int n4 = Color.red((int)n);
        int n5 = Color.green((int)n);
        int n6 = Color.blue((int)n);
        int n7 = Color.alpha((int)n2);
        int n8 = Color.red((int)n2);
        int n9 = Color.green((int)n2);
        int n10 = Color.blue((int)n2);
        return Color.argb((int)((int)((float)n3 * (1.0f - f) + f * (float)n7)), (int)((int)((float)n4 * (1.0f - f) + f * (float)n8)), (int)((int)((float)n5 * (1.0f - f) + f * (float)n9)), (int)((int)((float)n6 * (1.0f - f) + f * (float)n10)));
    }

    private void init(AttributeSet attributeSet) {
        Paint paint;
        Paint paint2;
        Paint paint3;
        TypedArray typedArray = this.getContext().obtainStyledAttributes(attributeSet, R.styleable.SmoothCheckBox);
        int n = typedArray.getColor(R.styleable.SmoothCheckBox_color_tick, -1);
        this.mAnimDuration = typedArray.getInt(R.styleable.SmoothCheckBox_duration, 300);
        this.mFloorColor = typedArray.getColor(R.styleable.SmoothCheckBox_color_unchecked_stroke, COLOR_FLOOR_UNCHECKED);
        this.mCheckedColor = typedArray.getColor(R.styleable.SmoothCheckBox_color_checked, COLOR_CHECKED);
        this.mUnCheckedColor = typedArray.getColor(R.styleable.SmoothCheckBox_color_unchecked, -1);
        this.mStrokeWidth = typedArray.getDimensionPixelSize(R.styleable.SmoothCheckBox_stroke_width, CompatUtils.dp2px(this.getContext(), 0.0f));
        typedArray.recycle();
        this.mFloorUnCheckedColor = this.mFloorColor;
        this.mTickPaint = paint2 = new Paint(1);
        paint2.setStyle(Paint.Style.STROKE);
        this.mTickPaint.setStrokeCap(Paint.Cap.ROUND);
        this.mTickPaint.setColor(n);
        this.mFloorPaint = paint = new Paint(1);
        paint.setStyle(Paint.Style.FILL);
        this.mFloorPaint.setColor(this.mFloorColor);
        this.mPaint = paint3 = new Paint(1);
        paint3.setStyle(Paint.Style.FILL);
        this.mPaint.setColor(this.mCheckedColor);
        this.mTickPath = new Path();
        this.mCenterPoint = new Point();
        Point[] arrpoint = new Point[3];
        this.mTickPoints = arrpoint;
        arrpoint[0] = new Point();
        this.mTickPoints[1] = new Point();
        this.mTickPoints[2] = new Point();
        this.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                SmoothCheckBox.this.toggle();
                SmoothCheckBox.this.mTickDrawing = false;
                SmoothCheckBox.this.mDrewDistance = 0.0f;
                if (SmoothCheckBox.this.isChecked()) {
                    SmoothCheckBox.this.startCheckedAnimation();
                    return;
                }
                SmoothCheckBox.this.startUnCheckedAnimation();
            }
        });
    }

    private int measureSize(int n) {
        int n2 = CompatUtils.dp2px(this.getContext(), 25.0f);
        int n3 = View.MeasureSpec.getSize((int)n);
        int n4 = View.MeasureSpec.getMode((int)n);
        if (n4 != Integer.MIN_VALUE && n4 != 0) {
            if (n4 != 1073741824) {
                return 0;
            }
            return n3;
        }
        return Math.min((int)n2, (int)n3);
    }

    private void reset() {
        float f;
        this.mTickDrawing = true;
        this.mFloorScale = f = 1.0f;
        if (this.isChecked()) {
            f = 0.0f;
        }
        this.mScaleVal = f;
        int n = this.isChecked() ? this.mCheckedColor : this.mFloorUnCheckedColor;
        this.mFloorColor = n;
        boolean bl = this.isChecked();
        float f2 = 0.0f;
        if (bl) {
            f2 = this.mLeftLineDistance + this.mRightLineDistance;
        }
        this.mDrewDistance = f2;
    }

    private void startCheckedAnimation() {
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.0f});
        valueAnimator.setDuration((long)(2 * (this.mAnimDuration / 3)));
        valueAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                SmoothCheckBox.this.mScaleVal = ((Float)valueAnimator.getAnimatedValue()).floatValue();
                SmoothCheckBox smoothCheckBox = SmoothCheckBox.this;
                smoothCheckBox.mFloorColor = SmoothCheckBox.getGradientColor(smoothCheckBox.mUnCheckedColor, SmoothCheckBox.this.mCheckedColor, 1.0f - SmoothCheckBox.this.mScaleVal);
                SmoothCheckBox.this.postInvalidate();
            }
        });
        valueAnimator.start();
        ValueAnimator valueAnimator2 = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.8f, 1.0f});
        valueAnimator2.setDuration((long)this.mAnimDuration);
        valueAnimator2.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator2.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                SmoothCheckBox.this.mFloorScale = ((Float)valueAnimator.getAnimatedValue()).floatValue();
                SmoothCheckBox.this.postInvalidate();
            }
        });
        valueAnimator2.start();
        this.drawTickDelayed();
    }

    private void startUnCheckedAnimation() {
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{0.0f, 1.0f});
        valueAnimator.setDuration((long)this.mAnimDuration);
        valueAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                SmoothCheckBox.this.mScaleVal = ((Float)valueAnimator.getAnimatedValue()).floatValue();
                SmoothCheckBox smoothCheckBox = SmoothCheckBox.this;
                smoothCheckBox.mFloorColor = SmoothCheckBox.getGradientColor(smoothCheckBox.mCheckedColor, SmoothCheckBox.this.mFloorUnCheckedColor, SmoothCheckBox.this.mScaleVal);
                SmoothCheckBox.this.postInvalidate();
            }
        });
        valueAnimator.start();
        ValueAnimator valueAnimator2 = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.8f, 1.0f});
        valueAnimator2.setDuration((long)this.mAnimDuration);
        valueAnimator2.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator2.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                SmoothCheckBox.this.mFloorScale = ((Float)valueAnimator.getAnimatedValue()).floatValue();
                SmoothCheckBox.this.postInvalidate();
            }
        });
        valueAnimator2.start();
    }

    public boolean isChecked() {
        return this.mChecked;
    }

    protected void onDraw(Canvas canvas) {
        this.drawBorder(canvas);
        this.drawCenter(canvas);
        this.drawTick(canvas);
    }

    protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
        this.mWidth = this.getMeasuredWidth();
        int n5 = this.mStrokeWidth;
        if (n5 == 0) {
            n5 = this.getMeasuredWidth() / 10;
        }
        this.mStrokeWidth = n5;
        int n6 = n5 > this.getMeasuredWidth() / 5 ? this.getMeasuredWidth() / 5 : this.mStrokeWidth;
        this.mStrokeWidth = n6;
        if (n6 < 3) {
            n6 = 3;
        }
        this.mStrokeWidth = n6;
        this.mCenterPoint.x = this.mWidth / 2;
        this.mCenterPoint.y = this.getMeasuredHeight() / 2;
        this.mTickPoints[0].x = Math.round((float)(7.0f * ((float)this.getMeasuredWidth() / 30.0f)));
        this.mTickPoints[0].y = Math.round((float)(14.0f * ((float)this.getMeasuredHeight() / 30.0f)));
        this.mTickPoints[1].x = Math.round((float)(13.0f * ((float)this.getMeasuredWidth() / 30.0f)));
        this.mTickPoints[1].y = Math.round((float)(20.0f * ((float)this.getMeasuredHeight() / 30.0f)));
        this.mTickPoints[2].x = Math.round((float)(22.0f * ((float)this.getMeasuredWidth() / 30.0f)));
        this.mTickPoints[2].y = Math.round((float)(10.0f * ((float)this.getMeasuredHeight() / 30.0f)));
        this.mLeftLineDistance = (float)Math.sqrt((double)(Math.pow((double)(this.mTickPoints[1].x - this.mTickPoints[0].x), (double)2.0) + Math.pow((double)(this.mTickPoints[1].y - this.mTickPoints[0].y), (double)2.0)));
        this.mRightLineDistance = (float)Math.sqrt((double)(Math.pow((double)(this.mTickPoints[2].x - this.mTickPoints[1].x), (double)2.0) + Math.pow((double)(this.mTickPoints[2].y - this.mTickPoints[1].y), (double)2.0)));
        this.mTickPaint.setStrokeWidth((float)this.mStrokeWidth);
    }

    protected void onMeasure(int n, int n2) {
        super.onMeasure(n, n2);
        this.setMeasuredDimension(this.measureSize(n), this.measureSize(n2));
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle)parcelable;
            this.setChecked(bundle.getBoolean(KEY_INSTANCE_STATE));
            super.onRestoreInstanceState(bundle.getParcelable(KEY_INSTANCE_STATE));
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    protected Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable(KEY_INSTANCE_STATE, super.onSaveInstanceState());
        bundle.putBoolean(KEY_INSTANCE_STATE, this.isChecked());
        return bundle;
    }

    public void setChecked(boolean bl) {
        this.mChecked = bl;
        this.reset();
        this.invalidate();
        OnCheckedChangeListener onCheckedChangeListener = this.mListener;
        if (onCheckedChangeListener != null) {
            onCheckedChangeListener.onCheckedChanged(this, this.mChecked);
        }
    }

    public void setChecked(boolean bl, boolean bl2) {
        if (bl2) {
            this.mTickDrawing = false;
            this.mChecked = bl;
            this.mDrewDistance = 0.0f;
            if (bl) {
                this.startCheckedAnimation();
            } else {
                this.startUnCheckedAnimation();
            }
            OnCheckedChangeListener onCheckedChangeListener = this.mListener;
            if (onCheckedChangeListener != null) {
                onCheckedChangeListener.onCheckedChanged(this, this.mChecked);
                return;
            }
        } else {
            this.setChecked(bl);
        }
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener onCheckedChangeListener) {
        this.mListener = onCheckedChangeListener;
    }

    public void toggle() {
        this.setChecked(true ^ this.isChecked());
    }

    public static interface OnCheckedChangeListener {
        public void onCheckedChanged(SmoothCheckBox var1, boolean var2);
    }

}

