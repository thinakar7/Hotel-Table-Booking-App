/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.util.DisplayMetrics
 *  java.lang.Object
 */
package cn.refactor.library;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;

public class CompatUtils {
    public static int dp2px(Context context, float f) {
        return (int)(0.5f + f * context.getResources().getDisplayMetrics().density);
    }
}

