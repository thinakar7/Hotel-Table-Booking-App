/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package de.hdodenhof.circleimageview;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int civ_border_color = 2130903179;
        public static final int civ_border_overlay = 2130903180;
        public static final int civ_border_width = 2130903181;
        public static final int civ_circle_background_color = 2130903182;
        public static final int civ_fill_color = 2130903183;

        private attr() {
        }
    }

    public static final class styleable {
        public static final int[] CircleImageView = new int[]{2130903179, 2130903180, 2130903181, 2130903182, 2130903183};
        public static final int CircleImageView_civ_border_color = 0;
        public static final int CircleImageView_civ_border_overlay = 1;
        public static final int CircleImageView_civ_border_width = 2;
        public static final int CircleImageView_civ_circle_background_color = 3;
        public static final int CircleImageView_civ_fill_color = 4;

        private styleable() {
        }
    }

}

