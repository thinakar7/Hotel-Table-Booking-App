/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.view.View$OnTouchListener
 *  com.github.ornolfr.ratingview.R
 *  com.github.ornolfr.ratingview.R$drawable
 *  com.github.ornolfr.ratingview.R$styleable
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.github.ornolfr.ratingview;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import com.github.ornolfr.ratingview.R;

public class RatingView
extends View
implements View.OnTouchListener {
    private static final int DEFAULT_DRAWABLE_MARGIN_IN_DP = 4;
    private static final int DEFAULT_DRAWABLE_SIZE_IN_DP = 32;
    private static final boolean DEFAULT_IS_INDICATOR = false;
    private static final int DEFAULT_MAX_COUNT = 5;
    private static final float DEFAULT_RATING = 3.5f;
    private Bitmap mDrawableEmpty;
    private Bitmap mDrawableFilled;
    private Bitmap mDrawableHalf;
    private int mDrawableMargin;
    private int mDrawableSize;
    private boolean mIsIndicator;
    private OnRatingChangedListener mListener;
    private int mMaxCount;
    private float mRating;
    private Rect mRect = new Rect();

    public RatingView(Context context) {
        super(context);
        this.init(null, 0, 0);
    }

    public RatingView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(attributeSet, 0, 0);
    }

    public RatingView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(attributeSet, n, 0);
    }

    public RatingView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.init(attributeSet, n, n2);
    }

    private void init(AttributeSet attributeSet, int n, int n2) {
        int n3;
        TypedArray typedArray = this.getContext().obtainStyledAttributes(attributeSet, R.styleable.RatingView, n, n2);
        this.mDrawableMargin = (int)typedArray.getDimension(R.styleable.RatingView_drawable_margin, TypedValue.applyDimension((int)1, (float)4.0f, (DisplayMetrics)this.getResources().getDisplayMetrics()));
        this.mDrawableSize = n3 = (int)typedArray.getDimension(R.styleable.RatingView_drawable_size, TypedValue.applyDimension((int)1, (float)32.0f, (DisplayMetrics)this.getResources().getDisplayMetrics()));
        if (n3 >= 0) {
            int n4;
            this.mMaxCount = n4 = typedArray.getInteger(R.styleable.RatingView_max_count, 5);
            if (n4 >= 1) {
                this.mRating = typedArray.getFloat(R.styleable.RatingView_rating, 3.5f);
                this.mIsIndicator = typedArray.getBoolean(R.styleable.RatingView_is_indicator, false);
                this.mDrawableEmpty = BitmapFactory.decodeResource((Resources)this.getContext().getResources(), (int)typedArray.getResourceId(R.styleable.RatingView_drawable_empty, R.drawable.ic_star_empty));
                this.mDrawableHalf = BitmapFactory.decodeResource((Resources)this.getContext().getResources(), (int)typedArray.getResourceId(R.styleable.RatingView_drawable_half, R.drawable.ic_star_half));
                this.mDrawableFilled = BitmapFactory.decodeResource((Resources)this.getContext().getResources(), (int)typedArray.getResourceId(R.styleable.RatingView_drawable_filled, R.drawable.ic_star_filled));
                typedArray.recycle();
                return;
            }
            throw new IllegalArgumentException("Max count < 1");
        }
        throw new IllegalArgumentException("Drawable size < 0");
    }

    public int getDrawableMargin() {
        return this.mDrawableMargin;
    }

    public int getDrawableSize() {
        return this.mDrawableSize;
    }

    public int getMaxCount() {
        return this.mMaxCount;
    }

    public float getRating() {
        return this.mRating;
    }

    public boolean isIndicator() {
        return this.mIsIndicator;
    }

    protected void onDraw(Canvas canvas) {
        if (!this.mIsIndicator) {
            this.setOnTouchListener((View.OnTouchListener)this);
        }
        if (this.mDrawableFilled != null && this.mDrawableHalf != null && this.mDrawableEmpty != null) {
            Rect rect = this.mRect;
            int n = this.mDrawableSize;
            rect.set(0, 0, n, n);
            float f = this.mRating;
            int n2 = (int)f;
            int n3 = this.mMaxCount - Math.round((float)f);
            if (this.mRating - (float)n2 >= 0.75f) {
                ++n2;
            }
            for (int i = 0; i < n2; ++i) {
                canvas.drawBitmap(this.mDrawableFilled, null, this.mRect, null);
                this.mRect.offset(this.mDrawableSize + this.mDrawableMargin, 0);
            }
            float f2 = this.mRating;
            if (f2 - (float)n2 >= 0.25f && f2 - (float)n2 < 0.75f) {
                canvas.drawBitmap(this.mDrawableHalf, null, this.mRect, null);
                this.mRect.offset(this.mDrawableSize + this.mDrawableMargin, 0);
            }
            for (int i = 0; i < n3; ++i) {
                canvas.drawBitmap(this.mDrawableEmpty, null, this.mRect, null);
                this.mRect.offset(this.mDrawableSize + this.mDrawableMargin, 0);
            }
        }
    }

    protected void onMeasure(int n, int n2) {
        int n3 = this.mDrawableSize;
        int n4 = this.mMaxCount;
        this.setMeasuredDimension(RatingView.resolveSize((int)(n3 * n4 + this.mDrawableMargin * (n4 - 1)), (int)n), RatingView.resolveSize((int)this.mDrawableSize, (int)n2));
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState)parcelable;
            super.onRestoreInstanceState(savedState.getSuperState());
            this.mRating = savedState.mRating;
            this.mIsIndicator = savedState.mIndicator;
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    protected Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.mRating = this.mRating;
        savedState.mIndicator = this.mIsIndicator;
        return savedState;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        int n = motionEvent.getActionMasked();
        if (n != 0) {
            if (n != 1) {
                return super.onTouchEvent(motionEvent);
            }
            this.setRating(Math.round((double)(0.5 + (double)(motionEvent.getX() / (float)this.getWidth() * (float)this.mMaxCount))));
            return false;
        }
        return true;
    }

    public void setDrawableEmpty(Bitmap bitmap) {
        this.mDrawableEmpty = bitmap;
        this.invalidate();
    }

    public void setDrawableFilled(Bitmap bitmap) {
        this.mDrawableFilled = bitmap;
        this.invalidate();
    }

    public void setDrawableHalf(Bitmap bitmap) {
        this.mDrawableHalf = bitmap;
        this.invalidate();
    }

    public void setIsIndicator(boolean bl) {
        this.mIsIndicator = bl;
        RatingView ratingView = bl ? null : this;
        this.setOnTouchListener((View.OnTouchListener)ratingView);
    }

    public void setOnRatingChangedListener(OnRatingChangedListener onRatingChangedListener) {
        this.mListener = onRatingChangedListener;
    }

    public void setRating(float f) {
        float f2 = f;
        if (f2 < 0.0f) {
            f2 = 0.0f;
        } else {
            int n = this.mMaxCount;
            if (f2 > (float)n) {
                f2 = n;
            }
        }
        OnRatingChangedListener onRatingChangedListener = this.mListener;
        if (onRatingChangedListener != null) {
            onRatingChangedListener.onRatingChange(this.mRating, f2);
        }
        this.mRating = f2;
        this.invalidate();
    }

    public static interface OnRatingChangedListener {
        public void onRatingChange(float var1, float var2);
    }

    static class SavedState
    extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>(){

            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public SavedState[] newArray(int n) {
                return new SavedState[n];
            }
        };
        boolean mIndicator;
        float mRating;

        private SavedState(Parcel parcel) {
            super(parcel);
            this.mRating = parcel.readFloat();
            boolean bl = parcel.readInt() == 0;
            this.mIndicator = bl;
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int n) {
            super.writeToParcel(parcel, n);
            parcel.writeFloat(this.mRating);
            parcel.writeInt((int)this.mIndicator);
        }

    }

}

