/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.app.ProgressDialog
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.res.Resources
 *  android.graphics.Typeface
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.text.Editable
 *  android.text.Html
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.RatingBar
 *  android.widget.RatingBar$OnRatingBarChangeListener
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  androidx.viewpager.widget.PagerAdapter
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Adapter;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.provider.Settings;
import android.text.Editable;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import com.daimajia.slider.library.SliderLayout;
import com.dewonderstruck.fireque.Activity.BookRoom;
import com.dewonderstruck.fireque.Activity.Login;
import com.dewonderstruck.fireque.Adapter.ReviewAdapter;
import com.dewonderstruck.fireque.Adapter.RoomAmenities;
import com.dewonderstruck.fireque.Item.RatingList;
import com.dewonderstruck.fireque.Item.RoomList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.github.ornolfr.ratingview.RatingView;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RoomDetailAdapter
extends PagerAdapter {
    private Activity activity;
    private int columnWidth;
    private LayoutInflater layoutInflater;
    private Method method;
    private String msg = "";
    private ProgressDialog progressDialog;
    private int rate;
    private List<RoomList> roomDetailLists;

    public RoomDetailAdapter(List<RoomList> list, Activity activity) {
        Method method;
        this.roomDetailLists = list;
        this.activity = activity;
        this.method = method = new Method(activity);
        this.columnWidth = method.getScreenWidth();
        this.progressDialog = new ProgressDialog((Context)activity);
    }

    static /* synthetic */ Method access$100(RoomDetailAdapter roomDetailAdapter) {
        return roomDetailAdapter.method;
    }

    private void roomDetail(final int n, final ArrayList<String> arrayList, final List<RatingList> list, final SliderLayout sliderLayout, final LinearLayout linearLayout) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.roomDetail);
        stringBuilder.append(((RoomList)this.roomDetailLists.get(n)).getId());
        String string2 = stringBuilder.toString();
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        AsyncHttpResponseHandler asyncHttpResponseHandler = new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n2, Header[] arrheader, byte[] arrby, Throwable throwable) {
            }

            /*
             * Exception decompiling
             */
            @Override
            public void onSuccess(int var1_1, Header[] var2_2, byte[] var3_3) {
                // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 4[FORLOOP]
                // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
                // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
                // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
                // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
                // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
                // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
                // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
                // org.benf.cfr.reader.entities.g.p(Method.java:396)
                // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
                // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
                // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
                // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
                // org.benf.cfr.reader.b.a(Driver.java:128)
                // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
                // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
                // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
                // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
                // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
                // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
                // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
                // java.lang.Thread.run(Thread.java:764)
                throw new IllegalStateException("Decompilation failed");
            }

        };
        asyncHttpClient.get(string2, null, (ResponseHandlerInterface)asyncHttpResponseHandler);
    }

    public void destroyItem(ViewGroup viewGroup, int n, Object object) {
        viewGroup.removeView((View)object);
    }

    public int getCount() {
        return this.roomDetailLists.size();
    }

    public int getItemPosition(Object object) {
        return -2;
    }

    public Object instantiateItem(ViewGroup viewGroup, final int n) {
        LayoutInflater layoutInflater;
        this.layoutInflater = layoutInflater = (LayoutInflater)this.activity.getSystemService("layout_inflater");
        View view = layoutInflater.inflate(2131427424, viewGroup, false);
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        TextView textView = (TextView)view.findViewById(2131231147);
        TextView textView2 = (TextView)view.findViewById(2131231145);
        TextView textView3 = (TextView)view.findViewById(2131231141);
        final TextView textView4 = (TextView)view.findViewById(2131231159);
        TextView textView5 = (TextView)view.findViewById(2131231157);
        TextView textView6 = (TextView)view.findViewById(2131231149);
        WebView webView = (WebView)view.findViewById(2131231203);
        final RatingView ratingView = (RatingView)view.findViewById(2131231018);
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131230961);
        RecyclerView recyclerView = (RecyclerView)view.findViewById(2131231024);
        SliderLayout sliderLayout = (SliderLayout)view.findViewById(2131231063);
        ((Button)view.findViewById(2131230820)).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (Method.isNetworkAvailable(RoomDetailAdapter.this.activity)) {
                    if (RoomDetailAdapter.access$100((RoomDetailAdapter)RoomDetailAdapter.this).pref.getBoolean(RoomDetailAdapter.access$100((RoomDetailAdapter)RoomDetailAdapter.this).pref_login, false)) {
                        RoomDetailAdapter.this.activity.startActivity(new Intent((Context)RoomDetailAdapter.this.activity, BookRoom.class));
                        return;
                    }
                    Method.loginBack = true;
                    RoomDetailAdapter.this.activity.startActivity(new Intent((Context)RoomDetailAdapter.this.activity, Login.class));
                    return;
                }
                Toast.makeText((Context)RoomDetailAdapter.this.activity, (CharSequence)RoomDetailAdapter.this.activity.getResources().getString(2131689589), (int)0).show();
            }
        });
        ImageView imageView = (ImageView)view.findViewById(2131230938);
        View.OnClickListener onClickListener = new View.OnClickListener((List)arrayList2){
            final /* synthetic */ List val$ratingLists;
            {
                this.val$ratingLists = list;
            }

            public void onClick(View view) {
                final Dialog dialog = new Dialog((Context)RoomDetailAdapter.this.activity, 2131755357);
                dialog.requestWindowFeature(1);
                dialog.setContentView(2131427387);
                ImageView imageView = (ImageView)dialog.findViewById(2131230924);
                RatingBar ratingBar = (RatingBar)dialog.findViewById(2131231015);
                final EditText editText = (EditText)dialog.findViewById(2131230880);
                Button button = (Button)dialog.findViewById(2131230825);
                ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener(){

                    public void onRatingChanged(RatingBar ratingBar, float f, boolean bl) {
                        RoomDetailAdapter.this.rate = (int)f;
                    }
                });
                imageView.setOnClickListener(new View.OnClickListener(){

                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                button.setOnClickListener(new View.OnClickListener(){

                    public void onClick(View view) {
                        RoomDetailAdapter.this.msg = editText.getText().toString();
                        if (RoomDetailAdapter.this.rate == 0) {
                            Toast.makeText((Context)RoomDetailAdapter.this.activity, (CharSequence)RoomDetailAdapter.this.activity.getResources().getString(2131689646), (int)0).show();
                            return;
                        }
                        if (Method.isNetworkAvailable(RoomDetailAdapter.this.activity)) {
                            if (RoomDetailAdapter.access$100((RoomDetailAdapter)RoomDetailAdapter.this).pref.getBoolean(RoomDetailAdapter.access$100((RoomDetailAdapter)RoomDetailAdapter.this).pref_login, false)) {
                                RoomDetailAdapter.this.rate = 0;
                                String string2 = RoomDetailAdapter.access$100((RoomDetailAdapter)RoomDetailAdapter.this).pref.getString(RoomDetailAdapter.access$100((RoomDetailAdapter)RoomDetailAdapter.this).profileId, null);
                                RoomDetailAdapter.this.rating(string2, n, ((RoomList)RoomDetailAdapter.this.roomDetailLists.get(n)).getId(), RoomDetailAdapter.this.rate, RoomDetailAdapter.this.msg, ratingView, textView4, (List<RatingList>)2.this.val$ratingLists);
                                dialog.dismiss();
                                return;
                            }
                            Method.loginBack = true;
                            RoomDetailAdapter.this.activity.startActivity(new Intent((Context)RoomDetailAdapter.this.activity, Login.class));
                            return;
                        }
                        Toast.makeText((Context)RoomDetailAdapter.this.activity, (CharSequence)RoomDetailAdapter.this.activity.getResources().getString(2131689589), (int)0).show();
                    }
                });
                dialog.show();
            }

        };
        imageView.setOnClickListener(onClickListener);
        int n2 = this.columnWidth;
        sliderLayout.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(n2, 80 + n2 / 2));
        this.roomDetail(n, (ArrayList<String>)arrayList, (List<RatingList>)arrayList2, sliderLayout, linearLayout);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager((Context)this.activity));
        recyclerView.setFocusable(false);
        textView.setText((CharSequence)((RoomList)this.roomDetailLists.get(n)).getRoom_name());
        textView2.setText((CharSequence)Html.fromHtml((String)((RoomList)this.roomDetailLists.get(n)).getRoom_description()));
        textView3.setText((CharSequence)((RoomList)this.roomDetailLists.get(n)).getRoom_price());
        ratingView.setRating(Float.parseFloat((String)((RoomList)this.roomDetailLists.get(n)).getRate_avg()));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("(");
        stringBuilder.append(((RoomList)this.roomDetailLists.get(n)).getTotal_rate());
        stringBuilder.append(")");
        textView4.setText((CharSequence)stringBuilder.toString());
        textView.setTypeface(this.method.typeface);
        textView5.setTypeface(this.method.typeface);
        textView6.setTypeface(this.method.typeface);
        webView.setBackgroundColor(0);
        webView.setFocusableInTouchMode(false);
        webView.setFocusable(false);
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        String string2 = ((RoomList)this.roomDetailLists.get(n)).getRoom_rules();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("<html><head><style type=\"text/css\">@font-face {font-family: MyFont;src: url(\"file:///android_asset/fonts/poppins_regular.ttf\")}body{font-family: MyFont;}</style></head><body>");
        stringBuilder2.append(string2);
        stringBuilder2.append("</body></html>");
        webView.loadDataWithBaseURL(null, stringBuilder2.toString(), "text/html", "utf-8", null);
        String[] arrstring = ((RoomList)this.roomDetailLists.get(n)).getRoom_amenities().split(",");
        recyclerView.setAdapter((RecyclerView.Adapter)new RoomAmenities(this.activity, arrstring));
        recyclerView.setNestedScrollingEnabled(false);
        viewGroup.addView(view);
        return view;
    }

    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    public void rating(String string2, final int n, final String string3, final int n2, final String string4, final RatingView ratingView, final TextView textView, final List<RatingList> list) {
        this.progressDialog.show();
        this.progressDialog.setMessage((CharSequence)this.activity.getResources().getString(2131689610));
        this.progressDialog.setCancelable(false);
        String string5 = Settings.Secure.getString((ContentResolver)this.activity.getContentResolver(), (String)"android_id");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.rating);
        stringBuilder.append(string3);
        stringBuilder.append("&device_id=");
        stringBuilder.append(string5);
        stringBuilder.append("&user_id=");
        stringBuilder.append(string2);
        stringBuilder.append("&rate=");
        stringBuilder.append(n2);
        stringBuilder.append("&message=");
        stringBuilder.append(string4);
        String string6 = stringBuilder.toString();
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        AsyncHttpResponseHandler asyncHttpResponseHandler = new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n3, Header[] arrheader, byte[] arrby, Throwable throwable) {
                RoomDetailAdapter.this.progressDialog.dismiss();
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void onSuccess(int n3, Header[] arrheader, byte[] arrby) {
                block4 : {
                    JSONArray jSONArray;
                    Log.d((String)"Response", (String)new String(arrby));
                    String string2 = new String(arrby);
                    try {
                        jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        break block4;
                    }
                    for (int i = 0; i < jSONArray.length(); ++i) {
                        JSONObject jSONObject = jSONArray.getJSONObject(i);
                        String string32 = jSONObject.getString("MSG");
                        if (!"You have already rated".equals((Object)string32)) {
                            String string42 = jSONObject.getString("total_rate");
                            String string5 = jSONObject.getString("rate_avg");
                            ((RoomList)RoomDetailAdapter.this.roomDetailLists.get(n)).setRate_avg(string5);
                            ((RoomList)RoomDetailAdapter.this.roomDetailLists.get(n)).setTotal_rate(string42);
                            ratingView.setRating(Float.parseFloat((String)((RoomList)RoomDetailAdapter.this.roomDetailLists.get(n)).getRate_avg()));
                            TextView textView2 = textView;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("(");
                            stringBuilder.append(((RoomList)RoomDetailAdapter.this.roomDetailLists.get(n)).getTotal_rate());
                            stringBuilder.append(")");
                            textView2.setText((CharSequence)stringBuilder.toString());
                            String string6 = RoomDetailAdapter.access$100((RoomDetailAdapter)RoomDetailAdapter.this).pref.getString(RoomDetailAdapter.access$100((RoomDetailAdapter)RoomDetailAdapter.this).userName, null);
                            String string7 = String.valueOf((int)n2);
                            List list2 = list;
                            RatingList ratingList = new RatingList("", string3, string6, string7, "", string4);
                            list2.add(0, (Object)ratingList);
                        }
                        Toast.makeText((Context)RoomDetailAdapter.this.activity, (CharSequence)string32, (int)0).show();
                    }
                }
                RoomDetailAdapter.this.progressDialog.dismiss();
            }
        };
        asyncHttpClient.get(string6, null, (ResponseHandlerInterface)asyncHttpResponseHandler);
    }

}

