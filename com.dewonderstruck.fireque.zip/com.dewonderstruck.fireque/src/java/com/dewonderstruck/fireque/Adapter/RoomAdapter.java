/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.Button
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.squareup.picasso.Callback
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.dewonderstruck.fireque.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.dewonderstruck.fireque.Activity.BookRoom;
import com.dewonderstruck.fireque.Activity.Login;
import com.dewonderstruck.fireque.InterFace.InterstitialAdView;
import com.dewonderstruck.fireque.Item.RoomList;
import com.dewonderstruck.fireque.Util.Method;
import com.github.ornolfr.ratingview.RatingView;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import fr.castorflex.android.smoothprogressbar.SmoothProgressBar;
import java.util.List;

public class RoomAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private Activity activity;
    private int columnWidth;
    private Method method;
    private List<RoomList> roomLists;

    public RoomAdapter(Activity activity, List<RoomList> list, InterstitialAdView interstitialAdView) {
        Method method;
        this.activity = activity;
        this.roomLists = list;
        this.method = method = new Method(activity, interstitialAdView);
        this.columnWidth = method.getScreenWidth();
    }

    static /* synthetic */ Method access$900(RoomAdapter roomAdapter) {
        return roomAdapter.method;
    }

    public int getItemCount() {
        return this.roomLists.size();
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int n) {
        RoundedImageView roundedImageView = viewHolder.imageView_room;
        int n2 = this.columnWidth;
        roundedImageView.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(n2, n2 / 2));
        View view = viewHolder.view;
        int n3 = this.columnWidth;
        view.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(n3, n3 / 2));
        Picasso.get().load(((RoomList)this.roomLists.get(n)).getRoom_image_thumb()).placeholder(2131165396).into((ImageView)viewHolder.imageView_room, new Callback(){

            public void onError(Exception exception) {
                viewHolder.progressBar.setVisibility(8);
            }

            public void onSuccess() {
                viewHolder.progressBar.setVisibility(8);
            }
        });
        viewHolder.textView_roomName.setText((CharSequence)((RoomList)this.roomLists.get(n)).getRoom_name());
        viewHolder.textView_price.setText((CharSequence)((RoomList)this.roomLists.get(n)).getRoom_price());
        TextView textView = viewHolder.textView_totalRate;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("(");
        stringBuilder.append(((RoomList)this.roomLists.get(n)).getTotal_rate());
        stringBuilder.append(")");
        textView.setText((CharSequence)stringBuilder.toString());
        viewHolder.ratingBar.setRating(Float.parseFloat((String)((RoomList)this.roomLists.get(n)).getRate_avg()));
        viewHolder.relativeLayout.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
            }
        });
        viewHolder.button.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (Method.isNetworkAvailable(RoomAdapter.this.activity)) {
                    if (RoomAdapter.access$900((RoomAdapter)RoomAdapter.this).pref.getBoolean(RoomAdapter.access$900((RoomAdapter)RoomAdapter.this).pref_login, false)) {
                        RoomAdapter.this.activity.startActivity(new Intent((Context)RoomAdapter.this.activity, BookRoom.class));
                        return;
                    }
                    Method.loginBack = true;
                    RoomAdapter.this.activity.startActivity(new Intent((Context)RoomAdapter.this.activity, Login.class));
                    return;
                }
                Toast.makeText((Context)RoomAdapter.this.activity, (CharSequence)RoomAdapter.this.activity.getResources().getString(2131689589), (int)0).show();
            }
        });
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new ViewHolder(LayoutInflater.from((Context)this.activity).inflate(2131427422, viewGroup, false));
    }

    public class ViewHolder
    extends RecyclerView.ViewHolder {
        private Button button;
        private RoundedImageView imageView_room;
        private SmoothProgressBar progressBar;
        private RatingView ratingBar;
        private RelativeLayout relativeLayout;
        private TextView textView_price;
        private TextView textView_roomName;
        private TextView textView_totalRate;
        private View view;

        public ViewHolder(View view) {
            super(view);
            this.relativeLayout = (RelativeLayout)view.findViewById(2131231029);
            this.button = (Button)view.findViewById(2131230826);
            this.imageView_room = (RoundedImageView)view.findViewById(2131230936);
            this.view = view.findViewById(2131231198);
            this.textView_roomName = (TextView)view.findViewById(2131231146);
            this.textView_price = (TextView)view.findViewById(2131231148);
            this.textView_totalRate = (TextView)view.findViewById(2131231158);
            this.ratingBar = (RatingView)view.findViewById(2131231017);
            this.progressBar = (SmoothProgressBar)view.findViewById(2131231066);
        }
    }

}

