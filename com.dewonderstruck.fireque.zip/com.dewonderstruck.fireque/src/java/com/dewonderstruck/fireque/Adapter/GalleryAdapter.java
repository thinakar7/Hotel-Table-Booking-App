/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.Resources
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.squareup.picasso.Callback
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.dewonderstruck.fireque.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.dewonderstruck.fireque.InterFace.InterstitialAdView;
import com.dewonderstruck.fireque.Item.GalleryList;
import com.dewonderstruck.fireque.Util.Method;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import fr.castorflex.android.smoothprogressbar.SmoothProgressBar;
import java.util.List;

public class GalleryAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private Activity activity;
    private int columnWidth;
    private List<GalleryList> galleryLists;
    private Method method;

    public GalleryAdapter(Activity activity, List<GalleryList> list, InterstitialAdView interstitialAdView) {
        this.activity = activity;
        this.galleryLists = list;
        this.method = new Method(activity, interstitialAdView);
        float f = TypedValue.applyDimension((int)1, (float)2.0f, (DisplayMetrics)activity.getResources().getDisplayMetrics());
        this.columnWidth = (int)(((float)this.method.getScreenWidth() - 4.0f * f) / 2.0f);
    }

    public int getItemCount() {
        return this.galleryLists.size();
    }

    public void onBindViewHolder(final ViewHolder viewHolder, final int n) {
        ImageView imageView = viewHolder.imageView_Gallery;
        int n2 = this.columnWidth;
        imageView.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(n2, n2));
        int n3 = this.columnWidth;
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(n3, n3 / 2);
        layoutParams.addRule(12);
        viewHolder.view.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        Picasso.get().load(((GalleryList)this.galleryLists.get(n)).getCategory_image_thumb()).into(viewHolder.imageView_Gallery, new Callback(){

            public void onError(Exception exception) {
                viewHolder.progressBar.setVisibility(8);
            }

            public void onSuccess() {
                viewHolder.progressBar.setVisibility(8);
            }
        });
        viewHolder.textView_galleryName.setText((CharSequence)((GalleryList)this.galleryLists.get(n)).getCategory_name());
        viewHolder.relativeLayout.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                GalleryAdapter.this.method.interstitialAdShow(n);
            }
        });
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new ViewHolder(LayoutInflater.from((Context)this.activity).inflate(2131427391, viewGroup, false));
    }

    public class ViewHolder
    extends RecyclerView.ViewHolder {
        private ImageView imageView_Gallery;
        private SmoothProgressBar progressBar;
        private RelativeLayout relativeLayout;
        private TextView textView_galleryName;
        private View view;

        public ViewHolder(View view) {
            super(view);
            this.imageView_Gallery = (ImageView)view.findViewById(2131230928);
            this.view = view.findViewById(2131231196);
            this.relativeLayout = (RelativeLayout)view.findViewById(2131231026);
            this.textView_galleryName = (TextView)view.findViewById(2131231131);
            this.progressBar = (SmoothProgressBar)view.findViewById(2131231065);
        }
    }

}

