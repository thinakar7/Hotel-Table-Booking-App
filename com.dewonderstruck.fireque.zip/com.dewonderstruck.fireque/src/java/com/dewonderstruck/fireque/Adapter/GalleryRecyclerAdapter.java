/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.dewonderstruck.fireque.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.dewonderstruck.fireque.Item.GalleryDetailList;
import com.dewonderstruck.fireque.Util.Method;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import java.util.List;

public class GalleryRecyclerAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private Activity activity;
    List<GalleryDetailList> galleryDetailLists;
    private Method method;

    public GalleryRecyclerAdapter(Activity activity, List<GalleryDetailList> list) {
        this.activity = activity;
        this.galleryDetailLists = list;
        this.method = new Method(activity);
    }

    public int getItemCount() {
        return this.galleryDetailLists.size();
    }

    public void onBindViewHolder(ViewHolder viewHolder, int n) {
        Picasso.get().load(((GalleryDetailList)this.galleryDetailLists.get(n)).getWallpaper_image_thumb()).into(viewHolder.imageView);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new ViewHolder(LayoutInflater.from((Context)this.activity).inflate(2131427394, viewGroup, false));
    }

    public static interface ClickListener {
        public void onClick(View var1, int var2);

        public void onLongClick(View var1, int var2);
    }

    public class ViewHolder
    extends RecyclerView.ViewHolder {
        private ImageView imageView;

        public ViewHolder(View view) {
            super(view);
            this.imageView = (ImageView)view.findViewById(2131230931);
        }
    }

}

