/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.dewonderstruck.fireque.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.dewonderstruck.fireque.Item.RatingList;
import com.github.ornolfr.ratingview.RatingView;
import java.util.List;

public class ReviewAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private Activity activity;
    private int lastPosition = -1;
    private List<RatingList> ratingLists;

    public ReviewAdapter(Activity activity, List<RatingList> list) {
        this.activity = activity;
        this.ratingLists = list;
    }

    public int getItemCount() {
        return this.ratingLists.size();
    }

    public void onBindViewHolder(ViewHolder viewHolder, int n) {
        viewHolder.textView_name.setText((CharSequence)((RatingList)this.ratingLists.get(n)).getUser_name());
        viewHolder.textView_msg.setText((CharSequence)((RatingList)this.ratingLists.get(n)).getMessage());
        viewHolder.ratingView.setRating(Float.parseFloat((String)((RatingList)this.ratingLists.get(n)).getRate()));
        if (n > this.lastPosition) {
            if (n % 2 == 0) {
                viewHolder.relativeLayout.setBackgroundColor(this.activity.getResources().getColor(2131034147));
                return;
            }
            viewHolder.relativeLayout.setBackgroundColor(this.activity.getResources().getColor(2131034148));
        }
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new ViewHolder(LayoutInflater.from((Context)this.activity).inflate(2131427421, viewGroup, false));
    }

    public class ViewHolder
    extends RecyclerView.ViewHolder {
        private RatingView ratingView;
        private RelativeLayout relativeLayout;
        private TextView textView_msg;
        private TextView textView_name;

        public ViewHolder(View view) {
            super(view);
            this.relativeLayout = (RelativeLayout)view.findViewById(2131231028);
            this.ratingView = (RatingView)view.findViewById(2131231016);
            this.textView_name = (TextView)view.findViewById(2131231137);
            this.textView_msg = (TextView)view.findViewById(2131231144);
        }
    }

}

