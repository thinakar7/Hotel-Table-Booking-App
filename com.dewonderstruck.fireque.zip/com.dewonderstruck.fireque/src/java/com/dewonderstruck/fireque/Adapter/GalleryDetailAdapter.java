/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  androidx.viewpager.widget.PagerAdapter
 *  com.squareup.picasso.Callback
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.dewonderstruck.fireque.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import androidx.viewpager.widget.PagerAdapter;
import com.dewonderstruck.fireque.Item.GalleryDetailList;
import com.dewonderstruck.fireque.Util.TouchImageView;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import java.util.List;

public class GalleryDetailAdapter
extends PagerAdapter {
    private Activity activity;
    private List<GalleryDetailList> galleryDetailLists;
    private LayoutInflater layoutInflater;

    public GalleryDetailAdapter(Activity activity, List<GalleryDetailList> list) {
        this.activity = activity;
        this.galleryDetailLists = list;
    }

    public void destroyItem(ViewGroup viewGroup, int n, Object object) {
        viewGroup.removeView((View)object);
    }

    public int getCount() {
        return this.galleryDetailLists.size();
    }

    public int getItemPosition(Object object) {
        return -2;
    }

    public Object instantiateItem(ViewGroup viewGroup, int n) {
        LayoutInflater layoutInflater;
        this.layoutInflater = layoutInflater = (LayoutInflater)this.activity.getSystemService("layout_inflater");
        View view = layoutInflater.inflate(2131427392, viewGroup, false);
        TouchImageView touchImageView = (TouchImageView)view.findViewById(2131230929);
        final ProgressBar progressBar = (ProgressBar)view.findViewById(2131230734);
        Picasso.get().load(((GalleryDetailList)this.galleryDetailLists.get(n)).getWallpaper_image()).into((ImageView)touchImageView, new Callback(){

            public void onError(Exception exception) {
                progressBar.setVisibility(8);
            }

            public void onSuccess() {
                progressBar.setVisibility(8);
            }
        });
        viewGroup.addView(view);
        return view;
    }

    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

}

