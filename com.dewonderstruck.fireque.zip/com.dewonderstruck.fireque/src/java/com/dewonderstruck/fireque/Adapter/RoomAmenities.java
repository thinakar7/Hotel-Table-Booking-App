/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.dewonderstruck.fireque.Util.Method;

public class RoomAmenities
extends RecyclerView.Adapter<ViewHolder> {
    private Activity activity;
    private Method method;
    private String[] separated;

    public RoomAmenities(Activity activity, String[] arrstring) {
        this.activity = activity;
        this.separated = arrstring;
        this.method = new Method(activity);
    }

    public int getItemCount() {
        return this.separated.length;
    }

    public void onBindViewHolder(ViewHolder viewHolder, int n) {
        viewHolder.textView_amenities.setText((CharSequence)this.separated[n].trim());
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new ViewHolder(LayoutInflater.from((Context)this.activity).inflate(2131427423, viewGroup, false));
    }

    public class ViewHolder
    extends RecyclerView.ViewHolder {
        private TextView textView_amenities;

        public ViewHolder(View view) {
            super(view);
            this.textView_amenities = (TextView)view.findViewById(2131231138);
        }
    }

}

