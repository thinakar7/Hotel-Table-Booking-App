/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Item;

import java.io.Serializable;

public class GalleryList
implements Serializable {
    private String category_image;
    private String category_image_thumb;
    private String category_name;
    private String cid;

    public GalleryList(String string2, String string3, String string4, String string5) {
        this.cid = string2;
        this.category_name = string3;
        this.category_image = string4;
        this.category_image_thumb = string5;
    }

    public String getCategory_image() {
        return this.category_image;
    }

    public String getCategory_image_thumb() {
        return this.category_image_thumb;
    }

    public String getCategory_name() {
        return this.category_name;
    }

    public String getCid() {
        return this.cid;
    }

    public void setCategory_image(String string2) {
        this.category_image = string2;
    }

    public void setCategory_image_thumb(String string2) {
        this.category_image_thumb = string2;
    }

    public void setCategory_name(String string2) {
        this.category_name = string2;
    }

    public void setCid(String string2) {
        this.cid = string2;
    }
}

