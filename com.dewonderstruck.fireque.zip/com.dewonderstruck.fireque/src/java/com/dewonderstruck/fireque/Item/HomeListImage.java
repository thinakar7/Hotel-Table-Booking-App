/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Item;

import java.io.Serializable;

public class HomeListImage
implements Serializable {
    private String banner_image;
    private String id;

    public HomeListImage(String string2, String string3) {
        this.id = string2;
        this.banner_image = string3;
    }

    public String getBanner_image() {
        return this.banner_image;
    }

    public String getId() {
        return this.id;
    }

    public void setBanner_image(String string2) {
        this.banner_image = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }
}

