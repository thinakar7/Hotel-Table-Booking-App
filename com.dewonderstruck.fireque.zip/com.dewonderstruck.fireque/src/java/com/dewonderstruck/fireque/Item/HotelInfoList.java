/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Item;

import java.io.Serializable;

public class HotelInfoList
implements Serializable {
    private String hotel_address;
    private String hotel_amenities;
    private String hotel_info;
    private String hotel_lat;
    private String hotel_long;
    private String hotel_name;

    public HotelInfoList(String string2, String string3, String string4) {
        this.hotel_name = string2;
        this.hotel_lat = string3;
        this.hotel_long = string4;
    }

    public HotelInfoList(String string2, String string3, String string4, String string5, String string6, String string7) {
        this.hotel_name = string2;
        this.hotel_address = string3;
        this.hotel_lat = string4;
        this.hotel_long = string5;
        this.hotel_info = string6;
        this.hotel_amenities = string7;
    }

    public String getHotel_address() {
        return this.hotel_address;
    }

    public String getHotel_amenities() {
        return this.hotel_amenities;
    }

    public String getHotel_info() {
        return this.hotel_info;
    }

    public String getHotel_lat() {
        return this.hotel_lat;
    }

    public String getHotel_long() {
        return this.hotel_long;
    }

    public String getHotel_name() {
        return this.hotel_name;
    }

    public void setHotel_address(String string2) {
        this.hotel_address = string2;
    }

    public void setHotel_amenities(String string2) {
        this.hotel_amenities = string2;
    }

    public void setHotel_info(String string2) {
        this.hotel_info = string2;
    }

    public void setHotel_lat(String string2) {
        this.hotel_lat = string2;
    }

    public void setHotel_long(String string2) {
        this.hotel_long = string2;
    }

    public void setHotel_name(String string2) {
        this.hotel_name = string2;
    }
}

