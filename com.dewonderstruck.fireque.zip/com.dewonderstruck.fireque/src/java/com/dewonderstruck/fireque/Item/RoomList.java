/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.dewonderstruck.fireque.Item;

import com.dewonderstruck.fireque.Item.RatingList;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RoomList
implements Serializable {
    private ArrayList<String> arrayImage;
    private String id;
    private String rate_avg;
    private List<RatingList> ratingLists;
    private String room_amenities;
    private String room_description;
    private String room_image;
    private String room_image_thumb;
    private String room_name;
    private String room_price;
    private String room_rules;
    private String total_rate;

    public RoomList(String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10, String string11, ArrayList<String> arrayList, List<RatingList> list) {
        this.id = string2;
        this.room_name = string3;
        this.room_image = string4;
        this.room_image_thumb = string5;
        this.room_description = string6;
        this.room_rules = string7;
        this.room_amenities = string8;
        this.room_price = string9;
        this.total_rate = string10;
        this.rate_avg = string11;
        this.arrayImage = arrayList;
        this.ratingLists = list;
    }

    public ArrayList<String> getArrayImage() {
        return this.arrayImage;
    }

    public String getId() {
        return this.id;
    }

    public String getRate_avg() {
        return this.rate_avg;
    }

    public List<RatingList> getRatingLists() {
        return this.ratingLists;
    }

    public String getRoom_amenities() {
        return this.room_amenities;
    }

    public String getRoom_description() {
        return this.room_description;
    }

    public String getRoom_image() {
        return this.room_image;
    }

    public String getRoom_image_thumb() {
        return this.room_image_thumb;
    }

    public String getRoom_name() {
        return this.room_name;
    }

    public String getRoom_price() {
        return this.room_price;
    }

    public String getRoom_rules() {
        return this.room_rules;
    }

    public String getTotal_rate() {
        return this.total_rate;
    }

    public void setArrayImage(ArrayList<String> arrayList) {
        this.arrayImage = arrayList;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setRate_avg(String string2) {
        this.rate_avg = string2;
    }

    public void setRatingLists(List<RatingList> list) {
        this.ratingLists = list;
    }

    public void setRoom_amenities(String string2) {
        this.room_amenities = string2;
    }

    public void setRoom_description(String string2) {
        this.room_description = string2;
    }

    public void setRoom_image(String string2) {
        this.room_image = string2;
    }

    public void setRoom_image_thumb(String string2) {
        this.room_image_thumb = string2;
    }

    public void setRoom_name(String string2) {
        this.room_name = string2;
    }

    public void setRoom_price(String string2) {
        this.room_price = string2;
    }

    public void setRoom_rules(String string2) {
        this.room_rules = string2;
    }

    public void setTotal_rate(String string2) {
        this.total_rate = string2;
    }
}

