/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Item;

import java.io.Serializable;

public class HomeList
implements Serializable {
    private String banner_image;
    private String hotel_address;
    private String hotel_name;
    private String id;

    public HomeList(String string2, String string3, String string4, String string5) {
        this.id = string2;
        this.banner_image = string3;
        this.hotel_name = string4;
        this.hotel_address = string5;
    }

    public String getBanner_image() {
        return this.banner_image;
    }

    public String getHotel_address() {
        return this.hotel_address;
    }

    public String getHotel_name() {
        return this.hotel_name;
    }

    public String getId() {
        return this.id;
    }

    public void setBanner_image(String string2) {
        this.banner_image = string2;
    }

    public void setHotel_address(String string2) {
        this.hotel_address = string2;
    }

    public void setHotel_name(String string2) {
        this.hotel_name = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }
}

