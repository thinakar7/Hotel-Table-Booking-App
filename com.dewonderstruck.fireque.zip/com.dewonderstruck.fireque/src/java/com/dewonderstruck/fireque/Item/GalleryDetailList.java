/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Item;

import java.io.Serializable;

public class GalleryDetailList
implements Serializable {
    private String cat_id;
    private String category_name;
    private String id;
    private String wallpaper_image;
    private String wallpaper_image_thumb;

    public GalleryDetailList(String string2, String string3, String string4, String string5, String string6) {
        this.id = string2;
        this.cat_id = string3;
        this.wallpaper_image = string4;
        this.wallpaper_image_thumb = string5;
        this.category_name = string6;
    }

    public String getCat_id() {
        return this.cat_id;
    }

    public String getCategory_name() {
        return this.category_name;
    }

    public String getId() {
        return this.id;
    }

    public String getWallpaper_image() {
        return this.wallpaper_image;
    }

    public String getWallpaper_image_thumb() {
        return this.wallpaper_image_thumb;
    }

    public void setCat_id(String string2) {
        this.cat_id = string2;
    }

    public void setCategory_name(String string2) {
        this.category_name = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setWallpaper_image(String string2) {
        this.wallpaper_image = string2;
    }

    public void setWallpaper_image_thumb(String string2) {
        this.wallpaper_image_thumb = string2;
    }
}

