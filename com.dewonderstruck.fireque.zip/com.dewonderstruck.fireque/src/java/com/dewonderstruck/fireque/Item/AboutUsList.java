/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Item;

import java.io.Serializable;

public class AboutUsList
implements Serializable {
    private String app_author;
    private String app_contact;
    private String app_description;
    private String app_developed_by;
    private String app_email;
    private String app_logo;
    private String app_name;
    private String app_privacy_policy;
    private String app_version;
    private String app_website;
    private boolean banner_ad = false;
    private String banner_ad_id;
    private boolean interstital_ad = false;
    private String interstital_ad_click;
    private String interstital_ad_id;
    private String publisher_id;

    public AboutUsList(String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10, String string11, String string12, String string13, String string14, String string15, boolean bl, boolean bl2) {
        this.app_name = string2;
        this.app_logo = string3;
        this.app_version = string4;
        this.app_author = string5;
        this.app_contact = string6;
        this.app_email = string7;
        this.app_website = string8;
        this.app_description = string9;
        this.app_developed_by = string10;
        this.app_privacy_policy = string11;
        this.publisher_id = string12;
        this.interstital_ad_id = string13;
        this.interstital_ad_click = string14;
        this.banner_ad_id = string15;
        this.interstital_ad = bl;
        this.banner_ad = bl2;
    }

    public String getApp_author() {
        return this.app_author;
    }

    public String getApp_contact() {
        return this.app_contact;
    }

    public String getApp_description() {
        return this.app_description;
    }

    public String getApp_developed_by() {
        return this.app_developed_by;
    }

    public String getApp_email() {
        return this.app_email;
    }

    public String getApp_logo() {
        return this.app_logo;
    }

    public String getApp_name() {
        return this.app_name;
    }

    public String getApp_privacy_policy() {
        return this.app_privacy_policy;
    }

    public String getApp_version() {
        return this.app_version;
    }

    public String getApp_website() {
        return this.app_website;
    }

    public String getBanner_ad_id() {
        return this.banner_ad_id;
    }

    public String getInterstital_ad_click() {
        return this.interstital_ad_click;
    }

    public String getInterstital_ad_id() {
        return this.interstital_ad_id;
    }

    public String getPublisher_id() {
        return this.publisher_id;
    }

    public boolean isBanner_ad() {
        return this.banner_ad;
    }

    public boolean isInterstital_ad() {
        return this.interstital_ad;
    }

    public void setApp_author(String string2) {
        this.app_author = string2;
    }

    public void setApp_contact(String string2) {
        this.app_contact = string2;
    }

    public void setApp_description(String string2) {
        this.app_description = string2;
    }

    public void setApp_developed_by(String string2) {
        this.app_developed_by = string2;
    }

    public void setApp_email(String string2) {
        this.app_email = string2;
    }

    public void setApp_logo(String string2) {
        this.app_logo = string2;
    }

    public void setApp_name(String string2) {
        this.app_name = string2;
    }

    public void setApp_privacy_policy(String string2) {
        this.app_privacy_policy = string2;
    }

    public void setApp_version(String string2) {
        this.app_version = string2;
    }

    public void setApp_website(String string2) {
        this.app_website = string2;
    }

    public void setBanner_ad(boolean bl) {
        this.banner_ad = bl;
    }

    public void setBanner_ad_id(String string2) {
        this.banner_ad_id = string2;
    }

    public void setInterstital_ad(boolean bl) {
        this.interstital_ad = bl;
    }

    public void setInterstital_ad_click(String string2) {
        this.interstital_ad_click = string2;
    }

    public void setInterstital_ad_id(String string2) {
        this.interstital_ad_id = string2;
    }

    public void setPublisher_id(String string2) {
        this.publisher_id = string2;
    }
}

