/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Item;

import java.io.Serializable;

public class RatingList
implements Serializable {
    private String dt_rate;
    private String id;
    private String message;
    private String rate;
    private String room_id;
    private String user_name;

    public RatingList(String string2, String string3, String string4, String string5, String string6, String string7) {
        this.id = string2;
        this.room_id = string3;
        this.user_name = string4;
        this.rate = string5;
        this.dt_rate = string6;
        this.message = string7;
    }

    public String getDt_rate() {
        return this.dt_rate;
    }

    public String getId() {
        return this.id;
    }

    public String getMessage() {
        return this.message;
    }

    public String getRate() {
        return this.rate;
    }

    public String getRoom_id() {
        return this.room_id;
    }

    public String getUser_name() {
        return this.user_name;
    }

    public void setDt_rate(String string2) {
        this.dt_rate = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setRate(String string2) {
        this.rate = string2;
    }

    public void setRoom_id(String string2) {
        this.room_id = string2;
    }

    public void setUser_name(String string2) {
        this.user_name = string2;
    }
}

