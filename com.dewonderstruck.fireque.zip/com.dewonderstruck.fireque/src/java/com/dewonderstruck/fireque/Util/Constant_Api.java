/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.dewonderstruck.fireque.Util;

import com.dewonderstruck.fireque.Item.AboutUsList;
import com.dewonderstruck.fireque.Item.RoomList;
import java.util.ArrayList;
import java.util.List;

public class Constant_Api {
    public static int AD_COUNT;
    public static int AD_COUNT_SHOW;
    public static AboutUsList aboutUsList;
    public static String app_detail;
    public static String booking;
    public static String contact_us;
    public static String forgetPassword;
    public static String gallery;
    public static String galleryDetail;
    public static String home;
    public static String hotel_info;
    public static String image;
    public static String login;
    public static String map_api;
    public static String profile;
    public static String profileUpdate;
    public static String rating;
    public static String register;
    public static String room;
    public static String roomDetail;
    public static List<RoomList> roomLists;
    public static String tag;
    public static String url;

    static {
        url = "http://devtools.oversee.network/rmenu/";
        tag = "SINGLE_HOTEL_APP";
        map_api = "AIzaSyDqJZDEt2DHp6Nm0aGtAIgTzoaFxVh1mag";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(url);
        stringBuilder.append("images/");
        image = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(url);
        stringBuilder2.append("api.php");
        app_detail = stringBuilder2.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(url);
        stringBuilder3.append("api.php?users_login");
        login = stringBuilder3.toString();
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(url);
        stringBuilder4.append("api.php?user_register");
        register = stringBuilder4.toString();
        StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append(url);
        stringBuilder5.append("api.php?forgot_pass&email=");
        forgetPassword = stringBuilder5.toString();
        StringBuilder stringBuilder6 = new StringBuilder();
        stringBuilder6.append(url);
        stringBuilder6.append("api.php?user_profile&id=");
        profile = stringBuilder6.toString();
        StringBuilder stringBuilder7 = new StringBuilder();
        stringBuilder7.append(url);
        stringBuilder7.append("api.php?user_profile_update&user_id=");
        profileUpdate = stringBuilder7.toString();
        StringBuilder stringBuilder8 = new StringBuilder();
        stringBuilder8.append(url);
        stringBuilder8.append("api.php?home");
        home = stringBuilder8.toString();
        StringBuilder stringBuilder9 = new StringBuilder();
        stringBuilder9.append(url);
        stringBuilder9.append("api.php?room_list");
        room = stringBuilder9.toString();
        StringBuilder stringBuilder10 = new StringBuilder();
        stringBuilder10.append(url);
        stringBuilder10.append("api.php?room_id=");
        roomDetail = stringBuilder10.toString();
        StringBuilder stringBuilder11 = new StringBuilder();
        stringBuilder11.append(url);
        stringBuilder11.append("api_rating.php?room_id=");
        rating = stringBuilder11.toString();
        StringBuilder stringBuilder12 = new StringBuilder();
        stringBuilder12.append(url);
        stringBuilder12.append("api.php?cat_list");
        gallery = stringBuilder12.toString();
        StringBuilder stringBuilder13 = new StringBuilder();
        stringBuilder13.append(url);
        stringBuilder13.append("api.php?cat_id=");
        galleryDetail = stringBuilder13.toString();
        StringBuilder stringBuilder14 = new StringBuilder();
        stringBuilder14.append(url);
        stringBuilder14.append("api.php?hotel_info");
        hotel_info = stringBuilder14.toString();
        StringBuilder stringBuilder15 = new StringBuilder();
        stringBuilder15.append(url);
        stringBuilder15.append("api_contact.php?");
        contact_us = stringBuilder15.toString();
        StringBuilder stringBuilder16 = new StringBuilder();
        stringBuilder16.append(url);
        stringBuilder16.append("api_booking.php?name=");
        booking = stringBuilder16.toString();
        roomLists = new ArrayList();
        AD_COUNT = 0;
        AD_COUNT_SHOW = 0;
    }
}

