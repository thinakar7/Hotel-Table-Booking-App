/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.StrictMode
 *  android.os.StrictMode$VmPolicy
 *  android.os.StrictMode$VmPolicy$Builder
 *  com.google.android.gms.analytics.GoogleAnalytics
 *  com.google.android.gms.analytics.Tracker
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Util;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.StrictMode;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.Tracker;
import io.github.inflationx.calligraphy3.CalligraphyConfig;
import io.github.inflationx.calligraphy3.CalligraphyInterceptor;
import io.github.inflationx.viewpump.Interceptor;
import io.github.inflationx.viewpump.ViewPump;

public class CalligraphyApplication
extends Application {
    private static GoogleAnalytics sAnalytics;
    private static Tracker sTracker;

    public Tracker getDefaultTracker() {
        CalligraphyApplication calligraphyApplication = this;
        synchronized (calligraphyApplication) {
            if (sTracker == null) {
                sTracker = sAnalytics.newTracker(2131886080);
            }
            Tracker tracker = sTracker;
            return tracker;
        }
    }

    public void onCreate() {
        super.onCreate();
        ViewPump.init(ViewPump.builder().addInterceptor(new CalligraphyInterceptor(new CalligraphyConfig.Builder().setDefaultFontPath("fonts/poppins_regular.ttf").setFontAttrId(2130903298).build())).build());
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy((StrictMode.VmPolicy)builder.build());
        if (Build.VERSION.SDK_INT >= 18) {
            builder.detectFileUriExposure();
        }
        sAnalytics = GoogleAnalytics.getInstance((Context)this);
    }
}

