/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.GestureDetector
 *  android.view.GestureDetector$OnGestureListener
 *  android.view.GestureDetector$SimpleOnGestureListener
 *  android.view.MotionEvent
 *  android.view.View
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$OnItemTouchListener
 *  java.lang.Object
 */
package com.dewonderstruck.fireque.Util;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import com.dewonderstruck.fireque.Adapter.GalleryRecyclerAdapter;

public class RecyclerTouchListener
implements RecyclerView.OnItemTouchListener {
    private GalleryRecyclerAdapter.ClickListener clickListener;
    private GestureDetector gestureDetector;

    public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final GalleryRecyclerAdapter.ClickListener clickListener) {
        this.clickListener = clickListener;
        this.gestureDetector = new GestureDetector(context, (GestureDetector.OnGestureListener)new GestureDetector.SimpleOnGestureListener(){

            public void onLongPress(MotionEvent motionEvent) {
                GalleryRecyclerAdapter.ClickListener clickListener2;
                View view = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
                if (view != null && (clickListener2 = clickListener) != null) {
                    clickListener2.onLongClick(view, recyclerView.getChildPosition(view));
                }
            }

            public boolean onSingleTapUp(MotionEvent motionEvent) {
                return true;
            }
        });
    }

    public boolean onInterceptTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
        View view = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
        if (view != null && this.clickListener != null && this.gestureDetector.onTouchEvent(motionEvent)) {
            this.clickListener.onClick(view, recyclerView.getChildPosition(view));
        }
        return false;
    }

    public void onRequestDisallowInterceptTouchEvent(boolean bl) {
    }

    public void onTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
    }

}

