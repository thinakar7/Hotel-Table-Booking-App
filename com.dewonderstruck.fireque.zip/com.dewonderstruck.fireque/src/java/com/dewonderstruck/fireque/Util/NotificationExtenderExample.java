/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.media.RingtoneManager
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  androidx.core.app.NotificationCompat
 *  androidx.core.app.NotificationCompat$BigPictureStyle
 *  androidx.core.app.NotificationCompat$Builder
 *  androidx.core.app.NotificationCompat$Style
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.net.URLConnection
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.dewonderstruck.fireque.Activity.SplashScreen;
import com.onesignal.NotificationExtenderService;
import com.onesignal.OSNotificationPayload;
import com.onesignal.OSNotificationReceivedResult;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import org.json.JSONObject;

public class NotificationExtenderExample
extends NotificationExtenderService {
    public static final int NOTIFICATION_ID = 1;
    private String NOTIFICATION_CHANNEL_ID = "single_hotel";
    String bigpicture;
    private NotificationManager mNotificationManager;
    String message;
    String title;
    String url;

    public static Bitmap getBitmapFromURL(String string2) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection)new URL(string2).openConnection();
            httpURLConnection.setDoInput(true);
            httpURLConnection.connect();
            Bitmap bitmap = BitmapFactory.decodeStream((InputStream)httpURLConnection.getInputStream());
            return bitmap;
        }
        catch (IOException iOException) {
            return null;
        }
    }

    private int getColour() {
        return 4149685;
    }

    private int getNotificationIcon(NotificationCompat.Builder builder) {
        if (Build.VERSION.SDK_INT >= 21) {
            builder.setColor(this.getColour());
            return 2131165361;
        }
        return 2131165349;
    }

    private void sendNotification() {
        Intent intent;
        this.mNotificationManager = (NotificationManager)this.getSystemService("notification");
        if (!this.url.equals((Object)"false") && !this.url.trim().isEmpty()) {
            intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse((String)this.url));
        } else {
            intent = new Intent((Context)this, SplashScreen.class);
        }
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(this.NOTIFICATION_CHANNEL_ID, (CharSequence)"single hotel", 4);
            this.mNotificationManager.createNotificationChannel(notificationChannel);
        }
        PendingIntent pendingIntent = PendingIntent.getActivity((Context)this, (int)0, (Intent)intent, (int)134217728);
        Uri uri = RingtoneManager.getDefaultUri((int)2);
        NotificationCompat.Builder builder = new NotificationCompat.Builder((Context)this).setAutoCancel(true).setSound(uri).setAutoCancel(true).setChannelId(this.NOTIFICATION_CHANNEL_ID).setLights(-65536, 800, 800);
        builder.setSmallIcon(this.getNotificationIcon(builder));
        builder.setContentTitle((CharSequence)this.title);
        builder.setTicker((CharSequence)this.message);
        if (this.bigpicture != null) {
            builder.setStyle((NotificationCompat.Style)new NotificationCompat.BigPictureStyle().bigPicture(NotificationExtenderExample.getBitmapFromURL(this.bigpicture)).setSummaryText((CharSequence)this.message));
        } else {
            builder.setContentText((CharSequence)this.message);
        }
        builder.setContentIntent(pendingIntent);
        this.mNotificationManager.notify(1, builder.build());
    }

    @Override
    protected boolean onNotificationProcessing(OSNotificationReceivedResult oSNotificationReceivedResult) {
        this.title = oSNotificationReceivedResult.payload.title;
        this.message = oSNotificationReceivedResult.payload.body;
        this.bigpicture = oSNotificationReceivedResult.payload.bigPicture;
        try {
            this.url = oSNotificationReceivedResult.payload.additionalData.getString("external_link");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this.sendNotification();
        return true;
    }
}

