/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.greenrobot.eventbus.EventBus
 */
package com.dewonderstruck.fireque.Util;

import org.greenrobot.eventbus.EventBus;

public class GlobalBus {
    private static EventBus sBus;

    public static EventBus getBus() {
        if (sBus == null) {
            sBus = EventBus.getDefault();
        }
        return sBus;
    }
}

