/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.graphics.Point
 *  android.graphics.Typeface
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.Display
 *  android.view.View
 *  android.view.Window
 *  android.view.WindowManager
 *  android.widget.LinearLayout
 *  com.google.ads.mediation.admob.AdMobAdapter
 *  com.google.android.gms.ads.AdListener
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.AdSize
 *  com.google.android.gms.ads.AdView
 *  com.google.android.gms.ads.InterstitialAd
 *  com.google.android.gms.analytics.HitBuilders
 *  com.google.android.gms.analytics.HitBuilders$ScreenViewBuilder
 *  com.google.android.gms.analytics.Tracker
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.dewonderstruck.fireque.Util;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import com.dewonderstruck.fireque.InterFace.InterstitialAdView;
import com.dewonderstruck.fireque.Item.AboutUsList;
import com.dewonderstruck.fireque.Util.CalligraphyApplication;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import java.util.Map;

public class Method {
    public static boolean loginBack;
    public static boolean onBackPress;
    public static boolean personalization_ad;
    public Activity activity;
    public SharedPreferences.Editor editor;
    private String firstTime = "firstTime";
    private InterstitialAd interstitialAd;
    public InterstitialAdView interstitialAdView;
    private final String myPreference = "login";
    public String notification = "notification";
    public SharedPreferences pref;
    public String pref_login = "pref_login";
    public String profileId = "profileId";
    public Typeface typeface;
    public String userEmail = "userEmail";
    public String userName = "userName";
    public String userPassword = "userPassword";

    static {
        onBackPress = false;
        personalization_ad = false;
        loginBack = false;
    }

    public Method(Activity activity) {
        SharedPreferences sharedPreferences;
        this.activity = activity;
        this.typeface = Typeface.createFromAsset((AssetManager)activity.getAssets(), (String)"fonts/poppins_medium.ttf");
        this.pref = sharedPreferences = activity.getSharedPreferences("login", 0);
        this.editor = sharedPreferences.edit();
    }

    public Method(Activity activity, InterstitialAdView interstitialAdView) {
        SharedPreferences sharedPreferences;
        this.activity = activity;
        this.interstitialAdView = interstitialAdView;
        this.typeface = Typeface.createFromAsset((AssetManager)activity.getAssets(), (String)"fonts/poppins_medium.ttf");
        this.pref = sharedPreferences = activity.getSharedPreferences("login", 0);
        this.editor = sharedPreferences.edit();
        this.loadInterstitialAd();
    }

    public static void forceRTLIfSupported(Window window, Activity activity) {
        if (activity.getResources().getString(2131689591).equals((Object)"true") && Build.VERSION.SDK_INT >= 17) {
            window.getDecorView().setLayoutDirection(1);
        }
    }

    public static boolean isNetworkAvailable(Activity activity) {
        NetworkInfo networkInfo = ((ConnectivityManager)activity.getSystemService("connectivity")).getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }

    private void loadInterstitialAd() {
        AdRequest adRequest;
        this.interstitialAd = new InterstitialAd((Context)this.activity);
        if (personalization_ad) {
            adRequest = new AdRequest.Builder().build();
        } else {
            Bundle bundle = new Bundle();
            bundle.putString("npa", "1");
            adRequest = new AdRequest.Builder().addNetworkExtrasBundle(AdMobAdapter.class, bundle).build();
        }
        if (Constant_Api.aboutUsList != null) {
            this.interstitialAd.setAdUnitId(Constant_Api.aboutUsList.getInterstital_ad_id());
        } else {
            this.interstitialAd.setAdUnitId("");
        }
        this.interstitialAd.loadAd(adRequest);
    }

    public static void showNonPersonalizedAds(LinearLayout linearLayout, Activity activity) {
        Bundle bundle = new Bundle();
        bundle.putString("npa", "1");
        if (Constant_Api.aboutUsList != null) {
            if (Constant_Api.aboutUsList.isBanner_ad()) {
                AdView adView = new AdView((Context)activity);
                AdRequest adRequest = new AdRequest.Builder().addNetworkExtrasBundle(AdMobAdapter.class, bundle).build();
                adView.setAdUnitId(Constant_Api.aboutUsList.getBanner_ad_id());
                adView.setAdSize(AdSize.BANNER);
                linearLayout.addView((View)adView);
                adView.loadAd(adRequest);
                return;
            }
            linearLayout.setVisibility(8);
            return;
        }
        linearLayout.setVisibility(8);
    }

    public static void showPersonalizedAds(LinearLayout linearLayout, Activity activity) {
        if (Constant_Api.aboutUsList != null) {
            if (Constant_Api.aboutUsList.isBanner_ad()) {
                AdView adView = new AdView((Context)activity);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.setAdUnitId(Constant_Api.aboutUsList.getBanner_ad_id());
                adView.setAdSize(AdSize.BANNER);
                linearLayout.addView((View)adView);
                adView.loadAd(adRequest);
                return;
            }
            linearLayout.setVisibility(8);
            return;
        }
        linearLayout.setVisibility(8);
    }

    public static void trackScreenView(Activity activity, String string2) {
        Tracker tracker = ((CalligraphyApplication)activity.getApplication()).getDefaultTracker();
        tracker.setScreenName(string2);
        tracker.send(new HitBuilders.ScreenViewBuilder().build());
    }

    public int getScreenWidth() {
        Display display = ((WindowManager)this.activity.getSystemService("window")).getDefaultDisplay();
        Point point = new Point();
        point.x = display.getWidth();
        point.y = display.getHeight();
        return point.x;
    }

    public void interstitialAdShow(final int n) {
        if (Constant_Api.aboutUsList != null) {
            if (Constant_Api.aboutUsList.isInterstital_ad()) {
                if ((Constant_Api.AD_COUNT = 1 + Constant_Api.AD_COUNT) == Constant_Api.AD_COUNT_SHOW) {
                    Constant_Api.AD_COUNT = 0;
                    if (this.interstitialAd.isLoaded()) {
                        this.interstitialAd.show();
                        this.interstitialAd.setAdListener(new AdListener(){

                            public void onAdClosed() {
                                Method.this.loadInterstitialAd();
                                Method.this.interstitialAdView.position(n);
                                super.onAdClosed();
                            }
                        });
                        return;
                    }
                    this.interstitialAdView.position(n);
                    return;
                }
                this.interstitialAdView.position(n);
                return;
            }
            this.interstitialAdView.position(n);
            return;
        }
        this.interstitialAdView.position(n);
    }

    public void login() {
        if (!this.pref.getBoolean(this.firstTime, false)) {
            this.editor.putBoolean(this.pref_login, false);
            this.editor.putBoolean(this.firstTime, true);
            this.editor.commit();
        }
    }

}

