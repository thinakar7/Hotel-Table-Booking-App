/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Util;

public class Events {

    public static class Login {
        private String login;

        public Login(String string2) {
            this.login = string2;
        }

        public String getLogin() {
            return this.login;
        }
    }

}

