/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.text.Editable
 *  android.util.Log
 *  android.util.Patterns
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.IBinder;
import android.text.Editable;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import cn.refactor.library.SmoothCheckBox;
import com.dewonderstruck.fireque.Activity.ForgetPassword;
import com.dewonderstruck.fireque.Activity.MainActivity;
import com.dewonderstruck.fireque.Activity.Register;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Events;
import com.dewonderstruck.fireque.Util.GlobalBus;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Login
extends AppCompatActivity {
    private static SharedPreferences.Editor editor;
    public static final String mypreference = "mypref";
    private static SharedPreferences pref;
    public static final String pref_check = "pref_check";
    public static final String pref_email = "pref_email";
    public static final String pref_password = "pref_password";
    private EditText editText_email;
    private EditText editText_password;
    private String email;
    private InputMethodManager imm;
    private Method method;
    private String password;
    private ProgressDialog progressDialog;

    static /* synthetic */ Method access$600(Login login) {
        return login.method;
    }

    private boolean isValidMail(String string2) {
        return Patterns.EMAIL_ADDRESS.matcher((CharSequence)string2).matches();
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    public void login(SmoothCheckBox smoothCheckBox) {
        this.editText_email.setError(null);
        this.editText_password.setError(null);
        if (this.isValidMail(this.email) && !this.email.isEmpty()) {
            if (this.password.isEmpty()) {
                this.editText_password.requestFocus();
                this.editText_password.setError((CharSequence)this.getResources().getString(2131689644));
                return;
            }
            if (Method.isNetworkAvailable((Activity)this)) {
                this.login(this.email, this.password, smoothCheckBox);
                return;
            }
            Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689589), (int)0).show();
            return;
        }
        this.editText_email.requestFocus();
        this.editText_email.setError((CharSequence)this.getResources().getString(2131689642));
    }

    public void login(final String string2, final String string3, final SmoothCheckBox smoothCheckBox) {
        this.progressDialog.show();
        this.progressDialog.setMessage((CharSequence)this.getResources().getString(2131689610));
        this.progressDialog.setCancelable(false);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.login);
        stringBuilder.append("&email=");
        stringBuilder.append(string2);
        stringBuilder.append("&password=");
        stringBuilder.append(string3);
        String string4 = stringBuilder.toString();
        new AsyncHttpClient().get(string4, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                Login.this.progressDialog.dismiss();
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string22 = new String(arrby);
                JSONArray jSONArray = new JSONObject(string22).getJSONArray(Constant_Api.tag);
                int n2 = 0;
                do {
                    block10 : {
                        try {
                            if (n2 < jSONArray.length()) {
                                JSONObject jSONObject = jSONArray.getJSONObject(n2);
                                if (jSONObject.getString("success").equals((Object)"1")) {
                                    String string32 = jSONObject.getString("user_id");
                                    String string4 = jSONObject.getString("name");
                                    Login.access$600((Login)Login.this).editor.putBoolean(Login.access$600((Login)Login.this).pref_login, true);
                                    Login.access$600((Login)Login.this).editor.putString(Login.access$600((Login)Login.this).profileId, string32);
                                    Login.access$600((Login)Login.this).editor.putString(Login.access$600((Login)Login.this).userName, string4);
                                    Login.access$600((Login)Login.this).editor.putString(Login.access$600((Login)Login.this).userEmail, string2);
                                    Login.access$600((Login)Login.this).editor.putString(Login.access$600((Login)Login.this).userPassword, string3);
                                    Login.access$600((Login)Login.this).editor.commit();
                                    if (smoothCheckBox.isChecked()) {
                                        editor.putString(Login.pref_email, Login.this.editText_email.getText().toString());
                                        editor.putString(Login.pref_password, Login.this.editText_password.getText().toString());
                                        editor.putBoolean(Login.pref_check, true);
                                        editor.commit();
                                    }
                                    Login.this.editText_email.setText((CharSequence)"");
                                    Login.this.editText_password.setText((CharSequence)"");
                                    if (Method.loginBack) {
                                        Events.Login login = new Events.Login("");
                                        GlobalBus.getBus().post((Object)login);
                                        Method.loginBack = false;
                                        Login.this.onBackPressed();
                                    } else {
                                        Login.this.startActivity(new Intent((Context)Login.this, MainActivity.class).setFlags(32768));
                                        Login.this.finishAffinity();
                                    }
                                } else {
                                    Login login = Login.this;
                                    Toast.makeText((Context)login, (CharSequence)login.getResources().getString(2131689617), (int)0).show();
                                }
                                break block10;
                            }
                            Login.this.progressDialog.dismiss();
                            return;
                        }
                        catch (JSONException jSONException) {
                            jSONException.printStackTrace();
                            return;
                        }
                    }
                    ++n2;
                } while (true);
            }
        });
    }

    protected void onCreate(Bundle bundle) {
        SharedPreferences sharedPreferences;
        super.onCreate(bundle);
        this.requestWindowFeature(1);
        this.getWindow().setFlags(1024, 1024);
        this.setContentView(2131427362);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        this.method = new Method((Activity)this);
        pref = sharedPreferences = this.getSharedPreferences(mypreference, 0);
        editor = sharedPreferences.edit();
        this.imm = (InputMethodManager)this.getSystemService("input_method");
        this.getWindow().setSoftInputMode(2);
        this.progressDialog = new ProgressDialog((Context)this);
        this.editText_email = (EditText)this.findViewById(2131230877);
        this.editText_password = (EditText)this.findViewById(2131230885);
        Button button = (Button)this.findViewById(2131230824);
        TextView textView = (TextView)this.findViewById(2131231152);
        Button button2 = (Button)this.findViewById(2131230827);
        TextView textView2 = (TextView)this.findViewById(2131231129);
        final SmoothCheckBox smoothCheckBox = (SmoothCheckBox)this.findViewById(2131230836);
        smoothCheckBox.setChecked(false);
        if (pref.getBoolean(pref_check, false)) {
            this.editText_email.setText((CharSequence)pref.getString(pref_email, null));
            this.editText_password.setText((CharSequence)pref.getString(pref_password, null));
            smoothCheckBox.setChecked(true);
        } else {
            this.editText_email.setText((CharSequence)"");
            this.editText_password.setText((CharSequence)"");
            smoothCheckBox.setChecked(false);
        }
        smoothCheckBox.setOnCheckedChangeListener(new SmoothCheckBox.OnCheckedChangeListener(){

            @Override
            public void onCheckedChanged(SmoothCheckBox smoothCheckBox, boolean bl) {
                Log.d((String)"SmoothCheckBox", (String)String.valueOf((boolean)bl));
                if (bl) {
                    editor.putString(Login.pref_email, Login.this.editText_email.getText().toString());
                    editor.putString(Login.pref_password, Login.this.editText_password.getText().toString());
                    editor.putBoolean(Login.pref_check, true);
                    editor.commit();
                    return;
                }
                editor.putBoolean(Login.pref_check, false);
                editor.commit();
            }
        });
        button.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Login login = Login.this;
                login.email = login.editText_email.getText().toString();
                Login login2 = Login.this;
                login2.password = login2.editText_password.getText().toString();
                Login.this.editText_email.clearFocus();
                Login.this.editText_password.clearFocus();
                Login.this.imm.hideSoftInputFromWindow(Login.this.editText_email.getWindowToken(), 0);
                Login.this.imm.hideSoftInputFromWindow(Login.this.editText_password.getWindowToken(), 0);
                Login.this.login(smoothCheckBox);
            }
        });
        textView.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Login.this.startActivity(new Intent((Context)Login.this, Register.class));
            }
        });
        button2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (Method.loginBack) {
                    Method.loginBack = false;
                    Login.this.onBackPressed();
                    return;
                }
                Login.this.startActivity(new Intent((Context)Login.this, MainActivity.class));
                Login.this.finish();
            }
        });
        textView2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Login.this.startActivity(new Intent((Context)Login.this, ForgetPassword.class));
            }
        });
    }

}

