/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.text.Editable
 *  android.util.Log
 *  android.util.Patterns
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.IBinder;
import android.text.Editable;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.dewonderstruck.fireque.Activity.Login;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Register
extends AppCompatActivity {
    private String conform_password;
    private EditText editText_conform_password;
    private EditText editText_email;
    private EditText editText_name;
    private EditText editText_password;
    private EditText editText_phoneNo;
    private String email;
    private InputMethodManager imm;
    private String name;
    private String password;
    private String phoneNo;

    private boolean isValidMail(String string2) {
        return Patterns.EMAIL_ADDRESS.matcher((CharSequence)string2).matches();
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    public void form() {
        this.editText_name.setError(null);
        this.editText_email.setError(null);
        this.editText_password.setError(null);
        this.editText_conform_password.setError(null);
        this.editText_phoneNo.setError(null);
        if (!this.name.isEmpty() && !this.name.equals((Object)"")) {
            if (this.isValidMail(this.email) && !this.email.isEmpty()) {
                if (!this.password.isEmpty() && !this.password.equals((Object)"")) {
                    if (!this.conform_password.isEmpty() && !this.conform_password.equals((Object)"")) {
                        if (!this.phoneNo.isEmpty() && !this.phoneNo.equals((Object)"")) {
                            if (!this.password.equals((Object)this.conform_password)) {
                                Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689630), (int)0).show();
                                return;
                            }
                            this.editText_name.clearFocus();
                            this.editText_email.clearFocus();
                            this.editText_password.clearFocus();
                            this.editText_conform_password.clearFocus();
                            this.editText_phoneNo.clearFocus();
                            this.imm.hideSoftInputFromWindow(this.editText_name.getWindowToken(), 0);
                            this.imm.hideSoftInputFromWindow(this.editText_email.getWindowToken(), 0);
                            this.imm.hideSoftInputFromWindow(this.editText_password.getWindowToken(), 0);
                            this.imm.hideSoftInputFromWindow(this.editText_conform_password.getWindowToken(), 0);
                            this.imm.hideSoftInputFromWindow(this.editText_phoneNo.getWindowToken(), 0);
                            if (Method.isNetworkAvailable((Activity)this)) {
                                this.register(this.name, this.email, this.password, this.phoneNo);
                                return;
                            }
                            Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689589), (int)0).show();
                            return;
                        }
                        this.editText_phoneNo.requestFocus();
                        this.editText_phoneNo.setError((CharSequence)this.getResources().getString(2131689645));
                        return;
                    }
                    this.editText_conform_password.requestFocus();
                    this.editText_conform_password.setError((CharSequence)this.getResources().getString(2131689641));
                    return;
                }
                this.editText_password.requestFocus();
                this.editText_password.setError((CharSequence)this.getResources().getString(2131689644));
                return;
            }
            this.editText_email.requestFocus();
            this.editText_email.setError((CharSequence)this.getResources().getString(2131689642));
            return;
        }
        this.editText_name.requestFocus();
        this.editText_name.setError((CharSequence)this.getResources().getString(2131689643));
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.requestWindowFeature(1);
        this.getWindow().setFlags(1024, 1024);
        this.setContentView(2131427366);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        this.imm = (InputMethodManager)this.getSystemService("input_method");
        this.getWindow().setSoftInputMode(2);
        this.editText_name = (EditText)this.findViewById(2131230883);
        this.editText_email = (EditText)this.findViewById(2131230878);
        this.editText_password = (EditText)this.findViewById(2131230886);
        this.editText_conform_password = (EditText)this.findViewById(2131230874);
        this.editText_phoneNo = (EditText)this.findViewById(2131230888);
        ((TextView)this.findViewById(2131231132)).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Register.this.startActivity(new Intent((Context)Register.this, Login.class));
                Register.this.finishAffinity();
            }
        });
        ((Button)this.findViewById(2131230828)).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Register register = Register.this;
                register.name = register.editText_name.getText().toString();
                Register register2 = Register.this;
                register2.email = register2.editText_email.getText().toString();
                Register register3 = Register.this;
                register3.password = register3.editText_password.getText().toString();
                Register register4 = Register.this;
                register4.conform_password = register4.editText_conform_password.getText().toString();
                Register register5 = Register.this;
                register5.phoneNo = register5.editText_phoneNo.getText().toString();
                Register.this.form();
            }
        });
    }

    public void register(String string2, String string3, String string4, String string5) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.register);
        stringBuilder.append("&name=");
        stringBuilder.append(string2);
        stringBuilder.append("&email=");
        stringBuilder.append(string3);
        stringBuilder.append("&password=");
        stringBuilder.append(string4);
        stringBuilder.append("&phone=");
        stringBuilder.append(string5);
        String string6 = stringBuilder.toString();
        new AsyncHttpClient().get(string6, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                JSONArray jSONArray;
                int n2;
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                try {
                    jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                    n2 = 0;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
                do {
                    block5 : {
                        if (n2 >= jSONArray.length()) break;
                        JSONObject jSONObject = jSONArray.getJSONObject(n2);
                        String string3 = jSONObject.getString("msg");
                        if (jSONObject.getString("success").equals((Object)"1")) {
                            Toast.makeText((Context)Register.this, (CharSequence)string3, (int)0).show();
                            Register.this.editText_name.setText((CharSequence)"");
                            Register.this.editText_email.setText((CharSequence)"");
                            Register.this.editText_password.setText((CharSequence)"");
                            Register.this.editText_conform_password.setText((CharSequence)"");
                            Register.this.editText_phoneNo.setText((CharSequence)"");
                            Register.this.startActivity(new Intent((Context)Register.this, Login.class));
                            Register.this.finishAffinity();
                            break block5;
                        }
                        Toast.makeText((Context)Register.this, (CharSequence)string3, (int)0).show();
                    }
                    ++n2;
                } while (true);
                return;
            }
        });
    }

}

