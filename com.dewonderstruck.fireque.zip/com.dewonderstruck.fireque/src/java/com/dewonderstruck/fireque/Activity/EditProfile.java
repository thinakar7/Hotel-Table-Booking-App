/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Log
 *  android.util.Patterns
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.Window
 *  android.widget.EditText
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.dewonderstruck.fireque.Activity.Profile;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class EditProfile
extends AppCompatActivity {
    private EditText editText_confirm_password;
    private EditText editText_email;
    private EditText editText_name;
    private EditText editText_password;
    private EditText editText_phoneNo;
    private LinearLayout linearLayout;
    private String profileId;
    private ProgressBar progressBar;
    public Toolbar toolbar;

    private boolean isValidMail(String string2) {
        return Patterns.EMAIL_ADDRESS.matcher((CharSequence)string2).matches();
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    protected void onCreate(Bundle bundle) {
        Toolbar toolbar;
        super.onCreate(bundle);
        this.setContentView(2131427358);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        Intent intent = this.getIntent();
        String string2 = intent.getStringExtra("name");
        String string3 = intent.getStringExtra("email");
        String string4 = intent.getStringExtra("phone");
        this.profileId = intent.getStringExtra("profileId");
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131231172);
        toolbar.setTitle((CharSequence)this.getResources().getString(2131689567));
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.progressBar = (ProgressBar)this.findViewById(2131231010);
        this.editText_name = (EditText)this.findViewById(2131230882);
        this.editText_email = (EditText)this.findViewById(2131230876);
        this.editText_password = (EditText)this.findViewById(2131230884);
        this.editText_confirm_password = (EditText)this.findViewById(2131230873);
        this.editText_phoneNo = (EditText)this.findViewById(2131230889);
        this.linearLayout = (LinearLayout)this.findViewById(2131230954);
        if (Method.personalization_ad) {
            Method.showPersonalizedAds(this.linearLayout, (Activity)this);
        } else {
            Method.showNonPersonalizedAds(this.linearLayout, (Activity)this);
        }
        this.progressBar.setVisibility(8);
        this.editText_name.setText((CharSequence)string2);
        this.editText_email.setText((CharSequence)string3);
        this.editText_phoneNo.setText((CharSequence)string4);
    }

    public boolean onCreateOptionsMenu(Menu menu2) {
        this.getMenuInflater().inflate(2131492865, menu2);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int n = menuItem.getItemId();
        if (n != 16908332) {
            if (n == 2131230797) {
                String string2 = this.editText_name.getText().toString();
                String string3 = this.editText_email.getText().toString();
                String string4 = this.editText_password.getText().toString();
                String string5 = this.editText_confirm_password.getText().toString();
                String string6 = this.editText_phoneNo.getText().toString();
                this.editText_name.setError(null);
                this.editText_email.setError(null);
                this.editText_password.setError(null);
                this.editText_confirm_password.setError(null);
                this.editText_phoneNo.setError(null);
                if (!string2.isEmpty() && !string2.equals((Object)"")) {
                    if (this.isValidMail(string3) && !string3.isEmpty()) {
                        if (!string4.isEmpty() && !string4.equals((Object)"")) {
                            if (!string5.isEmpty() && !string5.equals((Object)"")) {
                                if (!string6.isEmpty() && !string6.equals((Object)"")) {
                                    if (!string4.equals((Object)string5)) {
                                        Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689630), (int)0).show();
                                    } else {
                                        this.profileUpdate(this.profileId, string2, string3, string4, string6);
                                    }
                                } else {
                                    this.editText_phoneNo.requestFocus();
                                    this.editText_phoneNo.setError((CharSequence)this.getResources().getString(2131689645));
                                }
                            } else {
                                this.editText_confirm_password.requestFocus();
                                this.editText_confirm_password.setError((CharSequence)this.getResources().getString(2131689641));
                            }
                        } else {
                            this.editText_password.requestFocus();
                            this.editText_password.setError((CharSequence)this.getResources().getString(2131689644));
                        }
                    } else {
                        this.editText_email.requestFocus();
                        this.editText_email.setError((CharSequence)this.getResources().getString(2131689642));
                    }
                } else {
                    this.editText_name.requestFocus();
                    this.editText_name.setError((CharSequence)this.getResources().getString(2131689643));
                }
            }
        } else {
            this.onBackPressed();
        }
        return true;
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }

    public void profileUpdate(String string2, String string3, String string4, String string5, String string6) {
        this.progressBar.setVisibility(0);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.profileUpdate);
        stringBuilder.append(string2);
        stringBuilder.append("&name=");
        stringBuilder.append(string3);
        stringBuilder.append("&email=");
        stringBuilder.append(string4);
        stringBuilder.append("&password=");
        stringBuilder.append(string5);
        stringBuilder.append("&phone=");
        stringBuilder.append(string6);
        String string7 = stringBuilder.toString();
        new AsyncHttpClient().get(string7, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                EditProfile.this.progressBar.setVisibility(8);
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                JSONArray jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                int n2 = 0;
                do {
                    block7 : {
                        try {
                            if (n2 < jSONArray.length()) {
                                JSONObject jSONObject = jSONArray.getJSONObject(n2);
                                String string3 = jSONObject.getString("msg");
                                if (jSONObject.getString("success").equals((Object)"1")) {
                                    Toast.makeText((Context)EditProfile.this, (CharSequence)string3, (int)0).show();
                                    EditProfile.this.startActivity(new Intent((Context)EditProfile.this, Profile.class).setFlags(67108864));
                                } else {
                                    Toast.makeText((Context)EditProfile.this, (CharSequence)string3, (int)0).show();
                                }
                                break block7;
                            }
                            EditProfile.this.progressBar.setVisibility(8);
                            return;
                        }
                        catch (JSONException jSONException) {
                            jSONException.printStackTrace();
                            return;
                        }
                    }
                    ++n2;
                } while (true);
            }
        });
    }

}

