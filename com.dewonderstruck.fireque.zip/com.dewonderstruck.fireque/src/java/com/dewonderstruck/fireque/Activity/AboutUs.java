/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.view.View
 *  android.view.Window
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.CharSequence
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.dewonderstruck.fireque.Item.AboutUsList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;

public class AboutUs
extends AppCompatActivity {
    private LinearLayout linearLayout;
    public Toolbar toolbar;

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    protected void onCreate(Bundle bundle) {
        Toolbar toolbar;
        super.onCreate(bundle);
        this.setContentView(2131427356);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131231170);
        toolbar.setTitle((CharSequence)this.getResources().getString(2131689503));
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        TextView textView = (TextView)this.findViewById(2131231120);
        TextView textView2 = (TextView)this.findViewById(2131231121);
        TextView textView3 = (TextView)this.findViewById(2131231117);
        TextView textView4 = (TextView)this.findViewById(2131231118);
        TextView textView5 = (TextView)this.findViewById(2131231119);
        TextView textView6 = (TextView)this.findViewById(2131231122);
        WebView webView = (WebView)this.findViewById(2131231202);
        ImageView imageView = (ImageView)this.findViewById(2131230807);
        this.linearLayout = (LinearLayout)this.findViewById(2131230951);
        if (Method.personalization_ad) {
            Method.showPersonalizedAds(this.linearLayout, (Activity)this);
        } else {
            Method.showNonPersonalizedAds(this.linearLayout, (Activity)this);
        }
        if (Constant_Api.aboutUsList != null) {
            textView.setText((CharSequence)Constant_Api.aboutUsList.getApp_name());
            Picasso picasso = Picasso.get();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Constant_Api.image);
            stringBuilder.append(Constant_Api.aboutUsList.getApp_logo());
            picasso.load(stringBuilder.toString()).into(imageView);
            textView2.setText((CharSequence)Constant_Api.aboutUsList.getApp_version());
            textView3.setText((CharSequence)Constant_Api.aboutUsList.getApp_author());
            textView4.setText((CharSequence)Constant_Api.aboutUsList.getApp_contact());
            textView5.setText((CharSequence)Constant_Api.aboutUsList.getApp_email());
            textView6.setText((CharSequence)Constant_Api.aboutUsList.getApp_website());
            webView.setBackgroundColor(0);
            webView.setFocusableInTouchMode(false);
            webView.setFocusable(false);
            webView.getSettings().setDefaultTextEncodingName("UTF-8");
            String string2 = Constant_Api.aboutUsList.getApp_description();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("<html><head><style type=\"text/css\">@font-face {font-family: MyFont;src: url(\"file:///android_asset/fonts/poppins_regular.ttf\")}body{font-family: MyFont;color: #8b8b8b;}</style></head><body>");
            stringBuilder2.append(string2);
            stringBuilder2.append("</body></html>");
            webView.loadDataWithBaseURL(null, stringBuilder2.toString(), "text/html", "utf-8", null);
        }
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }
}

