/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.view.Window
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentManager
 *  com.google.android.gms.maps.CameraUpdate
 *  com.google.android.gms.maps.CameraUpdateFactory
 *  com.google.android.gms.maps.GoogleMap
 *  com.google.android.gms.maps.OnMapReadyCallback
 *  com.google.android.gms.maps.SupportMapFragment
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.android.gms.maps.model.Marker
 *  com.google.android.gms.maps.model.MarkerOptions
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.dewonderstruck.fireque.Item.HotelInfoList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Location
extends AppCompatActivity {
    private List<HotelInfoList> hotelInfoLists;
    private LinearLayout linearLayout;
    private SupportMapFragment mapFragment;
    private Method method;
    private ProgressBar progressBar;
    public Toolbar toolbar;

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    public void location() {
        this.progressBar.setVisibility(0);
        new AsyncHttpClient().get(Constant_Api.hotel_info, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                Location.this.progressBar.setVisibility(8);
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                JSONArray jSONArray = new JSONObject(string2).getJSONObject(Constant_Api.tag).getJSONArray("hotel_info");
                int n2 = 0;
                do {
                    if (n2 >= jSONArray.length()) break;
                    JSONObject jSONObject = jSONArray.getJSONObject(n2);
                    String string3 = jSONObject.getString("hotel_name");
                    String string4 = jSONObject.getString("hotel_address");
                    String string5 = jSONObject.getString("hotel_lat");
                    String string6 = jSONObject.getString("hotel_long");
                    String string7 = jSONObject.getString("hotel_info");
                    String string8 = jSONObject.getString("hotel_amenities");
                    Location.this.hotelInfoLists.add((Object)new HotelInfoList(string3, string4, string5, string6, string7, string8));
                    ++n2;
                } while (true);
                try {
                    Location.this.mapFragment.getMapAsync(new OnMapReadyCallback(){

                        public void onMapReady(GoogleMap googleMap) {
                            try {
                                LatLng latLng = new LatLng(Double.parseDouble((String)((HotelInfoList)Location.this.hotelInfoLists.get(0)).getHotel_lat()), Double.parseDouble((String)((HotelInfoList)Location.this.hotelInfoLists.get(0)).getHotel_long()));
                                googleMap.addMarker(new MarkerOptions().position(latLng).title(""));
                                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom((LatLng)latLng, (float)12.0f));
                                return;
                            }
                            catch (Exception exception) {
                                Log.d((String)"error_map", (String)exception.toString());
                                return;
                            }
                        }
                    });
                    Location.this.progressBar.setVisibility(8);
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }

        });
    }

    protected void onCreate(Bundle bundle) {
        Toolbar toolbar;
        super.onCreate(bundle);
        this.setContentView(2131427361);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131231175);
        toolbar.setTitle((CharSequence)this.getResources().getString(2131689611));
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.hotelInfoLists = new ArrayList();
        this.linearLayout = (LinearLayout)this.findViewById(2131230956);
        if (Method.personalization_ad) {
            Method.showPersonalizedAds(this.linearLayout, (Activity)this);
        } else {
            Method.showNonPersonalizedAds(this.linearLayout, (Activity)this);
        }
        this.progressBar = (ProgressBar)this.findViewById(2131231012);
        this.mapFragment = (SupportMapFragment)this.getSupportFragmentManager().findFragmentById(2131230968);
        if (Method.isNetworkAvailable((Activity)this)) {
            this.location();
            return;
        }
        Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689589), (int)0).show();
        this.progressBar.setVisibility(8);
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }

}

