/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.text.Editable
 *  android.util.Log
 *  android.util.Patterns
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.IBinder;
import android.text.Editable;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ForgetPassword
extends AppCompatActivity {
    private Button button;
    private EditText editText_fp;
    private InputMethodManager imm;
    private ProgressDialog progressDialog;
    public Toolbar toolbar;

    private boolean isValidMail(String string2) {
        return Patterns.EMAIL_ADDRESS.matcher((CharSequence)string2).matches();
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    public void forgetPassword(String string2) {
        this.progressDialog.show();
        this.progressDialog.setMessage((CharSequence)this.getResources().getString(2131689610));
        this.progressDialog.setCancelable(false);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.forgetPassword);
        stringBuilder.append("&email=");
        stringBuilder.append(string2);
        String string3 = stringBuilder.toString();
        new AsyncHttpClient().get(string3, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                ForgetPassword.this.progressDialog.dismiss();
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                JSONArray jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                int n2 = 0;
                do {
                    block7 : {
                        try {
                            if (n2 < jSONArray.length()) {
                                JSONObject jSONObject = jSONArray.getJSONObject(n2);
                                String string3 = jSONObject.getString("msg");
                                if (jSONObject.getString("success").equals((Object)"1")) {
                                    Toast.makeText((Context)ForgetPassword.this, (CharSequence)string3, (int)0).show();
                                } else {
                                    Toast.makeText((Context)ForgetPassword.this, (CharSequence)string3, (int)0).show();
                                }
                                break block7;
                            }
                            ForgetPassword.this.progressDialog.dismiss();
                            return;
                        }
                        catch (JSONException jSONException) {
                            jSONException.printStackTrace();
                            return;
                        }
                    }
                    ++n2;
                } while (true);
            }
        });
    }

    protected void onCreate(Bundle bundle) {
        Button button;
        Toolbar toolbar;
        super.onCreate(bundle);
        this.setContentView(2131427359);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        this.progressDialog = new ProgressDialog((Context)this);
        this.imm = (InputMethodManager)this.getSystemService("input_method");
        this.getWindow().setSoftInputMode(2);
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131231173);
        toolbar.setTitle((CharSequence)this.getResources().getString(2131689577));
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.editText_fp = (EditText)this.findViewById(2131230879);
        this.button = button = (Button)this.findViewById(2131230823);
        button.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                ForgetPassword.this.editText_fp.clearFocus();
                ForgetPassword.this.imm.hideSoftInputFromWindow(ForgetPassword.this.editText_fp.getWindowToken(), 0);
                String string2 = ForgetPassword.this.editText_fp.getText().toString();
                ForgetPassword.this.editText_fp.setError(null);
                if (ForgetPassword.this.isValidMail(string2) && !string2.isEmpty()) {
                    if (Method.isNetworkAvailable((Activity)ForgetPassword.this)) {
                        ForgetPassword.this.editText_fp.setText((CharSequence)"");
                        ForgetPassword.this.forgetPassword(string2);
                        return;
                    }
                    ForgetPassword forgetPassword = ForgetPassword.this;
                    Toast.makeText((Context)forgetPassword, (CharSequence)forgetPassword.getResources().getString(2131689589), (int)0).show();
                    return;
                }
                ForgetPassword.this.editText_fp.requestFocus();
                ForgetPassword.this.editText_fp.setError((CharSequence)ForgetPassword.this.getResources().getString(2131689642));
            }
        });
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }

}

