/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.DatePickerDialog
 *  android.app.DatePickerDialog$OnDateSetListener
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.text.Editable
 *  android.util.Log
 *  android.util.Patterns
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.DatePicker
 *  android.widget.EditText
 *  android.widget.LinearLayout
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.List
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.IBinder;
import android.text.Editable;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.dewonderstruck.fireque.Item.RoomList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BookRoom
extends AppCompatActivity {
    private String adults;
    private int arr_day;
    private int arr_month;
    private int arr_year;
    private String arrivalDate;
    private Button button;
    private String children;
    private DatePickerDialog datePickerDialog;
    private int day;
    private String departureDate;
    private EditText editText_email;
    private EditText editText_name;
    private EditText editText_phoneNo;
    private String email;
    private InputMethodManager imm;
    private boolean isDate = false;
    private LinearLayout linearLayout;
    private Method method;
    private int month;
    private String name;
    private String[] number_adults;
    private String[] number_children;
    private String phoneNo;
    private ProgressDialog progressDialog;
    private String room;
    private ArrayList<String> room_data;
    private Spinner spinner_adults;
    private Spinner spinner_children;
    private Spinner spinner_room;
    private TextView textView_arrivalDate;
    private TextView textView_departureDate;
    public Toolbar toolbar;
    private int year;

    private boolean isValidMail(String string2) {
        return Patterns.EMAIL_ADDRESS.matcher((CharSequence)string2).matches();
    }

    public void adults_spinner() {
        String[] arrstring;
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < (arrstring = this.number_adults).length; ++i) {
            arrayList.add((Object)arrstring[i]);
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, (List)arrayList);
        arrayAdapter.setDropDownViewResource(17367049);
        this.spinner_adults.setAdapter((SpinnerAdapter)arrayAdapter);
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    public void booking(String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9) {
        this.progressDialog.show();
        this.progressDialog.setMessage((CharSequence)this.getResources().getString(2131689610));
        this.progressDialog.setCancelable(false);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.booking);
        stringBuilder.append(string2);
        stringBuilder.append("&email=");
        stringBuilder.append(string3);
        stringBuilder.append("&phone=");
        stringBuilder.append(string4);
        stringBuilder.append("&room_type=");
        stringBuilder.append(string5);
        stringBuilder.append("&adults=");
        stringBuilder.append(string6);
        stringBuilder.append("&children=");
        stringBuilder.append(string7);
        stringBuilder.append("&check_in_date=");
        stringBuilder.append(string8);
        stringBuilder.append("&check_out_date=");
        stringBuilder.append(string9);
        String string10 = stringBuilder.toString();
        new AsyncHttpClient().get(string10, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                BookRoom.this.progressDialog.dismiss();
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                block5 : {
                    JSONArray jSONArray;
                    int n2;
                    Log.d((String)"Response", (String)new String(arrby));
                    String string2 = new String(arrby);
                    try {
                        jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                        n2 = 0;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                    }
                    do {
                        block6 : {
                            if (n2 >= jSONArray.length()) break block5;
                            JSONObject jSONObject = jSONArray.getJSONObject(n2);
                            String string3 = jSONObject.getString("msg");
                            if (jSONObject.getString("success").equals((Object)"1")) {
                                Toast.makeText((Context)BookRoom.this, (CharSequence)string3, (int)0).show();
                                BookRoom.this.isDate = false;
                                BookRoom.this.editText_name.setText((CharSequence)"");
                                BookRoom.this.editText_email.setText((CharSequence)"");
                                BookRoom.this.editText_phoneNo.setText((CharSequence)"");
                                BookRoom.this.textView_arrivalDate.setText((CharSequence)BookRoom.this.getResources().getString(2131689525));
                                BookRoom.this.adults = "";
                                BookRoom.this.children = "";
                                BookRoom.this.room = "";
                                BookRoom.this.spinner_room.setSelection(0);
                                BookRoom.this.spinner_adults.setSelection(0);
                                BookRoom.this.spinner_children.setSelection(0);
                                BookRoom.this.arrivalDate = "";
                                BookRoom.this.departureDate = "";
                                break block6;
                            }
                            Toast.makeText((Context)BookRoom.this, (CharSequence)string3, (int)0).show();
                        }
                        ++n2;
                    } while (true);
                }
                BookRoom.this.progressDialog.dismiss();
            }
        });
    }

    public void children_spinner() {
        String[] arrstring;
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < (arrstring = this.number_children).length; ++i) {
            arrayList.add((Object)arrstring[i]);
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, (List)arrayList);
        arrayAdapter.setDropDownViewResource(17367049);
        this.spinner_children.setAdapter((SpinnerAdapter)arrayAdapter);
    }

    protected void onCreate(Bundle bundle) {
        Toolbar toolbar;
        ArrayList arrayList;
        super.onCreate(bundle);
        this.setContentView(2131427357);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        this.method = new Method((Activity)this);
        this.progressDialog = new ProgressDialog((Context)this);
        this.imm = (InputMethodManager)this.getSystemService("input_method");
        this.getWindow().setSoftInputMode(2);
        Calendar calendar = Calendar.getInstance();
        this.year = calendar.get(1);
        this.month = calendar.get(2);
        this.day = calendar.get(5);
        String[] arrstring = new String[]{this.getResources().getString(2131689519), "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        this.number_adults = arrstring;
        String[] arrstring2 = new String[]{this.getResources().getString(2131689534), "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        this.number_children = arrstring2;
        this.room_data = arrayList = new ArrayList();
        arrayList.add((Object)this.getResources().getString(2131689674));
        for (int i = 0; i < Constant_Api.roomLists.size(); ++i) {
            this.room_data.add((Object)((RoomList)Constant_Api.roomLists.get(i)).getRoom_name());
        }
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131231171);
        toolbar.setTitle((CharSequence)this.getResources().getString(2131689526));
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.editText_name = (EditText)this.findViewById(2131230881);
        this.editText_email = (EditText)this.findViewById(2131230875);
        this.editText_phoneNo = (EditText)this.findViewById(2131230887);
        this.spinner_room = (Spinner)this.findViewById(2131231078);
        this.spinner_adults = (Spinner)this.findViewById(2131231076);
        this.spinner_children = (Spinner)this.findViewById(2131231077);
        this.textView_arrivalDate = (TextView)this.findViewById(2131231123);
        this.button = (Button)this.findViewById(2131230821);
        this.linearLayout = (LinearLayout)this.findViewById(2131230953);
        if (Method.personalization_ad) {
            Method.showPersonalizedAds(this.linearLayout, (Activity)this);
        } else {
            Method.showNonPersonalizedAds(this.linearLayout, (Activity)this);
        }
        this.profile(this.method.pref.getString(this.method.profileId, null));
        this.spinner_adults.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                if (n == 0) {
                    ((TextView)adapterView.getChildAt(0)).setTextColor(BookRoom.this.getResources().getColor(2131034207));
                    BookRoom bookRoom = BookRoom.this;
                    bookRoom.adults = bookRoom.number_adults[n];
                    return;
                }
                ((TextView)adapterView.getChildAt(0)).setTextColor(BookRoom.this.getResources().getColor(2131034319));
                BookRoom bookRoom = BookRoom.this;
                bookRoom.adults = bookRoom.number_adults[n];
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.spinner_children.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                if (n == 0) {
                    ((TextView)adapterView.getChildAt(0)).setTextColor(BookRoom.this.getResources().getColor(2131034207));
                    BookRoom bookRoom = BookRoom.this;
                    bookRoom.children = bookRoom.number_children[n];
                    return;
                }
                ((TextView)adapterView.getChildAt(0)).setTextColor(BookRoom.this.getResources().getColor(2131034319));
                BookRoom bookRoom = BookRoom.this;
                bookRoom.children = bookRoom.number_children[n];
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.spinner_room.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                if (n == 0) {
                    ((TextView)adapterView.getChildAt(0)).setTextColor(BookRoom.this.getResources().getColor(2131034207));
                    BookRoom bookRoom = BookRoom.this;
                    bookRoom.room = ((String)bookRoom.room_data.get(n)).toString();
                    return;
                }
                ((TextView)adapterView.getChildAt(0)).setTextColor(BookRoom.this.getResources().getColor(2131034319));
                BookRoom bookRoom = BookRoom.this;
                bookRoom.room = ((String)bookRoom.room_data.get(n)).toString();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.textView_arrivalDate.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                BookRoom bookRoom = BookRoom.this;
                DatePickerDialog datePickerDialog = new DatePickerDialog((Context)BookRoom.this, new DatePickerDialog.OnDateSetListener(){

                    public void onDateSet(DatePicker datePicker, int n, int n2, int n3) {
                        BookRoom.this.arr_year = n;
                        BookRoom.this.arr_month = n2;
                        BookRoom.this.arr_day = n3;
                        BookRoom.this.isDate = true;
                        BookRoom.this.arrivalDate = BookRoom.this.selectDate(n3, n2, n);
                        BookRoom.this.textView_arrivalDate.setText((CharSequence)BookRoom.this.arrivalDate);
                    }
                }, BookRoom.this.year, BookRoom.this.month, BookRoom.this.day);
                bookRoom.datePickerDialog = datePickerDialog;
                BookRoom.this.datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000L);
                BookRoom.this.datePickerDialog.show();
            }

        });
        this.button.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                BookRoom.this.submit();
            }
        });
        this.room_spinner();
        this.adults_spinner();
        this.children_spinner();
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }

    public void profile(String string2) {
        this.progressDialog.show();
        this.progressDialog.setMessage((CharSequence)this.getResources().getString(2131689610));
        this.progressDialog.setCancelable(false);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.profile);
        stringBuilder.append(string2);
        String string3 = stringBuilder.toString();
        new AsyncHttpClient().get(string3, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                BookRoom.this.progressDialog.dismiss();
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                String string3 = null;
                String string4 = null;
                String string5 = null;
                JSONArray jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                int n2 = 0;
                do {
                    if (n2 >= jSONArray.length()) break;
                    JSONObject jSONObject = jSONArray.getJSONObject(n2);
                    jSONObject.getString("user_id");
                    string3 = jSONObject.getString("name");
                    string4 = jSONObject.getString("email");
                    string5 = jSONObject.getString("phone");
                    jSONObject.getString("success");
                    ++n2;
                } while (true);
                try {
                    BookRoom.this.progressDialog.dismiss();
                    BookRoom.this.editText_name.setText(string3);
                    BookRoom.this.editText_email.setText(string4);
                    BookRoom.this.editText_phoneNo.setText((CharSequence)string5);
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                }
                BookRoom.this.progressDialog.dismiss();
            }
        });
    }

    public void room_spinner() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.room_data.size(); ++i) {
            arrayList.add((Object)((String)this.room_data.get(i)).toString());
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, (List)arrayList);
        arrayAdapter.setDropDownViewResource(17367049);
        this.spinner_room.setAdapter((SpinnerAdapter)arrayAdapter);
    }

    public String selectDate(int n, int n2, int n3) {
        String string2;
        String string3;
        if (n2 + 1 < 10) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("0");
            stringBuilder.append(String.valueOf((int)(n2 + 1)));
            string3 = stringBuilder.toString();
        } else {
            string3 = String.valueOf((int)(n2 + 1));
        }
        if (n < 10) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("0");
            stringBuilder.append(String.valueOf((int)n));
            string2 = stringBuilder.toString();
        } else {
            string2 = String.valueOf((int)n);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append("/");
        stringBuilder.append(string3);
        stringBuilder.append("/");
        stringBuilder.append(String.valueOf((int)n3));
        return stringBuilder.toString();
    }

    public void submit() {
        this.name = this.editText_name.getText().toString();
        this.email = this.editText_email.getText().toString();
        this.phoneNo = this.editText_phoneNo.getText().toString();
        this.editText_name.clearFocus();
        this.editText_email.clearFocus();
        this.editText_phoneNo.clearFocus();
        this.imm.hideSoftInputFromWindow(this.editText_name.getWindowToken(), 0);
        this.imm.hideSoftInputFromWindow(this.editText_email.getWindowToken(), 0);
        this.imm.hideSoftInputFromWindow(this.editText_phoneNo.getWindowToken(), 0);
        if (!this.name.isEmpty() && !this.name.equals((Object)"")) {
            if (this.isValidMail(this.email) && !this.email.isEmpty()) {
                if (!this.phoneNo.isEmpty() && !this.phoneNo.equals((Object)"")) {
                    if (!this.room.equals((Object)this.getResources().getString(2131689674)) && !this.room.equals((Object)"")) {
                        if (!this.adults.equals((Object)this.getResources().getString(2131689519)) && !this.adults.equals((Object)"")) {
                            if (!this.children.equals((Object)this.getResources().getString(2131689534)) && !this.children.equals((Object)"")) {
                                String string2 = this.arrivalDate;
                                if (string2 != null && !string2.equals((Object)"")) {
                                    this.booking(this.name, this.email, this.phoneNo, this.room, this.adults, this.children, this.arrivalDate, this.departureDate);
                                    return;
                                }
                                Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689648), (int)0).show();
                                return;
                            }
                            Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689649), (int)0).show();
                            return;
                        }
                        Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689647), (int)0).show();
                        return;
                    }
                    Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689652), (int)0).show();
                    return;
                }
                this.editText_phoneNo.requestFocus();
                this.editText_phoneNo.setError((CharSequence)this.getResources().getString(2131689643));
                return;
            }
            this.editText_email.requestFocus();
            this.editText_email.setError((CharSequence)this.getResources().getString(2131689642));
            return;
        }
        this.editText_name.requestFocus();
        this.editText_name.setError((CharSequence)this.getResources().getString(2131689643));
    }

}

