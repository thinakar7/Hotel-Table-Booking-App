/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.Window
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.TextView
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.dewonderstruck.fireque.Activity.EditProfile;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Profile
extends AppCompatActivity {
    private String email;
    private LinearLayout linearLayout;
    private Method method;
    private String name;
    private String phone;
    private ProgressBar progressBar;
    private String success;
    private TextView textViewEmail;
    private TextView textViewName;
    private TextView textViewPhone;
    public Toolbar toolbar;
    private String user_id;

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    protected void onCreate(Bundle bundle) {
        Toolbar toolbar;
        super.onCreate(bundle);
        this.setContentView(2131427365);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        this.method = new Method((Activity)this);
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131231178);
        toolbar.setTitle((CharSequence)this.getResources().getString(2131689655));
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.progressBar = (ProgressBar)this.findViewById(2131231013);
        this.textViewName = (TextView)this.findViewById(2131231136);
        this.textViewEmail = (TextView)this.findViewById(2131231128);
        this.textViewPhone = (TextView)this.findViewById(2131231140);
        this.linearLayout = (LinearLayout)this.findViewById(2131230958);
        this.progressBar.setVisibility(8);
        this.profile(this.method.pref.getString(this.method.profileId, null));
    }

    public boolean onCreateOptionsMenu(Menu menu2) {
        this.getMenuInflater().inflate(2131492867, menu2);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int n = menuItem.getItemId();
        if (n != 16908332) {
            if (n == 2131230790) {
                this.startActivity(new Intent((Context)this, EditProfile.class).putExtra("name", this.name).putExtra("email", this.email).putExtra("phone", this.phone).putExtra("profileId", this.method.pref.getString(this.method.profileId, null)));
            }
        } else {
            this.onBackPressed();
        }
        return true;
    }

    public void profile(String string2) {
        this.progressBar.setVisibility(0);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.profile);
        stringBuilder.append(string2);
        String string3 = stringBuilder.toString();
        new AsyncHttpClient().get(string3, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                Profile.this.progressBar.setVisibility(8);
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                JSONArray jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                int n2 = 0;
                do {
                    if (n2 >= jSONArray.length()) break;
                    JSONObject jSONObject = jSONArray.getJSONObject(n2);
                    Profile.this.user_id = jSONObject.getString("user_id");
                    Profile.this.name = jSONObject.getString("name");
                    Profile.this.email = jSONObject.getString("email");
                    Profile.this.phone = jSONObject.getString("phone");
                    Profile.this.success = jSONObject.getString("success");
                    ++n2;
                } while (true);
                try {
                    Profile.this.progressBar.setVisibility(8);
                    Profile.this.textViewName.setText((CharSequence)Profile.this.name);
                    Profile.this.textViewEmail.setText((CharSequence)Profile.this.email);
                    Profile.this.textViewPhone.setText((CharSequence)Profile.this.phone);
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

}

