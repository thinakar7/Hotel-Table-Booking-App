/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.text.Html
 *  android.view.View
 *  android.view.Window
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  java.lang.CharSequence
 *  java.lang.String
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.dewonderstruck.fireque.Item.AboutUsList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;

public class PrivacyPolice
extends AppCompatActivity {
    private LinearLayout linearLayout;
    private Method method;
    private TextView privacy_policy_textview;
    public Toolbar toolbar;

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    protected void onCreate(Bundle bundle) {
        Toolbar toolbar;
        super.onCreate(bundle);
        this.setContentView(2131427364);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        Method.trackScreenView((Activity)this, this.getResources().getString(2131689654));
        this.method = new Method((Activity)this);
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131231177);
        toolbar.setTitle((CharSequence)this.getResources().getString(2131689654));
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.privacy_policy_textview = (TextView)this.findViewById(2131231165);
        this.linearLayout = (LinearLayout)this.findViewById(2131230957);
        if (Method.personalization_ad) {
            Method.showPersonalizedAds(this.linearLayout, (Activity)this);
        } else {
            Method.showNonPersonalizedAds(this.linearLayout, (Activity)this);
        }
        if (Constant_Api.aboutUsList != null) {
            this.privacy_policy_textview.setText((CharSequence)Html.fromHtml((String)Constant_Api.aboutUsList.getApp_privacy_policy()));
        }
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }
}

