/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.view.Window
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  androidx.recyclerview.widget.RecyclerView$OnItemTouchListener
 *  androidx.viewpager.widget.PagerAdapter
 *  androidx.viewpager.widget.ViewPager
 *  androidx.viewpager.widget.ViewPager$OnPageChangeListener
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.dewonderstruck.fireque.Adapter.GalleryDetailAdapter;
import com.dewonderstruck.fireque.Adapter.GalleryRecyclerAdapter;
import com.dewonderstruck.fireque.Item.GalleryDetailList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.dewonderstruck.fireque.Util.RecyclerTouchListener;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GalleryDetail
extends AppCompatActivity {
    private GalleryDetailAdapter galleryDetailAdapter;
    private List<GalleryDetailList> galleryDetailLists;
    private GalleryRecyclerAdapter galleryRecyclerAdapter;
    private LinearLayout linearLayout;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private int selectPosition;
    private String selectedId;
    private TextView textView;
    private String title;
    public Toolbar toolbar;
    private ViewPager viewPager;
    ViewPager.OnPageChangeListener viewPagerPageChangeListener = new ViewPager.OnPageChangeListener(){

        public void onPageScrollStateChanged(int n) {
        }

        public void onPageScrolled(int n, float f, int n2) {
        }

        public void onPageSelected(int n) {
        }
    };

    private void setCurrentItem(int n) {
        this.viewPager.setCurrentItem(n, false);
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    public void galleryDetail() {
        this.progressBar.setVisibility(0);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.galleryDetail);
        stringBuilder.append(this.selectedId);
        String string2 = stringBuilder.toString();
        new AsyncHttpClient().get(string2, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                GalleryDetail.this.progressBar.setVisibility(8);
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                JSONArray jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                int n2 = 0;
                do {
                    if (n2 >= jSONArray.length()) break;
                    JSONObject jSONObject = jSONArray.getJSONObject(n2);
                    String string3 = jSONObject.getString("id");
                    String string4 = jSONObject.getString("cat_id");
                    String string5 = jSONObject.getString("wallpaper_image");
                    String string6 = jSONObject.getString("wallpaper_image_thumb");
                    String string7 = jSONObject.getString("category_name");
                    List list = GalleryDetail.this.galleryDetailLists;
                    GalleryDetailList galleryDetailList = new GalleryDetailList(string3, string4, string5, string6, string7);
                    list.add((Object)galleryDetailList);
                    ++n2;
                } while (true);
                try {
                    if (GalleryDetail.this.galleryDetailLists.size() == 0) {
                        GalleryDetail.this.textView.setVisibility(0);
                        GalleryDetail.this.progressBar.setVisibility(8);
                        GalleryDetail.this.viewPager.setVisibility(8);
                    } else {
                        GalleryDetail galleryDetail = GalleryDetail.this;
                        galleryDetail.galleryDetailAdapter = new GalleryDetailAdapter((Activity)galleryDetail, (List<GalleryDetailList>)galleryDetail.galleryDetailLists);
                        GalleryDetail.this.viewPager.setAdapter((PagerAdapter)GalleryDetail.this.galleryDetailAdapter);
                        GalleryDetail.this.viewPager.addOnPageChangeListener(GalleryDetail.this.viewPagerPageChangeListener);
                        GalleryDetail.this.viewPager.setOffscreenPageLimit(GalleryDetail.this.galleryDetailLists.size());
                        GalleryDetail galleryDetail2 = GalleryDetail.this;
                        galleryDetail2.galleryRecyclerAdapter = new GalleryRecyclerAdapter((Activity)galleryDetail2, (List<GalleryDetailList>)galleryDetail2.galleryDetailLists);
                        GalleryDetail.this.recyclerView.setAdapter((RecyclerView.Adapter)GalleryDetail.this.galleryRecyclerAdapter);
                        GalleryDetail.this.progressBar.setVisibility(8);
                    }
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131427360);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        Method.trackScreenView((Activity)this, this.getResources().getString(2131689579));
        this.galleryDetailLists = new ArrayList();
        Intent intent = this.getIntent();
        this.selectedId = intent.getStringExtra("id");
        this.title = intent.getStringExtra("title");
        this.selectPosition = intent.getIntExtra("position", 0);
        this.toolbar = (Toolbar)this.findViewById(2131231174);
        this.viewPager = (ViewPager)this.findViewById(2131231193);
        this.recyclerView = (RecyclerView)this.findViewById(2131231022);
        this.textView = (TextView)this.findViewById(2131231130);
        this.progressBar = (ProgressBar)this.findViewById(2131231004);
        this.linearLayout = (LinearLayout)this.findViewById(2131230955);
        if (Method.personalization_ad) {
            Method.showPersonalizedAds(this.linearLayout, (Activity)this);
        } else {
            Method.showNonPersonalizedAds(this.linearLayout, (Activity)this);
        }
        this.recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager((Context)this, 0, false);
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        RecyclerView recyclerView = this.recyclerView;
        recyclerView.addOnItemTouchListener((RecyclerView.OnItemTouchListener)new RecyclerTouchListener((Context)this, recyclerView, new GalleryRecyclerAdapter.ClickListener(){

            @Override
            public void onClick(View view, int n) {
                GalleryDetail.this.viewPager.setCurrentItem(n);
            }

            @Override
            public void onLongClick(View view, int n) {
            }
        }));
        this.textView.setVisibility(8);
        this.toolbar.setTitle((CharSequence)this.title);
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        if (Method.isNetworkAvailable((Activity)this)) {
            this.galleryDetail();
        } else {
            Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689589), (int)0).show();
            this.progressBar.setVisibility(8);
        }
        this.setCurrentItem(this.selectPosition);
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }

}

