/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.Window
 *  android.widget.LinearLayout
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.viewpager.widget.PagerAdapter
 *  androidx.viewpager.widget.ViewPager
 *  androidx.viewpager.widget.ViewPager$OnPageChangeListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.dewonderstruck.fireque.Activity.Location;
import com.dewonderstruck.fireque.Adapter.RoomDetailAdapter;
import com.dewonderstruck.fireque.Item.RoomList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import java.util.List;

public class RoomDetail
extends AppCompatActivity {
    private LinearLayout linearLayout;
    private RoomDetailAdapter roomDetailAdapter;
    private int selectPosition = 0;
    private Toolbar toolbar;
    private ViewPager viewPager;
    ViewPager.OnPageChangeListener viewPagerPageChangeListener = new ViewPager.OnPageChangeListener(){

        public void onPageScrollStateChanged(int n) {
        }

        public void onPageScrolled(int n, float f, int n2) {
        }

        public void onPageSelected(int n) {
            RoomDetail.this.toolbar.setTitle((CharSequence)((RoomList)Constant_Api.roomLists.get(n)).getRoom_name());
        }
    };

    private void setCurrentItem(int n) {
        this.viewPager.setCurrentItem(n, false);
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    protected void onCreate(Bundle bundle) {
        RoomDetailAdapter roomDetailAdapter;
        super.onCreate(bundle);
        this.setContentView(2131427367);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        Method.trackScreenView((Activity)this, this.getResources().getString(2131689662));
        this.selectPosition = this.getIntent().getIntExtra("position", 0);
        this.toolbar = (Toolbar)this.findViewById(2131231179);
        this.viewPager = (ViewPager)this.findViewById(2131231194);
        this.toolbar.setTitle((CharSequence)((RoomList)Constant_Api.roomLists.get(this.selectPosition)).getRoom_name());
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.linearLayout = (LinearLayout)this.findViewById(2131230960);
        if (Method.personalization_ad) {
            Method.showPersonalizedAds(this.linearLayout, (Activity)this);
        } else {
            Method.showNonPersonalizedAds(this.linearLayout, (Activity)this);
        }
        this.roomDetailAdapter = roomDetailAdapter = new RoomDetailAdapter(Constant_Api.roomLists, (Activity)this);
        this.viewPager.setAdapter((PagerAdapter)roomDetailAdapter);
        this.viewPager.addOnPageChangeListener(this.viewPagerPageChangeListener);
        this.viewPager.setOffscreenPageLimit(Constant_Api.roomLists.size());
        this.setCurrentItem(this.selectPosition);
    }

    public boolean onCreateOptionsMenu(Menu menu2) {
        this.getMenuInflater().inflate(2131492866, menu2);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int n = menuItem.getItemId();
        if (n != 16908332) {
            if (n == 2131230913) {
                this.startActivity(new Intent((Context)this, Location.class));
            }
        } else {
            this.onBackPressed();
        }
        return true;
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }

}

