/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.Window
 *  android.widget.LinearLayout
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.ActionBarDrawerToggle
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.drawerlayout.widget.DrawerLayout
 *  androidx.drawerlayout.widget.DrawerLayout$DrawerListener
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentTransaction
 *  com.google.ads.consent.ConsentForm
 *  com.google.android.material.navigation.NavigationView
 *  com.google.android.material.navigation.NavigationView$OnNavigationItemSelectedListener
 *  cz.msebera.android.httpclient.Header
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  org.greenrobot.eventbus.Subscribe
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.dewonderstruck.fireque.Activity.Login;
import com.dewonderstruck.fireque.Activity.Profile;
import com.dewonderstruck.fireque.Fragment.ContactUsFragment;
import com.dewonderstruck.fireque.Fragment.GalleryFragment;
import com.dewonderstruck.fireque.Fragment.HomeFragment;
import com.dewonderstruck.fireque.Fragment.LocationFragment;
import com.dewonderstruck.fireque.Fragment.RoomFragment;
import com.dewonderstruck.fireque.Item.AboutUsList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Events;
import com.dewonderstruck.fireque.Util.GlobalBus;
import com.dewonderstruck.fireque.Util.Method;
import com.google.ads.consent.ConsentForm;
import com.google.android.material.navigation.NavigationView;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import org.greenrobot.eventbus.Subscribe;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity
extends AppCompatActivity
implements NavigationView.OnNavigationItemSelectedListener {
    public static Toolbar toolbar;
    boolean doubleBackToExitPressedOnce = false;
    private DrawerLayout drawer;
    private ConsentForm form;
    private LinearLayout linearLayout;
    private Method method;
    private NavigationView navigationView;

    private void showForm() {
        ConsentForm consentForm = this.form;
        if (consentForm != null) {
            consentForm.show();
        }
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)ViewPumpContextWrapper.wrap(context));
    }

    @Subscribe
    public void getLogin(Events.Login login) {
        NavigationView navigationView;
        Method method = this.method;
        if (method != null && method.pref.getBoolean(this.method.pref_login, false) && (navigationView = this.navigationView) != null) {
            navigationView.getMenu().getItem(8).setIcon(2131165378);
            this.navigationView.getMenu().getItem(8).setTitle((CharSequence)this.getResources().getString(2131689516));
        }
    }

    public void loadAppDetail() {
        new AsyncHttpClient().get(Constant_Api.app_detail, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                block4 : {
                    JSONArray jSONArray;
                    Log.d((String)"Response", (String)new String(arrby));
                    String string2 = new String(arrby);
                    try {
                        jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        break block4;
                    }
                    for (int i = 0; i < jSONArray.length(); ++i) {
                        AboutUsList aboutUsList;
                        JSONObject jSONObject = jSONArray.getJSONObject(i);
                        String string3 = jSONObject.getString("app_name");
                        String string4 = jSONObject.getString("app_logo");
                        String string5 = jSONObject.getString("app_version");
                        String string6 = jSONObject.getString("app_author");
                        String string7 = jSONObject.getString("app_contact");
                        String string8 = jSONObject.getString("app_email");
                        String string9 = jSONObject.getString("app_website");
                        String string10 = jSONObject.getString("app_description");
                        String string11 = jSONObject.getString("app_developed_by");
                        String string12 = jSONObject.getString("app_privacy_policy");
                        String string13 = jSONObject.getString("publisher_id");
                        boolean bl = Boolean.parseBoolean((String)jSONObject.getString("interstital_ad"));
                        String string14 = jSONObject.getString("interstital_ad_id");
                        String string15 = jSONObject.getString("interstital_ad_click");
                        boolean bl2 = Boolean.parseBoolean((String)jSONObject.getString("banner_ad"));
                        String string16 = jSONObject.getString("banner_ad_id");
                        Constant_Api.aboutUsList = aboutUsList = new AboutUsList(string3, string4, string5, string6, string7, string8, string9, string10, string11, string12, string13, string14, string15, string16, bl, bl2);
                    }
                }
                if (!Constant_Api.aboutUsList.getInterstital_ad_click().equals((Object)"")) {
                    Constant_Api.AD_COUNT_SHOW = Integer.parseInt((String)Constant_Api.aboutUsList.getInterstital_ad_click());
                }
            }
        });
    }

    public void onBackPressed() {
        DrawerLayout drawerLayout = (DrawerLayout)this.findViewById(2131230872);
        if (drawerLayout.isDrawerOpen(8388611)) {
            drawerLayout.closeDrawer(8388611);
            return;
        }
        if (this.doubleBackToExitPressedOnce) {
            super.onBackPressed();
        }
        this.doubleBackToExitPressedOnce = true;
        Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689474), (int)0).show();
        new Handler().postDelayed(new Runnable(){

            public void run() {
                MainActivity.this.doubleBackToExitPressedOnce = false;
            }
        }, 2000L);
    }

    protected void onCreate(Bundle bundle) {
        NavigationView navigationView;
        DrawerLayout drawerLayout;
        Toolbar toolbar;
        super.onCreate(bundle);
        this.setContentView(2131427363);
        GlobalBus.getBus().register((Object)this);
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        this.method = new Method((Activity)this);
        MainActivity.toolbar = toolbar = (Toolbar)this.findViewById(2131231176);
        toolbar.setTitleTextColor(-1);
        MainActivity.toolbar.setSubtitleTextColor(-1);
        this.setSupportActionBar(MainActivity.toolbar);
        this.getSupportActionBar().setTitle((CharSequence)this.getResources().getString(2131689588));
        this.linearLayout = (LinearLayout)this.findViewById(2131230952);
        this.drawer = drawerLayout = (DrawerLayout)this.findViewById(2131230872);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle((Activity)this, drawerLayout, MainActivity.toolbar, 2131689627, 2131689626);
        this.drawer.setDrawerListener((DrawerLayout.DrawerListener)actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        MainActivity.toolbar.setNavigationIcon(2131165334);
        this.navigationView = navigationView = (NavigationView)this.findViewById(2131230978);
        navigationView.setNavigationItemSelectedListener((NavigationView.OnNavigationItemSelectedListener)this);
        if (Method.isNetworkAvailable((Activity)this)) {
            this.loadAppDetail();
        } else {
            Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689589), (int)0).show();
        }
        if (bundle != null) {
            (HomeFragment)this.getSupportFragmentManager().findFragmentByTag("home");
        } else {
            HomeFragment homeFragment = new HomeFragment();
            this.getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)homeFragment, "home").commit();
            Method.onBackPress = true;
        }
        Method.trackScreenView((Activity)this, this.getResources().getString(2131689620));
    }

    protected void onDestroy() {
        GlobalBus.getBus().unregister((Object)this);
        super.onDestroy();
    }

    public boolean onNavigationItemSelected(MenuItem menuItem) {
        if (menuItem.isChecked()) {
            menuItem.setChecked(false);
        } else {
            menuItem.setChecked(true);
        }
        this.drawer.closeDrawers();
        switch (menuItem.getItemId()) {
            default: {
                return true;
            }
            case 2131231035: {
                this.getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new RoomFragment(), "room").commit();
                return true;
            }
            case 2131231002: {
                if (Method.isNetworkAvailable((Activity)this)) {
                    if (this.method.pref.getBoolean(this.method.pref_login, false)) {
                        this.startActivity(new Intent((Context)this, Profile.class));
                        return true;
                    }
                    Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689687), (int)0).show();
                    return true;
                }
                Toast.makeText((Context)this, (CharSequence)this.getResources().getString(2131689589), (int)0).show();
                return true;
            }
            case 2131230966: {
                if (this.method.pref.getBoolean(this.method.pref_login, false)) {
                    this.method.editor.putBoolean(this.method.pref_login, false);
                    this.method.editor.commit();
                    this.startActivity(new Intent((Context)this, Login.class));
                } else {
                    this.startActivity(new Intent((Context)this, Login.class));
                    this.drawer.closeDrawers();
                }
                this.finishAffinity();
                return true;
            }
            case 2131230965: {
                toolbar.setTitle((CharSequence)this.getResources().getString(2131689611));
                this.getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new LocationFragment(), "location").commitAllowingStateLoss();
                return true;
            }
            case 2131230910: {
                this.getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new HomeFragment(), "home").commit();
                return true;
            }
            case 2131230905: {
                this.getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new GalleryFragment(), "gallery").commit();
                return true;
            }
            case 2131230843: 
        }
        this.getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new ContactUsFragment(), "contactus").commit();
        return true;
    }

}

