/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  android.view.Window
 *  androidx.appcompat.app.AppCompatActivity
 *  cz.msebera.android.httpclient.Header
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Window;
import androidx.appcompat.app.AppCompatActivity;
import com.dewonderstruck.fireque.Activity.Login;
import com.dewonderstruck.fireque.Activity.MainActivity;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SplashScreen
extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 2000;
    private Method method;

    static /* synthetic */ Method access$000(SplashScreen splashScreen) {
        return splashScreen.method;
    }

    public void login(String string2, String string3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.login);
        stringBuilder.append("&email=");
        stringBuilder.append(string2);
        stringBuilder.append("&password=");
        stringBuilder.append(string3);
        String string4 = stringBuilder.toString();
        new AsyncHttpClient().get(string4, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                JSONArray jSONArray;
                int n2;
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                try {
                    jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                    n2 = 0;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
                do {
                    block5 : {
                        if (n2 >= jSONArray.length()) break;
                        if (jSONArray.getJSONObject(n2).getString("success").equals((Object)"1")) {
                            Intent intent = new Intent((Context)SplashScreen.this, MainActivity.class);
                            SplashScreen.this.startActivity(intent);
                            SplashScreen.this.finish();
                            break block5;
                        }
                        SplashScreen.access$000((SplashScreen)SplashScreen.this).editor.putBoolean(SplashScreen.access$000((SplashScreen)SplashScreen.this).pref_login, false);
                        SplashScreen.access$000((SplashScreen)SplashScreen.this).editor.commit();
                        SplashScreen.this.startActivity(new Intent((Context)SplashScreen.this, Login.class));
                        SplashScreen.this.finish();
                    }
                    ++n2;
                } while (true);
                return;
            }
        });
    }

    protected void onCreate(Bundle bundle) {
        Method method;
        super.onCreate(bundle);
        this.setContentView(2131427368);
        this.method = method = new Method((Activity)this);
        method.login();
        Method.forceRTLIfSupported(this.getWindow(), (Activity)this);
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = this.getWindow();
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(this.getResources().getColor(2131034173));
        }
        if (Method.isNetworkAvailable((Activity)this)) {
            new Handler().postDelayed(new Runnable(){

                public void run() {
                    if (SplashScreen.access$000((SplashScreen)SplashScreen.this).pref.getBoolean(SplashScreen.access$000((SplashScreen)SplashScreen.this).pref_login, false)) {
                        Log.d((String)"value", (String)String.valueOf((boolean)SplashScreen.access$000((SplashScreen)SplashScreen.this).pref.getBoolean(SplashScreen.access$000((SplashScreen)SplashScreen.this).pref_login, false)));
                        SplashScreen splashScreen = SplashScreen.this;
                        splashScreen.login(SplashScreen.access$000((SplashScreen)splashScreen).pref.getString(SplashScreen.access$000((SplashScreen)SplashScreen.this).userEmail, null), SplashScreen.access$000((SplashScreen)SplashScreen.this).pref.getString(SplashScreen.access$000((SplashScreen)SplashScreen.this).userPassword, null));
                        return;
                    }
                    Intent intent = new Intent((Context)SplashScreen.this, Login.class);
                    SplashScreen.this.startActivity(intent);
                    SplashScreen.this.finish();
                }
            }, (long)SPLASH_TIME_OUT);
            return;
        }
        this.method.editor.putBoolean(this.method.pref_login, false);
        this.method.editor.commit();
        this.startActivity(new Intent((Context)this, Login.class));
    }

    protected void onDestroy() {
        super.onDestroy();
    }

}

