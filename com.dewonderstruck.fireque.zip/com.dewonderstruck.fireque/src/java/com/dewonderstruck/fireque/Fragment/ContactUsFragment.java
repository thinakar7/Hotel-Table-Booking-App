/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.text.Editable
 *  android.util.Log
 *  android.util.Patterns
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.Window
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Toast
 *  androidx.appcompat.widget.Toolbar
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Fragment;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.IBinder;
import android.text.Editable;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.dewonderstruck.fireque.Activity.MainActivity;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ContactUsFragment
extends Fragment {
    private Button button_submit;
    private String description;
    private EditText editText_description;
    private EditText editText_email;
    private EditText editText_name;
    private EditText editText_phoneNumber;
    private EditText editText_subject;
    private String email;
    private InputMethodManager imm;
    private Method method;
    private String name;
    private String phoneNumber;
    private ProgressDialog progressDialog;
    private String subject;

    private boolean isValidMail(String string2) {
        return Patterns.EMAIL_ADDRESS.matcher((CharSequence)string2).matches();
    }

    public void contactUs() {
        this.progressDialog.show();
        this.progressDialog.setMessage((CharSequence)this.getResources().getString(2131689610));
        this.progressDialog.setCancelable(false);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant_Api.contact_us);
        stringBuilder.append("name=");
        stringBuilder.append(this.name);
        stringBuilder.append("&email=");
        stringBuilder.append(this.email);
        stringBuilder.append("&phone=");
        stringBuilder.append(this.phoneNumber);
        stringBuilder.append("&subject=");
        stringBuilder.append(this.subject);
        stringBuilder.append("&message=");
        stringBuilder.append(this.description);
        String string2 = stringBuilder.toString();
        new AsyncHttpClient().get(string2, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                ContactUsFragment.this.progressDialog.dismiss();
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                block5 : {
                    JSONArray jSONArray;
                    int n2;
                    Log.d((String)"Response", (String)new String(arrby));
                    String string2 = new String(arrby);
                    try {
                        jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                        n2 = 0;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                    }
                    do {
                        block6 : {
                            if (n2 > jSONArray.length()) break block5;
                            JSONObject jSONObject = jSONArray.getJSONObject(n2);
                            String string3 = jSONObject.getString("msg");
                            if (jSONObject.getString("success").equals((Object)"1")) {
                                Toast.makeText((Context)ContactUsFragment.this.getActivity(), (CharSequence)string3, (int)0).show();
                                break block6;
                            }
                            Toast.makeText((Context)ContactUsFragment.this.getActivity(), (CharSequence)string3, (int)0).show();
                        }
                        ++n2;
                    } while (true);
                }
                ContactUsFragment.this.progressDialog.dismiss();
            }
        });
    }

    public void form() {
        this.editText_name.setError(null);
        this.editText_email.setError(null);
        this.editText_phoneNumber.setError(null);
        this.editText_subject.setError(null);
        this.editText_description.setError(null);
        if (!this.name.isEmpty() && !this.name.equals((Object)"")) {
            if (this.isValidMail(this.email) && !this.email.isEmpty()) {
                if (this.phoneNumber.isEmpty()) {
                    this.editText_phoneNumber.requestFocus();
                    this.editText_phoneNumber.setError((CharSequence)this.getResources().getString(2131689638));
                    return;
                }
                if (!this.subject.isEmpty() && !this.subject.equals((Object)"")) {
                    if (!this.description.isEmpty() && !this.description.equals((Object)"")) {
                        this.editText_name.setText((CharSequence)"");
                        this.editText_email.setText((CharSequence)"");
                        this.editText_phoneNumber.setText((CharSequence)"");
                        this.editText_subject.setText((CharSequence)"");
                        this.editText_description.setText((CharSequence)"");
                        this.contactUs();
                        return;
                    }
                    this.editText_description.requestFocus();
                    this.editText_description.setError((CharSequence)this.getResources().getString(2131689565));
                    return;
                }
                this.editText_subject.requestFocus();
                this.editText_subject.setError((CharSequence)this.getResources().getString(2131689682));
                return;
            }
            this.editText_email.requestFocus();
            this.editText_email.setError((CharSequence)this.getResources().getString(2131689569));
            return;
        }
        this.editText_name.requestFocus();
        this.editText_name.setError((CharSequence)this.getResources().getString(2131689624));
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Button button;
        View view = LayoutInflater.from((Context)this.getContext()).inflate(2131427371, viewGroup, false);
        this.method = new Method((Activity)this.getActivity());
        this.progressDialog = new ProgressDialog((Context)this.getActivity());
        MainActivity.toolbar.setTitle((CharSequence)this.getResources().getString(2131689560));
        this.imm = (InputMethodManager)this.getActivity().getSystemService("input_method");
        this.getActivity().getWindow().setSoftInputMode(2);
        this.editText_name = (EditText)view.findViewById(2131231134);
        this.editText_email = (EditText)view.findViewById(2131231127);
        this.editText_phoneNumber = (EditText)view.findViewById(2131231139);
        this.editText_subject = (EditText)view.findViewById(2131231154);
        this.editText_description = (EditText)view.findViewById(2131231124);
        this.button_submit = button = (Button)view.findViewById(2131230822);
        button.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (Method.isNetworkAvailable((Activity)ContactUsFragment.this.getActivity())) {
                    ContactUsFragment contactUsFragment = ContactUsFragment.this;
                    contactUsFragment.name = contactUsFragment.editText_name.getText().toString();
                    ContactUsFragment contactUsFragment2 = ContactUsFragment.this;
                    contactUsFragment2.email = contactUsFragment2.editText_email.getText().toString();
                    ContactUsFragment contactUsFragment3 = ContactUsFragment.this;
                    contactUsFragment3.phoneNumber = contactUsFragment3.editText_phoneNumber.getText().toString();
                    ContactUsFragment contactUsFragment4 = ContactUsFragment.this;
                    contactUsFragment4.subject = contactUsFragment4.editText_subject.getText().toString();
                    ContactUsFragment contactUsFragment5 = ContactUsFragment.this;
                    contactUsFragment5.description = contactUsFragment5.editText_description.getText().toString();
                    ContactUsFragment.this.editText_name.clearFocus();
                    ContactUsFragment.this.editText_email.clearFocus();
                    ContactUsFragment.this.editText_phoneNumber.clearFocus();
                    ContactUsFragment.this.editText_subject.clearFocus();
                    ContactUsFragment.this.editText_description.clearFocus();
                    ContactUsFragment.this.imm.hideSoftInputFromWindow(ContactUsFragment.this.editText_name.getWindowToken(), 0);
                    ContactUsFragment.this.imm.hideSoftInputFromWindow(ContactUsFragment.this.editText_email.getWindowToken(), 0);
                    ContactUsFragment.this.imm.hideSoftInputFromWindow(ContactUsFragment.this.editText_phoneNumber.getWindowToken(), 0);
                    ContactUsFragment.this.imm.hideSoftInputFromWindow(ContactUsFragment.this.editText_subject.getWindowToken(), 0);
                    ContactUsFragment.this.imm.hideSoftInputFromWindow(ContactUsFragment.this.editText_description.getWindowToken(), 0);
                    ContactUsFragment.this.form();
                    return;
                }
                Toast.makeText((Context)ContactUsFragment.this.getActivity(), (CharSequence)ContactUsFragment.this.getResources().getString(2131689589), (int)0).show();
            }
        });
        return view;
    }

}

