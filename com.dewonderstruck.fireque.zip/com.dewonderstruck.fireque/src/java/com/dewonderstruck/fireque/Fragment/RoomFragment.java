/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ProgressBar
 *  android.widget.Toast
 *  androidx.appcompat.widget.Toolbar
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.dewonderstruck.fireque.Activity.MainActivity;
import com.dewonderstruck.fireque.Activity.RoomDetail;
import com.dewonderstruck.fireque.Adapter.RoomAdapter;
import com.dewonderstruck.fireque.InterFace.InterstitialAdView;
import com.dewonderstruck.fireque.Item.RatingList;
import com.dewonderstruck.fireque.Item.RoomList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RoomFragment
extends Fragment {
    private InterstitialAdView interstitialAdView;
    private Method method;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private RoomAdapter roomAdapter;

    public void Gallery() {
        Constant_Api.roomLists.clear();
        this.progressBar.setVisibility(0);
        new AsyncHttpClient().get(Constant_Api.room, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                RoomFragment.this.progressBar.setVisibility(8);
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                JSONArray jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                int n2 = 0;
                do {
                    if (n2 >= jSONArray.length()) break;
                    JSONObject jSONObject = jSONArray.getJSONObject(n2);
                    String string3 = jSONObject.getString("id");
                    String string4 = jSONObject.getString("room_name");
                    String string5 = jSONObject.getString("room_image");
                    String string6 = jSONObject.getString("room_image_thumb");
                    String string7 = jSONObject.getString("room_description");
                    String string8 = jSONObject.getString("room_rules");
                    String string9 = jSONObject.getString("room_amenities");
                    String string10 = jSONObject.getString("room_price");
                    String string11 = jSONObject.getString("total_rate");
                    String string12 = jSONObject.getString("rate_avg");
                    Constant_Api.roomLists.add((Object)new RoomList(string3, string4, string5, string6, string7, string8, string9, string10, string11, string12, null, null));
                    ++n2;
                } while (true);
                try {
                    RoomFragment roomFragment = RoomFragment.this;
                    roomFragment.roomAdapter = new RoomAdapter((Activity)roomFragment.getActivity(), Constant_Api.roomLists, RoomFragment.this.interstitialAdView);
                    RoomFragment.this.recyclerView.setAdapter((RecyclerView.Adapter)RoomFragment.this.roomAdapter);
                    RoomFragment.this.progressBar.setVisibility(8);
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = LayoutInflater.from((Context)this.getContext()).inflate(2131427425, viewGroup, false);
        MainActivity.toolbar.setTitle((CharSequence)this.getResources().getString(2131689662));
        this.recyclerView = (RecyclerView)view.findViewById(2131231025);
        this.progressBar = (ProgressBar)view.findViewById(2131231007);
        this.recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getContext());
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.interstitialAdView = new InterstitialAdView(){

            @Override
            public void position(int n) {
                Intent intent = new Intent((Context)RoomFragment.this.getActivity(), RoomDetail.class);
                intent.putExtra("position", n);
                RoomFragment.this.startActivity(intent);
            }
        };
        this.method = new Method((Activity)this.getActivity(), this.interstitialAdView);
        if (Method.isNetworkAvailable((Activity)this.getActivity())) {
            this.Gallery();
            return view;
        }
        Toast.makeText((Context)this.getActivity(), (CharSequence)this.getResources().getString(2131689589), (int)0).show();
        this.progressBar.setVisibility(8);
        return view;
    }

    public void onResume() {
        RoomAdapter roomAdapter = this.roomAdapter;
        if (roomAdapter != null) {
            roomAdapter.notifyDataSetChanged();
        }
        super.onResume();
    }

}

