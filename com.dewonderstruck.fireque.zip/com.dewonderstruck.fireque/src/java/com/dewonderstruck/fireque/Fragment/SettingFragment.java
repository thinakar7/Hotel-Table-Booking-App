/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.TextView
 *  androidx.appcompat.widget.SwitchCompat
 *  androidx.appcompat.widget.Toolbar
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.dewonderstruck.fireque.Fragment;

import android.app.Activity;
import android.app.Application;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.dewonderstruck.fireque.Activity.AboutUs;
import com.dewonderstruck.fireque.Activity.MainActivity;
import com.dewonderstruck.fireque.Activity.PrivacyPolice;
import com.dewonderstruck.fireque.Util.Method;
import com.onesignal.OneSignal;

public class SettingFragment
extends Fragment {
    private Method method;

    static /* synthetic */ Method access$000(SettingFragment settingFragment) {
        return settingFragment.method;
    }

    private void moreApp() {
        this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)this.getResources().getString(2131689640))));
    }

    private void rateApp() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("market://details?id=");
        stringBuilder.append(this.getActivity().getApplication().getPackageName());
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse((String)stringBuilder.toString()));
        intent.addFlags(1208483840);
        try {
            this.startActivity(intent);
            return;
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("http://play.google.com/store/apps/details?id=");
            stringBuilder2.append(this.getActivity().getApplication().getPackageName());
            this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)stringBuilder2.toString())));
            return;
        }
    }

    private void shareApp() {
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.SUBJECT", "My application name");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("\n");
            stringBuilder.append(this.getResources().getString(2131689473));
            stringBuilder.append("\n\n");
            String string2 = stringBuilder.toString();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string2);
            stringBuilder2.append("https://play.google.com/store/apps/details?id=");
            stringBuilder2.append(this.getActivity().getApplication().getPackageName());
            intent.putExtra("android.intent.extra.TEXT", stringBuilder2.toString());
            this.startActivity(Intent.createChooser((Intent)intent, (CharSequence)"choose one"));
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = LayoutInflater.from((Context)this.getActivity()).inflate(2131427429, viewGroup, false);
        MainActivity.toolbar.setTitle((CharSequence)this.getResources().getString(2131689676));
        this.method = new Method((Activity)this.getActivity());
        SwitchCompat switchCompat = (SwitchCompat)view.findViewById(2131231091);
        TextView textView = (TextView)view.findViewById(2131231151);
        TextView textView2 = (TextView)view.findViewById(2131231143);
        TextView textView3 = (TextView)view.findViewById(2131231133);
        TextView textView4 = (TextView)view.findViewById(2131231142);
        TextView textView5 = (TextView)view.findViewById(2131231115);
        if (this.method.pref.getBoolean(this.method.notification, true)) {
            switchCompat.setChecked(true);
        } else {
            switchCompat.setChecked(false);
        }
        switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                if (bl) {
                    OneSignal.setSubscription(true);
                } else {
                    OneSignal.setSubscription(false);
                }
                SettingFragment.access$000((SettingFragment)SettingFragment.this).editor.putBoolean(SettingFragment.access$000((SettingFragment)SettingFragment.this).notification, bl);
                SettingFragment.access$000((SettingFragment)SettingFragment.this).editor.commit();
            }
        });
        textView.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                SettingFragment.this.shareApp();
            }
        });
        textView2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                SettingFragment.this.rateApp();
            }
        });
        textView3.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                SettingFragment.this.moreApp();
            }
        });
        textView5.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                SettingFragment.this.startActivity(new Intent((Context)SettingFragment.this.getActivity(), AboutUs.class));
            }
        });
        textView4.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                SettingFragment.this.startActivity(new Intent((Context)SettingFragment.this.getActivity(), PrivacyPolice.class));
            }
        });
        return view;
    }

}

