/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ProgressBar
 *  android.widget.Toast
 *  androidx.appcompat.widget.Toolbar
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.recyclerview.widget.GridLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.dewonderstruck.fireque.Activity.GalleryDetail;
import com.dewonderstruck.fireque.Activity.MainActivity;
import com.dewonderstruck.fireque.Adapter.GalleryAdapter;
import com.dewonderstruck.fireque.InterFace.InterstitialAdView;
import com.dewonderstruck.fireque.Item.GalleryList;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GalleryFragment
extends Fragment {
    private GalleryAdapter galleryAdapter;
    private List<GalleryList> galleryLists;
    private InterstitialAdView interstitialAdView;
    private Method method;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;

    public void Gallery() {
        this.progressBar.setVisibility(0);
        new AsyncHttpClient().get(Constant_Api.gallery, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                GalleryFragment.this.progressBar.setVisibility(8);
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                JSONArray jSONArray = new JSONObject(string2).getJSONArray(Constant_Api.tag);
                int n2 = 0;
                do {
                    if (n2 >= jSONArray.length()) break;
                    JSONObject jSONObject = jSONArray.getJSONObject(n2);
                    String string3 = jSONObject.getString("cid");
                    String string4 = jSONObject.getString("category_name");
                    String string5 = jSONObject.getString("category_image");
                    String string6 = jSONObject.getString("category_image_thumb");
                    GalleryFragment.this.galleryLists.add((Object)new GalleryList(string3, string4, string5, string6));
                    ++n2;
                } while (true);
                try {
                    GalleryFragment galleryFragment = GalleryFragment.this;
                    galleryFragment.galleryAdapter = new GalleryAdapter((Activity)galleryFragment.getActivity(), (List<GalleryList>)GalleryFragment.this.galleryLists, GalleryFragment.this.interstitialAdView);
                    GalleryFragment.this.recyclerView.setAdapter((RecyclerView.Adapter)GalleryFragment.this.galleryAdapter);
                    GalleryFragment.this.progressBar.setVisibility(8);
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = LayoutInflater.from((Context)this.getContext()).inflate(2131427393, viewGroup, false);
        this.galleryLists = new ArrayList();
        MainActivity.toolbar.setTitle((CharSequence)this.getResources().getString(2131689579));
        this.interstitialAdView = new InterstitialAdView(){

            @Override
            public void position(int n) {
                Intent intent = new Intent((Context)GalleryFragment.this.getActivity(), GalleryDetail.class);
                intent.putExtra("id", ((GalleryList)GalleryFragment.this.galleryLists.get(n)).getCid());
                intent.putExtra("title", ((GalleryList)GalleryFragment.this.galleryLists.get(n)).getCategory_name());
                intent.putExtra("position", n);
                GalleryFragment.this.startActivity(intent);
            }
        };
        this.method = new Method((Activity)this.getActivity(), this.interstitialAdView);
        this.recyclerView = (RecyclerView)view.findViewById(2131231023);
        this.progressBar = (ProgressBar)view.findViewById(2131231005);
        this.recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this.getContext(), 2);
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)gridLayoutManager);
        if (Method.isNetworkAvailable((Activity)this.getActivity())) {
            this.Gallery();
            return view;
        }
        Toast.makeText((Context)this.getActivity(), (CharSequence)this.getResources().getString(2131689589), (int)0).show();
        this.progressBar.setVisibility(8);
        return view;
    }

}

