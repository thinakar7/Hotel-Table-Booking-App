/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.widget.Toolbar
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentTransaction
 *  cz.msebera.android.httpclient.Header
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dewonderstruck.fireque.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.daimajia.slider.library.Animations.BaseAnimationInterface;
import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.Indicators.PagerIndicator;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.dewonderstruck.fireque.Activity.AboutUs;
import com.dewonderstruck.fireque.Activity.MainActivity;
import com.dewonderstruck.fireque.Fragment.ContactUsFragment;
import com.dewonderstruck.fireque.Fragment.FacilitiesFragment;
import com.dewonderstruck.fireque.Fragment.GalleryFragment;
import com.dewonderstruck.fireque.Fragment.LocationFragment;
import com.dewonderstruck.fireque.Fragment.RoomFragment;
import com.dewonderstruck.fireque.Item.HomeList;
import com.dewonderstruck.fireque.Item.HomeListImage;
import com.dewonderstruck.fireque.Util.Constant_Api;
import com.dewonderstruck.fireque.Util.Method;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class HomeFragment
extends Fragment {
    private List<HomeListImage> homeListImages;
    private List<HomeList> homeLists;
    private SliderLayout mDemoSlider;
    private ProgressBar progressBar;
    private TextView textView_addres;
    private TextView textView_title;

    public void about_us() {
        this.startActivity(new Intent((Context)this.getActivity(), AboutUs.class));
    }

    public void contact_us() {
        this.getActivity().getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new ContactUsFragment(), "contactus").commit();
    }

    public void facilities() {
        this.getActivity().getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new FacilitiesFragment(), "facilities").commit();
    }

    public void gallery() {
        this.getActivity().getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new GalleryFragment(), "gallery").commit();
    }

    public void home() {
        this.progressBar.setVisibility(0);
        new AsyncHttpClient().get(Constant_Api.home, null, (ResponseHandlerInterface)new AsyncHttpResponseHandler(){

            @Override
            public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
                HomeFragment.this.progressBar.setVisibility(8);
            }

            @Override
            public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
                Log.d((String)"Response", (String)new String(arrby));
                String string2 = new String(arrby);
                String string3 = null;
                String string4 = null;
                String string5 = null;
                String string6 = null;
                JSONObject jSONObject = new JSONObject(string2).getJSONObject(Constant_Api.tag);
                JSONArray jSONArray = jSONObject.getJSONArray("home_banner");
                int n2 = 0;
                do {
                    if (n2 >= jSONArray.length()) break;
                    JSONObject jSONObject2 = jSONArray.getJSONObject(n2);
                    string3 = jSONObject2.getString("id");
                    string4 = jSONObject2.getString("banner_image");
                    HomeFragment.this.homeListImages.add((Object)new HomeListImage(string3, string4));
                    ++n2;
                } while (true);
                JSONArray jSONArray2 = jSONObject.getJSONArray("hotel_info");
                int n3 = 0;
                do {
                    if (n3 >= jSONArray2.length()) break;
                    JSONObject jSONObject3 = jSONArray2.getJSONObject(n3);
                    string5 = jSONObject3.getString("hotel_name");
                    string6 = jSONObject3.getString("hotel_address");
                    ++n3;
                } while (true);
                try {
                    HomeFragment.this.homeLists.add((Object)new HomeList(string3, string4, string5, string6));
                    HomeFragment.this.progressBar.setVisibility(8);
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                }
                HomeFragment.this.textView_title.setText((CharSequence)((HomeList)HomeFragment.this.homeLists.get(0)).getHotel_name());
                HomeFragment.this.textView_addres.setText((CharSequence)((HomeList)HomeFragment.this.homeLists.get(0)).getHotel_address());
                for (int i = 0; i < HomeFragment.this.homeListImages.size(); ++i) {
                    TextSliderView textSliderView = new TextSliderView((Context)HomeFragment.this.getActivity());
                    textSliderView.image(((HomeListImage)HomeFragment.this.homeListImages.get(i)).getBanner_image()).setOnSliderClickListener(new BaseSliderView.OnSliderClickListener(){

                        @Override
                        public void onSliderClick(BaseSliderView baseSliderView) {
                        }
                    }).setScaleType(BaseSliderView.ScaleType.Fit);
                    HomeFragment.this.mDemoSlider.addSlider(textSliderView);
                }
                HomeFragment.this.mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
                HomeFragment.this.mDemoSlider.getPagerIndicator().setDefaultIndicatorColor(HomeFragment.this.getResources().getColor(2131034287), HomeFragment.this.getResources().getColor(2131034322));
                HomeFragment.this.mDemoSlider.setCustomAnimation(new DescriptionAnimation());
            }

        });
    }

    public void location() {
        MainActivity.toolbar.setTitle((CharSequence)this.getResources().getString(2131689611));
        this.getActivity().getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new LocationFragment(), "location").commitAllowingStateLoss();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = LayoutInflater.from((Context)this.getContext()).inflate(2131427395, viewGroup, false);
        MainActivity.toolbar.setTitle((CharSequence)this.getResources().getString(2131689588));
        int n = new Method((Activity)this.getActivity()).getScreenWidth();
        this.homeLists = new ArrayList();
        this.homeListImages = new ArrayList();
        this.progressBar = (ProgressBar)view.findViewById(2131231011);
        this.mDemoSlider = (SliderLayout)view.findViewById(2131231062);
        ImageView imageView = (ImageView)view.findViewById(2131230939);
        ImageView imageView2 = (ImageView)view.findViewById(2131230932);
        ImageView imageView3 = (ImageView)view.findViewById(2131230927);
        ImageView imageView4 = (ImageView)view.findViewById(2131230930);
        ImageView imageView5 = (ImageView)view.findViewById(2131230925);
        ImageView imageView6 = (ImageView)view.findViewById(2131230920);
        this.textView_title = (TextView)view.findViewById(2131231156);
        this.textView_addres = (TextView)view.findViewById(2131231116);
        this.mDemoSlider.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(n, 80 + n / 2));
        if (Method.isNetworkAvailable((Activity)this.getActivity())) {
            this.home();
        } else {
            Toast.makeText((Context)this.getActivity(), (CharSequence)this.getResources().getString(2131689589), (int)0).show();
            this.progressBar.setVisibility(8);
        }
        imageView.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                HomeFragment.this.room();
            }
        });
        imageView2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                HomeFragment.this.location();
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                HomeFragment.this.facilities();
            }
        });
        imageView4.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                HomeFragment.this.gallery();
            }
        });
        imageView5.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                HomeFragment.this.contact_us();
            }
        });
        imageView6.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                HomeFragment.this.about_us();
            }
        });
        return view;
    }

    public void room() {
        this.getActivity().getSupportFragmentManager().beginTransaction().replace(2131230904, (Fragment)new RoomFragment(), "room").commit();
    }

}

