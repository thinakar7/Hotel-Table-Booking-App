/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpResponse
 *  java.lang.Throwable
 */
package com.loopj.android.http;

import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpResponse;

public class BlackholeHttpResponseHandler
extends AsyncHttpResponseHandler {
    @Override
    public void onCancel() {
    }

    @Override
    public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
    }

    @Override
    public void onFinish() {
    }

    @Override
    public void onPostProcessResponse(ResponseHandlerInterface responseHandlerInterface, HttpResponse httpResponse) {
    }

    @Override
    public void onPreProcessResponse(ResponseHandlerInterface responseHandlerInterface, HttpResponse httpResponse) {
    }

    @Override
    public void onProgress(long l, long l2) {
    }

    @Override
    public void onRetry(int n) {
    }

    @Override
    public void onStart() {
    }

    @Override
    public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
    }

    @Override
    public void onUserException(Throwable throwable) {
    }
}

