/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpResponse
 *  cz.msebera.android.httpclient.StatusLine
 *  cz.msebera.android.httpclient.client.HttpResponseException
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.regex.Pattern
 *  java.util.regex.PatternSyntaxException
 */
package com.loopj.android.http;

import android.os.Looper;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.LogInterface;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.StatusLine;
import cz.msebera.android.httpclient.client.HttpResponseException;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public abstract class BinaryHttpResponseHandler
extends AsyncHttpResponseHandler {
    private static final String LOG_TAG = "BinaryHttpRH";
    private String[] mAllowedContentTypes = new String[]{"application/octet-stream", "image/jpeg", "image/png", "image/gif"};

    public BinaryHttpResponseHandler() {
    }

    public BinaryHttpResponseHandler(String[] arrstring) {
        if (arrstring != null) {
            this.mAllowedContentTypes = arrstring;
            return;
        }
        AsyncHttpClient.log.e(LOG_TAG, "Constructor passed allowedContentTypes was null !");
    }

    public BinaryHttpResponseHandler(String[] arrstring, Looper looper) {
        super(looper);
        if (arrstring != null) {
            this.mAllowedContentTypes = arrstring;
            return;
        }
        AsyncHttpClient.log.e(LOG_TAG, "Constructor passed allowedContentTypes was null !");
    }

    public String[] getAllowedContentTypes() {
        return this.mAllowedContentTypes;
    }

    @Override
    public abstract void onFailure(int var1, Header[] var2, byte[] var3, Throwable var4);

    @Override
    public abstract void onSuccess(int var1, Header[] var2, byte[] var3);

    @Override
    public final void sendResponseMessage(HttpResponse httpResponse) throws IOException {
        StatusLine statusLine = httpResponse.getStatusLine();
        Header[] arrheader = httpResponse.getHeaders("Content-Type");
        if (arrheader.length != 1) {
            this.sendFailureMessage(statusLine.getStatusCode(), httpResponse.getAllHeaders(), null, (Throwable)new HttpResponseException(statusLine.getStatusCode(), "None, or more than one, Content-Type Header found!"));
            return;
        }
        Header header = arrheader[0];
        boolean bl = false;
        for (String string2 : this.getAllowedContentTypes()) {
            try {
                boolean bl2 = Pattern.matches((String)string2, (CharSequence)header.getValue());
                if (!bl2) continue;
                bl = true;
            }
            catch (PatternSyntaxException patternSyntaxException) {
                LogInterface logInterface = AsyncHttpClient.log;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Given pattern is not valid: ");
                stringBuilder.append(string2);
                logInterface.e("BinaryHttpRH", stringBuilder.toString(), patternSyntaxException);
            }
        }
        if (!bl) {
            int n = statusLine.getStatusCode();
            Header[] arrheader2 = httpResponse.getAllHeaders();
            int n2 = statusLine.getStatusCode();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Content-Type (");
            stringBuilder.append(header.getValue());
            stringBuilder.append(") not allowed!");
            this.sendFailureMessage(n, arrheader2, null, (Throwable)new HttpResponseException(n2, stringBuilder.toString()));
            return;
        }
        super.sendResponseMessage(httpResponse);
    }
}

