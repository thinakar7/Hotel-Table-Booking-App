/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpHost
 *  cz.msebera.android.httpclient.HttpRequest
 *  cz.msebera.android.httpclient.HttpResponse
 *  cz.msebera.android.httpclient.ProtocolException
 *  cz.msebera.android.httpclient.RequestLine
 *  cz.msebera.android.httpclient.StatusLine
 *  cz.msebera.android.httpclient.client.CircularRedirectException
 *  cz.msebera.android.httpclient.client.utils.URIUtils
 *  cz.msebera.android.httpclient.impl.client.DefaultRedirectHandler
 *  cz.msebera.android.httpclient.impl.client.RedirectLocations
 *  cz.msebera.android.httpclient.params.HttpParams
 *  cz.msebera.android.httpclient.protocol.HttpContext
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URI
 *  java.net.URISyntaxException
 */
package com.loopj.android.http;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpHost;
import cz.msebera.android.httpclient.HttpRequest;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.ProtocolException;
import cz.msebera.android.httpclient.RequestLine;
import cz.msebera.android.httpclient.StatusLine;
import cz.msebera.android.httpclient.client.CircularRedirectException;
import cz.msebera.android.httpclient.client.utils.URIUtils;
import cz.msebera.android.httpclient.impl.client.DefaultRedirectHandler;
import cz.msebera.android.httpclient.impl.client.RedirectLocations;
import cz.msebera.android.httpclient.params.HttpParams;
import cz.msebera.android.httpclient.protocol.HttpContext;
import java.net.URI;
import java.net.URISyntaxException;

class MyRedirectHandler
extends DefaultRedirectHandler {
    private static final String REDIRECT_LOCATIONS = "http.protocol.redirect-locations";
    private final boolean enableRedirects;

    public MyRedirectHandler(boolean bl) {
        this.enableRedirects = bl;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public URI getLocationURI(HttpResponse httpResponse, HttpContext httpContext) throws ProtocolException {
        if (httpResponse == null) throw new IllegalArgumentException("HTTP response may not be null");
        Header header = httpResponse.getFirstHeader("location");
        if (header != null) {
            URI uRI;
            URI uRI2;
            String string2 = header.getValue().replaceAll(" ", "%20");
            try {
                uRI2 = new URI(string2);
            }
            catch (URISyntaxException uRISyntaxException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Invalid redirect URI: ");
                stringBuilder.append(string2);
                throw new ProtocolException(stringBuilder.toString(), (Throwable)uRISyntaxException);
            }
            HttpParams httpParams = httpResponse.getParams();
            if (!uRI2.isAbsolute()) {
                if (!httpParams.isParameterTrue("http.protocol.reject-relative-redirect")) {
                    HttpHost httpHost = (HttpHost)httpContext.getAttribute("http.target_host");
                    if (httpHost == null) throw new IllegalStateException("Target host not available in the HTTP context");
                    HttpRequest httpRequest = (HttpRequest)httpContext.getAttribute("http.request");
                    try {
                        URI uRI3;
                        uRI2 = uRI3 = URIUtils.resolve((URI)URIUtils.rewriteURI((URI)new URI(httpRequest.getRequestLine().getUri()), (HttpHost)httpHost, (boolean)true), (URI)uRI2);
                    }
                    catch (URISyntaxException uRISyntaxException) {
                        throw new ProtocolException(uRISyntaxException.getMessage(), (Throwable)uRISyntaxException);
                    }
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Relative redirect location '");
                    stringBuilder.append((Object)uRI2);
                    stringBuilder.append("' not allowed");
                    throw new ProtocolException(stringBuilder.toString());
                }
            }
            if (!httpParams.isParameterFalse("http.protocol.allow-circular-redirects")) return uRI2;
            RedirectLocations redirectLocations = (RedirectLocations)httpContext.getAttribute(REDIRECT_LOCATIONS);
            if (redirectLocations == null) {
                redirectLocations = new RedirectLocations();
                httpContext.setAttribute(REDIRECT_LOCATIONS, (Object)redirectLocations);
            }
            if (uRI2.getFragment() != null) {
                try {
                    URI uRI4;
                    uRI = uRI4 = URIUtils.rewriteURI((URI)uRI2, (HttpHost)new HttpHost(uRI2.getHost(), uRI2.getPort(), uRI2.getScheme()), (boolean)true);
                }
                catch (URISyntaxException uRISyntaxException) {
                    throw new ProtocolException(uRISyntaxException.getMessage(), (Throwable)uRISyntaxException);
                }
            } else {
                uRI = uRI2;
            }
            if (!redirectLocations.contains(uRI)) {
                redirectLocations.add(uRI);
                return uRI2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Circular redirect to '");
            stringBuilder.append((Object)uRI);
            stringBuilder.append("'");
            throw new CircularRedirectException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Received redirect response ");
        stringBuilder.append((Object)httpResponse.getStatusLine());
        stringBuilder.append(" but no location header");
        throw new ProtocolException(stringBuilder.toString());
    }

    public boolean isRedirectRequested(HttpResponse httpResponse, HttpContext httpContext) {
        if (!this.enableRedirects) {
            return false;
        }
        if (httpResponse != null) {
            int n = httpResponse.getStatusLine().getStatusCode();
            if (n != 307) {
                switch (n) {
                    default: {
                        return false;
                    }
                    case 301: 
                    case 302: 
                    case 303: 
                }
            }
            return true;
        }
        throw new IllegalArgumentException("HTTP response may not be null");
    }
}

