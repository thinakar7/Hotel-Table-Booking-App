/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpEntity
 *  cz.msebera.android.httpclient.message.BasicHeader
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.HashMap
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Set
 *  java.util.zip.GZIPOutputStream
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.loopj.android.http;

import android.text.TextUtils;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.Base64OutputStream;
import com.loopj.android.http.JsonValueInterface;
import com.loopj.android.http.LogInterface;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class JsonStreamerEntity
implements HttpEntity {
    private static final int BUFFER_SIZE = 4096;
    private static final UnsupportedOperationException ERR_UNSUPPORTED = new UnsupportedOperationException("Unsupported operation in this implementation.");
    private static final Header HEADER_GZIP_ENCODING;
    private static final Header HEADER_JSON_CONTENT;
    private static final byte[] JSON_FALSE;
    private static final byte[] JSON_NULL;
    private static final byte[] JSON_TRUE;
    private static final String LOG_TAG = "JsonStreamerEntity";
    private static final byte[] STREAM_CONTENTS;
    private static final byte[] STREAM_NAME;
    private static final byte[] STREAM_TYPE;
    private final byte[] buffer = new byte[4096];
    private final Header contentEncoding;
    private final byte[] elapsedField;
    private final Map<String, Object> jsonParams = new HashMap();
    private final ResponseHandlerInterface progressHandler;

    static {
        JSON_TRUE = "true".getBytes();
        JSON_FALSE = "false".getBytes();
        JSON_NULL = "null".getBytes();
        STREAM_NAME = JsonStreamerEntity.escape("name");
        STREAM_TYPE = JsonStreamerEntity.escape("type");
        STREAM_CONTENTS = JsonStreamerEntity.escape("contents");
        HEADER_JSON_CONTENT = new BasicHeader("Content-Type", "application/json");
        HEADER_GZIP_ENCODING = new BasicHeader("Content-Encoding", "gzip");
    }

    public JsonStreamerEntity(ResponseHandlerInterface responseHandlerInterface, boolean bl, String string) {
        this.progressHandler = responseHandlerInterface;
        Object object = bl ? HEADER_GZIP_ENCODING : null;
        this.contentEncoding = object;
        byte[] arrby = TextUtils.isEmpty((CharSequence)string) ? null : JsonStreamerEntity.escape(string);
        this.elapsedField = arrby;
    }

    private void endMetaData(OutputStream outputStream) throws IOException {
        outputStream.write(34);
    }

    static byte[] escape(String string) {
        if (string == null) {
            return JSON_NULL;
        }
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append('\"');
        int n = string.length();
        int n2 = -1;
        block5 : while (++n2 < n) {
            char c = string.charAt(n2);
            if (c != '\f') {
                if (c != '\r') {
                    if (c != '\"') {
                        if (c != '\\') {
                            switch (c) {
                                default: {
                                    if (!(c <= '\u001f' || c >= '' && c <= '\u009f' || c >= '\u2000' && c <= '\u20ff')) {
                                        stringBuilder.append(c);
                                        continue block5;
                                    }
                                    String string2 = Integer.toHexString((int)c);
                                    stringBuilder.append("\\u");
                                    int n3 = 4 - string2.length();
                                    for (int i = 0; i < n3; ++i) {
                                        stringBuilder.append('0');
                                    }
                                    stringBuilder.append(string2.toUpperCase(Locale.US));
                                    continue block5;
                                }
                                case '\n': {
                                    stringBuilder.append("\\n");
                                    continue block5;
                                }
                                case '\t': {
                                    stringBuilder.append("\\t");
                                    continue block5;
                                }
                                case '\b': 
                            }
                            stringBuilder.append("\\b");
                            continue;
                        }
                        stringBuilder.append("\\\\");
                        continue;
                    }
                    stringBuilder.append("\\\"");
                    continue;
                }
                stringBuilder.append("\\r");
                continue;
            }
            stringBuilder.append("\\f");
        }
        stringBuilder.append('\"');
        return stringBuilder.toString().getBytes();
    }

    private void writeMetaData(OutputStream outputStream, String string, String string2) throws IOException {
        outputStream.write(STREAM_NAME);
        outputStream.write(58);
        outputStream.write(JsonStreamerEntity.escape(string));
        outputStream.write(44);
        outputStream.write(STREAM_TYPE);
        outputStream.write(58);
        outputStream.write(JsonStreamerEntity.escape(string2));
        outputStream.write(44);
        outputStream.write(STREAM_CONTENTS);
        outputStream.write(58);
        outputStream.write(34);
    }

    private void writeToFromFile(OutputStream outputStream, RequestParams.FileWrapper fileWrapper) throws IOException {
        int n;
        this.writeMetaData(outputStream, fileWrapper.file.getName(), fileWrapper.contentType);
        long l = 0L;
        long l2 = fileWrapper.file.length();
        FileInputStream fileInputStream = new FileInputStream(fileWrapper.file);
        Base64OutputStream base64OutputStream = new Base64OutputStream(outputStream, 18);
        while ((n = fileInputStream.read(this.buffer)) != -1) {
            base64OutputStream.write(this.buffer, 0, n);
            this.progressHandler.sendProgressMessage(l += (long)n, l2);
        }
        AsyncHttpClient.silentCloseOutputStream((OutputStream)base64OutputStream);
        this.endMetaData(outputStream);
        AsyncHttpClient.silentCloseInputStream((InputStream)fileInputStream);
    }

    private void writeToFromStream(OutputStream outputStream, RequestParams.StreamWrapper streamWrapper) throws IOException {
        int n;
        this.writeMetaData(outputStream, streamWrapper.name, streamWrapper.contentType);
        Base64OutputStream base64OutputStream = new Base64OutputStream(outputStream, 18);
        while ((n = streamWrapper.inputStream.read(this.buffer)) != -1) {
            base64OutputStream.write(this.buffer, 0, n);
        }
        AsyncHttpClient.silentCloseOutputStream((OutputStream)base64OutputStream);
        this.endMetaData(outputStream);
        if (streamWrapper.autoClose) {
            AsyncHttpClient.silentCloseInputStream(streamWrapper.inputStream);
        }
    }

    public void addPart(String string, Object object) {
        this.jsonParams.put((Object)string, object);
    }

    public void consumeContent() throws IOException, UnsupportedOperationException {
    }

    public InputStream getContent() throws IOException, UnsupportedOperationException {
        throw ERR_UNSUPPORTED;
    }

    public Header getContentEncoding() {
        return this.contentEncoding;
    }

    public long getContentLength() {
        return -1L;
    }

    public Header getContentType() {
        return HEADER_JSON_CONTENT;
    }

    public boolean isChunked() {
        return false;
    }

    public boolean isRepeatable() {
        return false;
    }

    public boolean isStreaming() {
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void writeTo(OutputStream var1_1) throws IOException {
        block51 : {
            var2_2 = this;
            if (var1_1 == null) throw new IllegalStateException("Output stream cannot be null.");
            var4_3 = System.currentTimeMillis();
            if (var2_2.contentEncoding != null) {
                var6_4 = new GZIPOutputStream(var1_1, 4096);
            } else {
                var6_5 = var1_1;
            }
            var7_7 = var6_6;
            var7_7.write(123);
            var8_8 = var2_2.jsonParams.keySet();
            var9_9 = var8_8.size();
            if (var9_9 <= 0) break block51;
            var11_10 = 0;
            for (String var25_12 : var8_8) {
                block52 : {
                    block56 : {
                        block54 : {
                            block55 : {
                                block53 : {
                                    block42 : {
                                        block50 : {
                                            block44 : {
                                                block43 : {
                                                    block49 : {
                                                        block48 : {
                                                            block47 : {
                                                                block46 : {
                                                                    block45 : {
                                                                        var26_13 = var11_10 + 1;
                                                                        try {
                                                                            var29_15 = var2_2.jsonParams.get((Object)var25_12);
                                                                            var7_7.write(JsonStreamerEntity.escape(var25_12));
                                                                            var7_7.write(58);
                                                                            if (var29_15 == null) {
                                                                                var7_7.write(JsonStreamerEntity.JSON_NULL);
                                                                                var28_14 = var2_2;
                                                                                var30_16 = var26_13;
                                                                                break block42;
                                                                            }
                                                                            var31_17 = var29_15 instanceof RequestParams.FileWrapper;
                                                                            if (var31_17) break block43;
                                                                        }
                                                                        catch (Throwable var27_38) {}
                                                                        if (var29_15 instanceof RequestParams.StreamWrapper) {
                                                                            var30_16 = var26_13;
                                                                            break block44;
                                                                        }
                                                                        var33_19 = var29_15 instanceof JsonValueInterface;
                                                                        if (!var33_19) break block45;
                                                                        var7_7.write(((JsonValueInterface)var29_15).getEscapedJsonValue());
                                                                    }
                                                                    var34_20 = var29_15 instanceof JSONObject;
                                                                    if (!var34_20) break block46;
                                                                    var7_7.write(var29_15.toString().getBytes());
                                                                    var28_14 = var2_2;
                                                                    var30_16 = var26_13;
                                                                    break block42;
                                                                }
                                                                var35_21 = var29_15 instanceof JSONArray;
                                                                if (!var35_21) break block47;
                                                                var7_7.write(var29_15.toString().getBytes());
                                                                var28_14 = var2_2;
                                                                var30_16 = var26_13;
                                                                break block42;
                                                            }
                                                            var36_22 = var29_15 instanceof Boolean;
                                                            if (!var36_22) break block48;
                                                            var51_29 = (Boolean)var29_15 != false ? JsonStreamerEntity.JSON_TRUE : JsonStreamerEntity.JSON_FALSE;
                                                            var7_7.write(var51_29);
                                                            var28_14 = var2_2;
                                                            var30_16 = var26_13;
                                                            break block42;
                                                        }
                                                        var37_23 = var29_15 instanceof Long;
                                                        if (!var37_23) break block49;
                                                        var47_27 = new StringBuilder();
                                                        var48_28 = (Number)var29_15;
                                                        var30_16 = var26_13;
                                                        try {
                                                            var47_27.append(var48_28.longValue());
                                                            var47_27.append("");
                                                            var7_7.write(var47_27.toString().getBytes());
                                                        }
                                                        finally {
                                                            var28_14 = var2_2;
                                                        }
                                                        break block42;
                                                        catch (Throwable var27_31) {
                                                            var28_14 = var2_2;
                                                        }
                                                        break block52;
                                                    }
                                                    var30_16 = var26_13;
                                                    try {
                                                        if (var29_15 instanceof Double) {
                                                            var38_24 = new StringBuilder();
                                                            var38_24.append(((Number)var29_15).doubleValue());
                                                            var38_24.append("");
                                                            var7_7.write(var38_24.toString().getBytes());
                                                            var28_14 = this;
                                                        } else if (var29_15 instanceof Float) {
                                                            var41_25 = new StringBuilder();
                                                            var41_25.append(((Number)var29_15).floatValue());
                                                            var41_25.append("");
                                                            var7_7.write(var41_25.toString().getBytes());
                                                            var28_14 = this;
                                                        } else if (var29_15 instanceof Integer) {
                                                            var44_26 = new StringBuilder();
                                                            var44_26.append(((Number)var29_15).intValue());
                                                            var44_26.append("");
                                                            var7_7.write(var44_26.toString().getBytes());
                                                            var28_14 = this;
                                                        } else {
                                                            var7_7.write(JsonStreamerEntity.escape(var29_15.toString()));
                                                            var28_14 = this;
                                                        }
                                                        break block42;
                                                    }
                                                    catch (Throwable var27_35) {}
                                                    catch (Throwable var27_32) {
                                                        var28_14 = this;
                                                    }
                                                    break block52;
                                                }
                                                var30_16 = var26_13;
                                            }
                                            var7_7.write(123);
                                            ** if (!var31_17) goto lbl-1000
lbl-1000: // 1 sources:
                                            {
                                                var32_18 = (RequestParams.FileWrapper)var29_15;
                                            }
lbl-1000: // 1 sources:
                                            {
                                                break block50;
                                            }
                                            finally {
                                                var28_14 = this;
                                            }
                                        }
                                        var28_14 = this;
                                        try {
                                            var28_14.writeToFromStream((OutputStream)var7_7, (RequestParams.StreamWrapper)var29_15);
                                            var7_7.write(125);
                                        }
                                        catch (Throwable var27_36) {}
                                    }
                                    if (var28_14.elapsedField != null) break block53;
                                    var11_10 = var30_16;
                                    if (var11_10 >= var9_9) break block54;
                                    break block55;
                                }
                                var11_10 = var30_16;
                            }
                            var7_7.write(44);
                        }
                        var2_2 = var28_14;
                        continue;
                        break block56;
                        catch (Throwable var27_37) {
                            var28_14 = this;
                        }
                    }
                    var26_13 = var30_16;
                    break block52;
                    finally {
                        var28_14 = var2_2;
                    }
                }
                if (var28_14.elapsedField == null) {
                    if (var26_13 >= var9_9) throw var27_33;
                }
                var7_7.write(44);
                throw var27_33;
            }
            var13_39 = var2_2;
            var14_40 = System.currentTimeMillis() - var4_3;
            var16_41 = var13_39.elapsedField;
            if (var16_41 != null) {
                var7_7.write(var16_41);
                var7_7.write(58);
                var22_42 = new StringBuilder();
                var22_42.append(var14_40);
                var22_42.append("");
                var7_7.write(var22_42.toString().getBytes());
            }
            var17_43 = AsyncHttpClient.log;
            var18_44 = new StringBuilder();
            var18_44.append("Uploaded JSON in ");
            var18_44.append(Math.floor((double)(var14_40 / 1000L)));
            var18_44.append(" seconds");
            var17_43.i("JsonStreamerEntity", var18_44.toString());
        }
        var7_7.write(125);
        var7_7.flush();
        AsyncHttpClient.silentCloseOutputStream((OutputStream)var7_7);
    }
}

