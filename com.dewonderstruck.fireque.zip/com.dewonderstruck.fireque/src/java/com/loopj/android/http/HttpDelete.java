/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.client.methods.HttpEntityEnclosingRequestBase
 *  java.lang.String
 *  java.net.URI
 */
package com.loopj.android.http;

import cz.msebera.android.httpclient.client.methods.HttpEntityEnclosingRequestBase;
import java.net.URI;

public final class HttpDelete
extends HttpEntityEnclosingRequestBase {
    public static final String METHOD_NAME = "DELETE";

    public HttpDelete() {
    }

    public HttpDelete(String string2) {
        this.setURI(URI.create((String)string2));
    }

    public HttpDelete(URI uRI) {
        this.setURI(uRI);
    }

    public String getMethod() {
        return METHOD_NAME;
    }
}

