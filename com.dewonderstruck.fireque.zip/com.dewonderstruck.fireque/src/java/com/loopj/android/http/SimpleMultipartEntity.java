/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpEntity
 *  cz.msebera.android.httpclient.message.BasicHeader
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Random
 */
package com.loopj.android.http;

import android.text.TextUtils;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.LogInterface;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

class SimpleMultipartEntity
implements HttpEntity {
    private static final byte[] CR_LF = "\r\n".getBytes();
    private static final String LOG_TAG = "SimpleMultipartEntity";
    private static final char[] MULTIPART_CHARS;
    private static final String STR_CR_LF = "\r\n";
    private static final byte[] TRANSFER_ENCODING_BINARY;
    private final String boundary;
    private final byte[] boundaryEnd;
    private final byte[] boundaryLine;
    private long bytesWritten;
    private final List<FilePart> fileParts = new ArrayList();
    private boolean isRepeatable;
    private final ByteArrayOutputStream out = new ByteArrayOutputStream();
    private final ResponseHandlerInterface progressHandler;
    private long totalSize;

    static {
        TRANSFER_ENCODING_BINARY = "Content-Transfer-Encoding: binary\r\n".getBytes();
        MULTIPART_CHARS = "-_1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
    }

    public SimpleMultipartEntity(ResponseHandlerInterface responseHandlerInterface) {
        String string;
        StringBuilder stringBuilder = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 30; ++i) {
            char[] arrc = MULTIPART_CHARS;
            stringBuilder.append(arrc[random.nextInt(arrc.length)]);
        }
        this.boundary = string = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("--");
        stringBuilder2.append(string);
        stringBuilder2.append(STR_CR_LF);
        this.boundaryLine = stringBuilder2.toString().getBytes();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("--");
        stringBuilder3.append(string);
        stringBuilder3.append("--");
        stringBuilder3.append(STR_CR_LF);
        this.boundaryEnd = stringBuilder3.toString().getBytes();
        this.progressHandler = responseHandlerInterface;
    }

    private byte[] createContentDisposition(String string) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Content-Disposition: form-data; name=\"");
        stringBuilder.append(string);
        stringBuilder.append("\"");
        stringBuilder.append(STR_CR_LF);
        return stringBuilder.toString().getBytes();
    }

    private byte[] createContentDisposition(String string, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Content-Disposition: form-data; name=\"");
        stringBuilder.append(string);
        stringBuilder.append("\"");
        stringBuilder.append("; filename=\"");
        stringBuilder.append(string2);
        stringBuilder.append("\"");
        stringBuilder.append(STR_CR_LF);
        return stringBuilder.toString().getBytes();
    }

    private byte[] createContentType(String string) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Content-Type: ");
        stringBuilder.append(this.normalizeContentType(string));
        stringBuilder.append(STR_CR_LF);
        return stringBuilder.toString().getBytes();
    }

    private String normalizeContentType(String string) {
        if (string == null) {
            return "application/octet-stream";
        }
        return string;
    }

    private void updateProgress(long l) {
        long l2;
        this.bytesWritten = l2 = l + this.bytesWritten;
        this.progressHandler.sendProgressMessage(l2, this.totalSize);
    }

    public void addPart(String string, File file) {
        this.addPart(string, file, null);
    }

    public void addPart(String string, File file, String string2) {
        this.fileParts.add((Object)new FilePart(string, file, this.normalizeContentType(string2)));
    }

    public void addPart(String string, File file, String string2, String string3) {
        List<FilePart> list = this.fileParts;
        FilePart filePart = new FilePart(string, file, this.normalizeContentType(string2), string3);
        list.add((Object)filePart);
    }

    public void addPart(String string, String string2) {
        this.addPartWithCharset(string, string2, null);
    }

    public void addPart(String string, String string2, InputStream inputStream, String string3) throws IOException {
        int n;
        this.out.write(this.boundaryLine);
        this.out.write(this.createContentDisposition(string, string2));
        this.out.write(this.createContentType(string3));
        this.out.write(TRANSFER_ENCODING_BINARY);
        this.out.write(CR_LF);
        byte[] arrby = new byte[4096];
        while ((n = inputStream.read(arrby)) != -1) {
            this.out.write(arrby, 0, n);
        }
        this.out.write(CR_LF);
        this.out.flush();
    }

    public void addPart(String string, String string2, String string3) {
        try {
            this.out.write(this.boundaryLine);
            this.out.write(this.createContentDisposition(string));
            this.out.write(this.createContentType(string3));
            ByteArrayOutputStream byteArrayOutputStream = this.out;
            byte[] arrby = CR_LF;
            byteArrayOutputStream.write(arrby);
            this.out.write(string2.getBytes());
            this.out.write(arrby);
            return;
        }
        catch (IOException iOException) {
            AsyncHttpClient.log.e(LOG_TAG, "addPart ByteArrayOutputStream exception", iOException);
            return;
        }
    }

    public void addPartWithCharset(String string, String string2, String string3) {
        if (string3 == null) {
            string3 = "UTF-8";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("text/plain; charset=");
        stringBuilder.append(string3);
        this.addPart(string, string2, stringBuilder.toString());
    }

    public void consumeContent() throws IOException, UnsupportedOperationException {
        if (!this.isStreaming()) {
            return;
        }
        throw new UnsupportedOperationException("Streaming entity does not implement #consumeContent()");
    }

    public InputStream getContent() throws IOException, UnsupportedOperationException {
        throw new UnsupportedOperationException("getContent() is not supported. Use writeTo() instead.");
    }

    public Header getContentEncoding() {
        return null;
    }

    public long getContentLength() {
        long l = this.out.size();
        Iterator iterator = this.fileParts.iterator();
        while (iterator.hasNext()) {
            long l2 = ((FilePart)iterator.next()).getTotalLength();
            if (l2 < 0L) {
                return -1L;
            }
            l += l2;
        }
        return l + (long)this.boundaryEnd.length;
    }

    public Header getContentType() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("multipart/form-data; boundary=");
        stringBuilder.append(this.boundary);
        return new BasicHeader("Content-Type", stringBuilder.toString());
    }

    public boolean isChunked() {
        return false;
    }

    public boolean isRepeatable() {
        return this.isRepeatable;
    }

    public boolean isStreaming() {
        return false;
    }

    public void setIsRepeatable(boolean bl) {
        this.isRepeatable = bl;
    }

    public void writeTo(OutputStream outputStream) throws IOException {
        this.bytesWritten = 0L;
        this.totalSize = (int)this.getContentLength();
        this.out.writeTo(outputStream);
        this.updateProgress(this.out.size());
        Iterator iterator = this.fileParts.iterator();
        while (iterator.hasNext()) {
            ((FilePart)iterator.next()).writeTo(outputStream);
        }
        outputStream.write(this.boundaryEnd);
        this.updateProgress(this.boundaryEnd.length);
    }

    private class FilePart {
        public final File file;
        public final byte[] header;

        public FilePart(String string, File file, String string2) {
            this.header = this.createHeader(string, file.getName(), string2);
            this.file = file;
        }

        public FilePart(String string, File file, String string2, String string3) {
            String string4 = TextUtils.isEmpty((CharSequence)string3) ? file.getName() : string3;
            this.header = this.createHeader(string, string4, string2);
            this.file = file;
        }

        private byte[] createHeader(String string, String string2, String string3) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            try {
                byteArrayOutputStream.write(SimpleMultipartEntity.this.boundaryLine);
                byteArrayOutputStream.write(SimpleMultipartEntity.this.createContentDisposition(string, string2));
                byteArrayOutputStream.write(SimpleMultipartEntity.this.createContentType(string3));
                byteArrayOutputStream.write(TRANSFER_ENCODING_BINARY);
                byteArrayOutputStream.write(CR_LF);
            }
            catch (IOException iOException) {
                AsyncHttpClient.log.e(SimpleMultipartEntity.LOG_TAG, "createHeader ByteArrayOutputStream exception", iOException);
            }
            return byteArrayOutputStream.toByteArray();
        }

        public long getTotalLength() {
            return this.file.length() + (long)CR_LF.length + (long)this.header.length;
        }

        public void writeTo(OutputStream outputStream) throws IOException {
            int n;
            outputStream.write(this.header);
            SimpleMultipartEntity.this.updateProgress(this.header.length);
            FileInputStream fileInputStream = new FileInputStream(this.file);
            byte[] arrby = new byte[4096];
            while ((n = fileInputStream.read(arrby)) != -1) {
                outputStream.write(arrby, 0, n);
                SimpleMultipartEntity.this.updateProgress(n);
            }
            outputStream.write(CR_LF);
            SimpleMultipartEntity.this.updateProgress(CR_LF.length);
            outputStream.flush();
            AsyncHttpClient.silentCloseInputStream((InputStream)fileInputStream);
        }
    }

}

