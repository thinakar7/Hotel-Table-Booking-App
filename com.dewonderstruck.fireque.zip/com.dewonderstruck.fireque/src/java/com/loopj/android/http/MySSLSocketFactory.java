/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.HttpVersion
 *  cz.msebera.android.httpclient.ProtocolVersion
 *  cz.msebera.android.httpclient.conn.ClientConnectionManager
 *  cz.msebera.android.httpclient.conn.scheme.PlainSocketFactory
 *  cz.msebera.android.httpclient.conn.scheme.Scheme
 *  cz.msebera.android.httpclient.conn.scheme.SchemeRegistry
 *  cz.msebera.android.httpclient.conn.scheme.SocketFactory
 *  cz.msebera.android.httpclient.conn.ssl.SSLSocketFactory
 *  cz.msebera.android.httpclient.conn.ssl.X509HostnameVerifier
 *  cz.msebera.android.httpclient.impl.client.DefaultHttpClient
 *  cz.msebera.android.httpclient.impl.conn.tsccm.ThreadSafeClientConnManager
 *  cz.msebera.android.httpclient.params.BasicHttpParams
 *  cz.msebera.android.httpclient.params.HttpParams
 *  cz.msebera.android.httpclient.params.HttpProtocolParams
 *  java.io.BufferedInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.Socket
 *  java.security.KeyManagementException
 *  java.security.KeyStore
 *  java.security.KeyStoreException
 *  java.security.NoSuchAlgorithmException
 *  java.security.SecureRandom
 *  java.security.UnrecoverableKeyException
 *  java.security.cert.Certificate
 *  java.security.cert.CertificateException
 *  java.security.cert.CertificateFactory
 *  javax.net.ssl.HttpsURLConnection
 *  javax.net.ssl.KeyManager
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSocketFactory
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.X509TrustManager
 */
package com.loopj.android.http;

import com.loopj.android.http.MySSLSocketFactory;
import cz.msebera.android.httpclient.HttpVersion;
import cz.msebera.android.httpclient.ProtocolVersion;
import cz.msebera.android.httpclient.conn.ClientConnectionManager;
import cz.msebera.android.httpclient.conn.scheme.PlainSocketFactory;
import cz.msebera.android.httpclient.conn.scheme.Scheme;
import cz.msebera.android.httpclient.conn.scheme.SchemeRegistry;
import cz.msebera.android.httpclient.conn.scheme.SocketFactory;
import cz.msebera.android.httpclient.conn.ssl.X509HostnameVerifier;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.impl.conn.tsccm.ThreadSafeClientConnManager;
import cz.msebera.android.httpclient.params.BasicHttpParams;
import cz.msebera.android.httpclient.params.HttpParams;
import cz.msebera.android.httpclient.params.HttpProtocolParams;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class MySSLSocketFactory
extends cz.msebera.android.httpclient.conn.ssl.SSLSocketFactory {
    final SSLContext sslContext;

    public MySSLSocketFactory(KeyStore keyStore) throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException, UnrecoverableKeyException {
        SSLContext sSLContext;
        super(keyStore);
        this.sslContext = sSLContext = SSLContext.getInstance((String)"TLS");
        sSLContext.init(null, new TrustManager[]{new X509TrustManager(this){
            final /* synthetic */ MySSLSocketFactory this$0;
            {
                this.this$0 = mySSLSocketFactory;
            }

            public void checkClientTrusted(java.security.cert.X509Certificate[] arrx509Certificate, String string2) throws CertificateException {
            }

            public void checkServerTrusted(java.security.cert.X509Certificate[] arrx509Certificate, String string2) throws CertificateException {
            }

            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        }}, null);
    }

    public static cz.msebera.android.httpclient.conn.ssl.SSLSocketFactory getFixedSocketFactory() {
        try {
            MySSLSocketFactory mySSLSocketFactory = new MySSLSocketFactory(MySSLSocketFactory.getKeystore());
            mySSLSocketFactory.setHostnameVerifier(cz.msebera.android.httpclient.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            return mySSLSocketFactory;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return cz.msebera.android.httpclient.conn.ssl.SSLSocketFactory.getSocketFactory();
        }
    }

    public static KeyStore getKeystore() {
        KeyStore keyStore = null;
        try {
            keyStore = KeyStore.getInstance((String)KeyStore.getDefaultType());
            keyStore.load(null, null);
            return keyStore;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return keyStore;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static KeyStore getKeystoreOfCA(InputStream inputStream) {
        BufferedInputStream bufferedInputStream;
        Throwable throwable2222;
        block11 : {
            Certificate certificate;
            block12 : {
                Certificate certificate2;
                bufferedInputStream = null;
                CertificateFactory certificateFactory = CertificateFactory.getInstance((String)"X.509");
                bufferedInputStream = new BufferedInputStream(inputStream);
                certificate = certificate2 = certificateFactory.generateCertificate((InputStream)bufferedInputStream);
                bufferedInputStream.close();
                {
                    catch (IOException iOException) {
                        iOException.printStackTrace();
                    }
                    catch (Throwable throwable2222) {
                        break block11;
                    }
                    catch (CertificateException certificateException) {}
                    {
                        certificateException.printStackTrace();
                        certificate = null;
                        if (bufferedInputStream == null) break block12;
                    }
                    {
                        bufferedInputStream.close();
                        certificate = null;
                    }
                }
            }
            String string2 = KeyStore.getDefaultType();
            KeyStore keyStore = null;
            try {
                keyStore = KeyStore.getInstance((String)string2);
                keyStore.load(null, null);
                keyStore.setCertificateEntry("ca", certificate);
                return keyStore;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return keyStore;
            }
        }
        if (bufferedInputStream == null) throw throwable2222;
        try {
            bufferedInputStream.close();
            throw throwable2222;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            throw throwable2222;
        }
    }

    public static DefaultHttpClient getNewHttpClient(KeyStore keyStore) {
        try {
            MySSLSocketFactory mySSLSocketFactory = new MySSLSocketFactory(keyStore);
            SchemeRegistry schemeRegistry = new SchemeRegistry();
            schemeRegistry.register(new Scheme("http", (SocketFactory)PlainSocketFactory.getSocketFactory(), 80));
            schemeRegistry.register(new Scheme("https", (SocketFactory)mySSLSocketFactory, 443));
            BasicHttpParams basicHttpParams = new BasicHttpParams();
            HttpProtocolParams.setVersion((HttpParams)basicHttpParams, (ProtocolVersion)HttpVersion.HTTP_1_1);
            HttpProtocolParams.setContentCharset((HttpParams)basicHttpParams, (String)"UTF-8");
            DefaultHttpClient defaultHttpClient = new DefaultHttpClient((ClientConnectionManager)new ThreadSafeClientConnManager((HttpParams)basicHttpParams, schemeRegistry), (HttpParams)basicHttpParams);
            return defaultHttpClient;
        }
        catch (Exception exception) {
            return new DefaultHttpClient();
        }
    }

    public Socket createSocket() throws IOException {
        return this.sslContext.getSocketFactory().createSocket();
    }

    public Socket createSocket(Socket socket, String string2, int n, boolean bl) throws IOException {
        return this.sslContext.getSocketFactory().createSocket(socket, string2, n, bl);
    }

    public void fixHttpsURLConnection() {
        HttpsURLConnection.setDefaultSSLSocketFactory((SSLSocketFactory)this.sslContext.getSocketFactory());
    }
}

