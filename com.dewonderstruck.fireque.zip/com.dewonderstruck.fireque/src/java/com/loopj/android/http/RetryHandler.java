/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.SystemClock
 *  cz.msebera.android.httpclient.NoHttpResponseException
 *  cz.msebera.android.httpclient.client.HttpRequestRetryHandler
 *  cz.msebera.android.httpclient.client.methods.HttpUriRequest
 *  cz.msebera.android.httpclient.protocol.HttpContext
 *  java.io.IOException
 *  java.io.InterruptedIOException
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.SocketException
 *  java.net.UnknownHostException
 *  java.util.HashSet
 *  java.util.Iterator
 *  javax.net.ssl.SSLException
 */
package com.loopj.android.http;

import android.os.SystemClock;
import cz.msebera.android.httpclient.NoHttpResponseException;
import cz.msebera.android.httpclient.client.HttpRequestRetryHandler;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;
import cz.msebera.android.httpclient.protocol.HttpContext;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.Iterator;
import javax.net.ssl.SSLException;

class RetryHandler
implements HttpRequestRetryHandler {
    private static final HashSet<Class<?>> exceptionBlacklist;
    private static final HashSet<Class<?>> exceptionWhitelist;
    private final int maxRetries;
    private final int retrySleepTimeMS;

    static {
        HashSet hashSet;
        HashSet hashSet2;
        exceptionWhitelist = hashSet = new HashSet();
        exceptionBlacklist = hashSet2 = new HashSet();
        hashSet.add(NoHttpResponseException.class);
        hashSet.add(UnknownHostException.class);
        hashSet.add(SocketException.class);
        hashSet2.add(InterruptedIOException.class);
        hashSet2.add(SSLException.class);
    }

    public RetryHandler(int n, int n2) {
        this.maxRetries = n;
        this.retrySleepTimeMS = n2;
    }

    static void addClassToBlacklist(Class<?> class_) {
        exceptionBlacklist.add(class_);
    }

    static void addClassToWhitelist(Class<?> class_) {
        exceptionWhitelist.add(class_);
    }

    protected boolean isInList(HashSet<Class<?>> hashSet, Throwable throwable) {
        Iterator iterator = hashSet.iterator();
        while (iterator.hasNext()) {
            if (!((Class)iterator.next()).isInstance((Object)throwable)) continue;
            return true;
        }
        return false;
    }

    public boolean retryRequest(IOException iOException, int n, HttpContext httpContext) {
        boolean bl = true;
        Boolean bl2 = (Boolean)httpContext.getAttribute("http.request_sent");
        boolean bl3 = bl2 != null && bl2 != false;
        if (n > this.maxRetries) {
            bl = false;
        } else if (this.isInList(exceptionWhitelist, iOException)) {
            bl = true;
        } else if (this.isInList(exceptionBlacklist, iOException)) {
            bl = false;
        } else if (!bl3) {
            bl = true;
        }
        if (bl && (HttpUriRequest)httpContext.getAttribute("http.request") == null) {
            return false;
        }
        if (bl) {
            SystemClock.sleep((long)this.retrySleepTimeMS);
            return bl;
        }
        iOException.printStackTrace();
        return bl;
    }
}

