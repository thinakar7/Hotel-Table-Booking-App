/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.UnsupportedEncodingException
 *  java.lang.AssertionError
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.loopj.android.http;

import java.io.UnsupportedEncodingException;

public class Base64 {
    public static final int CRLF = 4;
    public static final int DEFAULT = 0;
    public static final int NO_CLOSE = 16;
    public static final int NO_PADDING = 1;
    public static final int NO_WRAP = 2;
    public static final int URL_SAFE = 8;

    private Base64() {
    }

    public static byte[] decode(String string, int n) {
        return Base64.decode(string.getBytes(), n);
    }

    public static byte[] decode(byte[] arrby, int n) {
        return Base64.decode(arrby, 0, arrby.length, n);
    }

    public static byte[] decode(byte[] arrby, int n, int n2, int n3) {
        Decoder decoder = new Decoder(n3, new byte[n2 * 3 / 4]);
        if (decoder.process(arrby, n, n2, true)) {
            if (decoder.op == decoder.output.length) {
                return decoder.output;
            }
            byte[] arrby2 = new byte[decoder.op];
            System.arraycopy((Object)decoder.output, (int)0, (Object)arrby2, (int)0, (int)decoder.op);
            return arrby2;
        }
        throw new IllegalArgumentException("bad base-64");
    }

    public static byte[] encode(byte[] arrby, int n) {
        return Base64.encode(arrby, 0, arrby.length, n);
    }

    public static byte[] encode(byte[] arrby, int n, int n2, int n3) {
        Encoder encoder = new Encoder(n3, null);
        int n4 = 4 * (n2 / 3);
        boolean bl = encoder.do_padding;
        int n5 = 2;
        if (bl) {
            if (n2 % 3 > 0) {
                n4 += 4;
            }
        } else {
            int n6 = n2 % 3;
            if (n6 != 1) {
                if (n6 == n5) {
                    n4 += 3;
                }
            } else {
                n4 += 2;
            }
        }
        if (encoder.do_newline && n2 > 0) {
            int n7 = 1 + (n2 - 1) / 57;
            if (!encoder.do_cr) {
                n5 = 1;
            }
            n4 += n7 * n5;
        }
        encoder.output = new byte[n4];
        encoder.process(arrby, n, n2, true);
        return encoder.output;
    }

    public static String encodeToString(byte[] arrby, int n) {
        try {
            String string = new String(Base64.encode(arrby, n), "US-ASCII");
            return string;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            throw new AssertionError((Object)unsupportedEncodingException);
        }
    }

    public static String encodeToString(byte[] arrby, int n, int n2, int n3) {
        try {
            String string = new String(Base64.encode(arrby, n, n2, n3), "US-ASCII");
            return string;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            throw new AssertionError((Object)unsupportedEncodingException);
        }
    }

    static abstract class Coder {
        public int op;
        public byte[] output;

        Coder() {
        }

        public abstract int maxOutputSize(int var1);

        public abstract boolean process(byte[] var1, int var2, int var3, boolean var4);
    }

    static class Decoder
    extends Coder {
        private static final int[] DECODE = new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -2, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
        private static final int[] DECODE_WEBSAFE = new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -2, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, 63, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
        private static final int EQUALS = -2;
        private static final int SKIP = -1;
        private final int[] alphabet;
        private int state;
        private int value;

        public Decoder(int n, byte[] arrby) {
            this.output = arrby;
            int[] arrn = (n & 8) == 0 ? DECODE : DECODE_WEBSAFE;
            this.alphabet = arrn;
            this.state = 0;
            this.value = 0;
        }

        @Override
        public int maxOutputSize(int n) {
            return 10 + n * 3 / 4;
        }

        @Override
        public boolean process(byte[] arrby, int n, int n2, boolean bl) {
            if (this.state == 6) {
                return false;
            }
            int n3 = n;
            int n4 = n2 + n;
            int n5 = this.state;
            int n6 = this.value;
            int n7 = 0;
            byte[] arrby2 = this.output;
            int[] arrn = this.alphabet;
            while (n3 < n4) {
                if (n5 == 0) {
                    while (n3 + 4 <= n4) {
                        int n8;
                        n6 = n8 = arrn[255 & arrby[n3]] << 18 | arrn[255 & arrby[n3 + 1]] << 12 | arrn[255 & arrby[n3 + 2]] << 6 | arrn[255 & arrby[n3 + 3]];
                        if (n8 < 0) break;
                        arrby2[n7 + 2] = (byte)n6;
                        arrby2[n7 + 1] = (byte)(n6 >> 8);
                        arrby2[n7] = (byte)(n6 >> 16);
                        n7 += 3;
                        n3 += 4;
                    }
                    if (n3 >= n4) break;
                }
                int n9 = n3 + 1;
                int n10 = arrn[255 & arrby[n3]];
                if (n5 != 0) {
                    if (n5 != 1) {
                        if (n5 != 2) {
                            if (n5 != 3) {
                                if (n5 != 4) {
                                    if (n5 == 5 && n10 != -1) {
                                        this.state = 6;
                                        return false;
                                    }
                                } else if (n10 == -2) {
                                    ++n5;
                                } else if (n10 != -1) {
                                    this.state = 6;
                                    return false;
                                }
                            } else if (n10 >= 0) {
                                n6 = n10 | n6 << 6;
                                arrby2[n7 + 2] = (byte)n6;
                                arrby2[n7 + 1] = (byte)(n6 >> 8);
                                arrby2[n7] = (byte)(n6 >> 16);
                                n7 += 3;
                                n5 = 0;
                            } else if (n10 == -2) {
                                arrby2[n7 + 1] = (byte)(n6 >> 2);
                                arrby2[n7] = (byte)(n6 >> 10);
                                n7 += 2;
                                n5 = 5;
                            } else if (n10 != -1) {
                                this.state = 6;
                                return false;
                            }
                        } else if (n10 >= 0) {
                            n6 = n10 | n6 << 6;
                            ++n5;
                        } else if (n10 == -2) {
                            int n11 = n7 + 1;
                            arrby2[n7] = (byte)(n6 >> 4);
                            n5 = 4;
                            n7 = n11;
                        } else if (n10 != -1) {
                            this.state = 6;
                            return false;
                        }
                    } else if (n10 >= 0) {
                        n6 = n10 | n6 << 6;
                        ++n5;
                    } else if (n10 != -1) {
                        this.state = 6;
                        return false;
                    }
                } else if (n10 >= 0) {
                    n6 = n10;
                    ++n5;
                } else if (n10 != -1) {
                    this.state = 6;
                    return false;
                }
                n3 = n9;
            }
            if (!bl) {
                this.state = n5;
                this.value = n6;
                this.op = n7;
                return true;
            }
            if (n5 != 1) {
                if (n5 != 2) {
                    if (n5 != 3) {
                        if (n5 == 4) {
                            this.state = 6;
                            return false;
                        }
                    } else {
                        int n12 = n7 + 1;
                        arrby2[n7] = (byte)(n6 >> 10);
                        n7 = n12 + 1;
                        arrby2[n12] = (byte)(n6 >> 2);
                    }
                } else {
                    int n13 = n7 + 1;
                    arrby2[n7] = (byte)(n6 >> 4);
                    n7 = n13;
                }
                this.state = n5;
                this.op = n7;
                return true;
            }
            this.state = 6;
            return false;
        }
    }

    static class Encoder
    extends Coder {
        private static final byte[] ENCODE = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47};
        private static final byte[] ENCODE_WEBSAFE = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95};
        public static final int LINE_GROUPS = 19;
        private final byte[] alphabet;
        private int count;
        public final boolean do_cr;
        public final boolean do_newline;
        public final boolean do_padding;
        private final byte[] tail;
        int tailLen;

        public Encoder(int n, byte[] arrby) {
            this.output = arrby;
            int n2 = n & 1;
            boolean bl = true;
            boolean bl2 = n2 == 0;
            this.do_padding = bl2;
            boolean bl3 = (n & 2) == 0;
            this.do_newline = bl3;
            if ((n & 4) == 0) {
                bl = false;
            }
            this.do_cr = bl;
            byte[] arrby2 = (n & 8) == 0 ? ENCODE : ENCODE_WEBSAFE;
            this.alphabet = arrby2;
            this.tail = new byte[2];
            this.tailLen = 0;
            int n3 = bl3 ? 19 : -1;
            this.count = n3;
        }

        @Override
        public int maxOutputSize(int n) {
            return 10 + n * 8 / 5;
        }

        @Override
        public boolean process(byte[] arrby, int n, int n2, boolean bl) {
            byte[] arrby2 = this.alphabet;
            byte[] arrby3 = this.output;
            int n3 = this.count;
            int n4 = n;
            int n5 = n2 + n;
            int n6 = -1;
            int n7 = this.tailLen;
            if (n7 != 1) {
                if (n7 == 2 && n4 + 1 <= n5) {
                    byte[] arrby4 = this.tail;
                    int n8 = (255 & arrby4[0]) << 16 | (255 & arrby4[1]) << 8;
                    int n9 = n4 + 1;
                    n6 = n8 | 255 & arrby[n4];
                    this.tailLen = 0;
                    n4 = n9;
                }
            } else if (n4 + 2 <= n5) {
                int n10 = (255 & this.tail[0]) << 16;
                int n11 = n4 + 1;
                int n12 = n10 | (255 & arrby[n4]) << 8;
                int n13 = n11 + 1;
                n6 = n12 | 255 & arrby[n11];
                this.tailLen = 0;
                n4 = n13;
            }
            int n14 = 0;
            if (n6 != -1) {
                int n15 = 0 + 1;
                arrby3[0] = arrby2[63 & n6 >> 18];
                int n16 = n15 + 1;
                arrby3[n15] = arrby2[63 & n6 >> 12];
                int n17 = n16 + 1;
                arrby3[n16] = arrby2[63 & n6 >> 6];
                n14 = n17 + 1;
                arrby3[n17] = arrby2[n6 & 63];
                if (--n3 == 0) {
                    if (this.do_cr) {
                        int n18 = n14 + 1;
                        arrby3[n14] = 13;
                        n14 = n18;
                    }
                    int n19 = n14 + 1;
                    arrby3[n14] = 10;
                    n3 = 19;
                    n14 = n19;
                }
            }
            while (n4 + 3 <= n5) {
                int n20 = (255 & arrby[n4]) << 16 | (255 & arrby[n4 + 1]) << 8 | 255 & arrby[n4 + 2];
                arrby3[n14] = arrby2[63 & n20 >> 18];
                arrby3[n14 + 1] = arrby2[63 & n20 >> 12];
                arrby3[n14 + 2] = arrby2[63 & n20 >> 6];
                arrby3[n14 + 3] = arrby2[n20 & 63];
                n4 += 3;
                n14 += 4;
                if (--n3 != 0) continue;
                if (this.do_cr) {
                    int n21 = n14 + 1;
                    arrby3[n14] = 13;
                    n14 = n21;
                }
                int n22 = n14 + 1;
                arrby3[n14] = 10;
                n3 = 19;
                n14 = n22;
            }
            if (bl) {
                int n23 = this.tailLen;
                if (n4 - n23 == n5 - 1) {
                    byte by;
                    int n24;
                    if (n23 > 0) {
                        byte[] arrby5 = this.tail;
                        n24 = 0 + 1;
                        by = arrby5[0];
                    } else {
                        n4 + 1;
                        byte by2 = arrby[n4];
                        n24 = 0;
                        by = by2;
                    }
                    int n25 = (by & 255) << 4;
                    this.tailLen = n23 - n24;
                    int n26 = n14 + 1;
                    arrby3[n14] = arrby2[63 & n25 >> 6];
                    n14 = n26 + 1;
                    arrby3[n26] = arrby2[n25 & 63];
                    if (this.do_padding) {
                        int n27 = n14 + 1;
                        arrby3[n14] = 61;
                        n14 = n27 + 1;
                        arrby3[n27] = 61;
                    }
                    if (this.do_newline) {
                        if (this.do_cr) {
                            int n28 = n14 + 1;
                            arrby3[n14] = 13;
                            n14 = n28;
                        }
                        int n29 = n14 + 1;
                        arrby3[n14] = 10;
                        n14 = n29;
                    }
                } else if (n4 - n23 == n5 - 2) {
                    int n30;
                    byte by;
                    byte by3;
                    if (n23 > 1) {
                        byte[] arrby6 = this.tail;
                        n30 = 0 + 1;
                        by3 = arrby6[0];
                    } else {
                        int n31 = n4 + 1;
                        byte by4 = arrby[n4];
                        n30 = 0;
                        by3 = by4;
                        n4 = n31;
                    }
                    int n32 = (by3 & 255) << 10;
                    if (n23 > 0) {
                        byte[] arrby7 = this.tail;
                        int n33 = n30 + 1;
                        by = arrby7[n30];
                        n30 = n33;
                    } else {
                        n4 + 1;
                        by = arrby[n4];
                    }
                    int n34 = n32 | (by & 255) << 2;
                    this.tailLen = n23 - n30;
                    int n35 = n14 + 1;
                    arrby3[n14] = arrby2[63 & n34 >> 12];
                    int n36 = n35 + 1;
                    arrby3[n35] = arrby2[63 & n34 >> 6];
                    int n37 = n36 + 1;
                    arrby3[n36] = arrby2[n34 & 63];
                    if (this.do_padding) {
                        int n38 = n37 + 1;
                        arrby3[n37] = 61;
                        n37 = n38;
                    }
                    if (this.do_newline) {
                        if (this.do_cr) {
                            int n39 = n37 + 1;
                            arrby3[n37] = 13;
                            n37 = n39;
                        }
                        n14 = n37 + 1;
                        arrby3[n37] = 10;
                    } else {
                        n14 = n37;
                    }
                } else if (this.do_newline && n14 > 0 && n3 != 19) {
                    if (this.do_cr) {
                        int n40 = n14 + 1;
                        arrby3[n14] = 13;
                        n14 = n40;
                    }
                    int n41 = n14 + 1;
                    arrby3[n14] = 10;
                    n14 = n41;
                }
            } else if (n4 == n5 - 1) {
                byte[] arrby8 = this.tail;
                int n42 = this.tailLen;
                this.tailLen = n42 + 1;
                arrby8[n42] = arrby[n4];
            } else if (n4 == n5 - 2) {
                int n43;
                byte[] arrby9 = this.tail;
                int n44 = this.tailLen;
                this.tailLen = n43 = n44 + 1;
                arrby9[n44] = arrby[n4];
                this.tailLen = n43 + 1;
                arrby9[n43] = arrby[n4 + 1];
            }
            this.op = n14;
            this.count = n3;
            return true;
        }
    }

}

