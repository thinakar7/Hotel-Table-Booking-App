/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.HttpException
 *  cz.msebera.android.httpclient.HttpHost
 *  cz.msebera.android.httpclient.HttpRequest
 *  cz.msebera.android.httpclient.HttpRequestInterceptor
 *  cz.msebera.android.httpclient.auth.AuthScheme
 *  cz.msebera.android.httpclient.auth.AuthScope
 *  cz.msebera.android.httpclient.auth.AuthState
 *  cz.msebera.android.httpclient.auth.Credentials
 *  cz.msebera.android.httpclient.client.CredentialsProvider
 *  cz.msebera.android.httpclient.impl.auth.BasicScheme
 *  cz.msebera.android.httpclient.protocol.HttpContext
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 */
package com.loopj.android.http;

import cz.msebera.android.httpclient.HttpException;
import cz.msebera.android.httpclient.HttpHost;
import cz.msebera.android.httpclient.HttpRequest;
import cz.msebera.android.httpclient.HttpRequestInterceptor;
import cz.msebera.android.httpclient.auth.AuthScheme;
import cz.msebera.android.httpclient.auth.AuthScope;
import cz.msebera.android.httpclient.auth.AuthState;
import cz.msebera.android.httpclient.auth.Credentials;
import cz.msebera.android.httpclient.client.CredentialsProvider;
import cz.msebera.android.httpclient.impl.auth.BasicScheme;
import cz.msebera.android.httpclient.protocol.HttpContext;
import java.io.IOException;

public class PreemptiveAuthorizationHttpRequestInterceptor
implements HttpRequestInterceptor {
    public void process(HttpRequest httpRequest, HttpContext httpContext) throws HttpException, IOException {
        Credentials credentials;
        AuthState authState = (AuthState)httpContext.getAttribute("http.auth.target-scope");
        CredentialsProvider credentialsProvider = (CredentialsProvider)httpContext.getAttribute("http.auth.credentials-provider");
        HttpHost httpHost = (HttpHost)httpContext.getAttribute("http.target_host");
        if (authState.getAuthScheme() == null && (credentials = credentialsProvider.getCredentials(new AuthScope(httpHost.getHostName(), httpHost.getPort()))) != null) {
            authState.setAuthScheme((AuthScheme)new BasicScheme());
            authState.setCredentials(credentials);
        }
    }
}

