/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpEntity
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.net.URI
 */
package com.loopj.android.http;

import android.content.Context;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.LogInterface;
import com.loopj.android.http.Utils;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpEntity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;

public abstract class FileAsyncHttpResponseHandler
extends AsyncHttpResponseHandler {
    private static final String LOG_TAG = "FileAsyncHttpRH";
    protected final boolean append;
    protected final File file;
    protected File frontendFile;
    protected final boolean renameIfExists;

    public FileAsyncHttpResponseHandler(Context context) {
        this.file = this.getTemporaryFile(context);
        this.append = false;
        this.renameIfExists = false;
    }

    public FileAsyncHttpResponseHandler(File file) {
        this(file, false);
    }

    public FileAsyncHttpResponseHandler(File file, boolean bl) {
        this(file, bl, false);
    }

    public FileAsyncHttpResponseHandler(File file, boolean bl, boolean bl2) {
        this(file, bl, bl2, false);
    }

    public FileAsyncHttpResponseHandler(File file, boolean bl, boolean bl2, boolean bl3) {
        super(bl3);
        boolean bl4 = file != null;
        Utils.asserts(bl4, "File passed into FileAsyncHttpResponseHandler constructor must not be null");
        if (!file.isDirectory() && !file.getParentFile().isDirectory()) {
            Utils.asserts(file.getParentFile().mkdirs(), "Cannot create parent directories for requested File location");
        }
        if (file.isDirectory() && !file.mkdirs()) {
            AsyncHttpClient.log.d(LOG_TAG, "Cannot create directories for requested Directory location, might not be a problem");
        }
        this.file = file;
        this.append = bl;
        this.renameIfExists = bl2;
    }

    public boolean deleteTargetFile() {
        return this.getTargetFile() != null && this.getTargetFile().delete();
    }

    protected File getOriginalFile() {
        boolean bl = this.file != null;
        Utils.asserts(bl, "Target file is null, fatal!");
        return this.file;
    }

    @Override
    protected byte[] getResponseData(HttpEntity httpEntity) throws IOException {
        if (httpEntity != null) {
            InputStream inputStream = httpEntity.getContent();
            long l = httpEntity.getContentLength();
            FileOutputStream fileOutputStream = new FileOutputStream(this.getTargetFile(), this.append);
            if (inputStream != null) {
                byte[] arrby;
                int n;
                try {
                    arrby = new byte[4096];
                    n = 0;
                }
                catch (Throwable throwable) {
                    AsyncHttpClient.silentCloseInputStream(inputStream);
                    fileOutputStream.flush();
                    AsyncHttpClient.silentCloseOutputStream((OutputStream)fileOutputStream);
                    throw throwable;
                }
                do {
                    int n2 = inputStream.read(arrby);
                    if (n2 == -1) break;
                    if (Thread.currentThread().isInterrupted()) break;
                    n += n2;
                    fileOutputStream.write(arrby, 0, n2);
                    this.sendProgressMessage(n, l);
                    continue;
                    break;
                } while (true);
                AsyncHttpClient.silentCloseInputStream(inputStream);
                fileOutputStream.flush();
                AsyncHttpClient.silentCloseOutputStream((OutputStream)fileOutputStream);
            }
        }
        return null;
    }

    public File getTargetFile() {
        if (this.frontendFile == null) {
            File file = this.getOriginalFile().isDirectory() ? this.getTargetFileByParsingURL() : this.getOriginalFile();
            this.frontendFile = file;
        }
        return this.frontendFile;
    }

    protected File getTargetFileByParsingURL() {
        Utils.asserts(this.getOriginalFile().isDirectory(), "Target file is not a directory, cannot proceed");
        boolean bl = this.getRequestURI() != null;
        Utils.asserts(bl, "RequestURI is null, cannot proceed");
        String string2 = this.getRequestURI().toString();
        String string3 = string2.substring(1 + string2.lastIndexOf(47), string2.length());
        File file = new File(this.getOriginalFile(), string3);
        if (file.exists() && this.renameIfExists) {
            String string4;
            if (!string3.contains((CharSequence)".")) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string3);
                stringBuilder.append(" (%d)");
                string4 = stringBuilder.toString();
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string3.substring(0, string3.lastIndexOf(46)));
                stringBuilder.append(" (%d)");
                stringBuilder.append(string3.substring(string3.lastIndexOf(46), string3.length()));
                string4 = stringBuilder.toString();
            }
            int n = 0;
            do {
                File file2 = this.getOriginalFile();
                Object[] arrobject = new Object[]{n};
                File file3 = new File(file2, String.format((String)string4, (Object[])arrobject));
                if (!file3.exists()) {
                    return file3;
                }
                ++n;
            } while (true);
        }
        return file;
    }

    protected File getTemporaryFile(Context context) {
        boolean bl = context != null;
        Utils.asserts(bl, "Tried creating temporary file without having Context");
        try {
            File file = File.createTempFile((String)"temp_", (String)"_handled", (File)context.getCacheDir());
            return file;
        }
        catch (IOException iOException) {
            AsyncHttpClient.log.e(LOG_TAG, "Cannot create temporary file", iOException);
            return null;
        }
    }

    public abstract void onFailure(int var1, Header[] var2, Throwable var3, File var4);

    @Override
    public final void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
        this.onFailure(n, arrheader, throwable, this.getTargetFile());
    }

    public abstract void onSuccess(int var1, Header[] var2, File var3);

    @Override
    public final void onSuccess(int n, Header[] arrheader, byte[] arrby) {
        this.onSuccess(n, arrheader, this.getTargetFile());
    }
}

