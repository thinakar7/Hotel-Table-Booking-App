/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpEntity
 *  cz.msebera.android.httpclient.HttpResponse
 *  cz.msebera.android.httpclient.StatusLine
 *  cz.msebera.android.httpclient.client.HttpResponseException
 *  cz.msebera.android.httpclient.client.methods.HttpUriRequest
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 */
package com.loopj.android.http;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.FileAsyncHttpResponseHandler;
import com.loopj.android.http.LogInterface;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.StatusLine;
import cz.msebera.android.httpclient.client.HttpResponseException;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public abstract class RangeFileAsyncHttpResponseHandler
extends FileAsyncHttpResponseHandler {
    private static final String LOG_TAG = "RangeFileAsyncHttpRH";
    private boolean append = false;
    private long current = 0L;

    public RangeFileAsyncHttpResponseHandler(File file) {
        super(file);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected byte[] getResponseData(HttpEntity httpEntity) throws IOException {
        if (httpEntity == null) return null;
        {
            InputStream inputStream = httpEntity.getContent();
            long l = httpEntity.getContentLength() + this.current;
            FileOutputStream fileOutputStream = new FileOutputStream(this.getTargetFile(), this.append);
            if (inputStream == null) return null;
            {
                try {
                    int n;
                    byte[] arrby = new byte[4096];
                    while (this.current < l && (n = inputStream.read(arrby)) != -1 && !Thread.currentThread().isInterrupted()) {
                        this.current += (long)n;
                        fileOutputStream.write(arrby, 0, n);
                        this.sendProgressMessage(this.current, l);
                    }
                    return null;
                }
                finally {
                    inputStream.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                }
            }
        }
    }

    @Override
    public void sendResponseMessage(HttpResponse httpResponse) throws IOException {
        if (!Thread.currentThread().isInterrupted()) {
            StatusLine statusLine = httpResponse.getStatusLine();
            if (statusLine.getStatusCode() == 416) {
                if (!Thread.currentThread().isInterrupted()) {
                    this.sendSuccessMessage(statusLine.getStatusCode(), httpResponse.getAllHeaders(), null);
                    return;
                }
            } else if (statusLine.getStatusCode() >= 300) {
                if (!Thread.currentThread().isInterrupted()) {
                    this.sendFailureMessage(statusLine.getStatusCode(), httpResponse.getAllHeaders(), null, (Throwable)new HttpResponseException(statusLine.getStatusCode(), statusLine.getReasonPhrase()));
                    return;
                }
            } else if (!Thread.currentThread().isInterrupted()) {
                Header header = httpResponse.getFirstHeader("Content-Range");
                if (header == null) {
                    this.append = false;
                    this.current = 0L;
                } else {
                    LogInterface logInterface = AsyncHttpClient.log;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Content-Range: ");
                    stringBuilder.append(header.getValue());
                    logInterface.v(LOG_TAG, stringBuilder.toString());
                }
                this.sendSuccessMessage(statusLine.getStatusCode(), httpResponse.getAllHeaders(), this.getResponseData(httpResponse.getEntity()));
            }
        }
    }

    public void updateRequestHeaders(HttpUriRequest httpUriRequest) {
        if (this.file.exists() && this.file.canWrite()) {
            this.current = this.file.length();
        }
        if (this.current > 0L) {
            this.append = true;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("bytes=");
            stringBuilder.append(this.current);
            stringBuilder.append("-");
            httpUriRequest.setHeader("Range", stringBuilder.toString());
        }
    }
}

