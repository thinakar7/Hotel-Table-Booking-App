/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.Header
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 */
package com.loopj.android.http;

import com.loopj.android.http.BaseJsonHttpResponseHandler;
import com.loopj.android.http.TextHttpResponseHandler;
import cz.msebera.android.httpclient.Header;

public abstract class BaseJsonHttpResponseHandler<JSON_TYPE>
extends TextHttpResponseHandler {
    private static final String LOG_TAG = "BaseJsonHttpRH";

    public BaseJsonHttpResponseHandler() {
        this("UTF-8");
    }

    public BaseJsonHttpResponseHandler(String string2) {
        super(string2);
    }

    @Override
    public final void onFailure(int n, Header[] arrheader, String string2, Throwable throwable) {
        if (string2 != null) {
            Runnable runnable = new Runnable(this, string2, n, arrheader, throwable){
                final /* synthetic */ BaseJsonHttpResponseHandler this$0;
                final /* synthetic */ Header[] val$headers;
                final /* synthetic */ String val$responseString;
                final /* synthetic */ int val$statusCode;
                final /* synthetic */ Throwable val$throwable;
                {
                    this.this$0 = baseJsonHttpResponseHandler;
                    this.val$responseString = string2;
                    this.val$statusCode = n;
                    this.val$headers = arrheader;
                    this.val$throwable = throwable;
                }

                public void run() {
                    try {
                        JSON_TYPE JSON_TYPE = this.this$0.parseResponse(this.val$responseString, true);
                        this.this$0.postRunnable(new Runnable(this, JSON_TYPE){
                            final /* synthetic */ 2 this$1;
                            final /* synthetic */ Object val$jsonResponse;
                            {
                                this.this$1 = var1_1;
                                this.val$jsonResponse = object;
                            }

                            public void run() {
                                this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, this.this$1.val$throwable, this.this$1.val$responseString, this.val$jsonResponse);
                            }
                        });
                        return;
                    }
                    catch (Throwable throwable) {
                        com.loopj.android.http.AsyncHttpClient.log.d("BaseJsonHttpRH", "parseResponse thrown an problem", throwable);
                        this.this$0.postRunnable(new Runnable(this){
                            final /* synthetic */ 2 this$1;
                            {
                                this.this$1 = var1_1;
                            }

                            public void run() {
                                this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, this.this$1.val$throwable, this.this$1.val$responseString, null);
                            }
                        });
                        return;
                    }
                }
            };
            if (!this.getUseSynchronousMode() && !this.getUsePoolThread()) {
                new Thread(runnable).start();
            } else {
                runnable.run();
            }
            return;
        }
        this.onFailure(n, arrheader, throwable, null, null);
    }

    public abstract void onFailure(int var1, Header[] var2, Throwable var3, String var4, JSON_TYPE var5);

    @Override
    public final void onSuccess(int n, Header[] arrheader, String string2) {
        if (n != 204) {
            Runnable runnable = new Runnable(this, string2, n, arrheader){
                final /* synthetic */ BaseJsonHttpResponseHandler this$0;
                final /* synthetic */ Header[] val$headers;
                final /* synthetic */ String val$responseString;
                final /* synthetic */ int val$statusCode;
                {
                    this.this$0 = baseJsonHttpResponseHandler;
                    this.val$responseString = string2;
                    this.val$statusCode = n;
                    this.val$headers = arrheader;
                }

                public void run() {
                    try {
                        JSON_TYPE JSON_TYPE = this.this$0.parseResponse(this.val$responseString, false);
                        this.this$0.postRunnable(new Runnable(this, JSON_TYPE){
                            final /* synthetic */ 1 this$1;
                            final /* synthetic */ Object val$jsonResponse;
                            {
                                this.this$1 = var1_1;
                                this.val$jsonResponse = object;
                            }

                            public void run() {
                                this.this$1.this$0.onSuccess(this.this$1.val$statusCode, this.this$1.val$headers, this.this$1.val$responseString, this.val$jsonResponse);
                            }
                        });
                        return;
                    }
                    catch (Throwable throwable) {
                        com.loopj.android.http.AsyncHttpClient.log.d("BaseJsonHttpRH", "parseResponse thrown an problem", throwable);
                        this.this$0.postRunnable(new Runnable(this, throwable){
                            final /* synthetic */ 1 this$1;
                            final /* synthetic */ Throwable val$t;
                            {
                                this.this$1 = var1_1;
                                this.val$t = throwable;
                            }

                            public void run() {
                                this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, this.val$t, this.this$1.val$responseString, null);
                            }
                        });
                        return;
                    }
                }
            };
            if (!this.getUseSynchronousMode() && !this.getUsePoolThread()) {
                new Thread(runnable).start();
            } else {
                runnable.run();
            }
            return;
        }
        this.onSuccess(n, arrheader, null, null);
    }

    public abstract void onSuccess(int var1, Header[] var2, String var3, JSON_TYPE var4);

    protected abstract JSON_TYPE parseResponse(String var1, boolean var2) throws Throwable;
}

