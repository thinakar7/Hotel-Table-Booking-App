/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpEntity
 *  java.io.IOException
 *  java.lang.Error
 *  java.lang.String
 *  java.lang.Throwable
 *  org.xml.sax.helpers.DefaultHandler
 */
package com.loopj.android.http;

import com.loopj.android.http.AsyncHttpResponseHandler;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpEntity;
import java.io.IOException;
import org.xml.sax.helpers.DefaultHandler;

public abstract class SaxAsyncHttpResponseHandler<T extends DefaultHandler>
extends AsyncHttpResponseHandler {
    private static final String LOG_TAG = "SaxAsyncHttpRH";
    private T handler = null;

    public SaxAsyncHttpResponseHandler(T t) {
        if (t != null) {
            this.handler = t;
            return;
        }
        throw new Error("null instance of <T extends DefaultHandler> passed to constructor");
    }

    /*
     * Exception decompiling
     */
    @Override
    protected byte[] getResponseData(HttpEntity var1_1) throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [9] lbl20 : af: try { 2[TRYBLOCK]

        // org.benf.cfr.reader.b.a.a.b.g$1.a(Cleaner.java:44)
        // org.benf.cfr.reader.b.a.a.b.g$1.a(Cleaner.java:22)
        // org.benf.cfr.reader.util.d.c.d(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.b.a.a.b.g.a(Cleaner.java:54)
        // org.benf.cfr.reader.b.a.a.b.ao.a(RemoveDeterministicJumps.java:38)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:443)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public abstract void onFailure(int var1, Header[] var2, T var3);

    @Override
    public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
        this.onFailure(n, arrheader, this.handler);
    }

    public abstract void onSuccess(int var1, Header[] var2, T var3);

    @Override
    public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
        this.onSuccess(n, arrheader, this.handler);
    }
}

