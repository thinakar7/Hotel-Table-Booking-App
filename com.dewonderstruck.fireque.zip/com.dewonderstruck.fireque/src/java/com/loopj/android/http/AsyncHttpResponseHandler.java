/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpEntity
 *  cz.msebera.android.httpclient.HttpResponse
 *  cz.msebera.android.httpclient.StatusLine
 *  cz.msebera.android.httpclient.client.HttpResponseException
 *  cz.msebera.android.httpclient.util.ByteArrayBuffer
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 *  java.net.URI
 */
package com.loopj.android.http;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.LogInterface;
import com.loopj.android.http.ResponseHandlerInterface;
import com.loopj.android.http.Utils;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.StatusLine;
import cz.msebera.android.httpclient.client.HttpResponseException;
import cz.msebera.android.httpclient.util.ByteArrayBuffer;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URI;

public abstract class AsyncHttpResponseHandler
implements ResponseHandlerInterface {
    protected static final int BUFFER_SIZE = 4096;
    protected static final int CANCEL_MESSAGE = 6;
    public static final String DEFAULT_CHARSET = "UTF-8";
    protected static final int FAILURE_MESSAGE = 1;
    protected static final int FINISH_MESSAGE = 3;
    private static final String LOG_TAG = "AsyncHttpRH";
    protected static final int PROGRESS_MESSAGE = 4;
    protected static final int RETRY_MESSAGE = 5;
    protected static final int START_MESSAGE = 2;
    protected static final int SUCCESS_MESSAGE = 0;
    public static final String UTF8_BOM = "\ufeff";
    private WeakReference<Object> TAG = new WeakReference(null);
    private Handler handler;
    private Looper looper = null;
    private Header[] requestHeaders = null;
    private URI requestURI = null;
    private String responseCharset = "UTF-8";
    private boolean usePoolThread;
    private boolean useSynchronousMode;

    public AsyncHttpResponseHandler() {
        this(null);
    }

    public AsyncHttpResponseHandler(Looper looper) {
        Looper looper2 = looper == null ? Looper.myLooper() : looper;
        this.looper = looper2;
        this.setUseSynchronousMode(false);
        this.setUsePoolThread(false);
    }

    public AsyncHttpResponseHandler(boolean bl) {
        this.setUsePoolThread(bl);
        if (!this.getUsePoolThread()) {
            this.looper = Looper.myLooper();
            this.setUseSynchronousMode(false);
        }
    }

    public String getCharset() {
        String string = this.responseCharset;
        if (string == null) {
            string = DEFAULT_CHARSET;
        }
        return string;
    }

    @Override
    public Header[] getRequestHeaders() {
        return this.requestHeaders;
    }

    @Override
    public URI getRequestURI() {
        return this.requestURI;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    byte[] getResponseData(HttpEntity httpEntity) throws IOException {
        void var7_11;
        InputStream inputStream;
        block13 : {
            block12 : {
                long l;
                ByteArrayBuffer byteArrayBuffer;
                byte[] arrby;
                int n;
                if (httpEntity == null) {
                    return null;
                }
                inputStream = httpEntity.getContent();
                if (inputStream == null) {
                    return null;
                }
                long l2 = httpEntity.getContentLength();
                if (l2 > Integer.MAX_VALUE) {
                    throw new IllegalArgumentException("HTTP entity too large to be buffered in memory");
                }
                int n2 = l2 <= 0L ? 4096 : (int)l2;
                try {
                    byteArrayBuffer = new ByteArrayBuffer(n2);
                }
                catch (OutOfMemoryError outOfMemoryError) {
                    // empty catch block
                    break block12;
                }
                try {
                    arrby = new byte[4096];
                    l = 0L;
                }
                catch (Throwable throwable) {
                    break block13;
                }
                while ((n = inputStream.read(arrby)) != -1 && !Thread.currentThread().isInterrupted()) {
                    l += (long)n;
                    byteArrayBuffer.append(arrby, 0, n);
                    long l3 = l2 <= 0L ? 1L : l2;
                    try {
                        this.sendProgressMessage(l, l3);
                    }
                    catch (Throwable throwable) {
                        break block13;
                    }
                }
                try {
                    AsyncHttpClient.silentCloseInputStream(inputStream);
                    AsyncHttpClient.endEntityViaReflection(httpEntity);
                    return byteArrayBuffer.toByteArray();
                }
                catch (OutOfMemoryError outOfMemoryError) {}
            }
            System.gc();
            throw new IOException("File too large to fit into available memory");
        }
        AsyncHttpClient.silentCloseInputStream(inputStream);
        AsyncHttpClient.endEntityViaReflection(httpEntity);
        throw var7_11;
    }

    @Override
    public Object getTag() {
        return this.TAG.get();
    }

    @Override
    public boolean getUsePoolThread() {
        return this.usePoolThread;
    }

    @Override
    public boolean getUseSynchronousMode() {
        return this.useSynchronousMode;
    }

    /*
     * Exception decompiling
     */
    protected void handleMessage(Message var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CASE]], but top level block is 1[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    protected Message obtainMessage(int n, Object object) {
        return Message.obtain((Handler)this.handler, (int)n, (Object)object);
    }

    public void onCancel() {
        AsyncHttpClient.log.d(LOG_TAG, "Request got cancelled");
    }

    public abstract void onFailure(int var1, Header[] var2, byte[] var3, Throwable var4);

    public void onFinish() {
    }

    @Override
    public void onPostProcessResponse(ResponseHandlerInterface responseHandlerInterface, HttpResponse httpResponse) {
    }

    @Override
    public void onPreProcessResponse(ResponseHandlerInterface responseHandlerInterface, HttpResponse httpResponse) {
    }

    public void onProgress(long l, long l2) {
        LogInterface logInterface = AsyncHttpClient.log;
        Object[] arrobject = new Object[3];
        arrobject[0] = l;
        arrobject[1] = l2;
        double d = l2 > 0L ? 100.0 * (1.0 * (double)l / (double)l2) : -1.0;
        arrobject[2] = d;
        logInterface.v("AsyncHttpRH", String.format((String)"Progress %d from %d (%2.0f%%)", (Object[])arrobject));
    }

    public void onRetry(int n) {
        LogInterface logInterface = AsyncHttpClient.log;
        Object[] arrobject = new Object[]{n};
        logInterface.d("AsyncHttpRH", String.format((String)"Request retry no. %d", (Object[])arrobject));
    }

    public void onStart() {
    }

    public abstract void onSuccess(int var1, Header[] var2, byte[] var3);

    public void onUserException(Throwable throwable) {
        AsyncHttpClient.log.e("AsyncHttpRH", "User-space exception detected!", throwable);
        throw new RuntimeException(throwable);
    }

    protected void postRunnable(Runnable runnable) {
        if (runnable != null) {
            Handler handler;
            if (!this.getUseSynchronousMode() && (handler = this.handler) != null) {
                handler.post(runnable);
                return;
            }
            runnable.run();
        }
    }

    @Override
    public final void sendCancelMessage() {
        this.sendMessage(this.obtainMessage(6, null));
    }

    @Override
    public final void sendFailureMessage(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
        Object[] arrobject = new Object[]{n, arrheader, arrby, throwable};
        this.sendMessage(this.obtainMessage(1, arrobject));
    }

    @Override
    public final void sendFinishMessage() {
        this.sendMessage(this.obtainMessage(3, null));
    }

    protected void sendMessage(Message message) {
        if (!this.getUseSynchronousMode() && this.handler != null) {
            if (!Thread.currentThread().isInterrupted()) {
                boolean bl = this.handler != null;
                Utils.asserts(bl, "handler should not be null!");
                this.handler.sendMessage(message);
                return;
            }
        } else {
            this.handleMessage(message);
        }
    }

    @Override
    public final void sendProgressMessage(long l, long l2) {
        Object[] arrobject = new Object[]{l, l2};
        this.sendMessage(this.obtainMessage(4, arrobject));
    }

    @Override
    public void sendResponseMessage(HttpResponse httpResponse) throws IOException {
        if (!Thread.currentThread().isInterrupted()) {
            StatusLine statusLine = httpResponse.getStatusLine();
            byte[] arrby = this.getResponseData(httpResponse.getEntity());
            if (!Thread.currentThread().isInterrupted()) {
                if (statusLine.getStatusCode() >= 300) {
                    this.sendFailureMessage(statusLine.getStatusCode(), httpResponse.getAllHeaders(), arrby, (Throwable)new HttpResponseException(statusLine.getStatusCode(), statusLine.getReasonPhrase()));
                    return;
                }
                this.sendSuccessMessage(statusLine.getStatusCode(), httpResponse.getAllHeaders(), arrby);
            }
        }
    }

    @Override
    public final void sendRetryMessage(int n) {
        Object[] arrobject = new Object[]{n};
        this.sendMessage(this.obtainMessage(5, arrobject));
    }

    @Override
    public final void sendStartMessage() {
        this.sendMessage(this.obtainMessage(2, null));
    }

    @Override
    public final void sendSuccessMessage(int n, Header[] arrheader, byte[] arrby) {
        Object[] arrobject = new Object[]{n, arrheader, arrby};
        this.sendMessage(this.obtainMessage(0, arrobject));
    }

    public void setCharset(String string) {
        this.responseCharset = string;
    }

    @Override
    public void setRequestHeaders(Header[] arrheader) {
        this.requestHeaders = arrheader;
    }

    @Override
    public void setRequestURI(URI uRI) {
        this.requestURI = uRI;
    }

    @Override
    public void setTag(Object object) {
        this.TAG = new WeakReference(object);
    }

    @Override
    public void setUsePoolThread(boolean bl) {
        if (bl) {
            this.looper = null;
            this.handler = null;
        }
        this.usePoolThread = bl;
    }

    @Override
    public void setUseSynchronousMode(boolean bl) {
        if (!bl && this.looper == null) {
            bl = true;
            AsyncHttpClient.log.w("AsyncHttpRH", "Current thread has not called Looper.prepare(). Forcing synchronous mode.");
        }
        if (!bl && this.handler == null) {
            this.handler = new ResponderHandler(this, this.looper);
        } else if (bl && this.handler != null) {
            this.handler = null;
        }
        this.useSynchronousMode = bl;
    }

    private static class ResponderHandler
    extends Handler {
        private final AsyncHttpResponseHandler mResponder;

        ResponderHandler(AsyncHttpResponseHandler asyncHttpResponseHandler, Looper looper) {
            super(looper);
            this.mResponder = asyncHttpResponseHandler;
        }

        public void handleMessage(Message message) {
            this.mResponder.handleMessage(message);
        }
    }

}

