/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.String
 */
package com.loopj.android.http;

import java.io.IOException;

public class Base64DataException
extends IOException {
    public Base64DataException(String string) {
        super(string);
    }
}

