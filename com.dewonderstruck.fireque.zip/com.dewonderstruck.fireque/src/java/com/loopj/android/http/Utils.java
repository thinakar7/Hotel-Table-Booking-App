/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.loopj.android.http;

class Utils {
    private Utils() {
    }

    public static void asserts(boolean bl, String string) {
        if (bl) {
            return;
        }
        throw new AssertionError((Object)string);
    }

    public static <T> T notNull(T t, String string) {
        if (t != null) {
            return t;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(" should not be null!");
        throw new IllegalArgumentException(stringBuilder.toString());
    }
}

