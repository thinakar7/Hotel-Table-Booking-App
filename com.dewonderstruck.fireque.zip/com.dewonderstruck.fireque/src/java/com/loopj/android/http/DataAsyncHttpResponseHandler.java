/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Message
 *  cz.msebera.android.httpclient.HttpEntity
 *  cz.msebera.android.httpclient.util.ByteArrayBuffer
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.ArrayIndexOutOfBoundsException
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 */
package com.loopj.android.http;

import android.os.Message;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.LogInterface;
import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.util.ByteArrayBuffer;
import java.io.IOException;
import java.io.InputStream;

public abstract class DataAsyncHttpResponseHandler
extends AsyncHttpResponseHandler {
    private static final String LOG_TAG = "DataAsyncHttpRH";
    protected static final int PROGRESS_DATA_MESSAGE = 7;

    public static byte[] copyOfRange(byte[] arrby, int n, int n2) throws ArrayIndexOutOfBoundsException, IllegalArgumentException, NullPointerException {
        if (n <= n2) {
            int n3 = arrby.length;
            if (n >= 0 && n <= n3) {
                int n4 = n2 - n;
                int n5 = Math.min((int)n4, (int)(n3 - n));
                byte[] arrby2 = new byte[n4];
                System.arraycopy((Object)arrby, (int)n, (Object)arrby2, (int)0, (int)n5);
                return arrby2;
            }
            throw new ArrayIndexOutOfBoundsException();
        }
        throw new IllegalArgumentException();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    byte[] getResponseData(HttpEntity httpEntity) throws IOException {
        int n;
        if (httpEntity == null) return null;
        InputStream inputStream = httpEntity.getContent();
        if (inputStream == null) return null;
        long l = httpEntity.getContentLength();
        if (l > Integer.MAX_VALUE) throw new IllegalArgumentException("HTTP entity too large to be buffered in memory");
        if (l < 0L) {
            l = 4096L;
        }
        ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer((int)l);
        byte[] arrby = new byte[4096];
        while ((n = inputStream.read(arrby)) != -1 && !Thread.currentThread().isInterrupted()) {
            byteArrayBuffer.append(arrby, 0, n);
            this.sendProgressDataMessage(DataAsyncHttpResponseHandler.copyOfRange(arrby, 0, n));
            this.sendProgressMessage(0, l);
        }
        {
            catch (Throwable throwable) {
                AsyncHttpClient.silentCloseInputStream(inputStream);
                throw throwable;
            }
        }
        try {
            AsyncHttpClient.silentCloseInputStream(inputStream);
            return byteArrayBuffer.toByteArray();
        }
        catch (OutOfMemoryError outOfMemoryError) {
            System.gc();
            throw new IOException("File too large to fit into available memory");
        }
    }

    @Override
    protected void handleMessage(Message message) {
        super.handleMessage(message);
        if (message.what != 7) {
            return;
        }
        Object[] arrobject = (Object[])message.obj;
        if (arrobject != null && arrobject.length >= 1) {
            try {
                this.onProgressData((byte[])arrobject[0]);
            }
            catch (Throwable throwable) {
                AsyncHttpClient.log.e(LOG_TAG, "custom onProgressData contains an error", throwable);
            }
            return;
        }
        AsyncHttpClient.log.e(LOG_TAG, "PROGRESS_DATA_MESSAGE didn't got enough params");
    }

    public void onProgressData(byte[] arrby) {
        AsyncHttpClient.log.d(LOG_TAG, "onProgressData(byte[]) was not overriden, but callback was received");
    }

    public final void sendProgressDataMessage(byte[] arrby) {
        this.sendMessage(this.obtainMessage(7, new Object[]{arrby}));
    }
}

