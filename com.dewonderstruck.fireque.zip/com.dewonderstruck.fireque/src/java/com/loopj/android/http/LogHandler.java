/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.loopj.android.http;

import android.os.Build;
import android.util.Log;
import com.loopj.android.http.LogInterface;

public class LogHandler
implements LogInterface {
    boolean mLoggingEnabled = true;
    int mLoggingLevel = 2;

    private void checkedWtf(String string, String string2, Throwable throwable) {
        Log.wtf((String)string, (String)string2, (Throwable)throwable);
    }

    @Override
    public void d(String string, String string2) {
        this.log(2, string, string2);
    }

    @Override
    public void d(String string, String string2, Throwable throwable) {
        this.logWithThrowable(3, string, string2, throwable);
    }

    @Override
    public void e(String string, String string2) {
        this.log(6, string, string2);
    }

    @Override
    public void e(String string, String string2, Throwable throwable) {
        this.logWithThrowable(6, string, string2, throwable);
    }

    @Override
    public int getLoggingLevel() {
        return this.mLoggingLevel;
    }

    @Override
    public void i(String string, String string2) {
        this.log(4, string, string2);
    }

    @Override
    public void i(String string, String string2, Throwable throwable) {
        this.logWithThrowable(4, string, string2, throwable);
    }

    @Override
    public boolean isLoggingEnabled() {
        return this.mLoggingEnabled;
    }

    public void log(int n, String string, String string2) {
        this.logWithThrowable(n, string, string2, null);
    }

    public void logWithThrowable(int n, String string, String string2, Throwable throwable) {
        if (this.isLoggingEnabled() && this.shouldLog(n)) {
            if (n != 2) {
                if (n != 3) {
                    if (n != 4) {
                        if (n != 5) {
                            if (n != 6) {
                                if (n != 8) {
                                    return;
                                }
                                if (Integer.valueOf((String)Build.VERSION.SDK) > 8) {
                                    this.checkedWtf(string, string2, throwable);
                                    return;
                                }
                                Log.e((String)string, (String)string2, (Throwable)throwable);
                                return;
                            }
                            Log.e((String)string, (String)string2, (Throwable)throwable);
                            return;
                        }
                        Log.w((String)string, (String)string2, (Throwable)throwable);
                        return;
                    }
                    Log.i((String)string, (String)string2, (Throwable)throwable);
                    return;
                }
                Log.d((String)string, (String)string2, (Throwable)throwable);
                return;
            }
            Log.v((String)string, (String)string2, (Throwable)throwable);
        }
    }

    @Override
    public void setLoggingEnabled(boolean bl) {
        this.mLoggingEnabled = bl;
    }

    @Override
    public void setLoggingLevel(int n) {
        this.mLoggingLevel = n;
    }

    @Override
    public boolean shouldLog(int n) {
        return n >= this.mLoggingLevel;
    }

    @Override
    public void v(String string, String string2) {
        this.log(2, string, string2);
    }

    @Override
    public void v(String string, String string2, Throwable throwable) {
        this.logWithThrowable(2, string, string2, throwable);
    }

    @Override
    public void w(String string, String string2) {
        this.log(5, string, string2);
    }

    @Override
    public void w(String string, String string2, Throwable throwable) {
        this.logWithThrowable(5, string, string2, throwable);
    }

    @Override
    public void wtf(String string, String string2) {
        this.log(8, string, string2);
    }

    @Override
    public void wtf(String string, String string2, Throwable throwable) {
        this.logWithThrowable(8, string, string2, throwable);
    }
}

