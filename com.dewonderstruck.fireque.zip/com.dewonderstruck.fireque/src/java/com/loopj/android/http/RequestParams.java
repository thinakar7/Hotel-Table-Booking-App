/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.HttpEntity
 *  cz.msebera.android.httpclient.client.entity.UrlEncodedFormEntity
 *  cz.msebera.android.httpclient.client.utils.URLEncodedUtils
 *  cz.msebera.android.httpclient.message.BasicNameValuePair
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.Serializable
 *  java.io.UnsupportedEncodingException
 *  java.lang.Comparable
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 */
package com.loopj.android.http;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonStreamerEntity;
import com.loopj.android.http.LogInterface;
import com.loopj.android.http.ResponseHandlerInterface;
import com.loopj.android.http.SimpleMultipartEntity;
import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.client.entity.UrlEncodedFormEntity;
import cz.msebera.android.httpclient.client.utils.URLEncodedUtils;
import cz.msebera.android.httpclient.message.BasicNameValuePair;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class RequestParams
implements Serializable {
    public static final String APPLICATION_JSON = "application/json";
    public static final String APPLICATION_OCTET_STREAM = "application/octet-stream";
    protected static final String LOG_TAG = "RequestParams";
    protected boolean autoCloseInputStreams;
    protected String contentEncoding = "UTF-8";
    protected String elapsedFieldInJsonStreamer = "_elapsed";
    protected final ConcurrentHashMap<String, List<FileWrapper>> fileArrayParams = new ConcurrentHashMap();
    protected final ConcurrentHashMap<String, FileWrapper> fileParams = new ConcurrentHashMap();
    protected boolean forceMultipartEntity = false;
    protected boolean isRepeatable;
    protected final ConcurrentHashMap<String, StreamWrapper> streamParams = new ConcurrentHashMap();
    protected final ConcurrentHashMap<String, String> urlParams = new ConcurrentHashMap();
    protected final ConcurrentHashMap<String, Object> urlParamsWithObjects = new ConcurrentHashMap();
    protected boolean useJsonStreamer;

    public RequestParams() {
        this(null);
    }

    public RequestParams(String string, final String string2) {
        this((Map<String, String>)new HashMap<String, String>(){
            {
                this.put((Object)String.this, (Object)string22);
            }
        });
    }

    public RequestParams(Map<String, String> map) {
        if (map != null) {
            for (Map.Entry entry : map.entrySet()) {
                this.put((String)entry.getKey(), (String)entry.getValue());
            }
        }
    }

    public /* varargs */ RequestParams(Object ... arrobject) {
        int n = arrobject.length;
        if (n % 2 == 0) {
            for (int i = 0; i < n; i += 2) {
                this.put(String.valueOf((Object)arrobject[i]), String.valueOf((Object)arrobject[i + 1]));
            }
            return;
        }
        throw new IllegalArgumentException("Supplied arguments must be even");
    }

    private HttpEntity createFormEntity() {
        try {
            UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(this.getParamsList(), this.contentEncoding);
            return urlEncodedFormEntity;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            AsyncHttpClient.log.e(LOG_TAG, "createFormEntity failed", unsupportedEncodingException);
            return null;
        }
    }

    private HttpEntity createJsonStreamerEntity(ResponseHandlerInterface responseHandlerInterface) throws IOException {
        boolean bl = !this.fileParams.isEmpty() || !this.streamParams.isEmpty();
        JsonStreamerEntity jsonStreamerEntity = new JsonStreamerEntity(responseHandlerInterface, bl, this.elapsedFieldInJsonStreamer);
        for (Map.Entry entry : this.urlParams.entrySet()) {
            jsonStreamerEntity.addPart((String)entry.getKey(), entry.getValue());
        }
        for (Map.Entry entry : this.urlParamsWithObjects.entrySet()) {
            jsonStreamerEntity.addPart((String)entry.getKey(), entry.getValue());
        }
        for (Map.Entry entry : this.fileParams.entrySet()) {
            jsonStreamerEntity.addPart((String)entry.getKey(), entry.getValue());
        }
        for (Map.Entry entry : this.streamParams.entrySet()) {
            StreamWrapper streamWrapper = (StreamWrapper)entry.getValue();
            if (streamWrapper.inputStream == null) continue;
            jsonStreamerEntity.addPart((String)entry.getKey(), StreamWrapper.newInstance(streamWrapper.inputStream, streamWrapper.name, streamWrapper.contentType, streamWrapper.autoClose));
        }
        return jsonStreamerEntity;
    }

    private HttpEntity createMultipartEntity(ResponseHandlerInterface responseHandlerInterface) throws IOException {
        SimpleMultipartEntity simpleMultipartEntity = new SimpleMultipartEntity(responseHandlerInterface);
        simpleMultipartEntity.setIsRepeatable(this.isRepeatable);
        for (Map.Entry entry : this.urlParams.entrySet()) {
            simpleMultipartEntity.addPartWithCharset((String)entry.getKey(), (String)entry.getValue(), this.contentEncoding);
        }
        for (BasicNameValuePair basicNameValuePair : this.getParamsList((String)null, this.urlParamsWithObjects)) {
            simpleMultipartEntity.addPartWithCharset(basicNameValuePair.getName(), basicNameValuePair.getValue(), this.contentEncoding);
        }
        for (Map.Entry entry : this.streamParams.entrySet()) {
            StreamWrapper streamWrapper = (StreamWrapper)entry.getValue();
            if (streamWrapper.inputStream == null) continue;
            simpleMultipartEntity.addPart((String)entry.getKey(), streamWrapper.name, streamWrapper.inputStream, streamWrapper.contentType);
        }
        for (Map.Entry entry : this.fileParams.entrySet()) {
            FileWrapper fileWrapper = (FileWrapper)entry.getValue();
            simpleMultipartEntity.addPart((String)entry.getKey(), fileWrapper.file, fileWrapper.contentType, fileWrapper.customFileName);
        }
        for (Map.Entry entry : this.fileArrayParams.entrySet()) {
            for (FileWrapper fileWrapper : (List)entry.getValue()) {
                simpleMultipartEntity.addPart((String)entry.getKey(), fileWrapper.file, fileWrapper.contentType, fileWrapper.customFileName);
            }
        }
        return simpleMultipartEntity;
    }

    private List<BasicNameValuePair> getParamsList(String string, Object object) {
        LinkedList linkedList = new LinkedList();
        if (object instanceof Map) {
            Map map = (Map)object;
            ArrayList arrayList = new ArrayList((Collection)map.keySet());
            if (arrayList.size() > 0 && arrayList.get(0) instanceof Comparable) {
                Collections.sort((List)arrayList);
            }
            for (Object object2 : arrayList) {
                Object object3;
                if (!(object2 instanceof String) || (object3 = map.get(object2)) == null) continue;
                String string2 = string == null ? (String)object2 : String.format((Locale)Locale.US, (String)"%s[%s]", (Object[])new Object[]{string, object2});
                linkedList.addAll(this.getParamsList(string2, object3));
            }
            return linkedList;
        }
        if (object instanceof List) {
            List list = (List)object;
            int n = list.size();
            for (int i = 0; i < n; ++i) {
                Locale locale = Locale.US;
                Object[] arrobject = new Object[]{string, i};
                linkedList.addAll(this.getParamsList(String.format((Locale)locale, (String)"%s[%d]", (Object[])arrobject), list.get(i)));
            }
            return linkedList;
        }
        if (object instanceof Object[]) {
            Object[] arrobject = (Object[])object;
            int n = arrobject.length;
            for (int i = 0; i < n; ++i) {
                Locale locale = Locale.US;
                Object[] arrobject2 = new Object[]{string, i};
                linkedList.addAll(this.getParamsList(String.format((Locale)locale, (String)"%s[%d]", (Object[])arrobject2), arrobject[i]));
            }
            return linkedList;
        }
        if (object instanceof Set) {
            Iterator iterator = ((Set)object).iterator();
            while (iterator.hasNext()) {
                linkedList.addAll(this.getParamsList(string, iterator.next()));
            }
            return linkedList;
        }
        linkedList.add((Object)new BasicNameValuePair(string, object.toString()));
        return linkedList;
    }

    public void add(String string, String string2) {
        if (string != null && string2 != null) {
            Object object = this.urlParamsWithObjects.get((Object)string);
            if (object == null) {
                object = new HashSet();
                this.put(string, object);
            }
            if (object instanceof List) {
                ((List)object).add((Object)string2);
                return;
            }
            if (object instanceof Set) {
                ((Set)object).add((Object)string2);
            }
        }
    }

    public HttpEntity getEntity(ResponseHandlerInterface responseHandlerInterface) throws IOException {
        if (this.useJsonStreamer) {
            return this.createJsonStreamerEntity(responseHandlerInterface);
        }
        if (!this.forceMultipartEntity && this.streamParams.isEmpty() && this.fileParams.isEmpty() && this.fileArrayParams.isEmpty()) {
            return this.createFormEntity();
        }
        return this.createMultipartEntity(responseHandlerInterface);
    }

    protected String getParamString() {
        return URLEncodedUtils.format(this.getParamsList(), (String)this.contentEncoding);
    }

    protected List<BasicNameValuePair> getParamsList() {
        LinkedList linkedList = new LinkedList();
        for (Map.Entry entry : this.urlParams.entrySet()) {
            linkedList.add((Object)new BasicNameValuePair((String)entry.getKey(), (String)entry.getValue()));
        }
        linkedList.addAll(this.getParamsList((String)null, this.urlParamsWithObjects));
        return linkedList;
    }

    public boolean has(String string) {
        return this.urlParams.get((Object)string) != null || this.streamParams.get((Object)string) != null || this.fileParams.get((Object)string) != null || this.urlParamsWithObjects.get((Object)string) != null || this.fileArrayParams.get((Object)string) != null;
        {
        }
    }

    public void put(String string, int n) {
        if (string != null) {
            this.urlParams.put((Object)string, (Object)String.valueOf((int)n));
        }
    }

    public void put(String string, long l) {
        if (string != null) {
            this.urlParams.put((Object)string, (Object)String.valueOf((long)l));
        }
    }

    public void put(String string, File file) throws FileNotFoundException {
        this.put(string, file, null, null);
    }

    public void put(String string, File file, String string2) throws FileNotFoundException {
        this.put(string, file, string2, null);
    }

    public void put(String string, File file, String string2, String string3) throws FileNotFoundException {
        if (file != null && file.exists()) {
            if (string != null) {
                this.fileParams.put((Object)string, (Object)new FileWrapper(file, string2, string3));
            }
            return;
        }
        throw new FileNotFoundException();
    }

    public void put(String string, InputStream inputStream) {
        this.put(string, inputStream, null);
    }

    public void put(String string, InputStream inputStream, String string2) {
        this.put(string, inputStream, string2, null);
    }

    public void put(String string, InputStream inputStream, String string2, String string3) {
        this.put(string, inputStream, string2, string3, this.autoCloseInputStreams);
    }

    public void put(String string, InputStream inputStream, String string2, String string3, boolean bl) {
        if (string != null && inputStream != null) {
            this.streamParams.put((Object)string, (Object)StreamWrapper.newInstance(inputStream, string2, string3, bl));
        }
    }

    public void put(String string, Object object) {
        if (string != null && object != null) {
            this.urlParamsWithObjects.put((Object)string, object);
        }
    }

    public void put(String string, String string2) {
        if (string != null && string2 != null) {
            this.urlParams.put((Object)string, (Object)string2);
        }
    }

    public void put(String string, String string2, File file) throws FileNotFoundException {
        this.put(string, file, null, string2);
    }

    public void put(String string, File[] arrfile) throws FileNotFoundException {
        this.put(string, arrfile, null, null);
    }

    public void put(String string, File[] arrfile, String string2, String string3) throws FileNotFoundException {
        if (string != null) {
            ArrayList arrayList = new ArrayList();
            for (File file : arrfile) {
                if (file != null && file.exists()) {
                    arrayList.add((Object)new FileWrapper(file, string2, string3));
                    continue;
                }
                throw new FileNotFoundException();
            }
            this.fileArrayParams.put((Object)string, (Object)arrayList);
        }
    }

    public void remove(String string) {
        this.urlParams.remove((Object)string);
        this.streamParams.remove((Object)string);
        this.fileParams.remove((Object)string);
        this.urlParamsWithObjects.remove((Object)string);
        this.fileArrayParams.remove((Object)string);
    }

    public void setAutoCloseInputStreams(boolean bl) {
        this.autoCloseInputStreams = bl;
    }

    public void setContentEncoding(String string) {
        if (string != null) {
            this.contentEncoding = string;
            return;
        }
        AsyncHttpClient.log.d(LOG_TAG, "setContentEncoding called with null attribute");
    }

    public void setElapsedFieldInJsonStreamer(String string) {
        this.elapsedFieldInJsonStreamer = string;
    }

    public void setForceMultipartEntityContentType(boolean bl) {
        this.forceMultipartEntity = bl;
    }

    public void setHttpEntityIsRepeatable(boolean bl) {
        this.isRepeatable = bl;
    }

    public void setUseJsonStreamer(boolean bl) {
        this.useJsonStreamer = bl;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (Map.Entry entry : this.urlParams.entrySet()) {
            if (stringBuilder.length() > 0) {
                stringBuilder.append("&");
            }
            stringBuilder.append((String)entry.getKey());
            stringBuilder.append("=");
            stringBuilder.append((String)entry.getValue());
        }
        for (Map.Entry entry : this.streamParams.entrySet()) {
            if (stringBuilder.length() > 0) {
                stringBuilder.append("&");
            }
            stringBuilder.append((String)entry.getKey());
            stringBuilder.append("=");
            stringBuilder.append("STREAM");
        }
        for (Map.Entry entry : this.fileParams.entrySet()) {
            if (stringBuilder.length() > 0) {
                stringBuilder.append("&");
            }
            stringBuilder.append((String)entry.getKey());
            stringBuilder.append("=");
            stringBuilder.append("FILE");
        }
        for (Map.Entry entry : this.fileArrayParams.entrySet()) {
            if (stringBuilder.length() > 0) {
                stringBuilder.append("&");
            }
            stringBuilder.append((String)entry.getKey());
            stringBuilder.append("=");
            stringBuilder.append("FILES(SIZE=");
            stringBuilder.append(((List)entry.getValue()).size());
            stringBuilder.append(")");
        }
        for (BasicNameValuePair basicNameValuePair : this.getParamsList((String)null, this.urlParamsWithObjects)) {
            if (stringBuilder.length() > 0) {
                stringBuilder.append("&");
            }
            stringBuilder.append(basicNameValuePair.getName());
            stringBuilder.append("=");
            stringBuilder.append(basicNameValuePair.getValue());
        }
        return stringBuilder.toString();
    }

    public static class FileWrapper
    implements Serializable {
        public final String contentType;
        public final String customFileName;
        public final File file;

        public FileWrapper(File file, String string, String string2) {
            this.file = file;
            this.contentType = string;
            this.customFileName = string2;
        }
    }

    public static class StreamWrapper {
        public final boolean autoClose;
        public final String contentType;
        public final InputStream inputStream;
        public final String name;

        public StreamWrapper(InputStream inputStream, String string, String string2, boolean bl) {
            this.inputStream = inputStream;
            this.name = string;
            this.contentType = string2;
            this.autoClose = bl;
        }

        static StreamWrapper newInstance(InputStream inputStream, String string, String string2, boolean bl) {
            String string3 = string2 == null ? RequestParams.APPLICATION_OCTET_STREAM : string2;
            return new StreamWrapper(inputStream, string, string3, bl);
        }
    }

}

