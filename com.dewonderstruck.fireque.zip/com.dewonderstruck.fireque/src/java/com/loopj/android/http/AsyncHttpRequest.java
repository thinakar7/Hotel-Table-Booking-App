/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.loopj.android.http.RangeFileAsyncHttpResponseHandler
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpResponse
 *  cz.msebera.android.httpclient.client.HttpRequestRetryHandler
 *  cz.msebera.android.httpclient.client.methods.CloseableHttpResponse
 *  cz.msebera.android.httpclient.client.methods.HttpUriRequest
 *  cz.msebera.android.httpclient.impl.client.AbstractHttpClient
 *  cz.msebera.android.httpclient.protocol.HttpContext
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.MalformedURLException
 *  java.net.URI
 *  java.net.UnknownHostException
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package com.loopj.android.http;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.LogInterface;
import com.loopj.android.http.RangeFileAsyncHttpResponseHandler;
import com.loopj.android.http.ResponseHandlerInterface;
import com.loopj.android.http.Utils;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.client.HttpRequestRetryHandler;
import cz.msebera.android.httpclient.client.methods.CloseableHttpResponse;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;
import cz.msebera.android.httpclient.impl.client.AbstractHttpClient;
import cz.msebera.android.httpclient.protocol.HttpContext;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicBoolean;

public class AsyncHttpRequest
implements Runnable {
    private boolean cancelIsNotified;
    private final AbstractHttpClient client;
    private final HttpContext context;
    private int executionCount;
    private final AtomicBoolean isCancelled = new AtomicBoolean();
    private volatile boolean isFinished;
    private boolean isRequestPreProcessed;
    private final HttpUriRequest request;
    private final ResponseHandlerInterface responseHandler;

    public AsyncHttpRequest(AbstractHttpClient abstractHttpClient, HttpContext httpContext, HttpUriRequest httpUriRequest, ResponseHandlerInterface responseHandlerInterface) {
        this.client = Utils.notNull(abstractHttpClient, "client");
        this.context = Utils.notNull(httpContext, "context");
        this.request = Utils.notNull(httpUriRequest, "request");
        this.responseHandler = Utils.notNull(responseHandlerInterface, "responseHandler");
    }

    private void makeRequest() throws IOException {
        if (this.isCancelled()) {
            return;
        }
        if (this.request.getURI().getScheme() != null) {
            ResponseHandlerInterface responseHandlerInterface = this.responseHandler;
            if (responseHandlerInterface instanceof RangeFileAsyncHttpResponseHandler) {
                ((RangeFileAsyncHttpResponseHandler)responseHandlerInterface).updateRequestHeaders(this.request);
            }
            CloseableHttpResponse closeableHttpResponse = this.client.execute(this.request, this.context);
            if (this.isCancelled()) {
                return;
            }
            ResponseHandlerInterface responseHandlerInterface2 = this.responseHandler;
            responseHandlerInterface2.onPreProcessResponse(responseHandlerInterface2, (HttpResponse)closeableHttpResponse);
            if (this.isCancelled()) {
                return;
            }
            this.responseHandler.sendResponseMessage((HttpResponse)closeableHttpResponse);
            if (this.isCancelled()) {
                return;
            }
            ResponseHandlerInterface responseHandlerInterface3 = this.responseHandler;
            responseHandlerInterface3.onPostProcessResponse(responseHandlerInterface3, (HttpResponse)closeableHttpResponse);
            return;
        }
        throw new MalformedURLException("No valid URI scheme was provided");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void makeRequestWithRetries() throws IOException {
        int n = 1;
        IOException iOException = null;
        HttpRequestRetryHandler httpRequestRetryHandler = this.client.getHttpRequestRetryHandler();
        while (n != 0) {
            int n2 = 1;
            try {
                block8 : {
                    block10 : {
                        block9 : {
                            try {
                                this.makeRequest();
                                return;
                            }
                            catch (IOException iOException2) {
                                int n3;
                                if (this.isCancelled()) {
                                    return;
                                }
                                iOException = iOException2;
                                this.executionCount = n3 = n2 + this.executionCount;
                                n = httpRequestRetryHandler.retryRequest(iOException, n3, this.context);
                                break block8;
                            }
                            catch (NullPointerException nullPointerException) {
                                int n4;
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("NPE in HttpClient: ");
                                stringBuilder.append(nullPointerException.getMessage());
                                iOException = new IOException(stringBuilder.toString());
                                this.executionCount = n4 = n2 + this.executionCount;
                                n = httpRequestRetryHandler.retryRequest(iOException, n4, this.context) ? 1 : 0;
                                break block8;
                            }
                            catch (UnknownHostException unknownHostException) {
                                int n5;
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("UnknownHostException exception: ");
                                stringBuilder.append(unknownHostException.getMessage());
                                iOException = new IOException(stringBuilder.toString());
                                if (this.executionCount <= 0) break block9;
                                this.executionCount = n5 = n2 + this.executionCount;
                                if (httpRequestRetryHandler.retryRequest((IOException)((Object)unknownHostException), n5, this.context)) break block10;
                            }
                        }
                        n2 = 0;
                    }
                    n = n2;
                }
                if (n == 0) continue;
                this.responseHandler.sendRetryMessage(this.executionCount);
                continue;
            }
            catch (Exception exception2) {}
            AsyncHttpClient.log.e("AsyncHttpRequest", "Unhandled exception origin cause", exception2);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unhandled exception: ");
            stringBuilder.append(exception2.getMessage());
            iOException = new IOException(stringBuilder.toString());
            throw iOException;
        }
        throw iOException;
    }

    private void sendCancelNotification() {
        AsyncHttpRequest asyncHttpRequest = this;
        synchronized (asyncHttpRequest) {
            if (!this.isFinished && this.isCancelled.get() && !this.cancelIsNotified) {
                this.cancelIsNotified = true;
                this.responseHandler.sendCancelMessage();
            }
            return;
        }
    }

    public boolean cancel(boolean bl) {
        this.isCancelled.set(true);
        this.request.abort();
        return this.isCancelled();
    }

    public Object getTag() {
        return this.responseHandler.getTag();
    }

    public boolean isCancelled() {
        boolean bl = this.isCancelled.get();
        if (bl) {
            this.sendCancelNotification();
        }
        return bl;
    }

    public boolean isDone() {
        return this.isCancelled() || this.isFinished;
        {
        }
    }

    public void onPostProcessRequest(AsyncHttpRequest asyncHttpRequest) {
    }

    public void onPreProcessRequest(AsyncHttpRequest asyncHttpRequest) {
    }

    public void run() {
        if (this.isCancelled()) {
            return;
        }
        if (!this.isRequestPreProcessed) {
            this.isRequestPreProcessed = true;
            this.onPreProcessRequest(this);
        }
        if (this.isCancelled()) {
            return;
        }
        this.responseHandler.sendStartMessage();
        if (this.isCancelled()) {
            return;
        }
        try {
            this.makeRequestWithRetries();
        }
        catch (IOException iOException) {
            if (!this.isCancelled()) {
                this.responseHandler.sendFailureMessage(0, null, null, iOException);
            }
            AsyncHttpClient.log.e("AsyncHttpRequest", "makeRequestWithRetries returned error", iOException);
        }
        if (this.isCancelled()) {
            return;
        }
        this.responseHandler.sendFinishMessage();
        if (this.isCancelled()) {
            return;
        }
        this.onPostProcessRequest(this);
        this.isFinished = true;
    }

    public AsyncHttpRequest setRequestTag(Object object) {
        this.responseHandler.setTag(object);
        return this;
    }
}

