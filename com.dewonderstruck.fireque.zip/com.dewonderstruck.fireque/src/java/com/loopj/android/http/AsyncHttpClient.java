/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Looper
 *  com.loopj.android.http.AsyncHttpClient$InflatingEntity
 *  com.loopj.android.http.HttpDelete
 *  com.loopj.android.http.HttpGet
 *  com.loopj.android.http.MyRedirectHandler
 *  com.loopj.android.http.MySSLSocketFactory
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HeaderElement
 *  cz.msebera.android.httpclient.HttpEntity
 *  cz.msebera.android.httpclient.HttpException
 *  cz.msebera.android.httpclient.HttpHost
 *  cz.msebera.android.httpclient.HttpRequest
 *  cz.msebera.android.httpclient.HttpRequestInterceptor
 *  cz.msebera.android.httpclient.HttpResponse
 *  cz.msebera.android.httpclient.HttpResponseInterceptor
 *  cz.msebera.android.httpclient.HttpVersion
 *  cz.msebera.android.httpclient.ProtocolVersion
 *  cz.msebera.android.httpclient.auth.AuthScheme
 *  cz.msebera.android.httpclient.auth.AuthScope
 *  cz.msebera.android.httpclient.auth.AuthState
 *  cz.msebera.android.httpclient.auth.Credentials
 *  cz.msebera.android.httpclient.auth.UsernamePasswordCredentials
 *  cz.msebera.android.httpclient.client.CookieStore
 *  cz.msebera.android.httpclient.client.CredentialsProvider
 *  cz.msebera.android.httpclient.client.HttpClient
 *  cz.msebera.android.httpclient.client.HttpRequestRetryHandler
 *  cz.msebera.android.httpclient.client.RedirectHandler
 *  cz.msebera.android.httpclient.client.methods.HttpEntityEnclosingRequestBase
 *  cz.msebera.android.httpclient.client.methods.HttpHead
 *  cz.msebera.android.httpclient.client.methods.HttpPatch
 *  cz.msebera.android.httpclient.client.methods.HttpPost
 *  cz.msebera.android.httpclient.client.methods.HttpPut
 *  cz.msebera.android.httpclient.client.methods.HttpUriRequest
 *  cz.msebera.android.httpclient.conn.ClientConnectionManager
 *  cz.msebera.android.httpclient.conn.params.ConnManagerParams
 *  cz.msebera.android.httpclient.conn.params.ConnPerRoute
 *  cz.msebera.android.httpclient.conn.params.ConnPerRouteBean
 *  cz.msebera.android.httpclient.conn.scheme.PlainSocketFactory
 *  cz.msebera.android.httpclient.conn.scheme.Scheme
 *  cz.msebera.android.httpclient.conn.scheme.SchemeRegistry
 *  cz.msebera.android.httpclient.conn.scheme.SocketFactory
 *  cz.msebera.android.httpclient.conn.ssl.SSLSocketFactory
 *  cz.msebera.android.httpclient.entity.HttpEntityWrapper
 *  cz.msebera.android.httpclient.impl.auth.BasicScheme
 *  cz.msebera.android.httpclient.impl.client.AbstractHttpClient
 *  cz.msebera.android.httpclient.impl.client.DefaultHttpClient
 *  cz.msebera.android.httpclient.impl.conn.tsccm.ThreadSafeClientConnManager
 *  cz.msebera.android.httpclient.params.BasicHttpParams
 *  cz.msebera.android.httpclient.params.HttpConnectionParams
 *  cz.msebera.android.httpclient.params.HttpParams
 *  cz.msebera.android.httpclient.params.HttpProtocolParams
 *  cz.msebera.android.httpclient.protocol.BasicHttpContext
 *  cz.msebera.android.httpclient.protocol.HttpContext
 *  cz.msebera.android.httpclient.protocol.SyncBasicHttpContext
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.io.PushbackInputStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.net.URI
 *  java.net.URL
 *  java.net.URLDecoder
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.WeakHashMap
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Executors
 *  java.util.concurrent.Future
 */
package com.loopj.android.http;

import android.content.Context;
import android.os.Looper;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpRequest;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.HttpDelete;
import com.loopj.android.http.HttpGet;
import com.loopj.android.http.LogHandler;
import com.loopj.android.http.LogInterface;
import com.loopj.android.http.MyRedirectHandler;
import com.loopj.android.http.MySSLSocketFactory;
import com.loopj.android.http.PreemptiveAuthorizationHttpRequestInterceptor;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import com.loopj.android.http.RetryHandler;
import com.loopj.android.http.Utils;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HeaderElement;
import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.HttpException;
import cz.msebera.android.httpclient.HttpHost;
import cz.msebera.android.httpclient.HttpRequest;
import cz.msebera.android.httpclient.HttpRequestInterceptor;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.HttpResponseInterceptor;
import cz.msebera.android.httpclient.HttpVersion;
import cz.msebera.android.httpclient.ProtocolVersion;
import cz.msebera.android.httpclient.auth.AuthScheme;
import cz.msebera.android.httpclient.auth.AuthScope;
import cz.msebera.android.httpclient.auth.AuthState;
import cz.msebera.android.httpclient.auth.Credentials;
import cz.msebera.android.httpclient.auth.UsernamePasswordCredentials;
import cz.msebera.android.httpclient.client.CookieStore;
import cz.msebera.android.httpclient.client.CredentialsProvider;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.HttpRequestRetryHandler;
import cz.msebera.android.httpclient.client.RedirectHandler;
import cz.msebera.android.httpclient.client.methods.HttpEntityEnclosingRequestBase;
import cz.msebera.android.httpclient.client.methods.HttpHead;
import cz.msebera.android.httpclient.client.methods.HttpPatch;
import cz.msebera.android.httpclient.client.methods.HttpPost;
import cz.msebera.android.httpclient.client.methods.HttpPut;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;
import cz.msebera.android.httpclient.conn.ClientConnectionManager;
import cz.msebera.android.httpclient.conn.params.ConnManagerParams;
import cz.msebera.android.httpclient.conn.params.ConnPerRoute;
import cz.msebera.android.httpclient.conn.params.ConnPerRouteBean;
import cz.msebera.android.httpclient.conn.scheme.PlainSocketFactory;
import cz.msebera.android.httpclient.conn.scheme.Scheme;
import cz.msebera.android.httpclient.conn.scheme.SchemeRegistry;
import cz.msebera.android.httpclient.conn.scheme.SocketFactory;
import cz.msebera.android.httpclient.conn.ssl.SSLSocketFactory;
import cz.msebera.android.httpclient.entity.HttpEntityWrapper;
import cz.msebera.android.httpclient.impl.auth.BasicScheme;
import cz.msebera.android.httpclient.impl.client.AbstractHttpClient;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.impl.conn.tsccm.ThreadSafeClientConnManager;
import cz.msebera.android.httpclient.params.BasicHttpParams;
import cz.msebera.android.httpclient.params.HttpConnectionParams;
import cz.msebera.android.httpclient.params.HttpParams;
import cz.msebera.android.httpclient.params.HttpProtocolParams;
import cz.msebera.android.httpclient.protocol.BasicHttpContext;
import cz.msebera.android.httpclient.protocol.HttpContext;
import cz.msebera.android.httpclient.protocol.SyncBasicHttpContext;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.lang.reflect.Field;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class AsyncHttpClient {
    public static final int DEFAULT_MAX_CONNECTIONS = 10;
    public static final int DEFAULT_MAX_RETRIES = 5;
    public static final int DEFAULT_RETRY_SLEEP_TIME_MILLIS = 1500;
    public static final int DEFAULT_SOCKET_BUFFER_SIZE = 8192;
    public static final int DEFAULT_SOCKET_TIMEOUT = 10000;
    public static final String ENCODING_GZIP = "gzip";
    public static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
    public static final String HEADER_CONTENT_DISPOSITION = "Content-Disposition";
    public static final String HEADER_CONTENT_ENCODING = "Content-Encoding";
    public static final String HEADER_CONTENT_RANGE = "Content-Range";
    public static final String HEADER_CONTENT_TYPE = "Content-Type";
    public static final String LOG_TAG = "AsyncHttpClient";
    public static LogInterface log = new LogHandler();
    private final Map<String, String> clientHeaderMap;
    private int connectTimeout = 10000;
    private final DefaultHttpClient httpClient;
    private final HttpContext httpContext;
    private boolean isUrlEncodingEnabled;
    private int maxConnections = 10;
    private final Map<Context, List<RequestHandle>> requestMap;
    private int responseTimeout = 10000;
    private ExecutorService threadPool;

    public AsyncHttpClient() {
        this(false, 80, 443);
    }

    public AsyncHttpClient(int n) {
        this(false, n, 443);
    }

    public AsyncHttpClient(int n, int n2) {
        this(false, n, n2);
    }

    public AsyncHttpClient(SchemeRegistry schemeRegistry) {
        DefaultHttpClient defaultHttpClient;
        boolean bl;
        this.isUrlEncodingEnabled = bl = true;
        BasicHttpParams basicHttpParams = new BasicHttpParams();
        ConnManagerParams.setTimeout((HttpParams)basicHttpParams, (long)this.connectTimeout);
        ConnManagerParams.setMaxConnectionsPerRoute((HttpParams)basicHttpParams, (ConnPerRoute)new ConnPerRouteBean(this.maxConnections));
        ConnManagerParams.setMaxTotalConnections((HttpParams)basicHttpParams, (int)10);
        HttpConnectionParams.setSoTimeout((HttpParams)basicHttpParams, (int)this.responseTimeout);
        HttpConnectionParams.setConnectionTimeout((HttpParams)basicHttpParams, (int)this.connectTimeout);
        HttpConnectionParams.setTcpNoDelay((HttpParams)basicHttpParams, (boolean)bl);
        HttpConnectionParams.setSocketBufferSize((HttpParams)basicHttpParams, (int)8192);
        HttpProtocolParams.setVersion((HttpParams)basicHttpParams, (ProtocolVersion)HttpVersion.HTTP_1_1);
        ClientConnectionManager clientConnectionManager = this.createConnectionManager(schemeRegistry, basicHttpParams);
        if (clientConnectionManager == null) {
            bl = false;
        }
        Utils.asserts(bl, "Custom implementation of #createConnectionManager(SchemeRegistry, BasicHttpParams) returned null");
        this.threadPool = this.getDefaultThreadPool();
        this.requestMap = Collections.synchronizedMap((Map)new WeakHashMap());
        this.clientHeaderMap = new HashMap();
        this.httpContext = new SyncBasicHttpContext((HttpContext)new BasicHttpContext());
        this.httpClient = defaultHttpClient = new DefaultHttpClient(clientConnectionManager, (HttpParams)basicHttpParams);
        defaultHttpClient.addRequestInterceptor(new HttpRequestInterceptor(){

            public void process(HttpRequest httpRequest, HttpContext httpContext) {
                if (!httpRequest.containsHeader(AsyncHttpClient.HEADER_ACCEPT_ENCODING)) {
                    httpRequest.addHeader(AsyncHttpClient.HEADER_ACCEPT_ENCODING, AsyncHttpClient.ENCODING_GZIP);
                }
                for (String string : AsyncHttpClient.this.clientHeaderMap.keySet()) {
                    if (httpRequest.containsHeader(string)) {
                        Header header = httpRequest.getFirstHeader(string);
                        LogInterface logInterface = AsyncHttpClient.log;
                        Object[] arrobject = new Object[]{string, AsyncHttpClient.this.clientHeaderMap.get((Object)string), header.getName(), header.getValue()};
                        logInterface.d(AsyncHttpClient.LOG_TAG, String.format((String)"Headers were overwritten! (%s | %s) overwrites (%s | %s)", (Object[])arrobject));
                        httpRequest.removeHeader(header);
                    }
                    httpRequest.addHeader(string, (String)AsyncHttpClient.this.clientHeaderMap.get((Object)string));
                }
            }
        });
        defaultHttpClient.addResponseInterceptor(new HttpResponseInterceptor(this){
            final /* synthetic */ AsyncHttpClient this$0;
            {
                this.this$0 = asyncHttpClient;
            }

            public void process(HttpResponse httpResponse, HttpContext httpContext) {
                HttpEntity httpEntity = httpResponse.getEntity();
                if (httpEntity == null) {
                    return;
                }
                Header header = httpEntity.getContentEncoding();
                if (header != null) {
                    HeaderElement[] arrheaderElement = header.getElements();
                    int n = arrheaderElement.length;
                    for (int i = 0; i < n; ++i) {
                        if (!arrheaderElement[i].getName().equalsIgnoreCase(AsyncHttpClient.ENCODING_GZIP)) continue;
                        httpResponse.setEntity((HttpEntity)new /* Unavailable Anonymous Inner Class!! */);
                        return;
                    }
                }
            }
        });
        defaultHttpClient.addRequestInterceptor(new HttpRequestInterceptor(){

            public void process(HttpRequest httpRequest, HttpContext httpContext) throws HttpException, IOException {
                Credentials credentials;
                AuthState authState = (AuthState)httpContext.getAttribute("http.auth.target-scope");
                CredentialsProvider credentialsProvider = (CredentialsProvider)httpContext.getAttribute("http.auth.credentials-provider");
                HttpHost httpHost = (HttpHost)httpContext.getAttribute("http.target_host");
                if (authState.getAuthScheme() == null && (credentials = credentialsProvider.getCredentials(new AuthScope(httpHost.getHostName(), httpHost.getPort()))) != null) {
                    authState.setAuthScheme((AuthScheme)new BasicScheme());
                    authState.setCredentials(credentials);
                }
            }
        }, 0);
        defaultHttpClient.setHttpRequestRetryHandler((HttpRequestRetryHandler)new RetryHandler(5, 1500));
    }

    public AsyncHttpClient(boolean bl, int n, int n2) {
        this(AsyncHttpClient.getDefaultSchemeRegistry(bl, n, n2));
    }

    private HttpEntityEnclosingRequestBase addEntityToRequestBase(HttpEntityEnclosingRequestBase httpEntityEnclosingRequestBase, HttpEntity httpEntity) {
        if (httpEntity != null) {
            httpEntityEnclosingRequestBase.setEntity(httpEntity);
        }
        return httpEntityEnclosingRequestBase;
    }

    public static void allowRetryExceptionClass(Class<?> class_) {
        if (class_ != null) {
            RetryHandler.addClassToWhitelist(class_);
        }
    }

    public static void blockRetryExceptionClass(Class<?> class_) {
        if (class_ != null) {
            RetryHandler.addClassToBlacklist(class_);
        }
    }

    private void cancelRequests(List<RequestHandle> list, boolean bl) {
        if (list != null) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((RequestHandle)iterator.next()).cancel(bl);
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void endEntityViaReflection(HttpEntity httpEntity) {
        if (!(httpEntity instanceof HttpEntityWrapper)) return;
        Field[] arrfield = HttpEntityWrapper.class.getDeclaredFields();
        int n = arrfield.length;
        int n2 = 0;
        do {
            block8 : {
                Field field = null;
                if (n2 < n) {
                    Field field2 = arrfield[n2];
                    if (!field2.getName().equals((Object)"wrappedEntity")) break block8;
                    field = field2;
                }
                if (field == null) return;
                field.setAccessible(true);
                HttpEntity httpEntity2 = (HttpEntity)field.get((Object)httpEntity);
                if (httpEntity2 == null) return;
                try {
                    httpEntity2.consumeContent();
                    return;
                }
                catch (Throwable throwable) {
                    log.e(LOG_TAG, "wrappedEntity consume", throwable);
                }
                return;
            }
            ++n2;
        } while (true);
    }

    private static SchemeRegistry getDefaultSchemeRegistry(boolean bl, int n, int n2) {
        if (bl) {
            log.d(LOG_TAG, "Beware! Using the fix is insecure, as it doesn't verify SSL certificates.");
        }
        if (n < 1) {
            n = 80;
            log.d(LOG_TAG, "Invalid HTTP port number specified, defaulting to 80");
        }
        if (n2 < 1) {
            n2 = 443;
            log.d(LOG_TAG, "Invalid HTTPS port number specified, defaulting to 443");
        }
        SSLSocketFactory sSLSocketFactory = bl ? MySSLSocketFactory.getFixedSocketFactory() : SSLSocketFactory.getSocketFactory();
        SchemeRegistry schemeRegistry = new SchemeRegistry();
        schemeRegistry.register(new Scheme("http", (SocketFactory)PlainSocketFactory.getSocketFactory(), n));
        schemeRegistry.register(new Scheme("https", (SocketFactory)sSLSocketFactory, n2));
        return schemeRegistry;
    }

    public static String getUrlWithQueryString(boolean bl, String string, RequestParams requestParams) {
        String string2;
        String string3;
        if (string == null) {
            return null;
        }
        if (bl) {
            try {
                String string4;
                URL uRL = new URL(URLDecoder.decode((String)string, (String)"UTF-8"));
                URI uRI = new URI(uRL.getProtocol(), uRL.getUserInfo(), uRL.getHost(), uRL.getPort(), uRL.getPath(), uRL.getQuery(), uRL.getRef());
                string = string4 = uRI.toASCIIString();
            }
            catch (Exception exception) {
                log.e(LOG_TAG, "getUrlWithQueryString encoding URL", exception);
            }
        }
        if (requestParams != null && !(string3 = requestParams.getParamString().trim()).equals((Object)"") && !string3.equals((Object)(string2 = "?"))) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string);
            if (string.contains((CharSequence)string2)) {
                string2 = "&";
            }
            stringBuilder.append(string2);
            String string5 = stringBuilder.toString();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string5);
            stringBuilder2.append(string3);
            string = stringBuilder2.toString();
        }
        return string;
    }

    public static boolean isInputStreamGZIPCompressed(PushbackInputStream pushbackInputStream) throws IOException {
        int n;
        int n2;
        if (pushbackInputStream == null) {
            return false;
        }
        byte[] arrby = new byte[2];
        for (n2 = 0; n2 < 2; n2 += n) {
            int n3 = 2 - n2;
            try {
                n = pushbackInputStream.read(arrby, n2, n3);
                if (n >= 0) continue;
            }
            catch (Throwable throwable) {
                pushbackInputStream.unread(arrby, 0, n2);
                throw throwable;
            }
            pushbackInputStream.unread(arrby, 0, n2);
            return false;
        }
        pushbackInputStream.unread(arrby, 0, n2);
        int n4 = 255 & arrby[0] | 65280 & arrby[1] << 8;
        boolean bl = false;
        if (35615 == n4) {
            bl = true;
        }
        return bl;
    }

    private HttpEntity paramsToEntity(RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        HttpEntity httpEntity = null;
        if (requestParams != null) {
            try {
                HttpEntity httpEntity2;
                httpEntity = httpEntity2 = requestParams.getEntity(responseHandlerInterface);
            }
            catch (IOException iOException) {
                if (responseHandlerInterface != null) {
                    responseHandlerInterface.sendFailureMessage(0, null, null, iOException);
                    return null;
                }
                iOException.printStackTrace();
                return null;
            }
        }
        return httpEntity;
    }

    public static void silentCloseInputStream(InputStream inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close();
            }
            catch (IOException iOException) {
                log.w(LOG_TAG, "Cannot close input stream", iOException);
                return;
            }
        }
    }

    public static void silentCloseOutputStream(OutputStream outputStream) {
        if (outputStream != null) {
            try {
                outputStream.close();
            }
            catch (IOException iOException) {
                log.w(LOG_TAG, "Cannot close output stream", iOException);
                return;
            }
        }
    }

    public void addHeader(String string, String string2) {
        this.clientHeaderMap.put((Object)string, (Object)string2);
    }

    public void cancelAllRequests(boolean bl) {
        for (List list : this.requestMap.values()) {
            if (list == null) continue;
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((RequestHandle)iterator.next()).cancel(bl);
            }
        }
        this.requestMap.clear();
    }

    public void cancelRequests(Context context, final boolean bl) {
        if (context == null) {
            log.e(LOG_TAG, "Passed null Context to cancelRequests");
            return;
        }
        final List list = (List)this.requestMap.get((Object)context);
        this.requestMap.remove((Object)context);
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Runnable runnable = new Runnable(){

                public void run() {
                    AsyncHttpClient.this.cancelRequests((List<RequestHandle>)list, bl);
                }
            };
            this.threadPool.submit(runnable);
            return;
        }
        this.cancelRequests((List<RequestHandle>)list, bl);
    }

    public void cancelRequestsByTAG(Object object, boolean bl) {
        if (object == null) {
            log.d(LOG_TAG, "cancelRequestsByTAG, passed TAG is null, cannot proceed");
            return;
        }
        for (List list : this.requestMap.values()) {
            if (list == null) continue;
            for (RequestHandle requestHandle : list) {
                if (!object.equals(requestHandle.getTag())) continue;
                requestHandle.cancel(bl);
            }
        }
    }

    public void clearCredentialsProvider() {
        this.httpClient.getCredentialsProvider().clear();
    }

    protected ClientConnectionManager createConnectionManager(SchemeRegistry schemeRegistry, BasicHttpParams basicHttpParams) {
        return new ThreadSafeClientConnManager((HttpParams)basicHttpParams, schemeRegistry);
    }

    public RequestHandle delete(Context context, String string, ResponseHandlerInterface responseHandlerInterface) {
        HttpDelete httpDelete = new HttpDelete(this.getURI(string));
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpDelete, null, responseHandlerInterface, context);
    }

    public RequestHandle delete(Context context, String string, HttpEntity httpEntity, String string2, ResponseHandlerInterface responseHandlerInterface) {
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)this.addEntityToRequestBase((HttpEntityEnclosingRequestBase)new HttpDelete(URI.create((String)string).normalize()), httpEntity), string2, responseHandlerInterface, context);
    }

    public RequestHandle delete(Context context, String string, Header[] arrheader, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        HttpDelete httpDelete = new HttpDelete(AsyncHttpClient.getUrlWithQueryString(this.isUrlEncodingEnabled, string, requestParams));
        if (arrheader != null) {
            httpDelete.setHeaders(arrheader);
        }
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpDelete, null, responseHandlerInterface, context);
    }

    public RequestHandle delete(Context context, String string, Header[] arrheader, ResponseHandlerInterface responseHandlerInterface) {
        HttpDelete httpDelete = new HttpDelete(this.getURI(string));
        if (arrheader != null) {
            httpDelete.setHeaders(arrheader);
        }
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpDelete, null, responseHandlerInterface, context);
    }

    public RequestHandle delete(String string, ResponseHandlerInterface responseHandlerInterface) {
        return this.delete(null, string, responseHandlerInterface);
    }

    public void delete(String string, RequestParams requestParams, AsyncHttpResponseHandler asyncHttpResponseHandler) {
        HttpDelete httpDelete = new HttpDelete(AsyncHttpClient.getUrlWithQueryString(this.isUrlEncodingEnabled, string, requestParams));
        this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpDelete, null, asyncHttpResponseHandler, null);
    }

    public RequestHandle get(Context context, String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)new HttpGet(AsyncHttpClient.getUrlWithQueryString(this.isUrlEncodingEnabled, string, requestParams)), null, responseHandlerInterface, context);
    }

    public RequestHandle get(Context context, String string, ResponseHandlerInterface responseHandlerInterface) {
        return this.get(context, string, null, responseHandlerInterface);
    }

    public RequestHandle get(Context context, String string, HttpEntity httpEntity, String string2, ResponseHandlerInterface responseHandlerInterface) {
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)this.addEntityToRequestBase((HttpEntityEnclosingRequestBase)new HttpGet(URI.create((String)string).normalize()), httpEntity), string2, responseHandlerInterface, context);
    }

    public RequestHandle get(Context context, String string, Header[] arrheader, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        HttpGet httpGet = new HttpGet(AsyncHttpClient.getUrlWithQueryString(this.isUrlEncodingEnabled, string, requestParams));
        if (arrheader != null) {
            httpGet.setHeaders(arrheader);
        }
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpGet, null, responseHandlerInterface, context);
    }

    public RequestHandle get(String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.get(null, string, requestParams, responseHandlerInterface);
    }

    public RequestHandle get(String string, ResponseHandlerInterface responseHandlerInterface) {
        return this.get(null, string, null, responseHandlerInterface);
    }

    public int getConnectTimeout() {
        return this.connectTimeout;
    }

    protected ExecutorService getDefaultThreadPool() {
        return Executors.newCachedThreadPool();
    }

    public HttpClient getHttpClient() {
        return this.httpClient;
    }

    public HttpContext getHttpContext() {
        return this.httpContext;
    }

    public LogInterface getLogInterface() {
        return log;
    }

    public int getLoggingLevel() {
        return log.getLoggingLevel();
    }

    public int getMaxConnections() {
        return this.maxConnections;
    }

    public int getResponseTimeout() {
        return this.responseTimeout;
    }

    public ExecutorService getThreadPool() {
        return this.threadPool;
    }

    protected URI getURI(String string) {
        return URI.create((String)string).normalize();
    }

    public RequestHandle head(Context context, String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)new HttpHead(AsyncHttpClient.getUrlWithQueryString(this.isUrlEncodingEnabled, string, requestParams)), null, responseHandlerInterface, context);
    }

    public RequestHandle head(Context context, String string, ResponseHandlerInterface responseHandlerInterface) {
        return this.head(context, string, null, responseHandlerInterface);
    }

    public RequestHandle head(Context context, String string, Header[] arrheader, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        HttpHead httpHead = new HttpHead(AsyncHttpClient.getUrlWithQueryString(this.isUrlEncodingEnabled, string, requestParams));
        if (arrheader != null) {
            httpHead.setHeaders(arrheader);
        }
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpHead, null, responseHandlerInterface, context);
    }

    public RequestHandle head(String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.head(null, string, requestParams, responseHandlerInterface);
    }

    public RequestHandle head(String string, ResponseHandlerInterface responseHandlerInterface) {
        return this.head(null, string, null, responseHandlerInterface);
    }

    public boolean isLoggingEnabled() {
        return log.isLoggingEnabled();
    }

    public boolean isUrlEncodingEnabled() {
        return this.isUrlEncodingEnabled;
    }

    protected AsyncHttpRequest newAsyncHttpRequest(DefaultHttpClient defaultHttpClient, HttpContext httpContext, HttpUriRequest httpUriRequest, String string, ResponseHandlerInterface responseHandlerInterface, Context context) {
        return new AsyncHttpRequest((AbstractHttpClient)defaultHttpClient, httpContext, httpUriRequest, responseHandlerInterface);
    }

    public RequestHandle patch(Context context, String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.patch(context, string, this.paramsToEntity(requestParams, responseHandlerInterface), null, responseHandlerInterface);
    }

    public RequestHandle patch(Context context, String string, HttpEntity httpEntity, String string2, ResponseHandlerInterface responseHandlerInterface) {
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)this.addEntityToRequestBase((HttpEntityEnclosingRequestBase)new HttpPatch(this.getURI(string)), httpEntity), string2, responseHandlerInterface, context);
    }

    public RequestHandle patch(Context context, String string, Header[] arrheader, HttpEntity httpEntity, String string2, ResponseHandlerInterface responseHandlerInterface) {
        HttpEntityEnclosingRequestBase httpEntityEnclosingRequestBase = this.addEntityToRequestBase((HttpEntityEnclosingRequestBase)new HttpPatch(this.getURI(string)), httpEntity);
        if (arrheader != null) {
            httpEntityEnclosingRequestBase.setHeaders(arrheader);
        }
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpEntityEnclosingRequestBase, string2, responseHandlerInterface, context);
    }

    public RequestHandle patch(String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.patch(null, string, requestParams, responseHandlerInterface);
    }

    public RequestHandle patch(String string, ResponseHandlerInterface responseHandlerInterface) {
        return this.patch(null, string, null, responseHandlerInterface);
    }

    public RequestHandle post(Context context, String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.post(context, string, this.paramsToEntity(requestParams, responseHandlerInterface), null, responseHandlerInterface);
    }

    public RequestHandle post(Context context, String string, HttpEntity httpEntity, String string2, ResponseHandlerInterface responseHandlerInterface) {
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)this.addEntityToRequestBase((HttpEntityEnclosingRequestBase)new HttpPost(this.getURI(string)), httpEntity), string2, responseHandlerInterface, context);
    }

    public RequestHandle post(Context context, String string, Header[] arrheader, RequestParams requestParams, String string2, ResponseHandlerInterface responseHandlerInterface) {
        HttpPost httpPost = new HttpPost(this.getURI(string));
        if (requestParams != null) {
            httpPost.setEntity(this.paramsToEntity(requestParams, responseHandlerInterface));
        }
        if (arrheader != null) {
            httpPost.setHeaders(arrheader);
        }
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpPost, string2, responseHandlerInterface, context);
    }

    public RequestHandle post(Context context, String string, Header[] arrheader, HttpEntity httpEntity, String string2, ResponseHandlerInterface responseHandlerInterface) {
        HttpEntityEnclosingRequestBase httpEntityEnclosingRequestBase = this.addEntityToRequestBase((HttpEntityEnclosingRequestBase)new HttpPost(this.getURI(string)), httpEntity);
        if (arrheader != null) {
            httpEntityEnclosingRequestBase.setHeaders(arrheader);
        }
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpEntityEnclosingRequestBase, string2, responseHandlerInterface, context);
    }

    public RequestHandle post(String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.post(null, string, requestParams, responseHandlerInterface);
    }

    public RequestHandle post(String string, ResponseHandlerInterface responseHandlerInterface) {
        return this.post(null, string, null, responseHandlerInterface);
    }

    public RequestHandle put(Context context, String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.put(context, string, this.paramsToEntity(requestParams, responseHandlerInterface), null, responseHandlerInterface);
    }

    public RequestHandle put(Context context, String string, HttpEntity httpEntity, String string2, ResponseHandlerInterface responseHandlerInterface) {
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)this.addEntityToRequestBase((HttpEntityEnclosingRequestBase)new HttpPut(this.getURI(string)), httpEntity), string2, responseHandlerInterface, context);
    }

    public RequestHandle put(Context context, String string, Header[] arrheader, HttpEntity httpEntity, String string2, ResponseHandlerInterface responseHandlerInterface) {
        HttpEntityEnclosingRequestBase httpEntityEnclosingRequestBase = this.addEntityToRequestBase((HttpEntityEnclosingRequestBase)new HttpPut(this.getURI(string)), httpEntity);
        if (arrheader != null) {
            httpEntityEnclosingRequestBase.setHeaders(arrheader);
        }
        return this.sendRequest(this.httpClient, this.httpContext, (HttpUriRequest)httpEntityEnclosingRequestBase, string2, responseHandlerInterface, context);
    }

    public RequestHandle put(String string, RequestParams requestParams, ResponseHandlerInterface responseHandlerInterface) {
        return this.put(null, string, requestParams, responseHandlerInterface);
    }

    public RequestHandle put(String string, ResponseHandlerInterface responseHandlerInterface) {
        return this.put(null, string, null, responseHandlerInterface);
    }

    public void removeAllHeaders() {
        this.clientHeaderMap.clear();
    }

    public void removeHeader(String string) {
        this.clientHeaderMap.remove((Object)string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected RequestHandle sendRequest(DefaultHttpClient defaultHttpClient, HttpContext httpContext, HttpUriRequest httpUriRequest, String string, ResponseHandlerInterface responseHandlerInterface, Context context) {
        if (httpUriRequest == null) {
            throw new IllegalArgumentException("HttpUriRequest must not be null");
        }
        if (responseHandlerInterface == null) {
            throw new IllegalArgumentException("ResponseHandler must not be null");
        }
        if (responseHandlerInterface.getUseSynchronousMode() && !responseHandlerInterface.getUsePoolThread()) {
            throw new IllegalArgumentException("Synchronous ResponseHandler used in AsyncHttpClient. You should create your response handler in a looper thread or use SyncHttpClient instead.");
        }
        if (string != null) {
            if (httpUriRequest instanceof HttpEntityEnclosingRequestBase && ((HttpEntityEnclosingRequestBase)httpUriRequest).getEntity() != null && httpUriRequest.containsHeader(HEADER_CONTENT_TYPE)) {
                log.w(LOG_TAG, "Passed contentType will be ignored because HttpEntity sets content type");
            } else {
                httpUriRequest.setHeader(HEADER_CONTENT_TYPE, string);
            }
        }
        responseHandlerInterface.setRequestHeaders(httpUriRequest.getAllHeaders());
        responseHandlerInterface.setRequestURI(httpUriRequest.getURI());
        AsyncHttpRequest asyncHttpRequest = this.newAsyncHttpRequest(defaultHttpClient, httpContext, httpUriRequest, string, responseHandlerInterface, context);
        this.threadPool.submit((Runnable)asyncHttpRequest);
        RequestHandle requestHandle = new RequestHandle(asyncHttpRequest);
        if (context != null) {
            Map<Context, List<RequestHandle>> map;
            List list;
            Map<Context, List<RequestHandle>> map2 = map = this.requestMap;
            synchronized (map2) {
                list = (List)this.requestMap.get((Object)context);
                if (list == null) {
                    list = Collections.synchronizedList((List)new LinkedList());
                    this.requestMap.put((Object)context, (Object)list);
                }
            }
            list.add((Object)requestHandle);
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                if (!((RequestHandle)iterator.next()).shouldBeGarbageCollected()) continue;
                iterator.remove();
            }
        }
        return requestHandle;
    }

    public void setAuthenticationPreemptive(boolean bl) {
        if (bl) {
            this.httpClient.addRequestInterceptor((HttpRequestInterceptor)new PreemptiveAuthorizationHttpRequestInterceptor(), 0);
            return;
        }
        this.httpClient.removeRequestInterceptorByClass(PreemptiveAuthorizationHttpRequestInterceptor.class);
    }

    public void setBasicAuth(String string, String string2) {
        this.setBasicAuth(string, string2, false);
    }

    public void setBasicAuth(String string, String string2, AuthScope authScope) {
        this.setBasicAuth(string, string2, authScope, false);
    }

    public void setBasicAuth(String string, String string2, AuthScope authScope, boolean bl) {
        this.setCredentials(authScope, (Credentials)new UsernamePasswordCredentials(string, string2));
        this.setAuthenticationPreemptive(bl);
    }

    public void setBasicAuth(String string, String string2, boolean bl) {
        this.setBasicAuth(string, string2, null, bl);
    }

    public void setConnectTimeout(int n) {
        int n2 = n < 1000 ? 10000 : n;
        this.connectTimeout = n2;
        HttpParams httpParams = this.httpClient.getParams();
        ConnManagerParams.setTimeout((HttpParams)httpParams, (long)this.connectTimeout);
        HttpConnectionParams.setConnectionTimeout((HttpParams)httpParams, (int)this.connectTimeout);
    }

    public void setCookieStore(CookieStore cookieStore) {
        this.httpContext.setAttribute("http.cookie-store", (Object)cookieStore);
    }

    public void setCredentials(AuthScope authScope, Credentials credentials) {
        if (credentials == null) {
            log.d(LOG_TAG, "Provided credentials are null, not setting");
            return;
        }
        CredentialsProvider credentialsProvider = this.httpClient.getCredentialsProvider();
        AuthScope authScope2 = authScope == null ? AuthScope.ANY : authScope;
        credentialsProvider.setCredentials(authScope2, credentials);
    }

    public void setEnableRedirects(boolean bl) {
        this.setEnableRedirects(bl, bl, bl);
    }

    public void setEnableRedirects(boolean bl, boolean bl2) {
        this.setEnableRedirects(bl, bl2, true);
    }

    public void setEnableRedirects(boolean bl, boolean bl2, boolean bl3) {
        this.httpClient.getParams().setBooleanParameter("http.protocol.reject-relative-redirect", bl2 ^ true);
        this.httpClient.getParams().setBooleanParameter("http.protocol.allow-circular-redirects", bl3);
        this.httpClient.setRedirectHandler((RedirectHandler)new MyRedirectHandler(bl));
    }

    public void setLogInterface(LogInterface logInterface) {
        if (logInterface != null) {
            log = logInterface;
        }
    }

    public void setLoggingEnabled(boolean bl) {
        log.setLoggingEnabled(bl);
    }

    public void setLoggingLevel(int n) {
        log.setLoggingLevel(n);
    }

    public void setMaxConnections(int n) {
        if (n < 1) {
            n = 10;
        }
        this.maxConnections = n;
        ConnManagerParams.setMaxConnectionsPerRoute((HttpParams)this.httpClient.getParams(), (ConnPerRoute)new ConnPerRouteBean(this.maxConnections));
    }

    public void setMaxRetriesAndTimeout(int n, int n2) {
        this.httpClient.setHttpRequestRetryHandler((HttpRequestRetryHandler)new RetryHandler(n, n2));
    }

    public void setProxy(String string, int n) {
        HttpHost httpHost = new HttpHost(string, n);
        this.httpClient.getParams().setParameter("http.route.default-proxy", (Object)httpHost);
    }

    public void setProxy(String string, int n, String string2, String string3) {
        this.httpClient.getCredentialsProvider().setCredentials(new AuthScope(string, n), (Credentials)new UsernamePasswordCredentials(string2, string3));
        HttpHost httpHost = new HttpHost(string, n);
        this.httpClient.getParams().setParameter("http.route.default-proxy", (Object)httpHost);
    }

    public void setRedirectHandler(RedirectHandler redirectHandler) {
        this.httpClient.setRedirectHandler(redirectHandler);
    }

    public void setResponseTimeout(int n) {
        int n2 = n < 1000 ? 10000 : n;
        this.responseTimeout = n2;
        HttpConnectionParams.setSoTimeout((HttpParams)this.httpClient.getParams(), (int)this.responseTimeout);
    }

    public void setSSLSocketFactory(SSLSocketFactory sSLSocketFactory) {
        this.httpClient.getConnectionManager().getSchemeRegistry().register(new Scheme("https", (SocketFactory)sSLSocketFactory, 443));
    }

    public void setThreadPool(ExecutorService executorService) {
        this.threadPool = executorService;
    }

    public void setTimeout(int n) {
        int n2 = n < 1000 ? 10000 : n;
        int n3 = n2;
        this.setConnectTimeout(n3);
        this.setResponseTimeout(n3);
    }

    public void setURLEncodingEnabled(boolean bl) {
        this.isUrlEncodingEnabled = bl;
    }

    public void setUserAgent(String string) {
        HttpProtocolParams.setUserAgent((HttpParams)this.httpClient.getParams(), (String)string);
    }

}

