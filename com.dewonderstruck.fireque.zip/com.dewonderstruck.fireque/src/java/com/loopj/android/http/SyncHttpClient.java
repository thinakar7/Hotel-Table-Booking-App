/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  cz.msebera.android.httpclient.client.methods.HttpUriRequest
 *  cz.msebera.android.httpclient.conn.scheme.SchemeRegistry
 *  cz.msebera.android.httpclient.impl.client.DefaultHttpClient
 *  cz.msebera.android.httpclient.protocol.HttpContext
 *  java.lang.String
 */
package com.loopj.android.http;

import android.content.Context;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpRequest;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;
import cz.msebera.android.httpclient.conn.scheme.SchemeRegistry;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.protocol.HttpContext;

public class SyncHttpClient
extends AsyncHttpClient {
    public SyncHttpClient() {
        super(false, 80, 443);
    }

    public SyncHttpClient(int n) {
        super(false, n, 443);
    }

    public SyncHttpClient(int n, int n2) {
        super(false, n, n2);
    }

    public SyncHttpClient(SchemeRegistry schemeRegistry) {
        super(schemeRegistry);
    }

    public SyncHttpClient(boolean bl, int n, int n2) {
        super(bl, n, n2);
    }

    @Override
    protected RequestHandle sendRequest(DefaultHttpClient defaultHttpClient, HttpContext httpContext, HttpUriRequest httpUriRequest, String string, ResponseHandlerInterface responseHandlerInterface, Context context) {
        if (string != null) {
            httpUriRequest.addHeader("Content-Type", string);
        }
        responseHandlerInterface.setUseSynchronousMode(true);
        this.newAsyncHttpRequest(defaultHttpClient, httpContext, httpUriRequest, string, responseHandlerInterface, context).run();
        return new RequestHandle(null);
    }
}

