/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.Header
 *  cz.msebera.android.httpclient.HttpResponse
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.net.URI
 */
package com.loopj.android.http;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpResponse;
import java.io.IOException;
import java.net.URI;

public interface ResponseHandlerInterface {
    public Header[] getRequestHeaders();

    public URI getRequestURI();

    public Object getTag();

    public boolean getUsePoolThread();

    public boolean getUseSynchronousMode();

    public void onPostProcessResponse(ResponseHandlerInterface var1, HttpResponse var2);

    public void onPreProcessResponse(ResponseHandlerInterface var1, HttpResponse var2);

    public void sendCancelMessage();

    public void sendFailureMessage(int var1, Header[] var2, byte[] var3, Throwable var4);

    public void sendFinishMessage();

    public void sendProgressMessage(long var1, long var3);

    public void sendResponseMessage(HttpResponse var1) throws IOException;

    public void sendRetryMessage(int var1);

    public void sendStartMessage();

    public void sendSuccessMessage(int var1, Header[] var2, byte[] var3);

    public void setRequestHeaders(Header[] var1);

    public void setRequestURI(URI var1);

    public void setTag(Object var1);

    public void setUsePoolThread(boolean var1);

    public void setUseSynchronousMode(boolean var1);
}

