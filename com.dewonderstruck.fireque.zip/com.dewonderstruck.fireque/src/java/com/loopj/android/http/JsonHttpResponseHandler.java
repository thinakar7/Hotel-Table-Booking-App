/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.Header
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 *  org.json.JSONTokener
 */
package com.loopj.android.http;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.LogInterface;
import com.loopj.android.http.TextHttpResponseHandler;
import cz.msebera.android.httpclient.Header;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonHttpResponseHandler
extends TextHttpResponseHandler {
    private static final String LOG_TAG = "JsonHttpRH";
    private boolean useRFC5179CompatibilityMode = true;

    public JsonHttpResponseHandler() {
        super("UTF-8");
    }

    public JsonHttpResponseHandler(String string2) {
        super(string2);
    }

    public JsonHttpResponseHandler(String string2, boolean bl) {
        super(string2);
        this.useRFC5179CompatibilityMode = bl;
    }

    public JsonHttpResponseHandler(boolean bl) {
        super("UTF-8");
        this.useRFC5179CompatibilityMode = bl;
    }

    static /* synthetic */ boolean access$000(JsonHttpResponseHandler jsonHttpResponseHandler) {
        return jsonHttpResponseHandler.useRFC5179CompatibilityMode;
    }

    public boolean isUseRFC5179CompatibilityMode() {
        return this.useRFC5179CompatibilityMode;
    }

    @Override
    public void onFailure(int n, Header[] arrheader, String string2, Throwable throwable) {
        AsyncHttpClient.log.w(LOG_TAG, "onFailure(int, Header[], String, Throwable) was not overriden, but callback was received", throwable);
    }

    public void onFailure(int n, Header[] arrheader, Throwable throwable, JSONArray jSONArray) {
        AsyncHttpClient.log.w(LOG_TAG, "onFailure(int, Header[], Throwable, JSONArray) was not overriden, but callback was received", throwable);
    }

    public void onFailure(int n, Header[] arrheader, Throwable throwable, JSONObject jSONObject) {
        AsyncHttpClient.log.w(LOG_TAG, "onFailure(int, Header[], Throwable, JSONObject) was not overriden, but callback was received", throwable);
    }

    @Override
    public final void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
        if (arrby != null) {
            Runnable runnable = new Runnable(this, arrby, n, arrheader, throwable){
                final /* synthetic */ JsonHttpResponseHandler this$0;
                final /* synthetic */ Header[] val$headers;
                final /* synthetic */ byte[] val$responseBytes;
                final /* synthetic */ int val$statusCode;
                final /* synthetic */ Throwable val$throwable;
                {
                    this.this$0 = jsonHttpResponseHandler;
                    this.val$responseBytes = arrby;
                    this.val$statusCode = n;
                    this.val$headers = arrheader;
                    this.val$throwable = throwable;
                }

                public void run() {
                    try {
                        Object object = this.this$0.parseResponse(this.val$responseBytes);
                        this.this$0.postRunnable(new Runnable(this, object){
                            final /* synthetic */ 2 this$1;
                            final /* synthetic */ Object val$jsonResponse;
                            {
                                this.this$1 = var1_1;
                                this.val$jsonResponse = object;
                            }

                            public void run() {
                                if (!JsonHttpResponseHandler.access$000(this.this$1.this$0) && this.val$jsonResponse == null) {
                                    this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, (String)null, this.this$1.val$throwable);
                                    return;
                                }
                                Object object = this.val$jsonResponse;
                                if (object instanceof JSONObject) {
                                    this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, this.this$1.val$throwable, (JSONObject)this.val$jsonResponse);
                                    return;
                                }
                                if (object instanceof JSONArray) {
                                    this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, this.this$1.val$throwable, (JSONArray)this.val$jsonResponse);
                                    return;
                                }
                                if (object instanceof String) {
                                    this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, (String)this.val$jsonResponse, this.this$1.val$throwable);
                                    return;
                                }
                                JsonHttpResponseHandler jsonHttpResponseHandler = this.this$1.this$0;
                                int n = this.this$1.val$statusCode;
                                Header[] arrheader = this.this$1.val$headers;
                                java.lang.StringBuilder stringBuilder = new java.lang.StringBuilder();
                                stringBuilder.append("Unexpected response type ");
                                stringBuilder.append(this.val$jsonResponse.getClass().getName());
                                jsonHttpResponseHandler.onFailure(n, arrheader, (Throwable)new JSONException(stringBuilder.toString()), (JSONObject)null);
                            }
                        });
                        return;
                    }
                    catch (JSONException jSONException) {
                        this.this$0.postRunnable(new Runnable(this, jSONException){
                            final /* synthetic */ 2 this$1;
                            final /* synthetic */ JSONException val$ex;
                            {
                                this.this$1 = var1_1;
                                this.val$ex = jSONException;
                            }

                            public void run() {
                                this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, (Throwable)this.val$ex, (JSONObject)null);
                            }
                        });
                        return;
                    }
                }
            };
            if (!this.getUseSynchronousMode() && !this.getUsePoolThread()) {
                new Thread(runnable).start();
            } else {
                runnable.run();
            }
            return;
        }
        AsyncHttpClient.log.v(LOG_TAG, "response body is null, calling onFailure(Throwable, JSONObject)");
        this.onFailure(n, arrheader, throwable, (JSONObject)null);
    }

    @Override
    public void onSuccess(int n, Header[] arrheader, String string2) {
        AsyncHttpClient.log.w(LOG_TAG, "onSuccess(int, Header[], String) was not overriden, but callback was received");
    }

    public void onSuccess(int n, Header[] arrheader, JSONArray jSONArray) {
        AsyncHttpClient.log.w(LOG_TAG, "onSuccess(int, Header[], JSONArray) was not overriden, but callback was received");
    }

    public void onSuccess(int n, Header[] arrheader, JSONObject jSONObject) {
        AsyncHttpClient.log.w(LOG_TAG, "onSuccess(int, Header[], JSONObject) was not overriden, but callback was received");
    }

    @Override
    public final void onSuccess(int n, Header[] arrheader, byte[] arrby) {
        if (n != 204) {
            Runnable runnable = new Runnable(this, arrby, n, arrheader){
                final /* synthetic */ JsonHttpResponseHandler this$0;
                final /* synthetic */ Header[] val$headers;
                final /* synthetic */ byte[] val$responseBytes;
                final /* synthetic */ int val$statusCode;
                {
                    this.this$0 = jsonHttpResponseHandler;
                    this.val$responseBytes = arrby;
                    this.val$statusCode = n;
                    this.val$headers = arrheader;
                }

                public void run() {
                    try {
                        Object object = this.this$0.parseResponse(this.val$responseBytes);
                        this.this$0.postRunnable(new Runnable(this, object){
                            final /* synthetic */ 1 this$1;
                            final /* synthetic */ Object val$jsonResponse;
                            {
                                this.this$1 = var1_1;
                                this.val$jsonResponse = object;
                            }

                            public void run() {
                                if (!JsonHttpResponseHandler.access$000(this.this$1.this$0) && this.val$jsonResponse == null) {
                                    this.this$1.this$0.onSuccess(this.this$1.val$statusCode, this.this$1.val$headers, (String)null);
                                    return;
                                }
                                Object object = this.val$jsonResponse;
                                if (object instanceof JSONObject) {
                                    this.this$1.this$0.onSuccess(this.this$1.val$statusCode, this.this$1.val$headers, (JSONObject)this.val$jsonResponse);
                                    return;
                                }
                                if (object instanceof JSONArray) {
                                    this.this$1.this$0.onSuccess(this.this$1.val$statusCode, this.this$1.val$headers, (JSONArray)this.val$jsonResponse);
                                    return;
                                }
                                if (object instanceof String) {
                                    if (JsonHttpResponseHandler.access$000(this.this$1.this$0)) {
                                        this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, (String)this.val$jsonResponse, (Throwable)new JSONException("Response cannot be parsed as JSON data"));
                                        return;
                                    }
                                    this.this$1.this$0.onSuccess(this.this$1.val$statusCode, this.this$1.val$headers, (String)this.val$jsonResponse);
                                    return;
                                }
                                JsonHttpResponseHandler jsonHttpResponseHandler = this.this$1.this$0;
                                int n = this.this$1.val$statusCode;
                                Header[] arrheader = this.this$1.val$headers;
                                java.lang.StringBuilder stringBuilder = new java.lang.StringBuilder();
                                stringBuilder.append("Unexpected response type ");
                                stringBuilder.append(this.val$jsonResponse.getClass().getName());
                                jsonHttpResponseHandler.onFailure(n, arrheader, (Throwable)new JSONException(stringBuilder.toString()), (JSONObject)null);
                            }
                        });
                        return;
                    }
                    catch (JSONException jSONException) {
                        this.this$0.postRunnable(new Runnable(this, jSONException){
                            final /* synthetic */ 1 this$1;
                            final /* synthetic */ JSONException val$ex;
                            {
                                this.this$1 = var1_1;
                                this.val$ex = jSONException;
                            }

                            public void run() {
                                this.this$1.this$0.onFailure(this.this$1.val$statusCode, this.this$1.val$headers, (Throwable)this.val$ex, (JSONObject)null);
                            }
                        });
                        return;
                    }
                }
            };
            if (!this.getUseSynchronousMode() && !this.getUsePoolThread()) {
                new Thread(runnable).start();
            } else {
                runnable.run();
            }
            return;
        }
        this.onSuccess(n, arrheader, new JSONObject());
    }

    protected Object parseResponse(byte[] arrby) throws JSONException {
        String string2;
        Object object;
        block8 : {
            block9 : {
                block10 : {
                    if (arrby == null) {
                        return null;
                    }
                    string2 = JsonHttpResponseHandler.getResponseString(arrby, this.getCharset());
                    object = null;
                    if (string2 == null) break block8;
                    string2 = string2.trim();
                    if (!this.useRFC5179CompatibilityMode) break block9;
                    if (string2.startsWith("{")) break block10;
                    boolean bl = string2.startsWith("[");
                    object = null;
                    if (!bl) break block8;
                }
                object = new JSONTokener(string2).nextValue();
                break block8;
            }
            if (string2.startsWith("{") && string2.endsWith("}") || string2.startsWith("[") && string2.endsWith("]")) {
                object = new JSONTokener(string2).nextValue();
            } else {
                boolean bl = string2.startsWith("\"");
                object = null;
                if (bl) {
                    boolean bl2 = string2.endsWith("\"");
                    object = null;
                    if (bl2) {
                        object = string2.substring(1, string2.length() - 1);
                    }
                }
            }
        }
        if (object == null) {
            object = string2;
        }
        return object;
    }

    public void setUseRFC5179CompatibilityMode(boolean bl) {
        this.useRFC5179CompatibilityMode = bl;
    }
}

