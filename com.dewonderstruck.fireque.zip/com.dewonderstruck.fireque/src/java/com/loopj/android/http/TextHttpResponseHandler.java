/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cz.msebera.android.httpclient.Header
 *  java.io.UnsupportedEncodingException
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.loopj.android.http;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.LogInterface;
import cz.msebera.android.httpclient.Header;
import java.io.UnsupportedEncodingException;

public abstract class TextHttpResponseHandler
extends AsyncHttpResponseHandler {
    private static final String LOG_TAG = "TextHttpRH";

    public TextHttpResponseHandler() {
        this("UTF-8");
    }

    public TextHttpResponseHandler(String string2) {
        this.setCharset(string2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String getResponseString(byte[] arrby, String string2) {
        String string3;
        if (arrby == null) {
            return null;
        }
        try {
            string3 = new String(arrby, string2);
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            AsyncHttpClient.log.e(LOG_TAG, "Encoding response into string failed", unsupportedEncodingException);
            return null;
        }
        if (string3 == null) return string3;
        if (!string3.startsWith("\ufeff")) return string3;
        return string3.substring(1);
    }

    public abstract void onFailure(int var1, Header[] var2, String var3, Throwable var4);

    @Override
    public void onFailure(int n, Header[] arrheader, byte[] arrby, Throwable throwable) {
        this.onFailure(n, arrheader, TextHttpResponseHandler.getResponseString(arrby, this.getCharset()), throwable);
    }

    public abstract void onSuccess(int var1, Header[] var2, String var3);

    @Override
    public void onSuccess(int n, Header[] arrheader, byte[] arrby) {
        this.onSuccess(n, arrheader, TextHttpResponseHandler.getResponseString(arrby, this.getCharset()));
    }
}

