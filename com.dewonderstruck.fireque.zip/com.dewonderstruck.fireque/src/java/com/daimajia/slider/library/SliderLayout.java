/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.os.Handler
 *  android.os.Message
 *  android.util.AttributeSet
 *  android.view.LayoutInflater
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.animation.Interpolator
 *  android.widget.RelativeLayout
 *  androidx.viewpager.widget.PagerAdapter
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.util.Timer
 *  java.util.TimerTask
 */
package com.daimajia.slider.library;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.RelativeLayout;
import androidx.viewpager.widget.PagerAdapter;
import com.daimajia.slider.library.Animations.BaseAnimationInterface;
import com.daimajia.slider.library.Indicators.PagerIndicator;
import com.daimajia.slider.library.R;
import com.daimajia.slider.library.SliderAdapter;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.Transformers.AccordionTransformer;
import com.daimajia.slider.library.Transformers.BackgroundToForegroundTransformer;
import com.daimajia.slider.library.Transformers.BaseTransformer;
import com.daimajia.slider.library.Transformers.CubeInTransformer;
import com.daimajia.slider.library.Transformers.DefaultTransformer;
import com.daimajia.slider.library.Transformers.DepthPageTransformer;
import com.daimajia.slider.library.Transformers.FadeTransformer;
import com.daimajia.slider.library.Transformers.FlipHorizontalTransformer;
import com.daimajia.slider.library.Transformers.FlipPageViewTransformer;
import com.daimajia.slider.library.Transformers.ForegroundToBackgroundTransformer;
import com.daimajia.slider.library.Transformers.RotateDownTransformer;
import com.daimajia.slider.library.Transformers.RotateUpTransformer;
import com.daimajia.slider.library.Transformers.StackTransformer;
import com.daimajia.slider.library.Transformers.TabletTransformer;
import com.daimajia.slider.library.Transformers.ZoomInTransformer;
import com.daimajia.slider.library.Transformers.ZoomOutSlideTransformer;
import com.daimajia.slider.library.Transformers.ZoomOutTransformer;
import com.daimajia.slider.library.Tricks.FixedSpeedScroller;
import com.daimajia.slider.library.Tricks.InfinitePagerAdapter;
import com.daimajia.slider.library.Tricks.InfiniteViewPager;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import java.lang.reflect.Field;
import java.util.Timer;
import java.util.TimerTask;

public class SliderLayout
extends RelativeLayout {
    private boolean mAutoCycle;
    private boolean mAutoRecover = true;
    private Context mContext;
    private BaseAnimationInterface mCustomAnimation;
    private TimerTask mCycleTask;
    private Timer mCycleTimer;
    private boolean mCycling;
    private PagerIndicator mIndicator;
    private PagerIndicator.IndicatorVisibility mIndicatorVisibility = PagerIndicator.IndicatorVisibility.Visible;
    private TimerTask mResumingTask;
    private Timer mResumingTimer;
    private SliderAdapter mSliderAdapter;
    private long mSliderDuration = 4000L;
    private int mTransformerId;
    private int mTransformerSpan = 1100;
    private InfiniteViewPager mViewPager;
    private BaseTransformer mViewPagerTransformer;
    private Handler mh = new Handler(){

        public void handleMessage(Message message) {
            super.handleMessage(message);
            SliderLayout.this.moveNextPosition(true);
        }
    };

    public SliderLayout(Context context) {
        this(context, null);
    }

    public SliderLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.SliderStyle);
    }

    public SliderLayout(Context context, AttributeSet attributeSet, int n) {
        InfiniteViewPager infiniteViewPager;
        SliderAdapter sliderAdapter;
        super(context, attributeSet, n);
        this.mContext = context;
        LayoutInflater.from((Context)context).inflate(R.layout.slider_layout, (ViewGroup)this, true);
        Resources.Theme theme = context.getTheme();
        int[] arrn = R.styleable.SliderLayout;
        TypedArray typedArray = theme.obtainStyledAttributes(attributeSet, arrn, n, 0);
        this.mTransformerSpan = typedArray.getInteger(R.styleable.SliderLayout_pager_animation_span, 1100);
        this.mTransformerId = typedArray.getInt(R.styleable.SliderLayout_pager_animation, Transformer.Default.ordinal());
        this.mAutoCycle = typedArray.getBoolean(R.styleable.SliderLayout_auto_cycle, true);
        int n2 = typedArray.getInt(R.styleable.SliderLayout_indicator_visibility, 0);
        for (PagerIndicator.IndicatorVisibility indicatorVisibility : PagerIndicator.IndicatorVisibility.values()) {
            if (indicatorVisibility.ordinal() != n2) continue;
            this.mIndicatorVisibility = indicatorVisibility;
            break;
        }
        this.mSliderAdapter = sliderAdapter = new SliderAdapter(this.mContext);
        InfinitePagerAdapter infinitePagerAdapter = new InfinitePagerAdapter(sliderAdapter);
        this.mViewPager = infiniteViewPager = (InfiniteViewPager)this.findViewById(R.id.daimajia_slider_viewpager);
        infiniteViewPager.setAdapter(infinitePagerAdapter);
        this.mViewPager.setOnTouchListener(new View.OnTouchListener(){

            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 1) {
                    SliderLayout.this.recoverCycle();
                }
                return false;
            }
        });
        typedArray.recycle();
        this.setPresetIndicator(PresetIndicators.Center_Bottom);
        this.setPresetTransformer(this.mTransformerId);
        this.setSliderTransformDuration(this.mTransformerSpan, null);
        this.setIndicatorVisibility(this.mIndicatorVisibility);
        if (this.mAutoCycle) {
            this.startAutoCycle();
        }
    }

    private SliderAdapter getRealAdapter() {
        PagerAdapter pagerAdapter = this.mViewPager.getAdapter();
        if (pagerAdapter != null) {
            return ((InfinitePagerAdapter)pagerAdapter).getRealAdapter();
        }
        return null;
    }

    private InfinitePagerAdapter getWrapperAdapter() {
        PagerAdapter pagerAdapter = this.mViewPager.getAdapter();
        if (pagerAdapter != null) {
            return (InfinitePagerAdapter)pagerAdapter;
        }
        return null;
    }

    private void pauseAutoCycle() {
        if (this.mCycling) {
            this.mCycleTimer.cancel();
            this.mCycleTask.cancel();
            this.mCycling = false;
            return;
        }
        if (this.mResumingTimer != null && this.mResumingTask != null) {
            this.recoverCycle();
        }
    }

    private void recoverCycle() {
        if (this.mAutoRecover) {
            if (!this.mAutoCycle) {
                return;
            }
            if (!this.mCycling) {
                Timer timer;
                TimerTask timerTask;
                if (this.mResumingTask != null && (timer = this.mResumingTimer) != null) {
                    timer.cancel();
                    this.mResumingTask.cancel();
                }
                this.mResumingTimer = new Timer();
                this.mResumingTask = timerTask = new TimerTask(){

                    public void run() {
                        SliderLayout.this.startAutoCycle();
                    }
                };
                this.mResumingTimer.schedule(timerTask, 6000L);
            }
            return;
        }
    }

    public void addOnPageChangeListener(ViewPagerEx.OnPageChangeListener onPageChangeListener) {
        if (onPageChangeListener != null) {
            this.mViewPager.addOnPageChangeListener(onPageChangeListener);
        }
    }

    public <T extends BaseSliderView> void addSlider(T t) {
        this.mSliderAdapter.addSlider(t);
    }

    public int getCurrentPosition() {
        if (this.getRealAdapter() != null) {
            return this.mViewPager.getCurrentItem() % this.getRealAdapter().getCount();
        }
        throw new IllegalStateException("You did not set a slider adapter");
    }

    public BaseSliderView getCurrentSlider() {
        if (this.getRealAdapter() != null) {
            int n = this.getRealAdapter().getCount();
            int n2 = this.mViewPager.getCurrentItem() % n;
            return this.getRealAdapter().getSliderView(n2);
        }
        throw new IllegalStateException("You did not set a slider adapter");
    }

    public PagerIndicator.IndicatorVisibility getIndicatorVisibility() {
        PagerIndicator pagerIndicator = this.mIndicator;
        if (pagerIndicator == null) {
            return pagerIndicator.getIndicatorVisibility();
        }
        return PagerIndicator.IndicatorVisibility.Invisible;
    }

    public PagerIndicator getPagerIndicator() {
        return this.mIndicator;
    }

    public void moveNextPosition() {
        this.moveNextPosition(true);
    }

    public void moveNextPosition(boolean bl) {
        if (this.getRealAdapter() != null) {
            InfiniteViewPager infiniteViewPager = this.mViewPager;
            infiniteViewPager.setCurrentItem(1 + infiniteViewPager.getCurrentItem(), bl);
            return;
        }
        throw new IllegalStateException("You did not set a slider adapter");
    }

    public void movePrevPosition() {
        this.movePrevPosition(true);
    }

    public void movePrevPosition(boolean bl) {
        if (this.getRealAdapter() != null) {
            InfiniteViewPager infiniteViewPager = this.mViewPager;
            infiniteViewPager.setCurrentItem(-1 + infiniteViewPager.getCurrentItem(), bl);
            return;
        }
        throw new IllegalStateException("You did not set a slider adapter");
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.pauseAutoCycle();
        }
        return false;
    }

    public void removeAllSliders() {
        if (this.getRealAdapter() != null) {
            int n = this.getRealAdapter().getCount();
            this.getRealAdapter().removeAllSliders();
            InfiniteViewPager infiniteViewPager = this.mViewPager;
            infiniteViewPager.setCurrentItem(n + infiniteViewPager.getCurrentItem(), false);
        }
    }

    public void removeOnPageChangeListener(ViewPagerEx.OnPageChangeListener onPageChangeListener) {
        this.mViewPager.removeOnPageChangeListener(onPageChangeListener);
    }

    public void removeSliderAt(int n) {
        if (this.getRealAdapter() != null) {
            this.getRealAdapter().removeSliderAt(n);
            InfiniteViewPager infiniteViewPager = this.mViewPager;
            infiniteViewPager.setCurrentItem(infiniteViewPager.getCurrentItem(), false);
        }
    }

    public void setCurrentPosition(int n) {
        this.setCurrentPosition(n, true);
    }

    public void setCurrentPosition(int n, boolean bl) {
        if (this.getRealAdapter() != null) {
            if (n < this.getRealAdapter().getCount()) {
                int n2 = n - this.mViewPager.getCurrentItem() % this.getRealAdapter().getCount() + this.mViewPager.getCurrentItem();
                this.mViewPager.setCurrentItem(n2, bl);
                return;
            }
            throw new IllegalStateException("Item position is not exist");
        }
        throw new IllegalStateException("You did not set a slider adapter");
    }

    public void setCustomAnimation(BaseAnimationInterface baseAnimationInterface) {
        this.mCustomAnimation = baseAnimationInterface;
        BaseTransformer baseTransformer = this.mViewPagerTransformer;
        if (baseTransformer != null) {
            baseTransformer.setCustomAnimationInterface(baseAnimationInterface);
        }
    }

    public void setCustomIndicator(PagerIndicator pagerIndicator) {
        PagerIndicator pagerIndicator2 = this.mIndicator;
        if (pagerIndicator2 != null) {
            pagerIndicator2.destroySelf();
        }
        this.mIndicator = pagerIndicator;
        pagerIndicator.setIndicatorVisibility(this.mIndicatorVisibility);
        this.mIndicator.setViewPager(this.mViewPager);
        this.mIndicator.redraw();
    }

    public void setDuration(long l) {
        if (l >= 500L) {
            this.mSliderDuration = l;
            if (this.mAutoCycle && this.mCycling) {
                this.startAutoCycle();
            }
        }
    }

    public void setIndicatorVisibility(PagerIndicator.IndicatorVisibility indicatorVisibility) {
        PagerIndicator pagerIndicator = this.mIndicator;
        if (pagerIndicator == null) {
            return;
        }
        pagerIndicator.setIndicatorVisibility(indicatorVisibility);
    }

    public void setPagerTransformer(boolean bl, BaseTransformer baseTransformer) {
        this.mViewPagerTransformer = baseTransformer;
        baseTransformer.setCustomAnimationInterface(this.mCustomAnimation);
        this.mViewPager.setPageTransformer(bl, this.mViewPagerTransformer);
    }

    public void setPresetIndicator(PresetIndicators presetIndicators) {
        this.setCustomIndicator((PagerIndicator)this.findViewById(presetIndicators.getResourceId()));
    }

    public void setPresetTransformer(int n) {
        for (Transformer transformer : Transformer.values()) {
            if (transformer.ordinal() != n) continue;
            this.setPresetTransformer(transformer);
            return;
        }
    }

    public void setPresetTransformer(Transformer transformer) {
        BaseTransformer baseTransformer;
        switch (5.$SwitchMap$com$daimajia$slider$library$SliderLayout$Transformer[transformer.ordinal()]) {
            default: {
                baseTransformer = null;
                break;
            }
            case 16: {
                baseTransformer = new ZoomOutTransformer();
                break;
            }
            case 15: {
                baseTransformer = new ZoomOutSlideTransformer();
                break;
            }
            case 14: {
                baseTransformer = new ZoomInTransformer();
                break;
            }
            case 13: {
                baseTransformer = new TabletTransformer();
                break;
            }
            case 12: {
                baseTransformer = new StackTransformer();
                break;
            }
            case 11: {
                baseTransformer = new RotateUpTransformer();
                break;
            }
            case 10: {
                baseTransformer = new RotateDownTransformer();
                break;
            }
            case 9: {
                baseTransformer = new ForegroundToBackgroundTransformer();
                break;
            }
            case 8: {
                baseTransformer = new FlipPageViewTransformer();
                break;
            }
            case 7: {
                baseTransformer = new FlipHorizontalTransformer();
                break;
            }
            case 6: {
                baseTransformer = new FadeTransformer();
                break;
            }
            case 5: {
                baseTransformer = new DepthPageTransformer();
                break;
            }
            case 4: {
                baseTransformer = new CubeInTransformer();
                break;
            }
            case 3: {
                baseTransformer = new BackgroundToForegroundTransformer();
                break;
            }
            case 2: {
                baseTransformer = new AccordionTransformer();
                break;
            }
            case 1: {
                baseTransformer = new DefaultTransformer();
            }
        }
        this.setPagerTransformer(true, baseTransformer);
    }

    public void setPresetTransformer(String string2) {
        for (Transformer transformer : Transformer.values()) {
            if (!transformer.equals(string2)) continue;
            this.setPresetTransformer(transformer);
            return;
        }
    }

    public void setSliderTransformDuration(int n, Interpolator interpolator2) {
        try {
            Field field = ViewPagerEx.class.getDeclaredField("mScroller");
            field.setAccessible(true);
            FixedSpeedScroller fixedSpeedScroller = new FixedSpeedScroller(this.mViewPager.getContext(), interpolator2, n);
            field.set((Object)this.mViewPager, (Object)fixedSpeedScroller);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public void startAutoCycle() {
        long l = this.mSliderDuration;
        this.startAutoCycle(l, l, this.mAutoRecover);
    }

    public void startAutoCycle(long l, long l2, boolean bl) {
        Timer timer;
        TimerTask timerTask;
        TimerTask timerTask2;
        TimerTask timerTask3;
        Timer timer2 = this.mCycleTimer;
        if (timer2 != null) {
            timer2.cancel();
        }
        if ((timerTask3 = this.mCycleTask) != null) {
            timerTask3.cancel();
        }
        if ((timerTask = this.mResumingTask) != null) {
            timerTask.cancel();
        }
        if ((timer = this.mResumingTimer) != null) {
            timer.cancel();
        }
        this.mSliderDuration = l2;
        this.mCycleTimer = new Timer();
        this.mAutoRecover = bl;
        this.mCycleTask = timerTask2 = new TimerTask(){

            public void run() {
                SliderLayout.this.mh.sendEmptyMessage(0);
            }
        };
        this.mCycleTimer.schedule(timerTask2, l, this.mSliderDuration);
        this.mCycling = true;
        this.mAutoCycle = true;
    }

    public void stopAutoCycle() {
        Timer timer;
        Timer timer2;
        TimerTask timerTask;
        TimerTask timerTask2 = this.mCycleTask;
        if (timerTask2 != null) {
            timerTask2.cancel();
        }
        if ((timer = this.mCycleTimer) != null) {
            timer.cancel();
        }
        if ((timer2 = this.mResumingTimer) != null) {
            timer2.cancel();
        }
        if ((timerTask = this.mResumingTask) != null) {
            timerTask.cancel();
        }
        this.mAutoCycle = false;
        this.mCycling = false;
    }

    public static final class PresetIndicators
    extends Enum<PresetIndicators> {
        private static final /* synthetic */ PresetIndicators[] $VALUES;
        public static final /* enum */ PresetIndicators Center_Bottom;
        public static final /* enum */ PresetIndicators Center_Top;
        public static final /* enum */ PresetIndicators Left_Bottom;
        public static final /* enum */ PresetIndicators Left_Top;
        public static final /* enum */ PresetIndicators Right_Bottom;
        public static final /* enum */ PresetIndicators Right_Top;
        private final int id;
        private final String name;

        static {
            PresetIndicators presetIndicators;
            PresetIndicators presetIndicators2;
            PresetIndicators presetIndicators3;
            PresetIndicators presetIndicators4;
            PresetIndicators presetIndicators5;
            PresetIndicators presetIndicators6;
            Center_Bottom = presetIndicators2 = new PresetIndicators("Center_Bottom", R.id.default_center_bottom_indicator);
            Right_Bottom = presetIndicators5 = new PresetIndicators("Right_Bottom", R.id.default_bottom_right_indicator);
            Left_Bottom = presetIndicators = new PresetIndicators("Left_Bottom", R.id.default_bottom_left_indicator);
            Center_Top = presetIndicators4 = new PresetIndicators("Center_Top", R.id.default_center_top_indicator);
            Right_Top = presetIndicators6 = new PresetIndicators("Right_Top", R.id.default_center_top_right_indicator);
            Left_Top = presetIndicators3 = new PresetIndicators("Left_Top", R.id.default_center_top_left_indicator);
            $VALUES = new PresetIndicators[]{presetIndicators2, presetIndicators5, presetIndicators, presetIndicators4, presetIndicators6, presetIndicators3};
        }

        private PresetIndicators(String string3, int n2) {
            this.name = string3;
            this.id = n2;
        }

        public static PresetIndicators valueOf(String string2) {
            return (PresetIndicators)Enum.valueOf(PresetIndicators.class, (String)string2);
        }

        public static PresetIndicators[] values() {
            return (PresetIndicators[])$VALUES.clone();
        }

        public int getResourceId() {
            return this.id;
        }

        public String toString() {
            return this.name;
        }
    }

    public static final class Transformer
    extends Enum<Transformer> {
        private static final /* synthetic */ Transformer[] $VALUES;
        public static final /* enum */ Transformer Accordion;
        public static final /* enum */ Transformer Background2Foreground;
        public static final /* enum */ Transformer CubeIn;
        public static final /* enum */ Transformer Default;
        public static final /* enum */ Transformer DepthPage;
        public static final /* enum */ Transformer Fade;
        public static final /* enum */ Transformer FlipHorizontal;
        public static final /* enum */ Transformer FlipPage;
        public static final /* enum */ Transformer Foreground2Background;
        public static final /* enum */ Transformer RotateDown;
        public static final /* enum */ Transformer RotateUp;
        public static final /* enum */ Transformer Stack;
        public static final /* enum */ Transformer Tablet;
        public static final /* enum */ Transformer ZoomIn;
        public static final /* enum */ Transformer ZoomOut;
        public static final /* enum */ Transformer ZoomOutSlide;
        private final String name;

        static {
            Transformer transformer;
            Transformer transformer2;
            Transformer transformer3;
            Transformer transformer4;
            Transformer transformer5;
            Transformer transformer6;
            Transformer transformer7;
            Transformer transformer8;
            Transformer transformer9;
            Transformer transformer10;
            Transformer transformer11;
            Transformer transformer12;
            Transformer transformer13;
            Transformer transformer14;
            Transformer transformer15;
            Transformer transformer16;
            Default = transformer5 = new Transformer("Default");
            Accordion = transformer8 = new Transformer("Accordion");
            Background2Foreground = transformer16 = new Transformer("Background2Foreground");
            CubeIn = transformer4 = new Transformer("CubeIn");
            DepthPage = transformer9 = new Transformer("DepthPage");
            Fade = transformer15 = new Transformer("Fade");
            FlipHorizontal = transformer2 = new Transformer("FlipHorizontal");
            FlipPage = transformer10 = new Transformer("FlipPage");
            Foreground2Background = transformer = new Transformer("Foreground2Background");
            RotateDown = transformer14 = new Transformer("RotateDown");
            RotateUp = transformer11 = new Transformer("RotateUp");
            Stack = transformer7 = new Transformer("Stack");
            Tablet = transformer3 = new Transformer("Tablet");
            ZoomIn = transformer13 = new Transformer("ZoomIn");
            ZoomOutSlide = transformer12 = new Transformer("ZoomOutSlide");
            ZoomOut = transformer6 = new Transformer("ZoomOut");
            $VALUES = new Transformer[]{transformer5, transformer8, transformer16, transformer4, transformer9, transformer15, transformer2, transformer10, transformer, transformer14, transformer11, transformer7, transformer3, transformer13, transformer12, transformer6};
        }

        private Transformer(String string3) {
            this.name = string3;
        }

        public static Transformer valueOf(String string2) {
            return (Transformer)Enum.valueOf(Transformer.class, (String)string2);
        }

        public static Transformer[] values() {
            return (Transformer[])$VALUES.clone();
        }

        public boolean equals(String string2) {
            if (string2 == null) {
                return false;
            }
            return this.name.equals((Object)string2);
        }

        public String toString() {
            return this.name;
        }
    }

}

