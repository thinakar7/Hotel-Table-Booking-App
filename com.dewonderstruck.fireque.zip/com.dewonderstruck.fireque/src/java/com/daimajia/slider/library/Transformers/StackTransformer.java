/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.nineoldandroids.view.ViewHelper
 */
package com.daimajia.slider.library.Transformers;

import android.view.View;
import com.daimajia.slider.library.Transformers.BaseTransformer;
import com.nineoldandroids.view.ViewHelper;

public class StackTransformer
extends BaseTransformer {
    @Override
    protected void onTransform(View view, float f) {
        float f2 = f < 0.0f ? 0.0f : f * (float)(-view.getWidth());
        ViewHelper.setTranslationX((View)view, (float)f2);
    }
}

