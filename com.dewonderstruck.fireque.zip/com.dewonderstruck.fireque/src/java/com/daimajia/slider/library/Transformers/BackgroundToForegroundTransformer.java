/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.nineoldandroids.view.ViewHelper
 *  java.lang.Math
 */
package com.daimajia.slider.library.Transformers;

import android.view.View;
import com.daimajia.slider.library.Transformers.BaseTransformer;
import com.nineoldandroids.view.ViewHelper;

public class BackgroundToForegroundTransformer
extends BaseTransformer {
    private static final float min(float f, float f2) {
        if (f < f2) {
            return f2;
        }
        return f;
    }

    @Override
    protected void onTransform(View view, float f) {
        float f2 = view.getHeight();
        float f3 = view.getWidth();
        float f4 = 1.0f;
        if (!(f < 0.0f)) {
            f4 = Math.abs((float)(f4 - f));
        }
        float f5 = BackgroundToForegroundTransformer.min(f4, 0.5f);
        ViewHelper.setScaleX((View)view, (float)f5);
        ViewHelper.setScaleY((View)view, (float)f5);
        ViewHelper.setPivotX((View)view, (float)(f3 * 0.5f));
        ViewHelper.setPivotY((View)view, (float)(0.5f * f2));
        float f6 = f < 0.0f ? f3 * f : 0.25f * (f * -f3);
        ViewHelper.setTranslationX((View)view, (float)f6);
    }
}

