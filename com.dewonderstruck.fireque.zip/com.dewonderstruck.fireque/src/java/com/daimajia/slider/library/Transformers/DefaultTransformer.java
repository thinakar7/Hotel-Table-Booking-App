/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.daimajia.slider.library.Transformers;

import android.view.View;
import com.daimajia.slider.library.Transformers.BaseTransformer;

public class DefaultTransformer
extends BaseTransformer {
    @Override
    public boolean isPagingEnabled() {
        return true;
    }

    @Override
    protected void onTransform(View view, float f) {
    }
}

