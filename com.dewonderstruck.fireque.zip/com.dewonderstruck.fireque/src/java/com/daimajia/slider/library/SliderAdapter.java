/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.ViewGroup
 *  androidx.viewpager.widget.PagerAdapter
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package com.daimajia.slider.library;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import androidx.viewpager.widget.PagerAdapter;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import java.util.ArrayList;
import java.util.Iterator;

public class SliderAdapter
extends PagerAdapter
implements BaseSliderView.ImageLoadListener {
    private Context mContext;
    private ArrayList<BaseSliderView> mImageContents;

    public SliderAdapter(Context context) {
        this.mContext = context;
        this.mImageContents = new ArrayList();
    }

    public <T extends BaseSliderView> void addSlider(T t) {
        ((BaseSliderView)t).setOnImageLoadListener(this);
        this.mImageContents.add(t);
        this.notifyDataSetChanged();
    }

    public void destroyItem(ViewGroup viewGroup, int n, Object object) {
        viewGroup.removeView((View)object);
    }

    public int getCount() {
        return this.mImageContents.size();
    }

    public int getItemPosition(Object object) {
        return -2;
    }

    public BaseSliderView getSliderView(int n) {
        if (n >= 0 && n < this.mImageContents.size()) {
            return (BaseSliderView)this.mImageContents.get(n);
        }
        return null;
    }

    public Object instantiateItem(ViewGroup viewGroup, int n) {
        View view = ((BaseSliderView)this.mImageContents.get(n)).getView();
        viewGroup.addView(view);
        return view;
    }

    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void onEnd(boolean bl, BaseSliderView baseSliderView) {
        if (baseSliderView.isErrorDisappear()) {
            if (bl) {
                return;
            }
            Iterator iterator = this.mImageContents.iterator();
            while (iterator.hasNext()) {
                if (!((BaseSliderView)iterator.next()).equals((Object)baseSliderView)) continue;
                this.removeSlider(baseSliderView);
                return;
            }
            return;
        }
    }

    @Override
    public void onStart(BaseSliderView baseSliderView) {
    }

    public void removeAllSliders() {
        this.mImageContents.clear();
        this.notifyDataSetChanged();
    }

    public <T extends BaseSliderView> void removeSlider(T t) {
        if (this.mImageContents.contains(t)) {
            this.mImageContents.remove(t);
            this.notifyDataSetChanged();
        }
    }

    public void removeSliderAt(int n) {
        if (this.mImageContents.size() > n) {
            this.mImageContents.remove(n);
            this.notifyDataSetChanged();
        }
    }
}

