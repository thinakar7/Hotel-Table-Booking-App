/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  com.squareup.picasso.Callback
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.io.File
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 */
package com.daimajia.slider.library.SliderTypes;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import com.daimajia.slider.library.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import java.io.File;

public abstract class BaseSliderView {
    private Bundle mBundle;
    protected Context mContext;
    private int mEmptyPlaceHolderRes;
    private boolean mErrorDisappear;
    private int mErrorPlaceHolderRes;
    private File mFile;
    private ImageLoadListener mLoadListener;
    private String mName;
    protected OnSliderClickListener mOnSliderClickListener;
    private Picasso mPicasso;
    private int mRes;
    private ScaleType mScaleType = ScaleType.Fit;
    private String mSub_name;
    private String mUrl;
    private String mlogo;
    private String mrating;
    private String mratingView;

    protected BaseSliderView(Context context) {
        this.mContext = context;
    }

    protected void bindEventAndShow(final View view, ImageView imageView) {
        block17 : {
            RequestCreator requestCreator;
            int n;
            block15 : {
                Picasso picasso;
                block16 : {
                    block14 : {
                        view.setOnClickListener(new View.OnClickListener(){

                            public void onClick(View view) {
                                if (BaseSliderView.this.mOnSliderClickListener != null) {
                                    BaseSliderView.this.mOnSliderClickListener.onSliderClick(this);
                                }
                            }
                        });
                        if (imageView == null) {
                            return;
                        }
                        ImageLoadListener imageLoadListener = this.mLoadListener;
                        if (imageLoadListener != null) {
                            imageLoadListener.onStart(this);
                        }
                        if ((picasso = this.mPicasso) == null) {
                            picasso = Picasso.get();
                        }
                        String string2 = this.mUrl;
                        if (string2 == null) break block14;
                        requestCreator = picasso.load(string2);
                        break block15;
                    }
                    File file = this.mFile;
                    if (file == null) break block16;
                    requestCreator = picasso.load(file);
                    break block15;
                }
                int n2 = this.mRes;
                if (n2 == 0) break block17;
                requestCreator = picasso.load(n2);
            }
            if (requestCreator == null) {
                return;
            }
            if (this.getEmpty() != 0) {
                requestCreator.placeholder(this.getEmpty());
            }
            if (this.getError() != 0) {
                requestCreator.error(this.getError());
            }
            if ((n = 3.$SwitchMap$com$daimajia$slider$library$SliderTypes$BaseSliderView$ScaleType[this.mScaleType.ordinal()]) != 1) {
                if (n != 2) {
                    if (n == 3) {
                        requestCreator.fit().centerInside();
                    }
                } else {
                    requestCreator.fit().centerCrop();
                }
            } else {
                requestCreator.fit();
            }
            requestCreator.into(imageView, new Callback(){

                public void onError(Exception exception) {
                    if (BaseSliderView.this.mLoadListener != null) {
                        BaseSliderView.this.mLoadListener.onEnd(false, this);
                    }
                    if (view.findViewById(R.id.loading_bar) != null) {
                        view.findViewById(R.id.loading_bar).setVisibility(4);
                    }
                }

                public void onSuccess() {
                    if (view.findViewById(R.id.loading_bar) != null) {
                        view.findViewById(R.id.loading_bar).setVisibility(4);
                    }
                }
            });
            return;
        }
    }

    public BaseSliderView bundle(Bundle bundle) {
        this.mBundle = bundle;
        return this;
    }

    public BaseSliderView empty(int n) {
        this.mEmptyPlaceHolderRes = n;
        return this;
    }

    public BaseSliderView error(int n) {
        this.mErrorPlaceHolderRes = n;
        return this;
    }

    public BaseSliderView errorDisappear(boolean bl) {
        this.mErrorDisappear = bl;
        return this;
    }

    public Bundle getBundle() {
        return this.mBundle;
    }

    public Context getContext() {
        return this.mContext;
    }

    public int getEmpty() {
        return this.mEmptyPlaceHolderRes;
    }

    public int getError() {
        return this.mErrorPlaceHolderRes;
    }

    public String getLogo() {
        return this.mlogo;
    }

    public String getName() {
        return this.mName;
    }

    public Picasso getPicasso() {
        return this.mPicasso;
    }

    public String getRating() {
        return this.mrating;
    }

    public String getRatingView() {
        return this.mratingView;
    }

    public ScaleType getScaleType() {
        return this.mScaleType;
    }

    public String getSub_name() {
        return this.mSub_name;
    }

    public String getUrl() {
        return this.mUrl;
    }

    public abstract View getView();

    public BaseSliderView image(int n) {
        if (this.mUrl == null && this.mFile == null) {
            this.mRes = n;
            return this;
        }
        throw new IllegalStateException("Call multi image function,you only have permission to call it once");
    }

    public BaseSliderView image(File file) {
        if (this.mUrl == null && this.mRes == 0) {
            this.mFile = file;
            return this;
        }
        throw new IllegalStateException("Call multi image function,you only have permission to call it once");
    }

    public BaseSliderView image(String string2) {
        if (this.mFile == null && this.mRes == 0) {
            this.mUrl = string2;
            return this;
        }
        throw new IllegalStateException("Call multi image function,you only have permission to call it once");
    }

    public boolean isErrorDisappear() {
        return this.mErrorDisappear;
    }

    public BaseSliderView logo(String string2) {
        this.mlogo = string2;
        return this;
    }

    public BaseSliderView name(String string2) {
        this.mName = string2;
        return this;
    }

    public BaseSliderView rating(String string2) {
        this.mrating = string2;
        return this;
    }

    public BaseSliderView ratingView(String string2) {
        this.mratingView = string2;
        return this;
    }

    public void setOnImageLoadListener(ImageLoadListener imageLoadListener) {
        this.mLoadListener = imageLoadListener;
    }

    public BaseSliderView setOnSliderClickListener(OnSliderClickListener onSliderClickListener) {
        this.mOnSliderClickListener = onSliderClickListener;
        return this;
    }

    public void setPicasso(Picasso picasso) {
        this.mPicasso = picasso;
    }

    public BaseSliderView setScaleType(ScaleType scaleType) {
        this.mScaleType = scaleType;
        return this;
    }

    public BaseSliderView sub_name(String string2) {
        this.mSub_name = string2;
        return this;
    }

    public static interface ImageLoadListener {
        public void onEnd(boolean var1, BaseSliderView var2);

        public void onStart(BaseSliderView var1);
    }

    public static interface OnSliderClickListener {
        public void onSliderClick(BaseSliderView var1);
    }

    public static final class ScaleType
    extends Enum<ScaleType> {
        private static final /* synthetic */ ScaleType[] $VALUES;
        public static final /* enum */ ScaleType CenterCrop;
        public static final /* enum */ ScaleType CenterInside;
        public static final /* enum */ ScaleType Fit;
        public static final /* enum */ ScaleType FitCenterCrop;

        static {
            ScaleType scaleType;
            ScaleType scaleType2;
            ScaleType scaleType3;
            ScaleType scaleType4;
            CenterCrop = scaleType3 = new ScaleType();
            CenterInside = scaleType4 = new ScaleType();
            Fit = scaleType2 = new ScaleType();
            FitCenterCrop = scaleType = new ScaleType();
            $VALUES = new ScaleType[]{scaleType3, scaleType4, scaleType2, scaleType};
        }

        public static ScaleType valueOf(String string2) {
            return (ScaleType)Enum.valueOf(ScaleType.class, (String)string2);
        }

        public static ScaleType[] values() {
            return (ScaleType[])$VALUES.clone();
        }
    }

}

