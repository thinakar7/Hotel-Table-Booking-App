/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcelable
 *  android.view.View
 *  android.view.ViewGroup
 *  androidx.viewpager.widget.PagerAdapter
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.daimajia.slider.library.Tricks;

import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import androidx.viewpager.widget.PagerAdapter;
import com.daimajia.slider.library.SliderAdapter;

public class InfinitePagerAdapter
extends PagerAdapter {
    private static final boolean DEBUG = false;
    private static final String TAG = "InfinitePagerAdapter";
    private SliderAdapter adapter;

    public InfinitePagerAdapter(SliderAdapter sliderAdapter) {
        this.adapter = sliderAdapter;
    }

    private void debug(String string2) {
    }

    public void destroyItem(ViewGroup viewGroup, int n, Object object) {
        if (this.getRealCount() == 0) {
            return;
        }
        int n2 = n % this.getRealCount();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("destroyItem: real position: ");
        stringBuilder.append(n);
        this.debug(stringBuilder.toString());
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("destroyItem: virtual position: ");
        stringBuilder2.append(n2);
        this.debug(stringBuilder2.toString());
        this.adapter.destroyItem(viewGroup, n2, object);
    }

    public void finishUpdate(ViewGroup viewGroup) {
        this.adapter.finishUpdate(viewGroup);
    }

    public int getCount() {
        return Integer.MAX_VALUE;
    }

    public SliderAdapter getRealAdapter() {
        return this.adapter;
    }

    public int getRealCount() {
        return this.adapter.getCount();
    }

    public Object instantiateItem(ViewGroup viewGroup, int n) {
        if (this.getRealCount() == 0) {
            return null;
        }
        int n2 = n % this.getRealCount();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("instantiateItem: real position: ");
        stringBuilder.append(n);
        this.debug(stringBuilder.toString());
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("instantiateItem: virtual position: ");
        stringBuilder2.append(n2);
        this.debug(stringBuilder2.toString());
        return this.adapter.instantiateItem(viewGroup, n2);
    }

    public boolean isViewFromObject(View view, Object object) {
        return this.adapter.isViewFromObject(view, object);
    }

    public void restoreState(Parcelable parcelable, ClassLoader classLoader) {
        this.adapter.restoreState(parcelable, classLoader);
    }

    public Parcelable saveState() {
        return this.adapter.saveState();
    }

    public void startUpdate(ViewGroup viewGroup) {
        this.adapter.startUpdate(viewGroup);
    }
}

