/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.content.res.TypedArray
 *  android.database.DataSetObserver
 *  android.graphics.Canvas
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.SystemClock
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.FocusFinder
 *  android.view.KeyEvent
 *  android.view.MotionEvent
 *  android.view.SoundEffectConstants
 *  android.view.VelocityTracker
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.view.View$MeasureSpec
 *  android.view.ViewConfiguration
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.view.accessibility.AccessibilityEvent
 *  android.view.animation.Interpolator
 *  android.widget.Scroller
 *  androidx.core.os.ParcelableCompat
 *  androidx.core.os.ParcelableCompatCreatorCallbacks
 *  androidx.core.view.AccessibilityDelegateCompat
 *  androidx.core.view.MotionEventCompat
 *  androidx.core.view.VelocityTrackerCompat
 *  androidx.core.view.ViewCompat
 *  androidx.core.view.ViewConfigurationCompat
 *  androidx.core.view.accessibility.AccessibilityNodeInfoCompat
 *  androidx.core.view.accessibility.AccessibilityRecordCompat
 *  androidx.core.widget.EdgeEffectCompat
 *  androidx.viewpager.widget.PagerAdapter
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Comparator
 */
package com.daimajia.slider.library.Tricks;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import androidx.core.os.ParcelableCompat;
import androidx.core.os.ParcelableCompatCreatorCallbacks;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.VelocityTrackerCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.ViewConfigurationCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.core.view.accessibility.AccessibilityRecordCompat;
import androidx.core.widget.EdgeEffectCompat;
import androidx.viewpager.widget.PagerAdapter;
import com.daimajia.slider.library.Tricks.InfinitePagerAdapter;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ViewPagerEx
extends ViewGroup {
    private static final int CLOSE_ENOUGH = 2;
    private static final Comparator<ItemInfo> COMPARATOR;
    private static final boolean DEBUG = false;
    private static final int DEFAULT_GUTTER_SIZE = 16;
    private static final int DEFAULT_OFFSCREEN_PAGES = 1;
    private static final int DRAW_ORDER_DEFAULT = 0;
    private static final int DRAW_ORDER_FORWARD = 1;
    private static final int DRAW_ORDER_REVERSE = 2;
    private static final int INVALID_POINTER = -1;
    private static final int[] LAYOUT_ATTRS;
    private static final int MAX_SETTLE_DURATION = 600;
    private static final int MIN_DISTANCE_FOR_FLING = 25;
    private static final int MIN_FLING_VELOCITY = 400;
    public static final int SCROLL_STATE_DRAGGING = 1;
    public static final int SCROLL_STATE_IDLE = 0;
    public static final int SCROLL_STATE_SETTLING = 2;
    private static final String TAG = "ViewPagerEx";
    private static final boolean USE_CACHE;
    private static final Interpolator sInterpolator;
    private static final ViewPositionComparator sPositionComparator;
    private int mActivePointerId = -1;
    private PagerAdapter mAdapter;
    private OnAdapterChangeListener mAdapterChangeListener;
    private int mBottomPageBounds;
    private boolean mCalledSuper;
    private int mChildHeightMeasureSpec;
    private int mChildWidthMeasureSpec;
    private int mCloseEnough;
    private int mCurItem;
    private int mDecorChildCount;
    private int mDefaultGutterSize;
    private int mDrawingOrder;
    private ArrayList<View> mDrawingOrderedChildren;
    private final Runnable mEndScrollRunnable = new Runnable(){

        public void run() {
            ViewPagerEx.this.setScrollState(0);
            ViewPagerEx.this.populate();
        }
    };
    private int mExpectedAdapterCount;
    private long mFakeDragBeginTime;
    private boolean mFakeDragging;
    private boolean mFirstLayout = true;
    private float mFirstOffset = -3.4028235E38f;
    private int mFlingDistance;
    private int mGutterSize;
    private boolean mIgnoreGutter;
    private boolean mInLayout;
    private float mInitialMotionX;
    private float mInitialMotionY;
    private OnPageChangeListener mInternalPageChangeListener;
    private boolean mIsBeingDragged;
    private boolean mIsUnableToDrag;
    private final ArrayList<ItemInfo> mItems = new ArrayList();
    private float mLastMotionX;
    private float mLastMotionY;
    private float mLastOffset = Float.MAX_VALUE;
    private EdgeEffectCompat mLeftEdge;
    private Drawable mMarginDrawable;
    private int mMaximumVelocity;
    private int mMinimumVelocity;
    private boolean mNeedCalculatePageOffsets = false;
    private PagerObserver mObserver;
    private int mOffscreenPageLimit = 1;
    private ArrayList<OnPageChangeListener> mOnPageChangeListeners = new ArrayList();
    private int mPageMargin;
    private PageTransformer mPageTransformer;
    private boolean mPopulatePending;
    private Parcelable mRestoredAdapterState = null;
    private ClassLoader mRestoredClassLoader = null;
    private int mRestoredCurItem = -1;
    private EdgeEffectCompat mRightEdge;
    private int mScrollState = 0;
    private Scroller mScroller;
    private boolean mScrollingCacheEnabled;
    private Method mSetChildrenDrawingOrderEnabled;
    private final ItemInfo mTempItem = new ItemInfo();
    private final Rect mTempRect = new Rect();
    private int mTopPageBounds;
    private int mTouchSlop;
    private VelocityTracker mVelocityTracker;

    static {
        LAYOUT_ATTRS = new int[]{16842931};
        COMPARATOR = new Comparator<ItemInfo>(){

            public int compare(ItemInfo itemInfo, ItemInfo itemInfo2) {
                return itemInfo.position - itemInfo2.position;
            }
        };
        sInterpolator = new Interpolator(){

            public float getInterpolation(float f) {
                float f2 = f - 1.0f;
                return 1.0f + f2 * (f2 * (f2 * (f2 * f2)));
            }
        };
        sPositionComparator = new ViewPositionComparator();
    }

    public ViewPagerEx(Context context) {
        super(context);
        this.initViewPager();
    }

    public ViewPagerEx(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.initViewPager();
    }

    private void calculatePageOffsets(ItemInfo itemInfo, int n, ItemInfo itemInfo2) {
        int n2 = this.mAdapter.getCount();
        int n3 = this.getClientWidth();
        float f = n3 > 0 ? (float)this.mPageMargin / (float)n3 : 0.0f;
        if (itemInfo2 != null) {
            int n4 = itemInfo2.position;
            if (n4 < itemInfo.position) {
                int n5 = 0;
                float f2 = f + (itemInfo2.offset + itemInfo2.widthFactor);
                for (int i = n4 + 1; i <= itemInfo.position && n5 < this.mItems.size(); ++i) {
                    ItemInfo itemInfo3 = (ItemInfo)this.mItems.get(n5);
                    while (i > itemInfo3.position && n5 < -1 + this.mItems.size()) {
                        itemInfo3 = (ItemInfo)this.mItems.get(++n5);
                    }
                    while (i < itemInfo3.position) {
                        f2 += f + this.mAdapter.getPageWidth(i);
                        ++i;
                    }
                    itemInfo3.offset = f2;
                    f2 += f + itemInfo3.widthFactor;
                }
            } else if (n4 > itemInfo.position) {
                int n6 = -1 + this.mItems.size();
                float f3 = itemInfo2.offset;
                for (int i = n4 - 1; i >= itemInfo.position && n6 >= 0; --i) {
                    ItemInfo itemInfo4 = (ItemInfo)this.mItems.get(n6);
                    while (i < itemInfo4.position && n6 > 0) {
                        itemInfo4 = (ItemInfo)this.mItems.get(--n6);
                    }
                    while (i > itemInfo4.position) {
                        f3 -= f + this.mAdapter.getPageWidth(i);
                        --i;
                    }
                    itemInfo4.offset = f3 -= f + itemInfo4.widthFactor;
                }
            }
        }
        int n7 = this.mItems.size();
        float f4 = itemInfo.offset;
        int n8 = -1 + itemInfo.position;
        float f5 = itemInfo.position == 0 ? itemInfo.offset : -3.4028235E38f;
        this.mFirstOffset = f5;
        float f6 = itemInfo.position == n2 - 1 ? itemInfo.offset + itemInfo.widthFactor - 1.0f : Float.MAX_VALUE;
        this.mLastOffset = f6;
        int n9 = n - 1;
        while (n9 >= 0) {
            ItemInfo itemInfo5 = (ItemInfo)this.mItems.get(n9);
            while (n8 > itemInfo5.position) {
                PagerAdapter pagerAdapter = this.mAdapter;
                int n10 = n8 - 1;
                f4 -= f + pagerAdapter.getPageWidth(n8);
                n8 = n10;
            }
            itemInfo5.offset = f4 -= f + itemInfo5.widthFactor;
            if (itemInfo5.position == 0) {
                this.mFirstOffset = f4;
            }
            --n9;
            --n8;
        }
        float f7 = f + (itemInfo.offset + itemInfo.widthFactor);
        int n11 = 1 + itemInfo.position;
        int n12 = n + 1;
        while (n12 < n7) {
            ItemInfo itemInfo6 = (ItemInfo)this.mItems.get(n12);
            while (n11 < itemInfo6.position) {
                PagerAdapter pagerAdapter = this.mAdapter;
                int n13 = n11 + 1;
                f7 += f + pagerAdapter.getPageWidth(n11);
                n11 = n13;
            }
            if (itemInfo6.position == n2 - 1) {
                this.mLastOffset = f7 + itemInfo6.widthFactor - 1.0f;
            }
            itemInfo6.offset = f7;
            f7 += f + itemInfo6.widthFactor;
            ++n12;
            ++n11;
        }
        this.mNeedCalculatePageOffsets = false;
    }

    private void completeScroll(boolean bl) {
        boolean bl2 = this.mScrollState == 2;
        if (bl2) {
            this.setScrollingCacheEnabled(false);
            this.mScroller.abortAnimation();
            int n = this.getScrollX();
            int n2 = this.getScrollY();
            int n3 = this.mScroller.getCurrX();
            int n4 = this.mScroller.getCurrY();
            if (n != n3 || n2 != n4) {
                this.scrollTo(n3, n4);
            }
        }
        this.mPopulatePending = false;
        for (int i = 0; i < this.mItems.size(); ++i) {
            ItemInfo itemInfo = (ItemInfo)this.mItems.get(i);
            if (!itemInfo.scrolling) continue;
            bl2 = true;
            itemInfo.scrolling = false;
        }
        if (bl2) {
            if (bl) {
                ViewCompat.postOnAnimation((View)this, (Runnable)this.mEndScrollRunnable);
                return;
            }
            this.mEndScrollRunnable.run();
        }
    }

    private int determineTargetPage(int n, float f, int n2, int n3) {
        int n4;
        if (Math.abs((int)n3) > this.mFlingDistance && Math.abs((int)n2) > this.mMinimumVelocity) {
            n4 = n2 > 0 ? n : n + 1;
        } else {
            float f2 = n >= this.mCurItem ? 0.4f : 0.6f;
            n4 = (int)(f2 + (f + (float)n));
        }
        if (this.mItems.size() > 0) {
            ItemInfo itemInfo = (ItemInfo)this.mItems.get(0);
            ArrayList<ItemInfo> arrayList = this.mItems;
            ItemInfo itemInfo2 = (ItemInfo)arrayList.get(-1 + arrayList.size());
            n4 = Math.max((int)itemInfo.position, (int)Math.min((int)n4, (int)itemInfo2.position));
        }
        return n4;
    }

    @SuppressLint(value={"WrongConstant"})
    private void enableLayers(boolean bl) {
        int n = this.getChildCount();
        for (int i = 0; i < n; ++i) {
            int n2 = bl ? 2 : 0;
            ViewCompat.setLayerType((View)this.getChildAt(i), (int)n2, null);
        }
    }

    private void endDrag() {
        this.mIsBeingDragged = false;
        this.mIsUnableToDrag = false;
        VelocityTracker velocityTracker = this.mVelocityTracker;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.mVelocityTracker = null;
        }
    }

    private Rect getChildRectInPagerCoordinates(Rect rect, View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view == null) {
            rect.set(0, 0, 0, 0);
            return rect;
        }
        rect.left = view.getLeft();
        rect.right = view.getRight();
        rect.top = view.getTop();
        rect.bottom = view.getBottom();
        ViewParent viewParent = view.getParent();
        while (viewParent instanceof ViewGroup && viewParent != this) {
            ViewGroup viewGroup = (ViewGroup)viewParent;
            rect.left += viewGroup.getLeft();
            rect.right += viewGroup.getRight();
            rect.top += viewGroup.getTop();
            rect.bottom += viewGroup.getBottom();
            viewParent = viewGroup.getParent();
        }
        return rect;
    }

    private int getClientWidth() {
        return this.getMeasuredWidth() - this.getPaddingLeft() - this.getPaddingRight();
    }

    private ItemInfo infoForCurrentScrollPosition() {
        int n = this.getClientWidth();
        float f = n > 0 ? (float)this.getScrollX() / (float)n : 0.0f;
        float f2 = 0.0f;
        if (n > 0) {
            f2 = (float)this.mPageMargin / (float)n;
        }
        int n2 = -1;
        float f3 = 0.0f;
        float f4 = 0.0f;
        boolean bl = true;
        ItemInfo itemInfo = null;
        for (int i = 0; i < this.mItems.size(); ++i) {
            ItemInfo itemInfo2 = (ItemInfo)this.mItems.get(i);
            if (!bl && itemInfo2.position != n2 + 1) {
                itemInfo2 = this.mTempItem;
                itemInfo2.offset = f2 + (f3 + f4);
                itemInfo2.position = n2 + 1;
                itemInfo2.widthFactor = this.mAdapter.getPageWidth(itemInfo2.position);
                --i;
            }
            float f5 = itemInfo2.offset;
            float f6 = f2 + (f5 + itemInfo2.widthFactor);
            if (!bl && !(f >= f5)) {
                return itemInfo;
            }
            if (!(f < f6)) {
                if (i == -1 + this.mItems.size()) {
                    return itemInfo2;
                }
                n2 = itemInfo2.position;
                f3 = f5;
                f4 = itemInfo2.widthFactor;
                itemInfo = itemInfo2;
                bl = false;
                continue;
            }
            return itemInfo2;
        }
        return itemInfo;
    }

    private boolean isGutterDrag(float f, float f2) {
        return f < (float)this.mGutterSize && f2 > 0.0f || f > (float)(this.getWidth() - this.mGutterSize) && f2 < 0.0f;
    }

    private void onSecondaryPointerUp(MotionEvent motionEvent) {
        int n = MotionEventCompat.getActionIndex((MotionEvent)motionEvent);
        if (MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)n) == this.mActivePointerId) {
            int n2 = n == 0 ? 1 : 0;
            this.mLastMotionX = MotionEventCompat.getX((MotionEvent)motionEvent, (int)n2);
            this.mActivePointerId = MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)n2);
            VelocityTracker velocityTracker = this.mVelocityTracker;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    private boolean pageScrolled(int n) {
        if (this.mItems.size() == 0) {
            this.mCalledSuper = false;
            this.onPageScrolled(0, 0.0f, 0);
            if (this.mCalledSuper) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
        ItemInfo itemInfo = this.infoForCurrentScrollPosition();
        int n2 = this.getClientWidth();
        int n3 = this.mPageMargin;
        int n4 = n2 + n3;
        float f = (float)n3 / (float)n2;
        int n5 = itemInfo.position;
        float f2 = ((float)n / (float)n2 - itemInfo.offset) / (f + itemInfo.widthFactor);
        int n6 = (int)(f2 * (float)n4);
        this.mCalledSuper = false;
        this.onPageScrolled(n5, f2, n6);
        if (this.mCalledSuper) {
            return true;
        }
        throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    }

    private boolean performDrag(float f) {
        boolean bl;
        float f2 = this.mLastMotionX - f;
        this.mLastMotionX = f;
        float f3 = f2 + (float)this.getScrollX();
        int n = this.getClientWidth();
        float f4 = (float)n * this.mFirstOffset;
        float f5 = (float)n * this.mLastOffset;
        boolean bl2 = true;
        boolean bl3 = true;
        ItemInfo itemInfo = (ItemInfo)this.mItems.get(0);
        ArrayList<ItemInfo> arrayList = this.mItems;
        ItemInfo itemInfo2 = (ItemInfo)arrayList.get(-1 + arrayList.size());
        if (itemInfo.position != 0) {
            bl2 = false;
            f4 = itemInfo.offset * (float)n;
        }
        if (itemInfo2.position != -1 + this.mAdapter.getCount()) {
            bl3 = false;
            f5 = itemInfo2.offset * (float)n;
        }
        if (f3 < f4) {
            bl = false;
            if (bl2) {
                float f6 = f4 - f3;
                bl = this.mLeftEdge.onPull(Math.abs((float)f6) / (float)n);
            }
            f3 = f4;
        } else {
            float f7 = f3 FCMPL f5;
            bl = false;
            if (f7 > 0) {
                bl = false;
                if (bl3) {
                    float f8 = f3 - f5;
                    bl = this.mRightEdge.onPull(Math.abs((float)f8) / (float)n);
                }
                f3 = f5;
            }
        }
        this.mLastMotionX += f3 - (float)((int)f3);
        this.scrollTo((int)f3, this.getScrollY());
        this.pageScrolled((int)f3);
        return bl;
    }

    private void recomputeScrollPosition(int n, int n2, int n3, int n4) {
        if (n2 > 0 && !this.mItems.isEmpty()) {
            int n5 = n3 + (n - this.getPaddingLeft() - this.getPaddingRight());
            int n6 = n4 + (n2 - this.getPaddingLeft() - this.getPaddingRight());
            int n7 = (int)((float)this.getScrollX() / (float)n6 * (float)n5);
            this.scrollTo(n7, this.getScrollY());
            if (!this.mScroller.isFinished()) {
                int n8 = this.mScroller.getDuration() - this.mScroller.timePassed();
                ItemInfo itemInfo = this.infoForPosition(this.mCurItem);
                this.mScroller.startScroll(n7, 0, (int)(itemInfo.offset * (float)n), 0, n8);
            }
            return;
        }
        ItemInfo itemInfo = this.infoForPosition(this.mCurItem);
        float f = itemInfo != null ? Math.min((float)itemInfo.offset, (float)this.mLastOffset) : 0.0f;
        int n9 = (int)(f * (float)(n - this.getPaddingLeft() - this.getPaddingRight()));
        if (n9 != this.getScrollX()) {
            this.completeScroll(false);
            this.scrollTo(n9, this.getScrollY());
        }
    }

    private void removeNonDecorViews() {
        for (int i = 0; i < this.getChildCount(); ++i) {
            if (((LayoutParams)this.getChildAt((int)i).getLayoutParams()).isDecor) continue;
            this.removeViewAt(i);
            --i;
        }
    }

    private void requestParentDisallowInterceptTouchEvent(boolean bl) {
        ViewParent viewParent = this.getParent();
        if (viewParent != null) {
            viewParent.requestDisallowInterceptTouchEvent(bl);
        }
    }

    private void scrollToItem(int n, boolean bl, int n2, boolean bl2) {
        ItemInfo itemInfo = this.infoForPosition(n);
        int n3 = 0;
        if (itemInfo != null) {
            n3 = (int)((float)this.getClientWidth() * Math.max((float)this.mFirstOffset, (float)Math.min((float)itemInfo.offset, (float)this.mLastOffset)));
        }
        if (bl) {
            this.smoothScrollTo(n3, 0, n2);
            if (bl2) {
                this.triggerOnPageChangeEvent(n);
                return;
            }
        } else {
            if (bl2) {
                this.triggerOnPageChangeEvent(n);
            }
            this.completeScroll(false);
            this.scrollTo(n3, 0);
            this.pageScrolled(n3);
        }
    }

    private void setScrollState(int n) {
        if (this.mScrollState == n) {
            return;
        }
        this.mScrollState = n;
        if (this.mPageTransformer != null) {
            boolean bl = n != 0;
            this.enableLayers(bl);
        }
        for (OnPageChangeListener onPageChangeListener : this.mOnPageChangeListeners) {
            if (onPageChangeListener == null) continue;
            onPageChangeListener.onPageScrollStateChanged(n);
        }
    }

    private void setScrollingCacheEnabled(boolean bl) {
        if (this.mScrollingCacheEnabled != bl) {
            this.mScrollingCacheEnabled = bl;
        }
    }

    private void sortChildDrawingOrder() {
        if (this.mDrawingOrder != 0) {
            ArrayList<View> arrayList = this.mDrawingOrderedChildren;
            if (arrayList == null) {
                this.mDrawingOrderedChildren = new ArrayList();
            } else {
                arrayList.clear();
            }
            int n = this.getChildCount();
            for (int i = 0; i < n; ++i) {
                View view = this.getChildAt(i);
                this.mDrawingOrderedChildren.add((Object)view);
            }
            Collections.sort(this.mDrawingOrderedChildren, (Comparator)sPositionComparator);
        }
    }

    private void triggerOnPageChangeEvent(int n) {
        for (OnPageChangeListener onPageChangeListener : this.mOnPageChangeListeners) {
            if (onPageChangeListener == null) continue;
            InfinitePagerAdapter infinitePagerAdapter = (InfinitePagerAdapter)this.mAdapter;
            if (infinitePagerAdapter.getRealCount() == 0) {
                return;
            }
            onPageChangeListener.onPageSelected(n % infinitePagerAdapter.getRealCount());
        }
        OnPageChangeListener onPageChangeListener = this.mInternalPageChangeListener;
        if (onPageChangeListener != null) {
            onPageChangeListener.onPageSelected(n);
        }
    }

    public void addFocusables(ArrayList<View> arrayList, int n, int n2) {
        int n3 = arrayList.size();
        int n4 = this.getDescendantFocusability();
        if (n4 != 393216) {
            for (int i = 0; i < this.getChildCount(); ++i) {
                ItemInfo itemInfo;
                View view = this.getChildAt(i);
                if (view.getVisibility() != 0 || (itemInfo = this.infoForChild(view)) == null || itemInfo.position != this.mCurItem) continue;
                view.addFocusables(arrayList, n, n2);
            }
        }
        if (n4 != 262144 || n3 == arrayList.size()) {
            if (!this.isFocusable()) {
                return;
            }
            if ((n2 & 1) == 1 && this.isInTouchMode() && !this.isFocusableInTouchMode()) {
                return;
            }
            if (arrayList != null) {
                arrayList.add((Object)this);
            }
        }
    }

    ItemInfo addNewItem(int n, int n2) {
        ItemInfo itemInfo = new ItemInfo();
        itemInfo.position = n;
        itemInfo.object = this.mAdapter.instantiateItem((ViewGroup)this, n);
        itemInfo.widthFactor = this.mAdapter.getPageWidth(n);
        if (n2 >= 0 && n2 < this.mItems.size()) {
            this.mItems.add(n2, (Object)itemInfo);
            return itemInfo;
        }
        this.mItems.add((Object)itemInfo);
        return itemInfo;
    }

    public void addOnPageChangeListener(OnPageChangeListener onPageChangeListener) {
        if (!this.mOnPageChangeListeners.contains((Object)onPageChangeListener)) {
            this.mOnPageChangeListeners.add((Object)onPageChangeListener);
        }
    }

    public void addTouchables(ArrayList<View> arrayList) {
        for (int i = 0; i < this.getChildCount(); ++i) {
            ItemInfo itemInfo;
            View view = this.getChildAt(i);
            if (view.getVisibility() != 0 || (itemInfo = this.infoForChild(view)) == null || itemInfo.position != this.mCurItem) continue;
            view.addTouchables(arrayList);
        }
    }

    public void addView(View view, int n, ViewGroup.LayoutParams layoutParams) {
        if (!this.checkLayoutParams(layoutParams)) {
            layoutParams = this.generateLayoutParams(layoutParams);
        }
        LayoutParams layoutParams2 = (LayoutParams)layoutParams;
        layoutParams2.isDecor |= view instanceof Decor;
        if (this.mInLayout) {
            if (layoutParams2 != null && layoutParams2.isDecor) {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            }
            layoutParams2.needsMeasure = true;
            this.addViewInLayout(view, n, layoutParams);
            return;
        }
        super.addView(view, n, layoutParams);
    }

    public boolean arrowScroll(int n) {
        boolean bl;
        block14 : {
            block15 : {
                block16 : {
                    block13 : {
                        View view = this.findFocus();
                        if (view == this) {
                            view = null;
                        } else if (view != null) {
                            boolean bl2;
                            ViewParent viewParent = view.getParent();
                            do {
                                boolean bl3 = viewParent instanceof ViewGroup;
                                bl2 = false;
                                if (!bl3) break;
                                if (viewParent == this) {
                                    bl2 = true;
                                    break;
                                }
                                viewParent = viewParent.getParent();
                            } while (true);
                            if (!bl2) {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append(view.getClass().getSimpleName());
                                ViewParent viewParent2 = view.getParent();
                                while (viewParent2 instanceof ViewGroup) {
                                    stringBuilder.append(" => ");
                                    stringBuilder.append(viewParent2.getClass().getSimpleName());
                                    viewParent2 = viewParent2.getParent();
                                }
                                StringBuilder stringBuilder2 = new StringBuilder();
                                stringBuilder2.append("arrowScroll tried to find focus based on non-child current focused view ");
                                stringBuilder2.append(stringBuilder.toString());
                                Log.e((String)TAG, (String)stringBuilder2.toString());
                                view = null;
                            }
                        }
                        View view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view, n);
                        if (view2 == null || view2 == view) break block13;
                        if (n == 17) {
                            int n2 = this.getChildRectInPagerCoordinates((Rect)this.mTempRect, (View)view2).left;
                            int n3 = this.getChildRectInPagerCoordinates((Rect)this.mTempRect, (View)view).left;
                            bl = view != null && n2 >= n3 ? this.pageLeft() : view2.requestFocus();
                        } else {
                            bl = false;
                            if (n == 66) {
                                int n4 = this.getChildRectInPagerCoordinates((Rect)this.mTempRect, (View)view2).left;
                                int n5 = this.getChildRectInPagerCoordinates((Rect)this.mTempRect, (View)view).left;
                                bl = view != null && n4 <= n5 ? this.pageRight() : view2.requestFocus();
                            }
                        }
                        break block14;
                    }
                    if (n == 17 || n == 1) break block15;
                    if (n == 66) break block16;
                    bl = false;
                    if (n != 2) break block14;
                }
                bl = this.pageRight();
                break block14;
            }
            bl = this.pageLeft();
        }
        if (bl) {
            this.playSoundEffect(SoundEffectConstants.getContantForFocusDirection((int)n));
        }
        return bl;
    }

    public boolean beginFakeDrag() {
        if (this.mIsBeingDragged) {
            return false;
        }
        this.mFakeDragging = true;
        this.setScrollState(1);
        this.mLastMotionX = 0.0f;
        this.mInitialMotionX = 0.0f;
        VelocityTracker velocityTracker = this.mVelocityTracker;
        if (velocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
        } else {
            velocityTracker.clear();
        }
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain((long)l, (long)l, (int)0, (float)0.0f, (float)0.0f, (int)0);
        this.mVelocityTracker.addMovement(motionEvent);
        motionEvent.recycle();
        this.mFakeDragBeginTime = l;
        return true;
    }

    protected boolean canScroll(View view, boolean bl, int n, int n2, int n3) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup)view;
            int n4 = view.getScrollX();
            int n5 = view.getScrollY();
            for (int i = -1 + viewGroup.getChildCount(); i >= 0; --i) {
                View view2 = viewGroup.getChildAt(i);
                if (n2 + n4 < view2.getLeft() || n2 + n4 >= view2.getRight() || n3 + n5 < view2.getTop() || n3 + n5 >= view2.getBottom() || !this.canScroll(view2, true, n, n2 + n4 - view2.getLeft(), n3 + n5 - view2.getTop())) continue;
                return true;
            }
        }
        return bl && ViewCompat.canScrollHorizontally((View)view, (int)(-n));
    }

    public boolean canScrollHorizontally(int n) {
        if (this.mAdapter == null) {
            return false;
        }
        int n2 = this.getClientWidth();
        int n3 = this.getScrollX();
        if (n < 0) {
            int n4 = (int)((float)n2 * this.mFirstOffset);
            boolean bl = false;
            if (n3 > n4) {
                bl = true;
            }
            return bl;
        }
        if (n > 0) {
            int n5 = (int)((float)n2 * this.mLastOffset);
            boolean bl = false;
            if (n3 < n5) {
                bl = true;
            }
            return bl;
        }
        return false;
    }

    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams && super.checkLayoutParams(layoutParams);
    }

    public void computeScroll() {
        if (!this.mScroller.isFinished() && this.mScroller.computeScrollOffset()) {
            int n = this.getScrollX();
            int n2 = this.getScrollY();
            int n3 = this.mScroller.getCurrX();
            int n4 = this.mScroller.getCurrY();
            if (n != n3 || n2 != n4) {
                this.scrollTo(n3, n4);
                if (!this.pageScrolled(n3)) {
                    this.mScroller.abortAnimation();
                    this.scrollTo(0, n4);
                }
            }
            ViewCompat.postInvalidateOnAnimation((View)this);
            return;
        }
        this.completeScroll(true);
    }

    void dataSetChanged() {
        int n;
        this.mExpectedAdapterCount = n = this.mAdapter.getCount();
        boolean bl = this.mItems.size() < 1 + 2 * this.mOffscreenPageLimit && this.mItems.size() < n;
        int n2 = this.mCurItem;
        boolean bl2 = false;
        for (int i = 0; i < this.mItems.size(); ++i) {
            ItemInfo itemInfo = (ItemInfo)this.mItems.get(i);
            int n3 = this.mAdapter.getItemPosition(itemInfo.object);
            if (n3 == -1) continue;
            if (n3 == -2) {
                this.mItems.remove(i);
                --i;
                if (!bl2) {
                    this.mAdapter.startUpdate((ViewGroup)this);
                    bl2 = true;
                }
                this.mAdapter.destroyItem((ViewGroup)this, itemInfo.position, itemInfo.object);
                bl = true;
                if (this.mCurItem != itemInfo.position) continue;
                n2 = Math.max((int)0, (int)Math.min((int)this.mCurItem, (int)(n - 1)));
                bl = true;
                continue;
            }
            if (itemInfo.position == n3) continue;
            if (itemInfo.position == this.mCurItem) {
                n2 = n3;
            }
            itemInfo.position = n3;
            bl = true;
        }
        if (bl2) {
            this.mAdapter.finishUpdate((ViewGroup)this);
        }
        Collections.sort(this.mItems, COMPARATOR);
        if (bl) {
            int n4 = this.getChildCount();
            for (int i = 0; i < n4; ++i) {
                LayoutParams layoutParams = (LayoutParams)this.getChildAt(i).getLayoutParams();
                if (layoutParams.isDecor) continue;
                layoutParams.widthFactor = 0.0f;
            }
            this.setCurrentItemInternal(n2, false, true);
            this.requestLayout();
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || this.executeKeyEvent(keyEvent);
        {
        }
    }

    @SuppressLint(value={"WrongConstant"})
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int n = this.getChildCount();
        for (int i = 0; i < n; ++i) {
            ItemInfo itemInfo;
            View view = this.getChildAt(i);
            if (view.getVisibility() != 0 || (itemInfo = this.infoForChild(view)) == null || itemInfo.position != this.mCurItem || !view.dispatchPopulateAccessibilityEvent(accessibilityEvent)) continue;
            return true;
        }
        return false;
    }

    float distanceInfluenceForSnapDuration(float f) {
        return (float)Math.sin((double)((float)(0.4712389167638204 * (double)(f - 0.5f))));
    }

    public void draw(Canvas canvas) {
        PagerAdapter pagerAdapter;
        boolean bl;
        super.draw(canvas);
        int n = ViewCompat.getOverScrollMode((View)this);
        if (n != 0 && (n != 1 || (pagerAdapter = this.mAdapter) == null || pagerAdapter.getCount() <= 1)) {
            this.mLeftEdge.finish();
            this.mRightEdge.finish();
            bl = false;
        } else {
            boolean bl2 = this.mLeftEdge.isFinished();
            bl = false;
            if (!bl2) {
                int n2 = canvas.save();
                int n3 = this.getHeight() - this.getPaddingTop() - this.getPaddingBottom();
                int n4 = this.getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float)(-n3 + this.getPaddingTop()), this.mFirstOffset * (float)n4);
                this.mLeftEdge.setSize(n3, n4);
                bl = false | this.mLeftEdge.draw(canvas);
                canvas.restoreToCount(n2);
            }
            if (!this.mRightEdge.isFinished()) {
                int n5 = canvas.save();
                int n6 = this.getWidth();
                int n7 = this.getHeight() - this.getPaddingTop() - this.getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float)(-this.getPaddingTop()), -(1.0f + this.mLastOffset) * (float)n6);
                this.mRightEdge.setSize(n7, n6);
                bl |= this.mRightEdge.draw(canvas);
                canvas.restoreToCount(n5);
            }
        }
        if (bl) {
            ViewCompat.postInvalidateOnAnimation((View)this);
        }
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable2 = this.mMarginDrawable;
        if (drawable2 != null && drawable2.isStateful()) {
            drawable2.setState(this.getDrawableState());
        }
    }

    public void endFakeDrag() {
        if (this.mFakeDragging) {
            VelocityTracker velocityTracker = this.mVelocityTracker;
            velocityTracker.computeCurrentVelocity(1000, (float)this.mMaximumVelocity);
            int n = (int)VelocityTrackerCompat.getXVelocity((VelocityTracker)velocityTracker, (int)this.mActivePointerId);
            this.mPopulatePending = true;
            int n2 = this.getClientWidth();
            int n3 = this.getScrollX();
            ItemInfo itemInfo = this.infoForCurrentScrollPosition();
            this.setCurrentItemInternal(this.determineTargetPage(itemInfo.position, ((float)n3 / (float)n2 - itemInfo.offset) / itemInfo.widthFactor, n, (int)(this.mLastMotionX - this.mInitialMotionX)), true, true, n);
            this.endDrag();
            this.mFakeDragging = false;
            return;
        }
        throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
    }

    public boolean executeKeyEvent(KeyEvent keyEvent) {
        int n = keyEvent.getAction();
        boolean bl = false;
        if (n == 0) {
            int n2 = keyEvent.getKeyCode();
            if (n2 != 21) {
                if (n2 != 22) {
                    if (n2 != 61) {
                        return false;
                    }
                    return false;
                }
                return this.arrowScroll(66);
            }
            bl = this.arrowScroll(17);
        }
        return bl;
    }

    public void fakeDragBy(float f) {
        if (this.mFakeDragging) {
            this.mLastMotionX = f + this.mLastMotionX;
            float f2 = (float)this.getScrollX() - f;
            int n = this.getClientWidth();
            float f3 = (float)n * this.mFirstOffset;
            float f4 = (float)n * this.mLastOffset;
            ItemInfo itemInfo = (ItemInfo)this.mItems.get(0);
            ArrayList<ItemInfo> arrayList = this.mItems;
            ItemInfo itemInfo2 = (ItemInfo)arrayList.get(-1 + arrayList.size());
            if (itemInfo.position != 0) {
                f3 = itemInfo.offset * (float)n;
            }
            if (itemInfo2.position != -1 + this.mAdapter.getCount()) {
                f4 = itemInfo2.offset * (float)n;
            }
            if (f2 < f3) {
                f2 = f3;
            } else if (f2 > f4) {
                f2 = f4;
            }
            this.mLastMotionX += f2 - (float)((int)f2);
            this.scrollTo((int)f2, this.getScrollY());
            this.pageScrolled((int)f2);
            long l = SystemClock.uptimeMillis();
            MotionEvent motionEvent = MotionEvent.obtain((long)this.mFakeDragBeginTime, (long)l, (int)2, (float)this.mLastMotionX, (float)0.0f, (int)0);
            this.mVelocityTracker.addMovement(motionEvent);
            motionEvent.recycle();
            return;
        }
        throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
    }

    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams();
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(this.getContext(), attributeSet);
    }

    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return this.generateDefaultLayoutParams();
    }

    public PagerAdapter getAdapter() {
        return this.mAdapter;
    }

    protected int getChildDrawingOrder(int n, int n2) {
        int n3 = this.mDrawingOrder == 2 ? n - 1 - n2 : n2;
        return ((LayoutParams)((View)this.mDrawingOrderedChildren.get((int)n3)).getLayoutParams()).childIndex;
    }

    public int getCurrentItem() {
        return this.mCurItem;
    }

    public int getOffscreenPageLimit() {
        return this.mOffscreenPageLimit;
    }

    public int getPageMargin() {
        return this.mPageMargin;
    }

    ItemInfo infoForAnyChild(View view) {
        ViewParent viewParent;
        while ((viewParent = view.getParent()) != this) {
            if (viewParent != null && viewParent instanceof View) {
                view = (View)viewParent;
                continue;
            }
            return null;
        }
        return this.infoForChild(view);
    }

    ItemInfo infoForChild(View view) {
        for (int i = 0; i < this.mItems.size(); ++i) {
            ItemInfo itemInfo = (ItemInfo)this.mItems.get(i);
            if (!this.mAdapter.isViewFromObject(view, itemInfo.object)) continue;
            return itemInfo;
        }
        return null;
    }

    ItemInfo infoForPosition(int n) {
        for (int i = 0; i < this.mItems.size(); ++i) {
            ItemInfo itemInfo = (ItemInfo)this.mItems.get(i);
            if (itemInfo.position != n) continue;
            return itemInfo;
        }
        return null;
    }

    void initViewPager() {
        this.setWillNotDraw(false);
        this.setDescendantFocusability(262144);
        this.setFocusable(true);
        Context context = this.getContext();
        this.mScroller = new Scroller(context, sInterpolator);
        ViewConfiguration viewConfiguration = ViewConfiguration.get((Context)context);
        float f = context.getResources().getDisplayMetrics().density;
        this.mTouchSlop = ViewConfigurationCompat.getScaledPagingTouchSlop((ViewConfiguration)viewConfiguration);
        this.mMinimumVelocity = (int)(400.0f * f);
        this.mMaximumVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
        this.mLeftEdge = new EdgeEffectCompat(context);
        this.mRightEdge = new EdgeEffectCompat(context);
        this.mFlingDistance = (int)(25.0f * f);
        this.mCloseEnough = (int)(2.0f * f);
        this.mDefaultGutterSize = (int)(16.0f * f);
        ViewCompat.setAccessibilityDelegate((View)this, (AccessibilityDelegateCompat)new MyAccessibilityDelegate());
        if (ViewCompat.getImportantForAccessibility((View)this) == 0) {
            ViewCompat.setImportantForAccessibility((View)this, (int)1);
        }
    }

    public boolean isFakeDragging() {
        return this.mFakeDragging;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mFirstLayout = true;
    }

    protected void onDetachedFromWindow() {
        this.removeCallbacks(this.mEndScrollRunnable);
        super.onDetachedFromWindow();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.mPageMargin > 0 && this.mMarginDrawable != null && this.mItems.size() > 0 && this.mAdapter != null) {
            int n = this.getScrollX();
            int n2 = this.getWidth();
            float f = (float)this.mPageMargin / (float)n2;
            int n3 = 0;
            ItemInfo itemInfo = (ItemInfo)this.mItems.get(0);
            float f2 = itemInfo.offset;
            int n4 = this.mItems.size();
            int n5 = itemInfo.position;
            int n6 = ((ItemInfo)this.mItems.get((int)(n4 - 1))).position;
            for (int i = n5; i < n6; ++i) {
                float f3;
                float f4;
                while (i > itemInfo.position && n3 < n4) {
                    ArrayList<ItemInfo> arrayList = this.mItems;
                    itemInfo = (ItemInfo)arrayList.get(++n3);
                }
                if (i == itemInfo.position) {
                    f4 = (itemInfo.offset + itemInfo.widthFactor) * (float)n2;
                    f2 = f + (itemInfo.offset + itemInfo.widthFactor);
                } else {
                    float f5 = this.mAdapter.getPageWidth(i);
                    float f6 = (f2 + f5) * (float)n2;
                    f2 += f5 + f;
                    f4 = f6;
                }
                int n7 = this.mPageMargin;
                if (f4 + (float)n7 > (float)n) {
                    Drawable drawable2 = this.mMarginDrawable;
                    int n8 = (int)f4;
                    int n9 = this.mTopPageBounds;
                    int n10 = (int)(0.5f + (f4 + (float)n7));
                    f3 = f;
                    drawable2.setBounds(n8, n9, n10, this.mBottomPageBounds);
                    this.mMarginDrawable.draw(canvas);
                } else {
                    f3 = f;
                }
                if (f4 > (float)(n + n2)) {
                    return;
                }
                f = f3;
            }
            return;
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int n = 255 & motionEvent.getAction();
        if (n != 3 && n != 1) {
            if (n != 0) {
                if (this.mIsBeingDragged) {
                    return true;
                }
                if (this.mIsUnableToDrag) {
                    return false;
                }
            }
            if (n != 0) {
                if (n != 2) {
                    if (n == 6) {
                        this.onSecondaryPointerUp(motionEvent);
                    }
                } else {
                    int n2 = this.mActivePointerId;
                    if (n2 != -1) {
                        int n3;
                        float f;
                        int n4 = MotionEventCompat.findPointerIndex((MotionEvent)motionEvent, (int)n2);
                        float f2 = MotionEventCompat.getX((MotionEvent)motionEvent, (int)n4);
                        float f3 = f2 - this.mLastMotionX;
                        float f4 = Math.abs((float)f3);
                        float f5 = MotionEventCompat.getY((MotionEvent)motionEvent, (int)n4);
                        float f6 = Math.abs((float)(f5 - this.mInitialMotionY));
                        if (f3 != 0.0f && !this.isGutterDrag(this.mLastMotionX, f3)) {
                            int n5 = (int)f3;
                            int n6 = (int)f2;
                            int n7 = (int)f5;
                            f = f5;
                            if (this.canScroll((View)this, false, n5, n6, n7)) {
                                this.mLastMotionX = f2;
                                this.mLastMotionY = f;
                                this.mIsUnableToDrag = true;
                                return false;
                            }
                        } else {
                            f = f5;
                        }
                        if (f4 > (float)(n3 = this.mTouchSlop) && 0.5f * f4 > f6) {
                            this.mIsBeingDragged = true;
                            this.requestParentDisallowInterceptTouchEvent(true);
                            this.setScrollState(1);
                            float f7 = f3 > 0.0f ? this.mInitialMotionX + (float)this.mTouchSlop : this.mInitialMotionX - (float)this.mTouchSlop;
                            this.mLastMotionX = f7;
                            this.mLastMotionY = f;
                            this.setScrollingCacheEnabled(true);
                        } else if (f6 > (float)n3) {
                            this.mIsUnableToDrag = true;
                        }
                        if (this.mIsBeingDragged && this.performDrag(f2)) {
                            ViewCompat.postInvalidateOnAnimation((View)this);
                        }
                    }
                }
            } else {
                float f;
                float f8;
                this.mInitialMotionX = f = motionEvent.getX();
                this.mLastMotionX = f;
                this.mInitialMotionY = f8 = motionEvent.getY();
                this.mLastMotionY = f8;
                this.mActivePointerId = MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)0);
                this.mIsUnableToDrag = false;
                this.mScroller.computeScrollOffset();
                if (this.mScrollState == 2 && Math.abs((int)(this.mScroller.getFinalX() - this.mScroller.getCurrX())) > this.mCloseEnough) {
                    this.mScroller.abortAnimation();
                    this.mPopulatePending = false;
                    this.populate();
                    this.mIsBeingDragged = true;
                    this.requestParentDisallowInterceptTouchEvent(true);
                    this.setScrollState(1);
                } else {
                    this.completeScroll(false);
                    this.mIsBeingDragged = false;
                }
            }
            if (this.mVelocityTracker == null) {
                this.mVelocityTracker = VelocityTracker.obtain();
            }
            this.mVelocityTracker.addMovement(motionEvent);
            return this.mIsBeingDragged;
        }
        this.mIsBeingDragged = false;
        this.mIsUnableToDrag = false;
        this.mActivePointerId = -1;
        VelocityTracker velocityTracker = this.mVelocityTracker;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.mVelocityTracker = null;
        }
        return false;
    }

    protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
        int n5;
        int n6 = this.getChildCount();
        int n7 = n3 - n;
        int n8 = n4 - n2;
        int n9 = this.getPaddingLeft();
        int n10 = this.getPaddingTop();
        int n11 = this.getPaddingRight();
        int n12 = this.getPaddingBottom();
        int n13 = this.getScrollX();
        int n14 = 0;
        int n15 = 0;
        do {
            n5 = 8;
            if (n15 >= n6) break;
            View view = this.getChildAt(n15);
            if (view.getVisibility() != n5) {
                LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
                if (layoutParams.isDecor) {
                    int n16;
                    int n17;
                    int n18 = 7 & layoutParams.gravity;
                    int n19 = 112 & layoutParams.gravity;
                    if (n18 != 1) {
                        if (n18 != 3) {
                            if (n18 != 5) {
                                n17 = n9;
                            } else {
                                n17 = n7 - n11 - view.getMeasuredWidth();
                                n11 += view.getMeasuredWidth();
                            }
                        } else {
                            n17 = n9;
                            n9 += view.getMeasuredWidth();
                        }
                    } else {
                        n17 = Math.max((int)((n7 - view.getMeasuredWidth()) / 2), (int)n9);
                    }
                    int n20 = n9;
                    if (n19 != 16) {
                        if (n19 != 48) {
                            if (n19 != 80) {
                                n16 = n10;
                            } else {
                                n16 = n8 - n12 - view.getMeasuredHeight();
                                n12 += view.getMeasuredHeight();
                            }
                        } else {
                            n16 = n10;
                            n10 += view.getMeasuredHeight();
                        }
                    } else {
                        n16 = Math.max((int)((n8 - view.getMeasuredHeight()) / 2), (int)n10);
                    }
                    int n21 = n17 + n13;
                    int n22 = n21 + view.getMeasuredWidth();
                    int n23 = view.getMeasuredHeight();
                    int n24 = n10;
                    view.layout(n21, n16, n22, n16 + n23);
                    ++n14;
                    n9 = n20;
                    n10 = n24;
                }
            }
            ++n15;
        } while (true);
        int n25 = n7 - n9 - n11;
        for (int i = 0; i < n6; ++i) {
            int n26;
            int n27;
            int n28;
            View view = this.getChildAt(i);
            if (view.getVisibility() != n5) {
                LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
                if (!layoutParams.isDecor) {
                    ItemInfo itemInfo = this.infoForChild(view);
                    if (itemInfo != null) {
                        float f = n25;
                        n28 = n6;
                        int n29 = n9 + (int)(f * itemInfo.offset);
                        int n30 = n10;
                        if (layoutParams.needsMeasure) {
                            layoutParams.needsMeasure = false;
                            float f2 = n25;
                            n26 = n7;
                            int n31 = View.MeasureSpec.makeMeasureSpec((int)((int)(f2 * layoutParams.widthFactor)), (int)1073741824);
                            int n32 = n8 - n10;
                            n27 = n9;
                            view.measure(n31, View.MeasureSpec.makeMeasureSpec((int)(n32 - n12), (int)1073741824));
                        } else {
                            n26 = n7;
                            n27 = n9;
                        }
                        view.layout(n29, n30, n29 + view.getMeasuredWidth(), n30 + view.getMeasuredHeight());
                    } else {
                        n26 = n7;
                        n27 = n9;
                        n28 = n6;
                    }
                } else {
                    n28 = n6;
                    n26 = n7;
                    n27 = n9;
                }
            } else {
                n28 = n6;
                n26 = n7;
                n27 = n9;
            }
            n6 = n28;
            n7 = n26;
            n9 = n27;
            n5 = 8;
        }
        this.mTopPageBounds = n10;
        this.mBottomPageBounds = n8 - n12;
        this.mDecorChildCount = n14;
        if (this.mFirstLayout) {
            this.scrollToItem(this.mCurItem, false, 0, false);
        }
        this.mFirstLayout = false;
    }

    protected void onMeasure(int n, int n2) {
        this.setMeasuredDimension(ViewPagerEx.getDefaultSize((int)0, (int)n), ViewPagerEx.getDefaultSize((int)0, (int)n2));
        int n3 = this.getMeasuredWidth();
        int n4 = n3 / 10;
        this.mGutterSize = Math.min((int)n4, (int)this.mDefaultGutterSize);
        int n5 = n3 - this.getPaddingLeft() - this.getPaddingRight();
        int n6 = this.getMeasuredHeight() - this.getPaddingTop() - this.getPaddingBottom();
        int n7 = this.getChildCount();
        for (int i = 0; i < n7; ++i) {
            int n8;
            int n9;
            View view = this.getChildAt(i);
            if (view.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
                if (layoutParams != null && layoutParams.isDecor) {
                    int n10;
                    int n11;
                    int n12;
                    int n13 = 7 & layoutParams.gravity;
                    int n14 = 112 & layoutParams.gravity;
                    int n15 = Integer.MIN_VALUE;
                    int n16 = Integer.MIN_VALUE;
                    boolean bl = n14 == 48 || n14 == 80;
                    boolean bl2 = n13 == 3 || n13 == 5;
                    if (bl) {
                        n15 = 1073741824;
                    } else if (bl2) {
                        n16 = 1073741824;
                    }
                    int n17 = n5;
                    int n18 = n6;
                    int n19 = layoutParams.width;
                    n8 = n3;
                    if (n19 != -2) {
                        n15 = 1073741824;
                        n10 = layoutParams.width != -1 ? layoutParams.width : n17;
                    } else {
                        n10 = n17;
                    }
                    if (layoutParams.height != -2) {
                        if (layoutParams.height != -1) {
                            n11 = layoutParams.height;
                            n12 = 1073741824;
                        } else {
                            n12 = 1073741824;
                            n11 = n18;
                        }
                    } else {
                        n12 = n16;
                        n11 = n18;
                    }
                    n9 = n4;
                    int n20 = View.MeasureSpec.makeMeasureSpec((int)n10, (int)n15);
                    view.measure(n20, View.MeasureSpec.makeMeasureSpec((int)n11, (int)n12));
                    if (bl) {
                        n6 -= view.getMeasuredHeight();
                    } else if (bl2) {
                        n5 -= view.getMeasuredWidth();
                    }
                } else {
                    n8 = n3;
                    n9 = n4;
                }
            } else {
                n8 = n3;
                n9 = n4;
            }
            n4 = n9;
            n3 = n8;
        }
        this.mChildWidthMeasureSpec = View.MeasureSpec.makeMeasureSpec((int)n5, (int)1073741824);
        this.mChildHeightMeasureSpec = View.MeasureSpec.makeMeasureSpec((int)n6, (int)1073741824);
        this.mInLayout = true;
        this.populate();
        this.mInLayout = false;
        int n21 = this.getChildCount();
        for (int i = 0; i < n21; ++i) {
            LayoutParams layoutParams;
            View view = this.getChildAt(i);
            if (view.getVisibility() == 8 || (layoutParams = (LayoutParams)view.getLayoutParams()) != null && layoutParams.isDecor) continue;
            view.measure(View.MeasureSpec.makeMeasureSpec((int)((int)((float)n5 * layoutParams.widthFactor)), (int)1073741824), this.mChildHeightMeasureSpec);
        }
    }

    protected void onPageScrolled(int n, float f, int n2) {
        if (this.mDecorChildCount > 0) {
            int n3 = this.getScrollX();
            int n4 = this.getPaddingLeft();
            int n5 = this.getPaddingRight();
            int n6 = this.getWidth();
            int n7 = this.getChildCount();
            for (int i = 0; i < n7; ++i) {
                int n8;
                View view = this.getChildAt(i);
                LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
                if (!layoutParams.isDecor) continue;
                int n9 = 7 & layoutParams.gravity;
                if (n9 != 1) {
                    if (n9 != 3) {
                        if (n9 != 5) {
                            n8 = n4;
                        } else {
                            n8 = n6 - n5 - view.getMeasuredWidth();
                            n5 += view.getMeasuredWidth();
                        }
                    } else {
                        n8 = n4;
                        n4 += view.getWidth();
                    }
                } else {
                    n8 = Math.max((int)((n6 - view.getMeasuredWidth()) / 2), (int)n4);
                }
                int n10 = n8 + n3 - view.getLeft();
                if (n10 == 0) continue;
                view.offsetLeftAndRight(n10);
            }
        }
        for (OnPageChangeListener onPageChangeListener : this.mOnPageChangeListeners) {
            if (onPageChangeListener == null) continue;
            onPageChangeListener.onPageScrolled(n, f, n2);
        }
        OnPageChangeListener onPageChangeListener = this.mInternalPageChangeListener;
        if (onPageChangeListener != null) {
            onPageChangeListener.onPageScrolled(n, f, n2);
        }
        if (this.mPageTransformer != null) {
            int n11 = this.getScrollX();
            int n12 = this.getChildCount();
            for (int i = 0; i < n12; ++i) {
                View view = this.getChildAt(i);
                if (((LayoutParams)view.getLayoutParams()).isDecor) continue;
                float f2 = (float)(view.getLeft() - n11) / (float)this.getClientWidth();
                this.mPageTransformer.transformPage(view, f2);
            }
        }
        this.mCalledSuper = true;
    }

    protected boolean onRequestFocusInDescendants(int n, Rect rect) {
        int n2;
        int n3;
        int n4;
        int n5 = this.getChildCount();
        if ((n & 2) != 0) {
            n3 = 1;
            n4 = n5;
            n2 = 0;
        } else {
            n2 = n5 - 1;
            n3 = -1;
            n4 = -1;
        }
        for (int i = n2; i != n4; i += n3) {
            ItemInfo itemInfo;
            View view = this.getChildAt(i);
            if (view.getVisibility() != 0 || (itemInfo = this.infoForChild(view)) == null || itemInfo.position != this.mCurItem || !view.requestFocus(n, rect)) continue;
            return true;
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState)parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        PagerAdapter pagerAdapter = this.mAdapter;
        if (pagerAdapter != null) {
            pagerAdapter.restoreState(savedState.adapterState, savedState.loader);
            this.setCurrentItemInternal(savedState.position, false, true);
            return;
        }
        this.mRestoredCurItem = savedState.position;
        this.mRestoredAdapterState = savedState.adapterState;
        this.mRestoredClassLoader = savedState.loader;
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.position = this.mCurItem;
        PagerAdapter pagerAdapter = this.mAdapter;
        if (pagerAdapter != null) {
            savedState.adapterState = pagerAdapter.saveState();
        }
        return savedState;
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        super.onSizeChanged(n, n2, n3, n4);
        if (n != n3) {
            int n5 = this.mPageMargin;
            this.recomputeScrollPosition(n, n3, n5, n5);
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.mFakeDragging) {
            return true;
        }
        if (motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) {
            return false;
        }
        PagerAdapter pagerAdapter = this.mAdapter;
        if (pagerAdapter != null) {
            if (pagerAdapter.getCount() == 0) {
                return false;
            }
            if (this.mVelocityTracker == null) {
                this.mVelocityTracker = VelocityTracker.obtain();
            }
            this.mVelocityTracker.addMovement(motionEvent);
            int n = motionEvent.getAction();
            boolean bl = false;
            int n2 = n & 255;
            if (n2 != 0) {
                if (n2 != 1) {
                    if (n2 != 2) {
                        if (n2 != 3) {
                            if (n2 != 5) {
                                if (n2 != 6) {
                                    bl = false;
                                } else {
                                    this.onSecondaryPointerUp(motionEvent);
                                    this.mLastMotionX = MotionEventCompat.getX((MotionEvent)motionEvent, (int)MotionEventCompat.findPointerIndex((MotionEvent)motionEvent, (int)this.mActivePointerId));
                                    bl = false;
                                }
                            } else {
                                int n3 = MotionEventCompat.getActionIndex((MotionEvent)motionEvent);
                                this.mLastMotionX = MotionEventCompat.getX((MotionEvent)motionEvent, (int)n3);
                                this.mActivePointerId = MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)n3);
                                bl = false;
                            }
                        } else if (this.mIsBeingDragged) {
                            this.scrollToItem(this.mCurItem, true, 0, false);
                            this.mActivePointerId = -1;
                            this.endDrag();
                            bl = this.mLeftEdge.onRelease() | this.mRightEdge.onRelease();
                        } else {
                            bl = false;
                        }
                    } else {
                        if (!this.mIsBeingDragged) {
                            int n4 = MotionEventCompat.findPointerIndex((MotionEvent)motionEvent, (int)this.mActivePointerId);
                            float f = MotionEventCompat.getX((MotionEvent)motionEvent, (int)n4);
                            float f2 = Math.abs((float)(f - this.mLastMotionX));
                            float f3 = MotionEventCompat.getY((MotionEvent)motionEvent, (int)n4);
                            float f4 = Math.abs((float)(f3 - this.mLastMotionY));
                            if (f2 > (float)this.mTouchSlop && f2 > f4) {
                                this.mIsBeingDragged = true;
                                this.requestParentDisallowInterceptTouchEvent(true);
                                float f5 = this.mInitialMotionX;
                                float f6 = f - f5 > 0.0f ? f5 + (float)this.mTouchSlop : f5 - (float)this.mTouchSlop;
                                this.mLastMotionX = f6;
                                this.mLastMotionY = f3;
                                this.setScrollState(1);
                                this.setScrollingCacheEnabled(true);
                                ViewParent viewParent = this.getParent();
                                if (viewParent != null) {
                                    viewParent.requestDisallowInterceptTouchEvent(true);
                                }
                            }
                        }
                        bl = this.mIsBeingDragged ? false | this.performDrag(MotionEventCompat.getX((MotionEvent)motionEvent, (int)MotionEventCompat.findPointerIndex((MotionEvent)motionEvent, (int)this.mActivePointerId))) : false;
                    }
                } else if (this.mIsBeingDragged) {
                    VelocityTracker velocityTracker = this.mVelocityTracker;
                    velocityTracker.computeCurrentVelocity(1000, (float)this.mMaximumVelocity);
                    int n5 = (int)VelocityTrackerCompat.getXVelocity((VelocityTracker)velocityTracker, (int)this.mActivePointerId);
                    this.mPopulatePending = true;
                    int n6 = this.getClientWidth();
                    int n7 = this.getScrollX();
                    ItemInfo itemInfo = this.infoForCurrentScrollPosition();
                    this.setCurrentItemInternal(this.determineTargetPage(itemInfo.position, ((float)n7 / (float)n6 - itemInfo.offset) / itemInfo.widthFactor, n5, (int)(MotionEventCompat.getX((MotionEvent)motionEvent, (int)MotionEventCompat.findPointerIndex((MotionEvent)motionEvent, (int)this.mActivePointerId)) - this.mInitialMotionX)), true, true, n5);
                    this.mActivePointerId = -1;
                    this.endDrag();
                    bl = this.mLeftEdge.onRelease() | this.mRightEdge.onRelease();
                } else {
                    bl = false;
                }
            } else {
                float f;
                float f7;
                this.mScroller.abortAnimation();
                this.mPopulatePending = false;
                this.populate();
                this.mInitialMotionX = f7 = motionEvent.getX();
                this.mLastMotionX = f7;
                this.mInitialMotionY = f = motionEvent.getY();
                this.mLastMotionY = f;
                this.mActivePointerId = MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)0);
            }
            if (bl) {
                ViewCompat.postInvalidateOnAnimation((View)this);
            }
            return true;
        }
        return false;
    }

    boolean pageLeft() {
        int n = this.mCurItem;
        if (n > 0) {
            this.setCurrentItem(n - 1, true);
            return true;
        }
        return false;
    }

    boolean pageRight() {
        PagerAdapter pagerAdapter = this.mAdapter;
        if (pagerAdapter != null && this.mCurItem < pagerAdapter.getCount() - 1) {
            this.setCurrentItem(1 + this.mCurItem, true);
            return true;
        }
        return false;
    }

    void populate() {
        this.populate(this.mCurItem);
    }

    void populate(int n) {
        int n2;
        ItemInfo itemInfo;
        String string2;
        int n3 = this.mCurItem;
        if (n3 != n) {
            int n4 = n3 < n ? 66 : 17;
            int n5 = n4;
            ItemInfo itemInfo2 = this.infoForPosition(n3);
            this.mCurItem = n;
            n2 = n5;
            itemInfo = itemInfo2;
        } else {
            n2 = 2;
            itemInfo = null;
        }
        if (this.mAdapter == null) {
            this.sortChildDrawingOrder();
            return;
        }
        if (this.mPopulatePending) {
            this.sortChildDrawingOrder();
            return;
        }
        if (this.getWindowToken() == null) {
            return;
        }
        this.mAdapter.startUpdate((ViewGroup)this);
        int n6 = this.mOffscreenPageLimit;
        int n7 = Math.max((int)0, (int)(this.mCurItem - n6));
        int n8 = this.mAdapter.getCount();
        int n9 = Math.min((int)(n8 - 1), (int)(n6 + this.mCurItem));
        if (n8 == this.mExpectedAdapterCount) {
            ItemInfo itemInfo3;
            ItemInfo itemInfo4;
            ItemInfo itemInfo5;
            View view;
            int n10 = 0;
            do {
                int n11 = this.mItems.size();
                itemInfo4 = null;
                if (n10 >= n11) break;
                ItemInfo itemInfo6 = (ItemInfo)this.mItems.get(n10);
                if (itemInfo6.position >= this.mCurItem) {
                    int n12 = itemInfo6.position;
                    int n13 = this.mCurItem;
                    itemInfo4 = null;
                    if (n12 != n13) break;
                    itemInfo4 = itemInfo6;
                    break;
                }
                ++n10;
            } while (true);
            if (itemInfo4 == null && n8 > 0) {
                itemInfo4 = this.addNewItem(this.mCurItem, n10);
            }
            if (itemInfo4 != null) {
                int n14;
                float f;
                float f2 = 0.0f;
                int n15 = n10 - 1;
                ItemInfo itemInfo7 = n15 >= 0 ? (ItemInfo)this.mItems.get(n15) : null;
                int n16 = this.getClientWidth();
                if (n16 <= 0) {
                    n14 = n10;
                    f = 0.0f;
                } else {
                    float f3 = 2.0f - itemInfo4.widthFactor;
                    float f4 = this.getPaddingLeft();
                    n14 = n10;
                    f = f3 + f4 / (float)n16;
                }
                float f5 = f;
                int n17 = n14;
                for (int i = -1 + this.mCurItem; i >= 0; --i) {
                    float f6;
                    if (f2 >= f5 && i < n7) {
                        if (itemInfo7 == null) break;
                        f6 = f5;
                        if (i == itemInfo7.position && !itemInfo7.scrolling) {
                            this.mItems.remove(n15);
                            this.mAdapter.destroyItem((ViewGroup)this, i, itemInfo7.object);
                            --n17;
                            ItemInfo itemInfo8 = --n15 >= 0 ? (ItemInfo)this.mItems.get(n15) : null;
                            itemInfo7 = itemInfo8;
                        }
                    } else {
                        f6 = f5;
                        if (itemInfo7 != null && i == itemInfo7.position) {
                            f2 += itemInfo7.widthFactor;
                            ItemInfo itemInfo9 = --n15 >= 0 ? (ItemInfo)this.mItems.get(n15) : null;
                            itemInfo7 = itemInfo9;
                        } else {
                            f2 += this.addNewItem((int)i, (int)(n15 + 1)).widthFactor;
                            ++n17;
                            ItemInfo itemInfo10 = n15 >= 0 ? (ItemInfo)this.mItems.get(n15) : null;
                            itemInfo7 = itemInfo10;
                        }
                    }
                    f5 = f6;
                }
                float f7 = itemInfo4.widthFactor;
                int n18 = n17 + 1;
                if (f7 < 2.0f) {
                    ItemInfo itemInfo11 = n18 < this.mItems.size() ? (ItemInfo)this.mItems.get(n18) : null;
                    float f8 = n16 <= 0 ? 0.0f : 2.0f + (float)this.getPaddingRight() / (float)n16;
                    for (int i = 1 + this.mCurItem; i < n8; ++i) {
                        int n19;
                        int n20;
                        if (f7 >= f8 && i > n9) {
                            if (itemInfo11 == null) break;
                            n19 = n6;
                            if (i == itemInfo11.position && !itemInfo11.scrolling) {
                                this.mItems.remove(n18);
                                PagerAdapter pagerAdapter = this.mAdapter;
                                n20 = n7;
                                pagerAdapter.destroyItem((ViewGroup)this, i, itemInfo11.object);
                                ItemInfo itemInfo12 = n18 < this.mItems.size() ? (ItemInfo)this.mItems.get(n18) : null;
                                itemInfo11 = itemInfo12;
                            } else {
                                n20 = n7;
                            }
                        } else {
                            n19 = n6;
                            n20 = n7;
                            if (itemInfo11 != null && i == itemInfo11.position) {
                                f7 += itemInfo11.widthFactor;
                                ItemInfo itemInfo13 = ++n18 < this.mItems.size() ? (ItemInfo)this.mItems.get(n18) : null;
                                itemInfo11 = itemInfo13;
                            } else {
                                ItemInfo itemInfo14 = this.addNewItem(i, n18);
                                f7 += itemInfo14.widthFactor;
                                ItemInfo itemInfo15 = ++n18 < this.mItems.size() ? (ItemInfo)this.mItems.get(n18) : null;
                                itemInfo11 = itemInfo15;
                            }
                        }
                        n6 = n19;
                        n7 = n20;
                    }
                }
                this.calculatePageOffsets(itemInfo4, n17, itemInfo);
            }
            PagerAdapter pagerAdapter = this.mAdapter;
            int n21 = this.mCurItem;
            Object object = itemInfo4 != null ? itemInfo4.object : null;
            pagerAdapter.setPrimaryItem((ViewGroup)this, n21, object);
            this.mAdapter.finishUpdate((ViewGroup)this);
            int n22 = this.getChildCount();
            for (int i = 0; i < n22; ++i) {
                ItemInfo itemInfo16;
                View view2 = this.getChildAt(i);
                LayoutParams layoutParams = (LayoutParams)view2.getLayoutParams();
                layoutParams.childIndex = i;
                if (layoutParams.isDecor || layoutParams.widthFactor != 0.0f || (itemInfo16 = this.infoForChild(view2)) == null) continue;
                layoutParams.widthFactor = itemInfo16.widthFactor;
                layoutParams.position = itemInfo16.position;
            }
            this.sortChildDrawingOrder();
            if (this.hasFocus() && ((itemInfo3 = (itemInfo5 = (view = this.findFocus()) != null ? this.infoForAnyChild(view) : null)) == null || itemInfo3.position != this.mCurItem)) {
                for (int i = 0; i < this.getChildCount(); ++i) {
                    View view3 = this.getChildAt(i);
                    ItemInfo itemInfo17 = this.infoForChild(view3);
                    if (itemInfo17 == null || itemInfo17.position != this.mCurItem || !view3.requestFocus(n2)) continue;
                    return;
                }
            }
            return;
        }
        try {
            string2 = this.getResources().getResourceName(this.getId());
        }
        catch (Resources.NotFoundException notFoundException) {
            string2 = Integer.toHexString((int)this.getId());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: ");
        stringBuilder.append(this.mExpectedAdapterCount);
        stringBuilder.append(", found: ");
        stringBuilder.append(n8);
        stringBuilder.append(" Pager id: ");
        stringBuilder.append(string2);
        stringBuilder.append(" Pager class: ");
        stringBuilder.append((Object)this.getClass());
        stringBuilder.append(" Problematic adapter: ");
        stringBuilder.append((Object)this.mAdapter.getClass());
        throw new IllegalStateException(stringBuilder.toString());
    }

    public void removeOnPageChangeListener(OnPageChangeListener onPageChangeListener) {
        this.mOnPageChangeListeners.remove((Object)onPageChangeListener);
    }

    public void removeView(View view) {
        if (this.mInLayout) {
            this.removeViewInLayout(view);
            return;
        }
        super.removeView(view);
    }

    public void setAdapter(PagerAdapter pagerAdapter) {
        OnAdapterChangeListener onAdapterChangeListener;
        PagerAdapter pagerAdapter2 = this.mAdapter;
        if (pagerAdapter2 != null) {
            pagerAdapter2.unregisterDataSetObserver((DataSetObserver)this.mObserver);
            this.mAdapter.startUpdate((ViewGroup)this);
            for (int i = 0; i < this.mItems.size(); ++i) {
                ItemInfo itemInfo = (ItemInfo)this.mItems.get(i);
                this.mAdapter.destroyItem((ViewGroup)this, itemInfo.position, itemInfo.object);
            }
            this.mAdapter.finishUpdate((ViewGroup)this);
            this.mItems.clear();
            this.removeNonDecorViews();
            this.mCurItem = 0;
            this.scrollTo(0, 0);
        }
        PagerAdapter pagerAdapter3 = this.mAdapter;
        this.mAdapter = pagerAdapter;
        this.mExpectedAdapterCount = 0;
        if (pagerAdapter != null) {
            if (this.mObserver == null) {
                this.mObserver = new PagerObserver();
            }
            this.mAdapter.registerDataSetObserver((DataSetObserver)this.mObserver);
            this.mPopulatePending = false;
            boolean bl = this.mFirstLayout;
            this.mFirstLayout = true;
            this.mExpectedAdapterCount = this.mAdapter.getCount();
            if (this.mRestoredCurItem >= 0) {
                this.mAdapter.restoreState(this.mRestoredAdapterState, this.mRestoredClassLoader);
                this.setCurrentItemInternal(this.mRestoredCurItem, false, true);
                this.mRestoredCurItem = -1;
                this.mRestoredAdapterState = null;
                this.mRestoredClassLoader = null;
            } else if (!bl) {
                this.populate();
            } else {
                this.requestLayout();
            }
        }
        if ((onAdapterChangeListener = this.mAdapterChangeListener) != null && pagerAdapter3 != pagerAdapter) {
            onAdapterChangeListener.onAdapterChanged(pagerAdapter3, pagerAdapter);
        }
    }

    void setChildrenDrawingOrderEnabledCompat(boolean bl) {
        if (Build.VERSION.SDK_INT >= 7) {
            if (this.mSetChildrenDrawingOrderEnabled == null) {
                try {
                    Class[] arrclass = new Class[]{Boolean.TYPE};
                    this.mSetChildrenDrawingOrderEnabled = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", arrclass);
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    Log.e((String)TAG, (String)"Can't find setChildrenDrawingOrderEnabled", (Throwable)noSuchMethodException);
                }
            }
            try {
                Method method = this.mSetChildrenDrawingOrderEnabled;
                Object[] arrobject = new Object[]{bl};
                method.invoke((Object)this, arrobject);
                return;
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"Error changing children drawing order", (Throwable)exception);
            }
        }
    }

    public void setCurrentItem(int n) {
        this.mPopulatePending = false;
        this.setCurrentItemInternal(n, true ^ this.mFirstLayout, false);
    }

    public void setCurrentItem(int n, boolean bl) {
        this.mPopulatePending = false;
        this.setCurrentItemInternal(n, bl, false);
    }

    void setCurrentItemInternal(int n, boolean bl, boolean bl2) {
        this.setCurrentItemInternal(n, bl, bl2, 0);
    }

    void setCurrentItemInternal(int n, boolean bl, boolean bl2, int n2) {
        PagerAdapter pagerAdapter = this.mAdapter;
        if (pagerAdapter != null && pagerAdapter.getCount() > 0) {
            if (!bl2 && this.mCurItem == n && this.mItems.size() != 0) {
                this.setScrollingCacheEnabled(false);
                return;
            }
            if (n < 0) {
                n = 0;
            } else if (n >= this.mAdapter.getCount()) {
                n = -1 + this.mAdapter.getCount();
            }
            int n3 = this.mOffscreenPageLimit;
            int n4 = this.mCurItem;
            if (n > n4 + n3 || n < n4 - n3) {
                for (int i = 0; i < this.mItems.size(); ++i) {
                    ((ItemInfo)this.mItems.get((int)i)).scrolling = true;
                }
            }
            int n5 = this.mCurItem;
            boolean bl3 = false;
            if (n5 != n) {
                bl3 = true;
            }
            boolean bl4 = bl3;
            if (this.mFirstLayout) {
                this.mCurItem = n;
                this.triggerOnPageChangeEvent(n);
                this.requestLayout();
                return;
            }
            this.populate(n);
            this.scrollToItem(n, bl, n2, bl4);
            return;
        }
        this.setScrollingCacheEnabled(false);
    }

    OnPageChangeListener setInternalPageChangeListener(OnPageChangeListener onPageChangeListener) {
        OnPageChangeListener onPageChangeListener2 = this.mInternalPageChangeListener;
        this.mInternalPageChangeListener = onPageChangeListener;
        return onPageChangeListener2;
    }

    public void setOffscreenPageLimit(int n) {
        if (n < 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Requested offscreen page limit ");
            stringBuilder.append(n);
            stringBuilder.append(" too small; defaulting to ");
            stringBuilder.append(1);
            Log.w((String)TAG, (String)stringBuilder.toString());
            n = 1;
        }
        if (n != this.mOffscreenPageLimit) {
            this.mOffscreenPageLimit = n;
            this.populate();
        }
    }

    void setOnAdapterChangeListener(OnAdapterChangeListener onAdapterChangeListener) {
        this.mAdapterChangeListener = onAdapterChangeListener;
    }

    public void setPageMargin(int n) {
        int n2 = this.mPageMargin;
        this.mPageMargin = n;
        int n3 = this.getWidth();
        this.recomputeScrollPosition(n3, n3, n, n2);
        this.requestLayout();
    }

    public void setPageMarginDrawable(int n) {
        this.setPageMarginDrawable(this.getContext().getResources().getDrawable(n));
    }

    public void setPageMarginDrawable(Drawable drawable2) {
        this.mMarginDrawable = drawable2;
        if (drawable2 != null) {
            this.refreshDrawableState();
        }
        boolean bl = drawable2 == null;
        this.setWillNotDraw(bl);
        this.invalidate();
    }

    public void setPageTransformer(boolean bl, PageTransformer pageTransformer) {
        int n = 1;
        boolean bl2 = pageTransformer != null;
        boolean bl3 = this.mPageTransformer != null;
        boolean bl4 = bl2 != bl3;
        this.mPageTransformer = pageTransformer;
        this.setChildrenDrawingOrderEnabledCompat(bl2);
        if (bl2) {
            if (bl) {
                n = 2;
            }
            this.mDrawingOrder = n;
        } else {
            this.mDrawingOrder = 0;
        }
        if (bl4) {
            this.populate();
        }
    }

    void smoothScrollTo(int n, int n2) {
        this.smoothScrollTo(n, n2, 0);
    }

    void smoothScrollTo(int n, int n2, int n3) {
        int n4;
        if (this.getChildCount() == 0) {
            this.setScrollingCacheEnabled(false);
            return;
        }
        int n5 = this.getScrollX();
        int n6 = this.getScrollY();
        int n7 = n - n5;
        int n8 = n2 - n6;
        if (n7 == 0 && n8 == 0) {
            this.completeScroll(false);
            this.populate();
            this.setScrollState(0);
            return;
        }
        this.setScrollingCacheEnabled(true);
        this.setScrollState(2);
        int n9 = this.getClientWidth();
        int n10 = n9 / 2;
        float f = Math.min((float)1.0f, (float)(1.0f * (float)Math.abs((int)n7) / (float)n9));
        float f2 = (float)n10 + (float)n10 * this.distanceInfluenceForSnapDuration(f);
        int n11 = Math.abs((int)n3);
        if (n11 > 0) {
            n4 = 4 * Math.round((float)(1000.0f * Math.abs((float)(f2 / (float)n11))));
        } else {
            float f3 = (float)n9 * this.mAdapter.getPageWidth(this.mCurItem);
            n4 = (int)(100.0f * (1.0f + (float)Math.abs((int)n7) / (f3 + (float)this.mPageMargin)));
        }
        int n12 = Math.min((int)n4, (int)600);
        this.mScroller.startScroll(n5, n6, n7, n8, n12);
        ViewCompat.postInvalidateOnAnimation((View)this);
    }

    protected boolean verifyDrawable(Drawable drawable2) {
        return super.verifyDrawable(drawable2) || drawable2 == this.mMarginDrawable;
        {
        }
    }

    static interface Decor {
    }

    static class ItemInfo {
        Object object;
        float offset;
        int position;
        boolean scrolling;
        float widthFactor;

        ItemInfo() {
        }
    }

    public static class LayoutParams
    extends ViewGroup.LayoutParams {
        int childIndex;
        public int gravity;
        public boolean isDecor;
        boolean needsMeasure;
        int position;
        float widthFactor = 0.0f;

        public LayoutParams() {
            super(-1, -1);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray typedArray = context.obtainStyledAttributes(attributeSet, LAYOUT_ATTRS);
            this.gravity = typedArray.getInteger(0, 48);
            typedArray.recycle();
        }
    }

    class MyAccessibilityDelegate
    extends AccessibilityDelegateCompat {
        MyAccessibilityDelegate() {
        }

        private boolean canScroll() {
            return ViewPagerEx.this.mAdapter != null && ViewPagerEx.this.mAdapter.getCount() > 1;
        }

        @SuppressLint(value={"WrongConstant"})
        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setClassName((CharSequence)ViewPagerEx.class.getName());
            AccessibilityRecordCompat accessibilityRecordCompat = AccessibilityRecordCompat.obtain();
            accessibilityRecordCompat.setScrollable(this.canScroll());
            if (accessibilityEvent.getEventType() == 4096 && ViewPagerEx.this.mAdapter != null) {
                accessibilityRecordCompat.setItemCount(ViewPagerEx.this.mAdapter.getCount());
                accessibilityRecordCompat.setFromIndex(ViewPagerEx.this.mCurItem);
                accessibilityRecordCompat.setToIndex(ViewPagerEx.this.mCurItem);
            }
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfoCompat);
            accessibilityNodeInfoCompat.setClassName((CharSequence)ViewPagerEx.class.getName());
            accessibilityNodeInfoCompat.setScrollable(this.canScroll());
            if (ViewPagerEx.this.canScrollHorizontally(1)) {
                accessibilityNodeInfoCompat.addAction(4096);
            }
            if (ViewPagerEx.this.canScrollHorizontally(-1)) {
                accessibilityNodeInfoCompat.addAction(8192);
            }
        }

        public boolean performAccessibilityAction(View view, int n, Bundle bundle) {
            if (super.performAccessibilityAction(view, n, bundle)) {
                return true;
            }
            if (n != 4096) {
                if (n != 8192) {
                    return false;
                }
                if (ViewPagerEx.this.canScrollHorizontally(-1)) {
                    ViewPagerEx viewPagerEx = ViewPagerEx.this;
                    viewPagerEx.setCurrentItem(viewPagerEx.mCurItem - 1);
                    return true;
                }
                return false;
            }
            if (ViewPagerEx.this.canScrollHorizontally(1)) {
                ViewPagerEx viewPagerEx = ViewPagerEx.this;
                viewPagerEx.setCurrentItem(1 + viewPagerEx.mCurItem);
                return true;
            }
            return false;
        }
    }

    static interface OnAdapterChangeListener {
        public void onAdapterChanged(PagerAdapter var1, PagerAdapter var2);
    }

    public static interface OnPageChangeListener {
        public void onPageScrollStateChanged(int var1);

        public void onPageScrolled(int var1, float var2, int var3);

        public void onPageSelected(int var1);
    }

    public static interface PageTransformer {
        public void transformPage(View var1, float var2);
    }

    private class PagerObserver
    extends DataSetObserver {
        private PagerObserver() {
        }

        public void onChanged() {
            ViewPagerEx.this.dataSetChanged();
        }

        public void onInvalidated() {
            ViewPagerEx.this.dataSetChanged();
        }
    }

    public static class SavedState
    extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = ParcelableCompat.newCreator((ParcelableCompatCreatorCallbacks)new ParcelableCompatCreatorCallbacks<SavedState>(){

            public SavedState createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }

            public SavedState[] newArray(int n) {
                return new SavedState[n];
            }
        });
        Parcelable adapterState;
        ClassLoader loader;
        int position;

        SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel);
            if (classLoader == null) {
                classLoader = this.getClass().getClassLoader();
            }
            this.position = parcel.readInt();
            this.adapterState = parcel.readParcelable(classLoader);
            this.loader = classLoader;
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FragmentPager.SavedState{");
            stringBuilder.append(Integer.toHexString((int)System.identityHashCode((Object)((Object)this))));
            stringBuilder.append(" position=");
            stringBuilder.append(this.position);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }

        public void writeToParcel(Parcel parcel, int n) {
            super.writeToParcel(parcel, n);
            parcel.writeInt(this.position);
            parcel.writeParcelable(this.adapterState, n);
        }

    }

    public static class SimpleOnPageChangeListener
    implements OnPageChangeListener {
        @Override
        public void onPageScrollStateChanged(int n) {
        }

        @Override
        public void onPageScrolled(int n, float f, int n2) {
        }

        @Override
        public void onPageSelected(int n) {
        }
    }

    static class ViewPositionComparator
    implements Comparator<View> {
        ViewPositionComparator() {
        }

        public int compare(View view, View view2) {
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            LayoutParams layoutParams2 = (LayoutParams)view2.getLayoutParams();
            if (layoutParams.isDecor != layoutParams2.isDecor) {
                if (layoutParams.isDecor) {
                    return 1;
                }
                return -1;
            }
            return layoutParams.position - layoutParams2.position;
        }
    }

}

