/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.animation.Interpolator
 *  android.widget.Scroller
 */
package com.daimajia.slider.library.Tricks;

import android.content.Context;
import android.view.animation.Interpolator;
import android.widget.Scroller;

public class FixedSpeedScroller
extends Scroller {
    private int mDuration = 1000;

    public FixedSpeedScroller(Context context) {
        super(context);
    }

    public FixedSpeedScroller(Context context, Interpolator interpolator2) {
        super(context, interpolator2);
    }

    public FixedSpeedScroller(Context context, Interpolator interpolator2, int n) {
        this(context, interpolator2);
        this.mDuration = n;
    }

    public void startScroll(int n, int n2, int n3, int n4) {
        super.startScroll(n, n2, n3, n4, this.mDuration);
    }

    public void startScroll(int n, int n2, int n3, int n4, int n5) {
        super.startScroll(n, n2, n3, n4, this.mDuration);
    }
}

