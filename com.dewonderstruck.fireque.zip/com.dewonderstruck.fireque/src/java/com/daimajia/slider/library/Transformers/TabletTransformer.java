/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Camera
 *  android.graphics.Matrix
 *  android.view.View
 *  com.nineoldandroids.view.ViewHelper
 *  java.lang.Math
 */
package com.daimajia.slider.library.Transformers;

import android.graphics.Camera;
import android.graphics.Matrix;
import android.view.View;
import com.daimajia.slider.library.Transformers.BaseTransformer;
import com.nineoldandroids.view.ViewHelper;

public class TabletTransformer
extends BaseTransformer {
    private static final Camera OFFSET_CAMERA;
    private static final Matrix OFFSET_MATRIX;
    private static final float[] OFFSET_TEMP_FLOAT;

    static {
        OFFSET_MATRIX = new Matrix();
        OFFSET_CAMERA = new Camera();
        OFFSET_TEMP_FLOAT = new float[2];
    }

    protected static final float getOffsetXForRotation(float f, int n, int n2) {
        Matrix matrix = OFFSET_MATRIX;
        matrix.reset();
        Camera camera = OFFSET_CAMERA;
        camera.save();
        camera.rotateY(Math.abs((float)f));
        camera.getMatrix(matrix);
        camera.restore();
        matrix.preTranslate(0.5f * (float)(-n), 0.5f * (float)(-n2));
        matrix.postTranslate(0.5f * (float)n, 0.5f * (float)n2);
        float[] arrf = OFFSET_TEMP_FLOAT;
        arrf[0] = n;
        arrf[1] = n2;
        matrix.mapPoints(arrf);
        float f2 = (float)n - arrf[0];
        float f3 = f > 0.0f ? 1.0f : -1.0f;
        return f2 * f3;
    }

    @Override
    protected void onTransform(View view, float f) {
        float f2 = f < 0.0f ? 30.0f : -30.0f;
        float f3 = f2 * Math.abs((float)f);
        ViewHelper.setTranslationX((View)view, (float)TabletTransformer.getOffsetXForRotation(f3, view.getWidth(), view.getHeight()));
        ViewHelper.setPivotX((View)view, (float)(0.5f * (float)view.getWidth()));
        ViewHelper.setPivotY((View)view, (float)0.0f);
        ViewHelper.setRotationY((View)view, (float)f3);
    }
}

