/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.OSEmailSubscriptionState;
import com.onesignal.OSPermissionState;
import com.onesignal.OSSubscriptionState;
import org.json.JSONObject;

public class OSPermissionSubscriptionState {
    OSEmailSubscriptionState emailSubscriptionStatus;
    OSPermissionState permissionStatus;
    OSSubscriptionState subscriptionStatus;

    public OSEmailSubscriptionState getEmailSubscriptionStatus() {
        return this.emailSubscriptionStatus;
    }

    public OSPermissionState getPermissionStatus() {
        return this.permissionStatus;
    }

    public OSSubscriptionState getSubscriptionStatus() {
        return this.subscriptionStatus;
    }

    public JSONObject toJSONObject() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("permissionStatus", (Object)this.permissionStatus.toJSONObject());
            jSONObject.put("subscriptionStatus", (Object)this.subscriptionStatus.toJSONObject());
            jSONObject.put("emailSubscriptionStatus", (Object)this.emailSubscriptionStatus.toJSONObject());
            return jSONObject;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return jSONObject;
        }
    }

    public String toString() {
        return this.toJSONObject().toString();
    }
}

