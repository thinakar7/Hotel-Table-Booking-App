/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package com.onesignal;

import com.onesignal.OSInAppMessagePrompt;
import com.onesignal.OneSignal;

class OSInAppMessageLocationPrompt
extends OSInAppMessagePrompt {
    static final String LOCATION_PROMPT_KEY = "location";

    OSInAppMessageLocationPrompt() {
    }

    @Override
    String getPromptKey() {
        return LOCATION_PROMPT_KEY;
    }

    @Override
    void handlePrompt(OneSignal.OSPromptActionCompletionCallback oSPromptActionCompletionCallback) {
        OneSignal.promptLocation(oSPromptActionCompletionCallback, true);
    }
}

