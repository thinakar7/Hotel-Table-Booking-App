/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.onesignal;

import com.onesignal.OSEmailSubscriptionState;
import com.onesignal.OSPermissionState;
import com.onesignal.OSPermissionSubscriptionState;
import com.onesignal.OSSubscriptionState;
import com.onesignal.OneSignal;

public class OSDevice {
    public String getEmailAddress() {
        return OneSignal.getPermissionSubscriptionState().emailSubscriptionStatus.getEmailAddress();
    }

    public String getEmailUserId() {
        return OneSignal.getPermissionSubscriptionState().emailSubscriptionStatus.getEmailUserId();
    }

    public String getPushToken() {
        return OneSignal.getPermissionSubscriptionState().subscriptionStatus.getPushToken();
    }

    public String getUserId() {
        return OneSignal.getPermissionSubscriptionState().subscriptionStatus.getUserId();
    }

    public boolean isNotificationEnabled() {
        return OneSignal.getPermissionSubscriptionState().permissionStatus.getEnabled();
    }

    public boolean isSubscribed() {
        return OneSignal.getPermissionSubscriptionState().subscriptionStatus.getSubscribed();
    }

    public boolean isUserSubscribed() {
        return OneSignal.getPermissionSubscriptionState().subscriptionStatus.getUserSubscriptionSetting();
    }
}

