/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.onesignal.outcomes.OSOutcomeEventsV1Repository
 *  com.onesignal.outcomes.OSOutcomeEventsV1Service
 *  com.onesignal.outcomes.OSOutcomeEventsV2Repository
 *  com.onesignal.outcomes.OSOutcomeEventsV2Service
 *  java.lang.Object
 */
package com.onesignal.outcomes;

import com.onesignal.OSLogger;
import com.onesignal.OSSharedPreferences;
import com.onesignal.OneSignalAPIClient;
import com.onesignal.OneSignalDb;
import com.onesignal.outcomes.OSOutcomeEventsCache;
import com.onesignal.outcomes.OSOutcomeEventsV1Repository;
import com.onesignal.outcomes.OSOutcomeEventsV1Service;
import com.onesignal.outcomes.OSOutcomeEventsV2Repository;
import com.onesignal.outcomes.OSOutcomeEventsV2Service;
import com.onesignal.outcomes.domain.OSOutcomeEventsRepository;
import com.onesignal.outcomes.domain.OutcomeEventsService;

public class OSOutcomeEventsFactory {
    private final OneSignalAPIClient apiClient;
    private final OSLogger logger;
    private final OSOutcomeEventsCache outcomeEventsCache;
    private OSOutcomeEventsRepository repository;

    public OSOutcomeEventsFactory(OSLogger oSLogger, OneSignalAPIClient oneSignalAPIClient, OneSignalDb oneSignalDb, OSSharedPreferences oSSharedPreferences) {
        this.logger = oSLogger;
        this.apiClient = oneSignalAPIClient;
        this.outcomeEventsCache = new OSOutcomeEventsCache(oSLogger, oneSignalDb, oSSharedPreferences);
    }

    private void createRepository() {
        if (this.outcomeEventsCache.isOutcomesV2ServiceEnabled()) {
            this.repository = new OSOutcomeEventsV2Repository(this.logger, this.outcomeEventsCache, (OutcomeEventsService)new OSOutcomeEventsV2Service(this.apiClient));
            return;
        }
        this.repository = new OSOutcomeEventsV1Repository(this.logger, this.outcomeEventsCache, (OutcomeEventsService)new OSOutcomeEventsV1Service(this.apiClient));
    }

    private void validateRepositoryVersion() {
        if (!this.outcomeEventsCache.isOutcomesV2ServiceEnabled() && this.repository instanceof OSOutcomeEventsV1Repository) {
            return;
        }
        if (this.outcomeEventsCache.isOutcomesV2ServiceEnabled() && this.repository instanceof OSOutcomeEventsV2Repository) {
            return;
        }
        this.createRepository();
    }

    public OSOutcomeEventsRepository getRepository() {
        if (this.repository == null) {
            this.createRepository();
        } else {
            this.validateRepositoryVersion();
        }
        return this.repository;
    }
}

