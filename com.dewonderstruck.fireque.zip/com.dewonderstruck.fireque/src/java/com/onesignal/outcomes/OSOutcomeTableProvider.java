/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.onesignal.outcomes;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import com.onesignal.influence.model.OSInfluenceChannel;

public class OSOutcomeTableProvider {
    public static final String CACHE_UNIQUE_OUTCOME_COLUMN_CHANNEL_INFLUENCE_ID = "channel_influence_id";
    public static final String CACHE_UNIQUE_OUTCOME_COLUMN_CHANNEL_TYPE = "channel_type";
    public static final String CACHE_UNIQUE_OUTCOME_TABLE = "cached_unique_outcome";
    private static final String FLOAT_TYPE = " FLOAT";
    private static final String INTEGER_PRIMARY_KEY_TYPE = " INTEGER PRIMARY KEY";
    private static final String INT_TYPE = " INTEGER";
    public static final String OUTCOME_EVENT_TABLE = "outcome";
    public static final String SQL_CREATE_OUTCOME_ENTRIES_V1 = "CREATE TABLE outcome (_id INTEGER PRIMARY KEY,notification_ids TEXT,name TEXT,session TEXT,params TEXT,timestamp TIMESTAMP);";
    public static final String SQL_CREATE_OUTCOME_ENTRIES_V2 = "CREATE TABLE outcome (_id INTEGER PRIMARY KEY,session TEXT,notification_ids TEXT,name TEXT,timestamp TIMESTAMP,weight FLOAT);";
    public static final String SQL_CREATE_OUTCOME_ENTRIES_V3 = "CREATE TABLE outcome (_id INTEGER PRIMARY KEY,notification_influence_type TEXT,iam_influence_type TEXT,notification_ids TEXT,iam_ids TEXT,name TEXT,timestamp TIMESTAMP,weight FLOAT);";
    public static final String SQL_CREATE_UNIQUE_OUTCOME_ENTRIES_V1 = "CREATE TABLE cached_unique_outcome_notification (_id INTEGER PRIMARY KEY,notification_id TEXT,name TEXT);";
    public static final String SQL_CREATE_UNIQUE_OUTCOME_ENTRIES_V2 = "CREATE TABLE cached_unique_outcome (_id INTEGER PRIMARY KEY,channel_influence_id TEXT,channel_type TEXT,name TEXT);";
    private static final String TEXT_TYPE = " TEXT";
    private static final String TIMESTAMP_TYPE = " TIMESTAMP";

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void upgradeCacheOutcomeTableRevision1To2(SQLiteDatabase sQLiteDatabase) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("_id,name");
        stringBuilder.append(",");
        stringBuilder.append("notification_id");
        String string2 = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("_id,name");
        stringBuilder2.append(",");
        stringBuilder2.append(CACHE_UNIQUE_OUTCOME_COLUMN_CHANNEL_INFLUENCE_ID);
        String string3 = stringBuilder2.toString();
        try {
            try {
                sQLiteDatabase.execSQL("BEGIN TRANSACTION;");
                sQLiteDatabase.execSQL(SQL_CREATE_UNIQUE_OUTCOME_ENTRIES_V2);
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("INSERT INTO cached_unique_outcome(");
                stringBuilder3.append(string3);
                stringBuilder3.append(") SELECT ");
                stringBuilder3.append(string2);
                stringBuilder3.append(" FROM ");
                stringBuilder3.append("cached_unique_outcome_notification");
                stringBuilder3.append(";");
                sQLiteDatabase.execSQL(stringBuilder3.toString());
                StringBuilder stringBuilder4 = new StringBuilder();
                stringBuilder4.append("UPDATE cached_unique_outcome SET channel_type = '");
                stringBuilder4.append(OSInfluenceChannel.NOTIFICATION.toString());
                stringBuilder4.append("';");
                sQLiteDatabase.execSQL(stringBuilder4.toString());
                StringBuilder stringBuilder5 = new StringBuilder();
                stringBuilder5.append("DROP TABLE ");
                stringBuilder5.append("cached_unique_outcome_notification");
                stringBuilder5.append(";");
                sQLiteDatabase.execSQL(stringBuilder5.toString());
            }
            catch (SQLiteException sQLiteException) {
                sQLiteException.printStackTrace();
            }
        }
        catch (Throwable throwable2) {}
        sQLiteDatabase.execSQL("COMMIT;");
        return;
        sQLiteDatabase.execSQL("COMMIT;");
        throw throwable2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void upgradeOutcomeTableRevision1To2(SQLiteDatabase sQLiteDatabase) {
        try {
            try {
                sQLiteDatabase.execSQL("BEGIN TRANSACTION;");
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("CREATE TEMPORARY TABLE outcome_backup(");
                stringBuilder.append("_id,session,notification_ids,name,timestamp");
                stringBuilder.append(");");
                sQLiteDatabase.execSQL(stringBuilder.toString());
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("INSERT INTO outcome_backup SELECT ");
                stringBuilder2.append("_id,session,notification_ids,name,timestamp");
                stringBuilder2.append(" FROM outcome;");
                sQLiteDatabase.execSQL(stringBuilder2.toString());
                sQLiteDatabase.execSQL("DROP TABLE outcome;");
                sQLiteDatabase.execSQL(SQL_CREATE_OUTCOME_ENTRIES_V2);
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("INSERT INTO outcome (");
                stringBuilder3.append("_id,session,notification_ids,name,timestamp");
                stringBuilder3.append(", weight) SELECT ");
                stringBuilder3.append("_id,session,notification_ids,name,timestamp");
                stringBuilder3.append(", 0 FROM outcome_backup;");
                sQLiteDatabase.execSQL(stringBuilder3.toString());
                sQLiteDatabase.execSQL("DROP TABLE outcome_backup;");
            }
            catch (SQLiteException sQLiteException) {
                sQLiteException.printStackTrace();
            }
        }
        catch (Throwable throwable2) {}
        sQLiteDatabase.execSQL("COMMIT;");
        return;
        sQLiteDatabase.execSQL("COMMIT;");
        throw throwable2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void upgradeOutcomeTableRevision2To3(SQLiteDatabase sQLiteDatabase) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("_id,name,timestamp,notification_ids,weight");
        stringBuilder.append(",");
        stringBuilder.append("session");
        String string2 = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("_id,name,timestamp,notification_ids,weight");
        stringBuilder2.append(",");
        stringBuilder2.append("notification_influence_type");
        String string3 = stringBuilder2.toString();
        try {
            try {
                sQLiteDatabase.execSQL("BEGIN TRANSACTION;");
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("ALTER TABLE outcome RENAME TO ");
                stringBuilder3.append("outcome_aux");
                stringBuilder3.append(";");
                sQLiteDatabase.execSQL(stringBuilder3.toString());
                sQLiteDatabase.execSQL(SQL_CREATE_OUTCOME_ENTRIES_V3);
                StringBuilder stringBuilder4 = new StringBuilder();
                stringBuilder4.append("INSERT INTO outcome(");
                stringBuilder4.append(string3);
                stringBuilder4.append(") SELECT ");
                stringBuilder4.append(string2);
                stringBuilder4.append(" FROM ");
                stringBuilder4.append("outcome_aux");
                stringBuilder4.append(";");
                sQLiteDatabase.execSQL(stringBuilder4.toString());
                StringBuilder stringBuilder5 = new StringBuilder();
                stringBuilder5.append("DROP TABLE ");
                stringBuilder5.append("outcome_aux");
                stringBuilder5.append(";");
                sQLiteDatabase.execSQL(stringBuilder5.toString());
            }
            catch (SQLiteException sQLiteException) {
                sQLiteException.printStackTrace();
            }
        }
        catch (Throwable throwable2) {}
        sQLiteDatabase.execSQL("COMMIT;");
        return;
        sQLiteDatabase.execSQL("COMMIT;");
        throw throwable2;
    }
}

