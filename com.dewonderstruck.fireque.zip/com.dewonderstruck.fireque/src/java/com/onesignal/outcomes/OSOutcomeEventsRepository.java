/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 *  java.util.Set
 */
package com.onesignal.outcomes;

import com.onesignal.OSLogger;
import com.onesignal.OneSignalApiResponseHandler;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.outcomes.OSOutcomeEventsCache;
import com.onesignal.outcomes.domain.OutcomeEventsService;
import com.onesignal.outcomes.model.OSOutcomeEventParams;
import java.util.List;
import java.util.Set;

abstract class OSOutcomeEventsRepository
implements com.onesignal.outcomes.domain.OSOutcomeEventsRepository {
    static final String APP_ID = "app_id";
    static final String DEVICE_TYPE = "device_type";
    protected final OSLogger logger;
    private final OSOutcomeEventsCache outcomeEventsCache;
    final OutcomeEventsService outcomeEventsService;

    OSOutcomeEventsRepository(OSLogger oSLogger, OSOutcomeEventsCache oSOutcomeEventsCache, OutcomeEventsService outcomeEventsService) {
        this.logger = oSLogger;
        this.outcomeEventsCache = oSOutcomeEventsCache;
        this.outcomeEventsService = outcomeEventsService;
    }

    @Override
    public List<OSInfluence> getNotCachedUniqueOutcome(String string2, List<OSInfluence> list) {
        List<OSInfluence> list2 = this.outcomeEventsCache.getNotCachedUniqueInfluencesForOutcome(string2, list);
        OSLogger oSLogger = this.logger;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OneSignal getNotCachedUniqueOutcome influences: ");
        stringBuilder.append(list2);
        oSLogger.debug(stringBuilder.toString());
        return list2;
    }

    @Override
    public List<OSOutcomeEventParams> getSavedOutcomeEvents() {
        return this.outcomeEventsCache.getAllEventsToSend();
    }

    @Override
    public Set<String> getUnattributedUniqueOutcomeEventsSent() {
        Set<String> set = this.outcomeEventsCache.getUnattributedUniqueOutcomeEventsSentByChannel();
        OSLogger oSLogger = this.logger;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OneSignal getUnattributedUniqueOutcomeEventsSentByChannel: ");
        stringBuilder.append(set);
        oSLogger.debug(stringBuilder.toString());
        return set;
    }

    @Override
    public void removeEvent(OSOutcomeEventParams oSOutcomeEventParams) {
        this.outcomeEventsCache.deleteOldOutcomeEvent(oSOutcomeEventParams);
    }

    @Override
    public abstract void requestMeasureOutcomeEvent(String var1, int var2, OSOutcomeEventParams var3, OneSignalApiResponseHandler var4);

    @Override
    public void saveOutcomeEvent(OSOutcomeEventParams oSOutcomeEventParams) {
        this.outcomeEventsCache.saveOutcomeEvent(oSOutcomeEventParams);
    }

    @Override
    public void saveUnattributedUniqueOutcomeEventsSent(Set<String> set) {
        OSLogger oSLogger = this.logger;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OneSignal save unattributedUniqueOutcomeEvents: ");
        stringBuilder.append(set);
        oSLogger.debug(stringBuilder.toString());
        this.outcomeEventsCache.saveUnattributedUniqueOutcomeEventsSentByChannel(set);
    }

    @Override
    public void saveUniqueOutcomeNotifications(OSOutcomeEventParams oSOutcomeEventParams) {
        this.outcomeEventsCache.saveUniqueOutcomeEventParams(oSOutcomeEventParams);
    }
}

