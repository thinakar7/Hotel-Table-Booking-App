/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.onesignal.outcomes;

import com.onesignal.OneSignalAPIClient;
import com.onesignal.OneSignalApiResponseHandler;
import com.onesignal.outcomes.OSOutcomeEventsClient;
import org.json.JSONObject;

class OSOutcomeEventsV1Service
extends OSOutcomeEventsClient {
    OSOutcomeEventsV1Service(OneSignalAPIClient oneSignalAPIClient) {
        super(oneSignalAPIClient);
    }

    @Override
    public void sendOutcomeEvent(JSONObject jSONObject, OneSignalApiResponseHandler oneSignalApiResponseHandler) {
        this.client.post("outcomes/measure", jSONObject, oneSignalApiResponseHandler);
    }
}

