/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.onesignal.outcomes.model;

import com.onesignal.influence.model.OSInfluenceChannel;

public class OSCachedUniqueOutcome {
    private OSInfluenceChannel channel;
    private String influenceId;

    public OSCachedUniqueOutcome(String string2, OSInfluenceChannel oSInfluenceChannel) {
        this.influenceId = string2;
        this.channel = oSInfluenceChannel;
    }

    public OSInfluenceChannel getChannel() {
        return this.channel;
    }

    public String getInfluenceId() {
        return this.influenceId;
    }
}

