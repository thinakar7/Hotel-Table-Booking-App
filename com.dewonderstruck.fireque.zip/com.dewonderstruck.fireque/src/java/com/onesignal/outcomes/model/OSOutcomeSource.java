/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal.outcomes.model;

import com.onesignal.outcomes.model.OSOutcomeSourceBody;
import org.json.JSONException;
import org.json.JSONObject;

public class OSOutcomeSource {
    private static final String DIRECT = "direct";
    private static final String INDIRECT = "indirect";
    private OSOutcomeSourceBody directBody;
    private OSOutcomeSourceBody indirectBody;

    public OSOutcomeSource(OSOutcomeSourceBody oSOutcomeSourceBody, OSOutcomeSourceBody oSOutcomeSourceBody2) {
        this.directBody = oSOutcomeSourceBody;
        this.indirectBody = oSOutcomeSourceBody2;
    }

    public OSOutcomeSourceBody getDirectBody() {
        return this.directBody;
    }

    public OSOutcomeSourceBody getIndirectBody() {
        return this.indirectBody;
    }

    public OSOutcomeSource setDirectBody(OSOutcomeSourceBody oSOutcomeSourceBody) {
        this.directBody = oSOutcomeSourceBody;
        return this;
    }

    public OSOutcomeSource setIndirectBody(OSOutcomeSourceBody oSOutcomeSourceBody) {
        this.indirectBody = oSOutcomeSourceBody;
        return this;
    }

    public JSONObject toJSONObject() throws JSONException {
        OSOutcomeSourceBody oSOutcomeSourceBody;
        JSONObject jSONObject = new JSONObject();
        OSOutcomeSourceBody oSOutcomeSourceBody2 = this.directBody;
        if (oSOutcomeSourceBody2 != null) {
            jSONObject.put(DIRECT, (Object)oSOutcomeSourceBody2.toJSONObject());
        }
        if ((oSOutcomeSourceBody = this.indirectBody) != null) {
            jSONObject.put(INDIRECT, (Object)oSOutcomeSourceBody.toJSONObject());
        }
        return jSONObject;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OSOutcomeSource{directBody=");
        stringBuilder.append((Object)this.directBody);
        stringBuilder.append(", indirectBody=");
        stringBuilder.append((Object)this.indirectBody);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

