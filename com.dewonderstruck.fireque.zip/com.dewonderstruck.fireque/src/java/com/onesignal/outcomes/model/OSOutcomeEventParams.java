/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal.outcomes.model;

import com.onesignal.outcomes.model.OSOutcomeSource;
import com.onesignal.outcomes.model.OSOutcomeSourceBody;
import org.json.JSONException;
import org.json.JSONObject;

public class OSOutcomeEventParams {
    private static final String OUTCOME_ID = "id";
    private static final String OUTCOME_SOURCES = "sources";
    private static final String TIMESTAMP = "timestamp";
    private static final String WEIGHT = "weight";
    private String outcomeId;
    private OSOutcomeSource outcomeSource;
    private long timestamp;
    private Float weight;

    public OSOutcomeEventParams(String string2, OSOutcomeSource oSOutcomeSource, float f) {
        this(string2, oSOutcomeSource, f, 0L);
    }

    public OSOutcomeEventParams(String string2, OSOutcomeSource oSOutcomeSource, float f, long l) {
        this.outcomeId = string2;
        this.outcomeSource = oSOutcomeSource;
        this.weight = Float.valueOf((float)f);
        this.timestamp = l;
    }

    public String getOutcomeId() {
        return this.outcomeId;
    }

    public OSOutcomeSource getOutcomeSource() {
        return this.outcomeSource;
    }

    public long getTimestamp() {
        return this.timestamp;
    }

    public Float getWeight() {
        return this.weight;
    }

    public boolean isUnattributed() {
        OSOutcomeSource oSOutcomeSource = this.outcomeSource;
        return oSOutcomeSource == null || oSOutcomeSource.getDirectBody() == null && this.outcomeSource.getIndirectBody() == null;
        {
        }
    }

    public void setTimestamp(long l) {
        this.timestamp = l;
    }

    public void setWeight(float f) {
        this.weight = Float.valueOf((float)f);
    }

    public JSONObject toJSONObject() throws JSONException {
        long l;
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(OUTCOME_ID, (Object)this.outcomeId);
        OSOutcomeSource oSOutcomeSource = this.outcomeSource;
        if (oSOutcomeSource != null) {
            jSONObject.put(OUTCOME_SOURCES, (Object)oSOutcomeSource.toJSONObject());
        }
        if (this.weight.floatValue() > 0.0f) {
            jSONObject.put(WEIGHT, (Object)this.weight);
        }
        if ((l = this.timestamp) > 0L) {
            jSONObject.put(TIMESTAMP, l);
        }
        return jSONObject;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OSOutcomeEventParams{outcomeId='");
        stringBuilder.append(this.outcomeId);
        stringBuilder.append('\'');
        stringBuilder.append(", outcomeSource=");
        stringBuilder.append((Object)this.outcomeSource);
        stringBuilder.append(", weight=");
        stringBuilder.append((Object)this.weight);
        stringBuilder.append(", timestamp=");
        stringBuilder.append(this.timestamp);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

