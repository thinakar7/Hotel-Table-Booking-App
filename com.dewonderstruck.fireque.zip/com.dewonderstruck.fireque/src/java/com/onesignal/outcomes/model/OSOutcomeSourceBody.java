/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal.outcomes.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class OSOutcomeSourceBody {
    private static final String IAM_IDS = "in_app_message_ids";
    private static final String NOTIFICATION_IDS = "notification_ids";
    private JSONArray inAppMessagesIds;
    private JSONArray notificationIds;

    public OSOutcomeSourceBody() {
        this(new JSONArray(), new JSONArray());
    }

    public OSOutcomeSourceBody(JSONArray jSONArray, JSONArray jSONArray2) {
        this.notificationIds = jSONArray;
        this.inAppMessagesIds = jSONArray2;
    }

    public JSONArray getInAppMessagesIds() {
        return this.inAppMessagesIds;
    }

    public JSONArray getNotificationIds() {
        return this.notificationIds;
    }

    public void setInAppMessagesIds(JSONArray jSONArray) {
        this.inAppMessagesIds = jSONArray;
    }

    public void setNotificationIds(JSONArray jSONArray) {
        this.notificationIds = jSONArray;
    }

    public JSONObject toJSONObject() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(NOTIFICATION_IDS, (Object)this.notificationIds);
        jSONObject.put(IAM_IDS, (Object)this.inAppMessagesIds);
        return jSONObject;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OSOutcomeSourceBody{notificationIds=");
        stringBuilder.append((Object)this.notificationIds);
        stringBuilder.append(", inAppMessagesIds=");
        stringBuilder.append((Object)this.inAppMessagesIds);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

