/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Set
 */
package com.onesignal.outcomes.domain;

import com.onesignal.OneSignalApiResponseHandler;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.outcomes.model.OSOutcomeEventParams;
import java.util.List;
import java.util.Set;

public interface OSOutcomeEventsRepository {
    public List<OSInfluence> getNotCachedUniqueOutcome(String var1, List<OSInfluence> var2);

    public List<OSOutcomeEventParams> getSavedOutcomeEvents();

    public Set<String> getUnattributedUniqueOutcomeEventsSent();

    public void removeEvent(OSOutcomeEventParams var1);

    public void requestMeasureOutcomeEvent(String var1, int var2, OSOutcomeEventParams var3, OneSignalApiResponseHandler var4);

    public void saveOutcomeEvent(OSOutcomeEventParams var1);

    public void saveUnattributedUniqueOutcomeEventsSent(Set<String> var1);

    public void saveUniqueOutcomeNotifications(OSOutcomeEventParams var1);
}

