/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.json.JSONObject
 */
package com.onesignal.outcomes.domain;

import com.onesignal.OneSignalApiResponseHandler;
import org.json.JSONObject;

public interface OutcomeEventsService {
    public void sendOutcomeEvent(JSONObject var1, OneSignalApiResponseHandler var2);
}

