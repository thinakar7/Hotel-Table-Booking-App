/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.json.JSONObject
 */
package com.onesignal.outcomes;

import com.onesignal.OneSignalAPIClient;
import com.onesignal.OneSignalApiResponseHandler;
import com.onesignal.outcomes.domain.OutcomeEventsService;
import org.json.JSONObject;

abstract class OSOutcomeEventsClient
implements OutcomeEventsService {
    final OneSignalAPIClient client;

    OSOutcomeEventsClient(OneSignalAPIClient oneSignalAPIClient) {
        this.client = oneSignalAPIClient;
    }

    @Override
    public abstract void sendOutcomeEvent(JSONObject var1, OneSignalApiResponseHandler var2);
}

