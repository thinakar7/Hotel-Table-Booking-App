/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal.outcomes;

import com.onesignal.OSLogger;
import com.onesignal.OneSignalApiResponseHandler;
import com.onesignal.outcomes.OSOutcomeEventsCache;
import com.onesignal.outcomes.OSOutcomeEventsRepository;
import com.onesignal.outcomes.domain.OutcomeEventsService;
import com.onesignal.outcomes.model.OSOutcomeEventParams;
import org.json.JSONException;
import org.json.JSONObject;

class OSOutcomeEventsV2Repository
extends OSOutcomeEventsRepository {
    OSOutcomeEventsV2Repository(OSLogger oSLogger, OSOutcomeEventsCache oSOutcomeEventsCache, OutcomeEventsService outcomeEventsService) {
        super(oSLogger, oSOutcomeEventsCache, outcomeEventsService);
    }

    @Override
    public void requestMeasureOutcomeEvent(String string2, int n, OSOutcomeEventParams oSOutcomeEventParams, OneSignalApiResponseHandler oneSignalApiResponseHandler) {
        try {
            JSONObject jSONObject = oSOutcomeEventParams.toJSONObject();
            jSONObject.put("app_id", (Object)string2);
            jSONObject.put("device_type", n);
            this.outcomeEventsService.sendOutcomeEvent(jSONObject, oneSignalApiResponseHandler);
            return;
        }
        catch (JSONException jSONException) {
            this.logger.error("Generating indirect outcome:JSON Failed.", jSONException);
            return;
        }
    }
}

