/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  java.lang.Float
 *  java.lang.Long
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Set
 *  org.json.JSONArray
 *  org.json.JSONException
 */
package com.onesignal.outcomes;

import android.content.ContentValues;
import android.database.Cursor;
import com.onesignal.OSLogger;
import com.onesignal.OSSharedPreferences;
import com.onesignal.OneSignalDb;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.influence.model.OSInfluenceChannel;
import com.onesignal.influence.model.OSInfluenceType;
import com.onesignal.outcomes.model.OSCachedUniqueOutcome;
import com.onesignal.outcomes.model.OSOutcomeEventParams;
import com.onesignal.outcomes.model.OSOutcomeSource;
import com.onesignal.outcomes.model.OSOutcomeSourceBody;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;

class OSOutcomeEventsCache {
    private static final String PREFS_OS_UNATTRIBUTED_UNIQUE_OUTCOME_EVENTS_SENT = "PREFS_OS_UNATTRIBUTED_UNIQUE_OUTCOME_EVENTS_SENT";
    private OneSignalDb dbHelper;
    private OSLogger logger;
    private OSSharedPreferences preferences;

    OSOutcomeEventsCache(OSLogger oSLogger, OneSignalDb oneSignalDb, OSSharedPreferences oSSharedPreferences) {
        this.logger = oSLogger;
        this.dbHelper = oneSignalDb;
        this.preferences = oSSharedPreferences;
    }

    private void addIdToListFromChannel(List<OSCachedUniqueOutcome> list, JSONArray jSONArray, OSInfluenceChannel oSInfluenceChannel) {
        if (jSONArray != null) {
            for (int i = 0; i < jSONArray.length(); ++i) {
                try {
                    list.add((Object)new OSCachedUniqueOutcome(jSONArray.getString(i), oSInfluenceChannel));
                    continue;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                }
            }
        }
    }

    private void addIdsToListFromSource(List<OSCachedUniqueOutcome> list, OSOutcomeSourceBody oSOutcomeSourceBody) {
        if (oSOutcomeSourceBody != null) {
            JSONArray jSONArray = oSOutcomeSourceBody.getInAppMessagesIds();
            JSONArray jSONArray2 = oSOutcomeSourceBody.getNotificationIds();
            this.addIdToListFromChannel(list, jSONArray, OSInfluenceChannel.IAM);
            this.addIdToListFromChannel(list, jSONArray2, OSInfluenceChannel.NOTIFICATION);
        }
    }

    void deleteOldOutcomeEvent(OSOutcomeEventParams oSOutcomeEventParams) {
        OSOutcomeEventsCache oSOutcomeEventsCache = this;
        synchronized (oSOutcomeEventsCache) {
            OneSignalDb oneSignalDb = this.dbHelper;
            String[] arrstring = new String[]{String.valueOf((long)oSOutcomeEventParams.getTimestamp())};
            oneSignalDb.delete("outcome", "timestamp = ?", arrstring);
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    List<OSOutcomeEventParams> getAllEventsToSend() {
        block16 : {
            var27_1 = this;
            // MONITORENTER : var27_1
            var1_2 = new ArrayList();
            var3_3 = this.dbHelper.query("outcome", null, null, null, null, null, null);
            if (!var3_3.moveToFirst()) break block16;
            do {
                block14 : {
                    block15 : {
                        block13 : {
                            var4_4 = OSInfluenceType.fromString(var3_3.getString(var3_3.getColumnIndex("notification_influence_type")));
                            var5_5 = OSInfluenceType.fromString(var3_3.getString(var3_3.getColumnIndex("iam_influence_type")));
                            var6_6 = var3_3.getString(var3_3.getColumnIndex("notification_ids"));
                            var7_7 = var6_6 != null ? var6_6 : "[]";
                            var8_8 = var3_3.getString(var3_3.getColumnIndex("iam_ids"));
                            var9_9 = var8_8 != null ? var8_8 : "[]";
                            var10_10 = var3_3.getString(var3_3.getColumnIndex("name"));
                            var11_11 = var3_3.getFloat(var3_3.getColumnIndex("weight"));
                            var12_12 = var3_3.getLong(var3_3.getColumnIndex("timestamp"));
                            var14_13 = new OSOutcomeSourceBody();
                            var15_14 = new OSOutcomeSourceBody();
                            var17_19 = 1.$SwitchMap$com$onesignal$influence$model$OSInfluenceType;
                            var18_20 = var4_4.ordinal();
                            try {
                                var19_21 = var17_19[var18_20];
                                if (var19_21 == 1) ** GOTO lbl34
                                if (var19_21 == 2) break block13;
                                var20_22 = null;
                                ** GOTO lbl36
                            }
                            catch (JSONException var16_17) {
                                break block15;
                            }
                        }
                        try {
                            block17 : {
                                var15_14.setNotificationIds(new JSONArray(var7_7));
                                var20_22 = new OSOutcomeSource(null, var15_14);
                                break block17;
lbl34: // 1 sources:
                                var14_13.setNotificationIds(new JSONArray(var7_7));
                                var20_22 = new OSOutcomeSource(var14_13, null);
                            }
                            var21_23 = 1.$SwitchMap$com$onesignal$influence$model$OSInfluenceType[var5_5.ordinal()];
                            if (var21_23 != 1) {
                                if (var21_23 != 2) {
                                    var22_24 = var20_22;
                                } else {
                                    var15_14.setInAppMessagesIds(new JSONArray(var9_9));
                                    var22_24 = var20_22 == null ? new OSOutcomeSource(null, var15_14) : var20_22.setIndirectBody(var15_14);
                                }
                            } else {
                                var14_13.setInAppMessagesIds(new JSONArray(var9_9));
                                var22_24 = var20_22 == null ? new OSOutcomeSource(var14_13, null) : var20_22.setDirectBody(var14_13);
                            }
                            break block14;
                        }
                        catch (JSONException var16_16) {
                            break block15;
                        }
                        catch (JSONException var16_18) {
                            // empty catch block
                        }
                    }
                    this.logger.error("Generating JSONArray from notifications ids outcome:JSON Failed.", (Throwable)var16_15);
                    continue;
                }
                var24_25 = new OSOutcomeEventParams(var10_10, var22_24, var11_11, var12_12);
                var1_2.add((Object)var24_25);
            } while (var3_3.moveToNext());
        }
        var3_3.close();
        // MONITOREXIT : var27_1
        return var1_2;
    }

    /*
     * Exception decompiling
     */
    List<OSInfluence> getNotCachedUniqueInfluencesForOutcome(String var1_1, List<OSInfluence> var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [1[TRYBLOCK]], but top level block is 11[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    Set<String> getUnattributedUniqueOutcomeEventsSentByChannel() {
        OSSharedPreferences oSSharedPreferences = this.preferences;
        return oSSharedPreferences.getStringSet(oSSharedPreferences.getPreferencesName(), PREFS_OS_UNATTRIBUTED_UNIQUE_OUTCOME_EVENTS_SENT, null);
    }

    boolean isOutcomesV2ServiceEnabled() {
        OSSharedPreferences oSSharedPreferences = this.preferences;
        return oSSharedPreferences.getBool(oSSharedPreferences.getPreferencesName(), this.preferences.getOutcomesV2KeyName(), false);
    }

    void saveOutcomeEvent(OSOutcomeEventParams oSOutcomeEventParams) {
        OSOutcomeEventsCache oSOutcomeEventsCache = this;
        synchronized (oSOutcomeEventsCache) {
            JSONArray jSONArray = new JSONArray();
            JSONArray jSONArray2 = new JSONArray();
            OSInfluenceType oSInfluenceType = OSInfluenceType.UNATTRIBUTED;
            OSInfluenceType oSInfluenceType2 = OSInfluenceType.UNATTRIBUTED;
            if (oSOutcomeEventParams.getOutcomeSource() != null) {
                OSOutcomeSource oSOutcomeSource = oSOutcomeEventParams.getOutcomeSource();
                if (oSOutcomeSource.getDirectBody() != null) {
                    OSOutcomeSourceBody oSOutcomeSourceBody = oSOutcomeSource.getDirectBody();
                    if (oSOutcomeSourceBody.getNotificationIds() != null && oSOutcomeSourceBody.getNotificationIds().length() > 0) {
                        oSInfluenceType = OSInfluenceType.DIRECT;
                        jSONArray = oSOutcomeSource.getDirectBody().getNotificationIds();
                    }
                    if (oSOutcomeSourceBody.getInAppMessagesIds() != null && oSOutcomeSourceBody.getInAppMessagesIds().length() > 0) {
                        oSInfluenceType2 = OSInfluenceType.DIRECT;
                        jSONArray2 = oSOutcomeSource.getDirectBody().getInAppMessagesIds();
                    }
                }
                if (oSOutcomeSource.getIndirectBody() != null) {
                    OSOutcomeSourceBody oSOutcomeSourceBody = oSOutcomeSource.getIndirectBody();
                    if (oSOutcomeSourceBody.getNotificationIds() != null && oSOutcomeSourceBody.getNotificationIds().length() > 0) {
                        oSInfluenceType = OSInfluenceType.INDIRECT;
                        jSONArray = oSOutcomeSource.getIndirectBody().getNotificationIds();
                    }
                    if (oSOutcomeSourceBody.getInAppMessagesIds() != null && oSOutcomeSourceBody.getInAppMessagesIds().length() > 0) {
                        oSInfluenceType2 = OSInfluenceType.INDIRECT;
                        jSONArray2 = oSOutcomeSource.getIndirectBody().getInAppMessagesIds();
                    }
                }
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put("notification_ids", jSONArray.toString());
            contentValues.put("iam_ids", jSONArray2.toString());
            contentValues.put("notification_influence_type", oSInfluenceType.toString().toLowerCase());
            contentValues.put("iam_influence_type", oSInfluenceType2.toString().toLowerCase());
            contentValues.put("name", oSOutcomeEventParams.getOutcomeId());
            contentValues.put("weight", oSOutcomeEventParams.getWeight());
            contentValues.put("timestamp", Long.valueOf((long)oSOutcomeEventParams.getTimestamp()));
            this.dbHelper.insert("outcome", null, contentValues);
            return;
        }
    }

    void saveUnattributedUniqueOutcomeEventsSentByChannel(Set<String> set) {
        OSSharedPreferences oSSharedPreferences = this.preferences;
        oSSharedPreferences.saveStringSet(oSSharedPreferences.getPreferencesName(), PREFS_OS_UNATTRIBUTED_UNIQUE_OUTCOME_EVENTS_SENT, set);
    }

    void saveUniqueOutcomeEventParams(OSOutcomeEventParams oSOutcomeEventParams) {
        OSOutcomeEventsCache oSOutcomeEventsCache = this;
        synchronized (oSOutcomeEventsCache) {
            block5 : {
                OSLogger oSLogger = this.logger;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("OneSignal saveUniqueOutcomeEventParams: ");
                stringBuilder.append(oSOutcomeEventParams.toString());
                oSLogger.debug(stringBuilder.toString());
                OSOutcomeSource oSOutcomeSource = oSOutcomeEventParams.getOutcomeSource();
                if (oSOutcomeSource != null) break block5;
                return;
            }
            String string2 = oSOutcomeEventParams.getOutcomeId();
            ArrayList arrayList = new ArrayList();
            OSOutcomeSourceBody oSOutcomeSourceBody = oSOutcomeEventParams.getOutcomeSource().getDirectBody();
            OSOutcomeSourceBody oSOutcomeSourceBody2 = oSOutcomeEventParams.getOutcomeSource().getIndirectBody();
            this.addIdsToListFromSource((List<OSCachedUniqueOutcome>)arrayList, oSOutcomeSourceBody);
            this.addIdsToListFromSource((List<OSCachedUniqueOutcome>)arrayList, oSOutcomeSourceBody2);
            for (OSCachedUniqueOutcome oSCachedUniqueOutcome : arrayList) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("channel_influence_id", oSCachedUniqueOutcome.getInfluenceId());
                contentValues.put("channel_type", String.valueOf((Object)((Object)oSCachedUniqueOutcome.getChannel())));
                contentValues.put("name", string2);
                this.dbHelper.insert("cached_unique_outcome", null, contentValues);
            }
            return;
        }
    }

}

