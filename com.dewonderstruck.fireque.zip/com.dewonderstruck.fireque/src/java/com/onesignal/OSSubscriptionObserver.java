/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.onesignal;

import com.onesignal.OSSubscriptionStateChanges;

public interface OSSubscriptionObserver {
    public void onOSSubscriptionChanged(OSSubscriptionStateChanges var1);
}

