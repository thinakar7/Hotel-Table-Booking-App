/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.OneSignalAPIClient;
import com.onesignal.OneSignalApiResponseHandler;
import com.onesignal.OneSignalRestClient;
import org.json.JSONObject;

class OneSignalRestClientWrapper
implements OneSignalAPIClient {
    OneSignalRestClientWrapper() {
    }

    @Override
    public void get(String string2, final OneSignalApiResponseHandler oneSignalApiResponseHandler, String string3) {
        OneSignalRestClient.get(string2, new OneSignalRestClient.ResponseHandler(){

            @Override
            public void onFailure(int n, String string2, Throwable throwable) {
                oneSignalApiResponseHandler.onFailure(n, string2, throwable);
            }

            @Override
            public void onSuccess(String string2) {
                oneSignalApiResponseHandler.onSuccess(string2);
            }
        }, string3);
    }

    @Override
    public void getSync(String string2, final OneSignalApiResponseHandler oneSignalApiResponseHandler, String string3) {
        OneSignalRestClient.getSync(string2, new OneSignalRestClient.ResponseHandler(){

            @Override
            public void onFailure(int n, String string2, Throwable throwable) {
                oneSignalApiResponseHandler.onFailure(n, string2, throwable);
            }

            @Override
            public void onSuccess(String string2) {
                oneSignalApiResponseHandler.onSuccess(string2);
            }
        }, string3);
    }

    @Override
    public void post(String string2, JSONObject jSONObject, final OneSignalApiResponseHandler oneSignalApiResponseHandler) {
        OneSignalRestClient.post(string2, jSONObject, new OneSignalRestClient.ResponseHandler(){

            @Override
            public void onFailure(int n, String string2, Throwable throwable) {
                oneSignalApiResponseHandler.onFailure(n, string2, throwable);
            }

            @Override
            public void onSuccess(String string2) {
                oneSignalApiResponseHandler.onSuccess(string2);
            }
        });
    }

    @Override
    public void postSync(String string2, JSONObject jSONObject, final OneSignalApiResponseHandler oneSignalApiResponseHandler) {
        OneSignalRestClient.postSync(string2, jSONObject, new OneSignalRestClient.ResponseHandler(){

            @Override
            public void onFailure(int n, String string2, Throwable throwable) {
                oneSignalApiResponseHandler.onFailure(n, string2, throwable);
            }

            @Override
            public void onSuccess(String string2) {
                oneSignalApiResponseHandler.onSuccess(string2);
            }
        });
    }

    @Override
    public void put(String string2, JSONObject jSONObject, final OneSignalApiResponseHandler oneSignalApiResponseHandler) {
        OneSignalRestClient.put(string2, jSONObject, new OneSignalRestClient.ResponseHandler(){

            @Override
            public void onFailure(int n, String string2, Throwable throwable) {
                oneSignalApiResponseHandler.onFailure(n, string2, throwable);
            }

            @Override
            public void onSuccess(String string2) {
                oneSignalApiResponseHandler.onSuccess(string2);
            }
        });
    }

    @Override
    public void putSync(String string2, JSONObject jSONObject, final OneSignalApiResponseHandler oneSignalApiResponseHandler) {
        OneSignalRestClient.putSync(string2, jSONObject, new OneSignalRestClient.ResponseHandler(){

            @Override
            public void onFailure(int n, String string2, Throwable throwable) {
                oneSignalApiResponseHandler.onFailure(n, string2, throwable);
            }

            @Override
            public void onSuccess(String string2) {
                oneSignalApiResponseHandler.onSuccess(string2);
            }
        });
    }

}

