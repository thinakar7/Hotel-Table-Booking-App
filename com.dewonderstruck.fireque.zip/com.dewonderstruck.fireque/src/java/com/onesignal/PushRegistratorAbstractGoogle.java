/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.IOException
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 */
package com.onesignal;

import android.content.Context;
import com.onesignal.GooglePlayServicesUpgradePrompt;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.PushRegistrator;
import java.io.IOException;

abstract class PushRegistratorAbstractGoogle
implements PushRegistrator {
    private static int REGISTRATION_RETRY_BACKOFF_MS;
    private static int REGISTRATION_RETRY_COUNT;
    private boolean firedCallback;
    private Thread registerThread;
    private PushRegistrator.RegisteredHandler registeredHandler;

    static {
        REGISTRATION_RETRY_COUNT = 5;
        REGISTRATION_RETRY_BACKOFF_MS = 10000;
    }

    PushRegistratorAbstractGoogle() {
    }

    private boolean attemptRegistration(String string2, int n) {
        try {
            String string3 = this.getToken(string2);
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.INFO;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Device registered, push token = ");
            stringBuilder.append(string3);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            this.registeredHandler.complete(string3, 1);
            return true;
        }
        catch (Throwable throwable) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown error getting ");
            stringBuilder.append(this.getProviderName());
            stringBuilder.append(" Token");
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString(), throwable);
            this.registeredHandler.complete(null, -12);
            return true;
        }
        catch (IOException iOException) {
            if (!"SERVICE_NOT_AVAILABLE".equals((Object)iOException.getMessage())) {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Error Getting ");
                stringBuilder.append(this.getProviderName());
                stringBuilder.append(" Token");
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString(), iOException);
                if (!this.firedCallback) {
                    this.registeredHandler.complete(null, -11);
                }
                return true;
            }
            if (n >= REGISTRATION_RETRY_COUNT - 1) {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Retry count of ");
                stringBuilder.append(REGISTRATION_RETRY_COUNT);
                stringBuilder.append(" exceed! Could not get a ");
                stringBuilder.append(this.getProviderName());
                stringBuilder.append(" Token.");
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString(), iOException);
            } else {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.INFO;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("'Google Play services' returned SERVICE_NOT_AVAILABLE error. Current retry count: ");
                stringBuilder.append(n);
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString(), iOException);
                if (n == 2) {
                    this.registeredHandler.complete(null, -9);
                    this.firedCallback = true;
                    return true;
                }
            }
            return false;
        }
    }

    private void internalRegisterForPush(String string2) {
        try {
            if (OSUtils.isGMSInstalledAndEnabled()) {
                this.registerInBackground(string2);
            } else {
                GooglePlayServicesUpgradePrompt.showUpdateGPSDialog();
                OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "'Google Play services' app not installed or disabled on the device.");
                this.registeredHandler.complete(null, -7);
            }
            return;
        }
        catch (Throwable throwable) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Could not register with ");
            stringBuilder.append(this.getProviderName());
            stringBuilder.append(" due to an issue with your AndroidManifest.xml or with 'Google Play services'.");
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString(), throwable);
            this.registeredHandler.complete(null, -8);
            return;
        }
    }

    private boolean isValidProjectNumber(String string2, PushRegistrator.RegisteredHandler registeredHandler) {
        boolean bl;
        try {
            Float.parseFloat((String)string2);
            bl = true;
        }
        catch (Throwable throwable) {
            bl = false;
        }
        if (!bl) {
            OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Missing Google Project number!\nPlease enter a Google Project number / Sender ID on under App Settings > Android > Configuration on the OneSignal dashboard.");
            registeredHandler.complete(null, -6);
            return false;
        }
        return true;
    }

    private void registerInBackground(final String string2) {
        PushRegistratorAbstractGoogle pushRegistratorAbstractGoogle = this;
        synchronized (pushRegistratorAbstractGoogle) {
            Thread thread;
            block5 : {
                Thread thread2 = this.registerThread;
                if (thread2 == null) break block5;
                boolean bl = thread2.isAlive();
                if (!bl) break block5;
                return;
            }
            this.registerThread = thread = new Thread(new Runnable(){

                public void run() {
                    for (int i = 0; i < REGISTRATION_RETRY_COUNT; ++i) {
                        if (PushRegistratorAbstractGoogle.this.attemptRegistration(string2, i)) {
                            return;
                        }
                        OSUtils.sleep(REGISTRATION_RETRY_BACKOFF_MS * (i + 1));
                    }
                }
            });
            thread.start();
            return;
        }
    }

    abstract String getProviderName();

    abstract String getToken(String var1) throws Throwable;

    @Override
    public void registerForPush(Context context, String string2, PushRegistrator.RegisteredHandler registeredHandler) {
        this.registeredHandler = registeredHandler;
        if (this.isValidProjectNumber(string2, registeredHandler)) {
            this.internalRegisterForPush(string2);
        }
    }

}

