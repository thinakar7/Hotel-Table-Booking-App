/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.content.Context
 *  android.database.Cursor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.service.notification.StatusBarNotification
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.TreeMap
 */
package com.onesignal;

import android.app.Notification;
import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalDbHelper;
import com.onesignal.OneSignalNotificationManager;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

class NotificationLimitManager {
    private static final int MAX_NUMBER_OF_NOTIFICATIONS_INT = 49;
    static final String MAX_NUMBER_OF_NOTIFICATIONS_STR = Integer.toString((int)49);

    NotificationLimitManager() {
    }

    static void clearOldestOverLimit(Context context, int n) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                NotificationLimitManager.clearOldestOverLimitStandard(context, n);
            } else {
                NotificationLimitManager.clearOldestOverLimitFallback(context, n);
            }
            return;
        }
        catch (Throwable throwable) {
            NotificationLimitManager.clearOldestOverLimitFallback(context, n);
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static void clearOldestOverLimitFallback(Context var0, int var1_1) {
        var2_2 = OneSignalDbHelper.getInstance(var0);
        var3_3 = null;
        var4_4 = new String[]{"android_notification_id"};
        var7_5 = OneSignalDbHelper.recentUninteractedWithNotificationsWhere().toString();
        var8_6 = new StringBuilder();
        var8_6.append(NotificationLimitManager.getMaxNumberOfNotificationsString());
        var8_6.append(var1_1);
        var3_3 = var2_2.query("notification", var4_4, var7_5, null, null, null, "_id", var8_6.toString());
        var11_7 = var3_3.getCount();
        var12_8 = NotificationLimitManager.getMaxNumberOfNotificationsInt();
        var13_9 = var1_1 + (var11_7 - var12_8);
        if (var13_9 < 1) {
            if (var3_3 == null) return;
            if (var3_3.isClosed() != false) return;
            var3_3.close();
            return;
        }
        try {
            while (var3_3.moveToNext()) {
                OneSignal.cancelNotification(var3_3.getInt(var3_3.getColumnIndex("android_notification_id")));
                if (--var13_9 > 0) continue;
            }
        }
        catch (Throwable var5_10) {
            try {
                OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Error clearing oldest notifications over limit! ", var5_10);
                if (var3_3 == null) return;
            }
            catch (Throwable var6_11) {
                if (var3_3 == null) throw var6_11;
                if (var3_3.isClosed() != false) throw var6_11;
                var3_3.close();
                throw var6_11;
            }
            if (var3_3.isClosed() != false) return;
lbl32: // 2 sources:
            var3_3.close();
            return;
        }
        if (var3_3 == null) return;
        if (var3_3.isClosed() != false) return;
        ** GOTO lbl32
    }

    static void clearOldestOverLimitStandard(Context context, int n) throws Throwable {
        StatusBarNotification[] arrstatusBarNotification = OneSignalNotificationManager.getActiveNotifications(context);
        int n2 = n + (arrstatusBarNotification.length - NotificationLimitManager.getMaxNumberOfNotificationsInt());
        if (n2 < 1) {
            return;
        }
        TreeMap treeMap = new TreeMap();
        for (StatusBarNotification statusBarNotification : arrstatusBarNotification) {
            if (NotificationLimitManager.isGroupSummary(statusBarNotification)) continue;
            treeMap.put((Object)statusBarNotification.getNotification().when, (Object)statusBarNotification.getId());
        }
        Iterator iterator = treeMap.entrySet().iterator();
        while (iterator.hasNext()) {
            OneSignal.cancelNotification((Integer)((Map.Entry)iterator.next()).getValue());
            if (--n2 > 0) continue;
            return;
        }
    }

    private static int getMaxNumberOfNotificationsInt() {
        return 49;
    }

    private static String getMaxNumberOfNotificationsString() {
        return MAX_NUMBER_OF_NOTIFICATIONS_STR;
    }

    static boolean isGroupSummary(StatusBarNotification statusBarNotification) {
        return (512 & statusBarNotification.getNotification().flags) != 0;
    }
}

