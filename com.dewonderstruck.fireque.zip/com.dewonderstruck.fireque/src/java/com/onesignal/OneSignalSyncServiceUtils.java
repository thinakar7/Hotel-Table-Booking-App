/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AlarmManager
 *  android.app.PendingIntent
 *  android.app.Service
 *  android.app.job.JobInfo
 *  android.app.job.JobInfo$Builder
 *  android.app.job.JobParameters
 *  android.app.job.JobScheduler
 *  android.app.job.JobService
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Class
 *  java.lang.InterruptedException
 *  java.lang.Long
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.ArrayBlockingQueue
 *  java.util.concurrent.BlockingQueue
 */
package com.onesignal;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import com.onesignal.AndroidSupportV4Compat;
import com.onesignal.FocusTimeController;
import com.onesignal.LocationController;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalStateSynchronizer;
import com.onesignal.SyncJobService;
import com.onesignal.SyncService;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

class OneSignalSyncServiceUtils {
    private static final long SYNC_AFTER_BG_DELAY_MS = 30000L;
    private static final int SYNC_TASK_ID = 2071862118;
    private static boolean needsJobReschedule;
    private static Long nextScheduledSyncTimeMs;
    private static Thread syncBgThread;

    static {
        nextScheduledSyncTimeMs = 0L;
        needsJobReschedule = false;
    }

    OneSignalSyncServiceUtils() {
    }

    static void cancelSyncTask(Context context) {
        Class<OneSignalSyncServiceUtils> class_ = OneSignalSyncServiceUtils.class;
        synchronized (OneSignalSyncServiceUtils.class) {
            block6 : {
                nextScheduledSyncTimeMs = 0L;
                boolean bl = LocationController.scheduleUpdate(context);
                if (!bl) break block6;
                return;
            }
            if (OneSignalSyncServiceUtils.useJob()) {
                ((JobScheduler)context.getSystemService("jobscheduler")).cancel(2071862118);
            } else {
                ((AlarmManager)context.getSystemService("alarm")).cancel(OneSignalSyncServiceUtils.syncServicePendingIntent(context));
            }
            // ** MonitorExit[var3_1] (shouldn't be in output)
            return;
        }
    }

    static void doBackgroundSync(Context context, SyncRunnable syncRunnable) {
        Thread thread;
        OneSignal.setAppContext(context);
        syncBgThread = thread = new Thread((Runnable)syncRunnable, "OS_SYNCSRV_BG_SYNC");
        thread.start();
    }

    private static boolean hasBootPermission(Context context) {
        return AndroidSupportV4Compat.ContextCompat.checkSelfPermission(context, "android.permission.RECEIVE_BOOT_COMPLETED") == 0;
    }

    private static boolean isJobIdRunning(Context context) {
        Iterator iterator = ((JobScheduler)context.getSystemService("jobscheduler")).getAllPendingJobs().iterator();
        while (iterator.hasNext()) {
            Thread thread;
            if (((JobInfo)iterator.next()).getId() != 2071862118 || (thread = syncBgThread) == null || !thread.isAlive()) continue;
            return true;
        }
        return false;
    }

    static void scheduleLocationUpdateTask(Context context, long l) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.VERBOSE;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("scheduleLocationUpdateTask:delayMs: ");
        stringBuilder.append(l);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        OneSignalSyncServiceUtils.scheduleSyncTask(context, l);
    }

    private static void scheduleSyncServiceAsAlarm(Context context, long l) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.VERBOSE;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("scheduleServiceSyncTask:atTime: ");
        stringBuilder.append(l);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        PendingIntent pendingIntent = OneSignalSyncServiceUtils.syncServicePendingIntent(context);
        ((AlarmManager)context.getSystemService("alarm")).set(0, l + (l + System.currentTimeMillis()), pendingIntent);
    }

    private static void scheduleSyncServiceAsJob(Context context, long l) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.VERBOSE;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("scheduleSyncServiceAsJob:atTime: ");
        stringBuilder.append(l);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        if (OneSignalSyncServiceUtils.isJobIdRunning(context)) {
            OneSignal.Log(OneSignal.LOG_LEVEL.VERBOSE, "scheduleSyncServiceAsJob Scheduler already running!");
            needsJobReschedule = true;
            return;
        }
        JobInfo.Builder builder = new JobInfo.Builder(2071862118, new ComponentName(context, SyncJobService.class));
        builder.setMinimumLatency(l).setRequiredNetworkType(1);
        if (OneSignalSyncServiceUtils.hasBootPermission(context)) {
            builder.setPersisted(true);
        }
        JobScheduler jobScheduler = (JobScheduler)context.getSystemService("jobscheduler");
        try {
            int n = jobScheduler.schedule(builder.build());
            OneSignal.LOG_LEVEL lOG_LEVEL2 = OneSignal.LOG_LEVEL.INFO;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("scheduleSyncServiceAsJob:result: ");
            stringBuilder2.append(n);
            OneSignal.Log(lOG_LEVEL2, stringBuilder2.toString());
            return;
        }
        catch (NullPointerException nullPointerException) {
            OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "scheduleSyncServiceAsJob called JobScheduler.jobScheduler which triggered an internal null Android error. Skipping job.", nullPointerException);
            return;
        }
    }

    static void scheduleSyncTask(Context context) {
        OneSignal.Log(OneSignal.LOG_LEVEL.VERBOSE, "scheduleSyncTask:SYNC_AFTER_BG_DELAY_MS: 30000");
        OneSignalSyncServiceUtils.scheduleSyncTask(context, 30000L);
    }

    private static void scheduleSyncTask(Context context, long l) {
        Class<OneSignalSyncServiceUtils> class_ = OneSignalSyncServiceUtils.class;
        synchronized (OneSignalSyncServiceUtils.class) {
            block7 : {
                long l2;
                long l3;
                if (nextScheduledSyncTimeMs == 0L || (l3 = l + System.currentTimeMillis()) <= (l2 = nextScheduledSyncTimeMs.longValue())) break block7;
                return;
            }
            if (l < 5000L) {
                l = 5000L;
            }
            if (OneSignalSyncServiceUtils.useJob()) {
                OneSignalSyncServiceUtils.scheduleSyncServiceAsJob(context, l);
            } else {
                OneSignalSyncServiceUtils.scheduleSyncServiceAsAlarm(context, l);
            }
            nextScheduledSyncTimeMs = l + System.currentTimeMillis();
            // ** MonitorExit[var8_2] (shouldn't be in output)
            return;
        }
    }

    static boolean stopSyncBgThread() {
        Thread thread = syncBgThread;
        if (thread == null) {
            return false;
        }
        if (!thread.isAlive()) {
            return false;
        }
        syncBgThread.interrupt();
        return true;
    }

    private static PendingIntent syncServicePendingIntent(Context context) {
        return PendingIntent.getService((Context)context, (int)2071862118, (Intent)new Intent(context, SyncService.class), (int)134217728);
    }

    private static boolean useJob() {
        return Build.VERSION.SDK_INT >= 21;
    }

    static class LegacySyncRunnable
    extends SyncRunnable {
        Service callerService;

        LegacySyncRunnable(Service service) {
            this.callerService = service;
        }

        @Override
        protected void stopSync() {
            OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "LegacySyncRunnable:Stopped");
            this.callerService.stopSelf();
        }
    }

    static class LollipopSyncRunnable
    extends SyncRunnable {
        private JobParameters jobParameters;
        private JobService jobService;

        LollipopSyncRunnable(JobService jobService, JobParameters jobParameters) {
            this.jobService = jobService;
            this.jobParameters = jobParameters;
        }

        @Override
        protected void stopSync() {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("LollipopSyncRunnable:JobFinished needsJobReschedule: ");
            stringBuilder.append(needsJobReschedule);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            boolean bl = needsJobReschedule;
            needsJobReschedule = false;
            this.jobService.jobFinished(this.jobParameters, bl);
        }
    }

    static abstract class SyncRunnable
    implements Runnable {
        SyncRunnable() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public final void run() {
            Class<OneSignalSyncServiceUtils> class_ = OneSignalSyncServiceUtils.class;
            synchronized (OneSignalSyncServiceUtils.class) {
                nextScheduledSyncTimeMs = 0L;
                // ** MonitorExit[var7_1] (shouldn't be in output)
                if (OneSignal.getUserId() == null) {
                    this.stopSync();
                    return;
                }
                OneSignal.appId = OneSignal.getSavedAppId();
                OneSignalStateSynchronizer.initUserState();
                try {
                    ArrayBlockingQueue arrayBlockingQueue = new ArrayBlockingQueue(1);
                    LocationController.LocationHandler locationHandler = new LocationController.LocationHandler((BlockingQueue)arrayBlockingQueue){
                        final /* synthetic */ BlockingQueue val$queue;
                        {
                            this.val$queue = blockingQueue;
                        }

                        @Override
                        public LocationController.PermissionType getType() {
                            return LocationController.PermissionType.SYNC_SERVICE;
                        }

                        @Override
                        public void onComplete(LocationController.LocationPoint locationPoint) {
                            Object object = locationPoint != null ? locationPoint : new Object();
                            this.val$queue.offer(object);
                        }
                    };
                    LocationController.getLocation(OneSignal.appContext, false, false, locationHandler);
                    Object object = arrayBlockingQueue.take();
                    if (object instanceof LocationController.LocationPoint) {
                        OneSignalStateSynchronizer.updateLocation((LocationController.LocationPoint)object);
                    }
                }
                catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
                OneSignalStateSynchronizer.syncUserState(true);
                FocusTimeController.getInstance().doBlockingBackgroundSyncOfUnsentTime();
                this.stopSync();
                return;
            }
        }

        protected abstract void stopSync();

    }

}

