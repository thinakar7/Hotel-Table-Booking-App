/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Queue
 *  java.util.Set
 *  java.util.concurrent.ConcurrentLinkedQueue
 *  java.util.concurrent.atomic.AtomicBoolean
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import com.onesignal.ImmutableJSONObject;
import com.onesignal.JSONUtils;
import com.onesignal.LocationController;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalRestClient;
import com.onesignal.OneSignalStateSynchronizer;
import com.onesignal.UserState;
import java.util.HashMap;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

abstract class UserStateSynchronizer {
    protected final Object LOCK = new Object();
    private boolean canMakeUpdates;
    private OneSignalStateSynchronizer.UserStateSynchronizerType channel;
    protected UserState currentUserState;
    private final Queue<OneSignal.OSInternalExternalUserIdUpdateCompletionHandler> externalUserIdUpdateHandlers = new ConcurrentLinkedQueue();
    private final Object networkHandlerSyncLock = new Object(){};
    HashMap<Integer, NetworkHandlerThread> networkHandlerThreads = new HashMap();
    private AtomicBoolean runningSyncUserState = new AtomicBoolean();
    private final Queue<OneSignal.ChangeTagsUpdateHandler> sendTagsHandlers = new ConcurrentLinkedQueue();
    protected UserState toSyncUserState;
    protected boolean waitingForSessionResponse = false;

    UserStateSynchronizer(OneSignalStateSynchronizer.UserStateSynchronizerType userStateSynchronizerType) {
        this.channel = userStateSynchronizerType;
    }

    private void doCreateOrNewSession(final String string2, final JSONObject jSONObject, final JSONObject jSONObject2) {
        String string3;
        if (string2 == null) {
            string3 = "players";
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("players/");
            stringBuilder.append(string2);
            stringBuilder.append("/on_session");
            string3 = stringBuilder.toString();
        }
        this.waitingForSessionResponse = true;
        this.addOnSessionOrCreateExtras(jSONObject);
        OneSignalRestClient.postSync(string3, jSONObject, new OneSignalRestClient.ResponseHandler(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            void onFailure(int n, String string22, Throwable throwable) {
                Object object;
                Object object2 = object = UserStateSynchronizer.this.LOCK;
                synchronized (object2) {
                    UserStateSynchronizer.this.waitingForSessionResponse = false;
                    OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.WARN;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Failed last request. statusCode: ");
                    stringBuilder.append(n);
                    stringBuilder.append("\nresponse: ");
                    stringBuilder.append(string22);
                    OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                    if (UserStateSynchronizer.this.response400WithErrorsContaining(n, string22, "not a valid device_type")) {
                        UserStateSynchronizer.this.handlePlayerDeletedFromServer();
                    } else {
                        UserStateSynchronizer.this.handleNetworkFailure(n);
                    }
                    return;
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            void onSuccess(String string22) {
                Object object;
                Object object2 = object = UserStateSynchronizer.this.LOCK;
                synchronized (object2) {
                    UserStateSynchronizer.this.waitingForSessionResponse = false;
                    UserStateSynchronizer.this.currentUserState.persistStateAfterSync(jSONObject2, jSONObject);
                    try {
                        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("doCreateOrNewSession:response: ");
                        stringBuilder.append(string22);
                        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
                        JSONObject jSONObject3 = new JSONObject(string22);
                        if (jSONObject3.has("id")) {
                            String string3 = jSONObject3.optString("id");
                            UserStateSynchronizer.this.updateIdDependents(string3);
                            OneSignal.LOG_LEVEL lOG_LEVEL2 = OneSignal.LOG_LEVEL.INFO;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("Device registered, UserId = ");
                            stringBuilder2.append(string3);
                            OneSignal.Log(lOG_LEVEL2, stringBuilder2.toString());
                        } else {
                            OneSignal.LOG_LEVEL lOG_LEVEL3 = OneSignal.LOG_LEVEL.INFO;
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("session sent, UserId = ");
                            stringBuilder3.append(string2);
                            OneSignal.Log(lOG_LEVEL3, stringBuilder3.toString());
                        }
                        UserStateSynchronizer.this.getUserStateForModification().putOnDependValues("session", false);
                        UserStateSynchronizer.this.getUserStateForModification().persistState();
                        if (jSONObject3.has("in_app_messages")) {
                            OneSignal.getInAppMessageController().receivedInAppMessageJson(jSONObject3.getJSONArray("in_app_messages"));
                        }
                        UserStateSynchronizer.this.onSuccessfulSync(jSONObject);
                    }
                    catch (JSONException jSONException) {
                        OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "ERROR parsing on_session or create JSON Response.", jSONException);
                    }
                    return;
                }
            }
        });
    }

    private void doEmailLogout(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("players/");
        stringBuilder.append(string2);
        stringBuilder.append("/email_logout");
        String string3 = stringBuilder.toString();
        JSONObject jSONObject = new JSONObject();
        try {
            ImmutableJSONObject immutableJSONObject;
            ImmutableJSONObject immutableJSONObject2 = this.currentUserState.getDependValues();
            if (immutableJSONObject2.has("email_auth_hash")) {
                jSONObject.put("email_auth_hash", (Object)immutableJSONObject2.optString("email_auth_hash"));
            }
            if ((immutableJSONObject = this.currentUserState.getSyncValues()).has("parent_player_id")) {
                jSONObject.put("parent_player_id", (Object)immutableJSONObject.optString("parent_player_id"));
            }
            jSONObject.put("app_id", (Object)immutableJSONObject.optString("app_id"));
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
        }
        OneSignalRestClient.postSync(string3, jSONObject, new OneSignalRestClient.ResponseHandler(){

            @Override
            void onFailure(int n, String string2, Throwable throwable) {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.WARN;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Failed last request. statusCode: ");
                stringBuilder.append(n);
                stringBuilder.append("\nresponse: ");
                stringBuilder.append(string2);
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                if (UserStateSynchronizer.this.response400WithErrorsContaining(n, string2, "already logged out of email")) {
                    UserStateSynchronizer.this.logoutEmailSyncSuccess();
                    return;
                }
                if (UserStateSynchronizer.this.response400WithErrorsContaining(n, string2, "not a valid device_type")) {
                    UserStateSynchronizer.this.handlePlayerDeletedFromServer();
                    return;
                }
                UserStateSynchronizer.this.handleNetworkFailure(n);
            }

            @Override
            void onSuccess(String string2) {
                UserStateSynchronizer.this.logoutEmailSyncSuccess();
            }
        });
    }

    private void doPutSync(String string2, final JSONObject jSONObject, final JSONObject jSONObject2) {
        if (string2 == null) {
            OneSignal.onesignalLog(this.getLogLevel(), "Error updating the user record because of the null user id");
            this.sendTagsHandlersPerformOnFailure(new OneSignal.SendTagsError(-1, "Unable to update tags: the current user is not registered with OneSignal"));
            this.externalUserIdUpdateHandlersPerformOnFailure();
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("players/");
        stringBuilder.append(string2);
        OneSignalRestClient.putSync(stringBuilder.toString(), jSONObject, new OneSignalRestClient.ResponseHandler(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Converted monitor instructions to comments
             * Lifted jumps to return sites
             */
            @Override
            void onFailure(int n, String string2, Throwable throwable) {
                Object object;
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Failed PUT sync request with status code: ");
                stringBuilder.append(n);
                stringBuilder.append(" and response: ");
                stringBuilder.append(string2);
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                Object object2 = object = UserStateSynchronizer.this.LOCK;
                // MONITORENTER : object2
                if (UserStateSynchronizer.this.response400WithErrorsContaining(n, string2, "No user with this id found")) {
                    UserStateSynchronizer.this.handlePlayerDeletedFromServer();
                } else {
                    UserStateSynchronizer.this.handleNetworkFailure(n);
                }
                // MONITOREXIT : object2
                if (jSONObject.has("tags")) {
                    UserStateSynchronizer.this.sendTagsHandlersPerformOnFailure(new OneSignal.SendTagsError(n, string2));
                }
                if (!jSONObject.has("external_user_id")) return;
                OneSignal.LOG_LEVEL lOG_LEVEL2 = OneSignal.LOG_LEVEL.ERROR;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Error setting external user id for push with status code: ");
                stringBuilder2.append(n);
                stringBuilder2.append(" and message: ");
                stringBuilder2.append(string2);
                OneSignal.onesignalLog(lOG_LEVEL2, stringBuilder2.toString());
                UserStateSynchronizer.this.externalUserIdUpdateHandlersPerformOnFailure();
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Converted monitor instructions to comments
             * Lifted jumps to return sites
             */
            @Override
            void onSuccess(String string2) {
                Object object;
                Object object2 = object = UserStateSynchronizer.this.LOCK;
                // MONITORENTER : object2
                UserStateSynchronizer.this.currentUserState.persistStateAfterSync(jSONObject2, jSONObject);
                UserStateSynchronizer.this.onSuccessfulSync(jSONObject);
                // MONITOREXIT : object2
                if (jSONObject.has("tags")) {
                    UserStateSynchronizer.this.sendTagsHandlersPerformOnSuccess();
                }
                if (!jSONObject.has("external_user_id")) return;
                UserStateSynchronizer.this.externalUserIdUpdateHandlersPerformOnSuccess();
            }
        });
    }

    private void externalUserIdUpdateHandlersPerformOnFailure() {
        OneSignal.OSInternalExternalUserIdUpdateCompletionHandler oSInternalExternalUserIdUpdateCompletionHandler;
        while ((oSInternalExternalUserIdUpdateCompletionHandler = (OneSignal.OSInternalExternalUserIdUpdateCompletionHandler)this.externalUserIdUpdateHandlers.poll()) != null) {
            oSInternalExternalUserIdUpdateCompletionHandler.onComplete(this.getChannelString(), false);
        }
    }

    private void externalUserIdUpdateHandlersPerformOnSuccess() {
        OneSignal.OSInternalExternalUserIdUpdateCompletionHandler oSInternalExternalUserIdUpdateCompletionHandler;
        while ((oSInternalExternalUserIdUpdateCompletionHandler = (OneSignal.OSInternalExternalUserIdUpdateCompletionHandler)this.externalUserIdUpdateHandlers.poll()) != null) {
            oSInternalExternalUserIdUpdateCompletionHandler.onComplete(this.getChannelString(), true);
        }
    }

    private void fireNetworkFailureEvents() {
        JSONObject jSONObject = this.currentUserState.generateJsonDiff(this.toSyncUserState, false);
        if (jSONObject != null) {
            this.fireEventsForUpdateFailure(jSONObject);
        }
        if (this.getToSyncUserState().getDependValues().optBoolean("logoutEmail", false)) {
            OneSignal.handleFailedEmailLogout();
        }
    }

    private void handleNetworkFailure(int n) {
        if (n == 403) {
            OneSignal.Log(OneSignal.LOG_LEVEL.FATAL, "403 error updating player, omitting further retries!");
            this.fireNetworkFailureEvents();
            return;
        }
        if (!this.getNetworkHandlerThread(0).doRetry()) {
            this.fireNetworkFailureEvents();
        }
    }

    private void handlePlayerDeletedFromServer() {
        OneSignal.Log(OneSignal.LOG_LEVEL.WARN, "Creating new player based on missing player_id noted above.");
        OneSignal.handleSuccessfulEmailLogout();
        this.resetCurrentState();
        this.updateIdDependents(null);
        this.scheduleSyncToServer();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void internalSyncUserState(boolean bl) {
        Object object;
        String string2 = this.getId();
        if (this.syncEmailLogout() && string2 != null) {
            this.doEmailLogout(string2);
            return;
        }
        if (this.currentUserState == null) {
            this.initUserState();
        }
        boolean bl2 = !bl && this.isSessionCall();
        Object object2 = object = this.LOCK;
        // MONITORENTER : object2
        JSONObject jSONObject = this.currentUserState.generateJsonDiff(this.getToSyncUserState(), bl2);
        UserState userState = this.getToSyncUserState();
        JSONObject jSONObject2 = this.currentUserState.generateJsonDiffFromDependValues(userState, null);
        if (jSONObject == null) {
            this.currentUserState.persistStateAfterSync(jSONObject2, null);
            this.sendTagsHandlersPerformOnSuccess();
            this.externalUserIdUpdateHandlersPerformOnSuccess();
            // MONITOREXIT : object2
            return;
        }
        this.getToSyncUserState().persistState();
        // MONITOREXIT : object2
        if (!bl2) {
            this.doPutSync(string2, jSONObject, jSONObject2);
            return;
        }
        this.doCreateOrNewSession(string2, jSONObject, jSONObject2);
    }

    private boolean isSessionCall() {
        return (this.getToSyncUserState().getDependValues().optBoolean("session") || this.getId() == null) && !this.waitingForSessionResponse;
    }

    private void logoutEmailSyncSuccess() {
        this.getToSyncUserState().removeFromDependValues("logoutEmail");
        this.toSyncUserState.removeFromDependValues("email_auth_hash");
        this.toSyncUserState.removeFromSyncValues("parent_player_id");
        this.toSyncUserState.removeFromSyncValues("email");
        this.toSyncUserState.persistState();
        this.currentUserState.removeFromDependValues("email_auth_hash");
        this.currentUserState.removeFromSyncValues("parent_player_id");
        String string2 = this.currentUserState.getSyncValues().optString("email");
        this.currentUserState.removeFromSyncValues("email");
        OneSignalStateSynchronizer.setNewSessionForEmail();
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.INFO;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Device successfully logged out of email: ");
        stringBuilder.append(string2);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        OneSignal.handleSuccessfulEmailLogout();
    }

    private boolean response400WithErrorsContaining(int n, String string2, String string3) {
        if (n == 400 && string2 != null) {
            boolean bl;
            block4 : {
                JSONObject jSONObject = new JSONObject(string2);
                boolean bl2 = jSONObject.has("errors");
                bl = false;
                if (!bl2) break block4;
                try {
                    boolean bl3 = jSONObject.optString("errors").contains((CharSequence)string3);
                    bl = false;
                    if (!bl3) break block4;
                    bl = true;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                }
            }
            return bl;
        }
        return false;
    }

    private void sendTagsHandlersPerformOnFailure(OneSignal.SendTagsError sendTagsError) {
        OneSignal.ChangeTagsUpdateHandler changeTagsUpdateHandler;
        while ((changeTagsUpdateHandler = (OneSignal.ChangeTagsUpdateHandler)this.sendTagsHandlers.poll()) != null) {
            changeTagsUpdateHandler.onFailure(sendTagsError);
        }
    }

    private void sendTagsHandlersPerformOnSuccess() {
        OneSignal.ChangeTagsUpdateHandler changeTagsUpdateHandler;
        JSONObject jSONObject = OneSignalStateSynchronizer.getTags((boolean)false).result;
        while ((changeTagsUpdateHandler = (OneSignal.ChangeTagsUpdateHandler)this.sendTagsHandlers.poll()) != null) {
            changeTagsUpdateHandler.onSuccess(jSONObject);
        }
    }

    private boolean syncEmailLogout() {
        return this.getToSyncUserState().getDependValues().optBoolean("logoutEmail", false);
    }

    protected abstract void addOnSessionOrCreateExtras(JSONObject var1);

    void clearLocation() {
        this.getToSyncUserState().clearLocation();
        this.getToSyncUserState().persistState();
    }

    protected abstract void fireEventsForUpdateFailure(JSONObject var1);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected JSONObject generateJsonDiff(JSONObject jSONObject, JSONObject jSONObject2, JSONObject jSONObject3, Set<String> set) {
        Object object;
        Object object2 = object = this.LOCK;
        synchronized (object2) {
            return JSONUtils.generateJsonDiff(jSONObject, jSONObject2, jSONObject3, set);
        }
    }

    String getChannelString() {
        return this.channel.name().toLowerCase();
    }

    OneSignalStateSynchronizer.UserStateSynchronizerType getChannelType() {
        return this.channel;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected UserState getCurrentUserState() {
        Object object;
        Object object2 = object = this.LOCK;
        synchronized (object2) {
            if (this.currentUserState == null) {
                this.currentUserState = this.newUserState("CURRENT_STATE", true);
            }
            return this.currentUserState;
        }
    }

    abstract String getExternalId(boolean var1);

    protected abstract String getId();

    protected abstract OneSignal.LOG_LEVEL getLogLevel();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected NetworkHandlerThread getNetworkHandlerThread(Integer n) {
        Object object;
        Object object2 = object = this.networkHandlerSyncLock;
        synchronized (object2) {
            if (this.networkHandlerThreads.containsKey((Object)n)) return (NetworkHandlerThread)((Object)this.networkHandlerThreads.get((Object)n));
            this.networkHandlerThreads.put((Object)n, (Object)((Object)new NetworkHandlerThread(n)));
            return (NetworkHandlerThread)((Object)this.networkHandlerThreads.get((Object)n));
        }
    }

    String getRegistrationId() {
        return this.getToSyncUserState().getSyncValues().optString("identifier", null);
    }

    abstract boolean getSubscribed();

    boolean getSyncAsNewSession() {
        return this.getUserStateForModification().getDependValues().optBoolean("session");
    }

    abstract GetTagsResult getTags(boolean var1);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected UserState getToSyncUserState() {
        Object object;
        Object object2 = object = this.LOCK;
        synchronized (object2) {
            if (this.toSyncUserState == null) {
                this.toSyncUserState = this.newUserState("TOSYNC_STATE", true);
            }
            return this.toSyncUserState;
        }
    }

    protected UserState getUserStateForModification() {
        if (this.toSyncUserState == null) {
            this.toSyncUserState = this.getCurrentUserState().deepClone("TOSYNC_STATE");
        }
        this.scheduleSyncToServer();
        return this.toSyncUserState;
    }

    public abstract boolean getUserSubscribePreference();

    boolean hasQueuedHandlers() {
        return this.externalUserIdUpdateHandlers.size() > 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void initUserState() {
        Object object;
        Object object2 = object = this.LOCK;
        synchronized (object2) {
            if (this.currentUserState == null) {
                this.currentUserState = this.newUserState("CURRENT_STATE", true);
            }
        }
        this.getToSyncUserState();
    }

    abstract void logoutEmail();

    protected abstract UserState newUserState(String var1, boolean var2);

    protected abstract void onSuccessfulSync(JSONObject var1);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    boolean persist() {
        Object object;
        if (this.toSyncUserState == null) {
            return false;
        }
        Object object2 = object = this.LOCK;
        synchronized (object2) {
            JSONObject jSONObject = this.currentUserState.generateJsonDiff(this.toSyncUserState, this.isSessionCall());
            boolean bl = false;
            if (jSONObject != null) {
                bl = true;
            }
            this.toSyncUserState.persistState();
            return bl;
        }
    }

    void readyToUpdate(boolean bl) {
        boolean bl2 = this.canMakeUpdates != bl;
        this.canMakeUpdates = bl;
        if (bl2 && bl) {
            this.scheduleSyncToServer();
        }
    }

    void resetCurrentState() {
        this.currentUserState.setSyncValues(new JSONObject());
        this.currentUserState.persistState();
    }

    protected abstract void scheduleSyncToServer();

    void sendTags(JSONObject jSONObject, OneSignal.ChangeTagsUpdateHandler changeTagsUpdateHandler) {
        if (changeTagsUpdateHandler != null) {
            this.sendTagsHandlers.add((Object)changeTagsUpdateHandler);
        }
        this.getUserStateForModification().generateJsonDiffFromIntoSyncValued(jSONObject, null);
    }

    void setExternalUserId(String string2, String string3, OneSignal.OSInternalExternalUserIdUpdateCompletionHandler oSInternalExternalUserIdUpdateCompletionHandler) throws JSONException {
        if (oSInternalExternalUserIdUpdateCompletionHandler != null) {
            this.externalUserIdUpdateHandlers.add((Object)oSInternalExternalUserIdUpdateCompletionHandler);
        }
        UserState userState = this.getUserStateForModification();
        userState.putOnSyncValues("external_user_id", string2);
        if (string3 != null) {
            userState.putOnSyncValues("external_user_id_auth_hash", string3);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    void setNewSession() {
        try {
            Object object;
            Object object2 = object = this.LOCK;
            // MONITORENTER : object2
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
        this.getUserStateForModification().putOnDependValues("session", true);
        this.getUserStateForModification().persistState();
        // MONITOREXIT : object2
    }

    public abstract void setPermission(boolean var1);

    abstract void setSubscription(boolean var1);

    void syncHashedEmail(JSONObject jSONObject) {
        this.getUserStateForModification().generateJsonDiffFromIntoSyncValued(jSONObject, null);
    }

    void syncUserState(boolean bl) {
        this.runningSyncUserState.set(true);
        this.internalSyncUserState(bl);
        this.runningSyncUserState.set(false);
    }

    void updateDeviceInfo(JSONObject jSONObject) {
        this.getUserStateForModification().generateJsonDiffFromIntoSyncValued(jSONObject, null);
    }

    abstract void updateIdDependents(String var1);

    void updateLocation(LocationController.LocationPoint locationPoint) {
        this.getUserStateForModification().setLocation(locationPoint);
    }

    abstract void updateState(JSONObject var1);

    static class GetTagsResult {
        JSONObject result;
        boolean serverSuccess;

        GetTagsResult(boolean bl, JSONObject jSONObject) {
            this.serverSuccess = bl;
            this.result = jSONObject;
        }
    }

    class NetworkHandlerThread
    extends HandlerThread {
        static final int MAX_RETRIES = 3;
        static final int NETWORK_CALL_DELAY_TO_BUFFER_MS = 5000;
        protected static final int NETWORK_HANDLER_USERSTATE;
        int currentRetry;
        Handler mHandler;
        int mType;

        NetworkHandlerThread(int n) {
            super("OSH_NetworkHandlerThread");
            this.mHandler = null;
            this.mType = n;
            this.start();
            this.mHandler = new Handler(this.getLooper());
        }

        private Runnable getNewRunnable() {
            if (this.mType != 0) {
                return null;
            }
            return new Runnable(){

                public void run() {
                    if (!UserStateSynchronizer.this.runningSyncUserState.get()) {
                        UserStateSynchronizer.this.syncUserState(false);
                    }
                }
            };
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        boolean doRetry() {
            Handler handler;
            Handler handler2 = handler = this.mHandler;
            synchronized (handler2) {
                boolean bl = this.currentRetry < 3;
                boolean bl2 = this.mHandler.hasMessages(0);
                if (!bl) return this.mHandler.hasMessages(0);
                if (bl2) return this.mHandler.hasMessages(0);
                this.currentRetry = 1 + this.currentRetry;
                this.mHandler.postDelayed(this.getNewRunnable(), (long)(15000 * this.currentRetry));
                return this.mHandler.hasMessages(0);
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        void runNewJobDelayed() {
            Handler handler;
            if (!UserStateSynchronizer.this.canMakeUpdates) {
                return;
            }
            Handler handler2 = handler = this.mHandler;
            synchronized (handler2) {
                this.currentRetry = 0;
                this.mHandler.removeCallbacksAndMessages(null);
                this.mHandler.postDelayed(this.getNewRunnable(), 5000L);
                return;
            }
        }

        void stopScheduledRunnable() {
            this.mHandler.removeCallbacksAndMessages(null);
        }

    }

}

