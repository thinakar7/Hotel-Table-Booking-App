/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.R
 *  android.R$drawable
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.Notification
 *  android.app.PendingIntent
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.database.Cursor
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.service.notification.StatusBarNotification
 *  android.text.SpannableString
 *  android.text.style.StyleSpan
 *  android.widget.RemoteViews
 *  androidx.core.app.NotificationCompat
 *  androidx.core.app.NotificationCompat$BigPictureStyle
 *  androidx.core.app.NotificationCompat$BigTextStyle
 *  androidx.core.app.NotificationCompat$Builder
 *  androidx.core.app.NotificationCompat$Extender
 *  androidx.core.app.NotificationCompat$InboxStyle
 *  androidx.core.app.NotificationCompat$Style
 *  androidx.core.app.NotificationManagerCompat
 *  com.onesignal.R
 *  com.onesignal.R$id
 *  com.onesignal.R$layout
 *  java.io.InputStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.math.BigInteger
 *  java.net.URL
 *  java.net.URLConnection
 *  java.security.SecureRandom
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Iterator
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.onesignal.AndroidSupportV4Compat;
import com.onesignal.NotificationChannelManager;
import com.onesignal.NotificationExtenderService;
import com.onesignal.NotificationGenerationJob;
import com.onesignal.NotificationLimitManager;
import com.onesignal.NotificationOpenedActivity;
import com.onesignal.NotificationOpenedProcessor;
import com.onesignal.NotificationOpenedReceiver;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalDbHelper;
import com.onesignal.OneSignalNotificationManager;
import com.onesignal.R;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.net.URL;
import java.net.URLConnection;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class GenerateNotification {
    public static final String BUNDLE_KEY_ACTION_ID = "actionId";
    public static final String BUNDLE_KEY_ANDROID_NOTIFICATION_ID = "androidNotificationId";
    public static final String BUNDLE_KEY_ONESIGNAL_DATA = "onesignalData";
    private static Resources contextResources;
    private static Context currentContext;
    private static Class<?> notificationOpenedClass;
    private static boolean openerIsBroadcast;
    private static String packageName;

    static {
        currentContext = null;
        packageName = null;
        contextResources = null;
    }

    GenerateNotification() {
    }

    private static void addAlertButtons(Context context, JSONObject jSONObject, List<String> list, List<String> list2) {
        try {
            GenerateNotification.addCustomAlertButtons(context, jSONObject, list, list2);
        }
        catch (Throwable throwable) {
            OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Failed to parse JSON for custom buttons for alert dialog.", throwable);
        }
        if (list.size() == 0 || list.size() < 3) {
            list.add((Object)OSUtils.getResourceString(context, "onesignal_in_app_alert_ok_button_text", "Ok"));
            list2.add((Object)"__DEFAULT__");
        }
    }

    private static void addBackgroundImage(JSONObject jSONObject, NotificationCompat.Builder builder) throws Throwable {
        if (Build.VERSION.SDK_INT < 16) {
            return;
        }
        String string = jSONObject.optString("bg_img", null);
        Bitmap bitmap = null;
        JSONObject jSONObject2 = null;
        if (string != null) {
            jSONObject2 = new JSONObject(string);
            bitmap = GenerateNotification.getBitmap(jSONObject2.optString("img", null));
        }
        if (bitmap == null) {
            bitmap = GenerateNotification.getBitmapFromAssetsOrResourceName("onesignal_bgimage_default_image");
        }
        if (bitmap != null) {
            String string2;
            RemoteViews remoteViews = new RemoteViews(currentContext.getPackageName(), R.layout.onesignal_bgimage_notif_layout);
            remoteViews.setTextViewText(R.id.os_bgimage_notif_title, GenerateNotification.getTitle(jSONObject));
            remoteViews.setTextViewText(R.id.os_bgimage_notif_body, (CharSequence)jSONObject.optString("alert"));
            GenerateNotification.setTextColor(remoteViews, jSONObject2, R.id.os_bgimage_notif_title, "tc", "onesignal_bgimage_notif_title_color");
            GenerateNotification.setTextColor(remoteViews, jSONObject2, R.id.os_bgimage_notif_body, "bc", "onesignal_bgimage_notif_body_color");
            if (jSONObject2 != null && jSONObject2.has("img_align")) {
                string2 = jSONObject2.getString("img_align");
            } else {
                int n = contextResources.getIdentifier("onesignal_bgimage_notif_image_align", "string", packageName);
                string2 = null;
                if (n != 0) {
                    string2 = contextResources.getString(n);
                }
            }
            if ("right".equals((Object)string2)) {
                remoteViews.setViewPadding(R.id.os_bgimage_notif_bgimage_align_layout, -5000, 0, 0, 0);
                remoteViews.setImageViewBitmap(R.id.os_bgimage_notif_bgimage_right_aligned, bitmap);
                remoteViews.setViewVisibility(R.id.os_bgimage_notif_bgimage_right_aligned, 0);
                remoteViews.setViewVisibility(R.id.os_bgimage_notif_bgimage, 2);
            } else {
                remoteViews.setImageViewBitmap(R.id.os_bgimage_notif_bgimage, bitmap);
            }
            builder.setContent(remoteViews);
            builder.setStyle(null);
        }
    }

    private static void addCustomAlertButtons(Context context, JSONObject jSONObject, List<String> list, List<String> list2) throws JSONException {
        JSONObject jSONObject2 = new JSONObject(jSONObject.optString("custom"));
        if (!jSONObject2.has("a")) {
            return;
        }
        JSONObject jSONObject3 = jSONObject2.getJSONObject("a");
        if (!jSONObject3.has("actionButtons")) {
            return;
        }
        JSONArray jSONArray = jSONObject3.optJSONArray("actionButtons");
        for (int i = 0; i < jSONArray.length(); ++i) {
            JSONObject jSONObject4 = jSONArray.getJSONObject(i);
            list.add((Object)jSONObject4.optString("text"));
            list2.add((Object)jSONObject4.optString("id"));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void addNotificationActionButtons(JSONObject jSONObject, NotificationCompat.Builder builder, int n, String string) {
        JSONArray jSONArray;
        try {
            JSONObject jSONObject2 = new JSONObject(jSONObject.optString("custom"));
            if (!jSONObject2.has("a")) {
                return;
            }
            JSONObject jSONObject3 = jSONObject2.getJSONObject("a");
            if (!jSONObject3.has("actionButtons")) {
                return;
            }
            jSONArray = jSONObject3.getJSONArray("actionButtons");
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return;
        }
        for (int i = 0; i < jSONArray.length(); ++i) {
            JSONObject jSONObject4 = jSONArray.optJSONObject(i);
            JSONObject jSONObject5 = new JSONObject(jSONObject.toString());
            Intent intent = GenerateNotification.getNewBaseIntent(n);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
            intent.setAction(stringBuilder.toString());
            intent.putExtra("action_button", true);
            jSONObject5.put(BUNDLE_KEY_ACTION_ID, (Object)jSONObject4.optString("id"));
            intent.putExtra(BUNDLE_KEY_ONESIGNAL_DATA, jSONObject5.toString());
            if (string != null) {
                intent.putExtra("summary", string);
            } else if (jSONObject.has("grp")) {
                intent.putExtra("grp", jSONObject.optString("grp"));
            }
            PendingIntent pendingIntent = GenerateNotification.getNewActionPendingIntent(n, intent);
            boolean bl = jSONObject4.has("icon");
            int n2 = 0;
            if (bl) {
                n2 = GenerateNotification.getResourceIcon(jSONObject4.optString("icon"));
            }
            builder.addAction(n2, (CharSequence)jSONObject4.optString("text"), pendingIntent);
        }
    }

    private static void addXiaomiSettings(OneSignalNotificationBuilder oneSignalNotificationBuilder, Notification notification) {
        if (!oneSignalNotificationBuilder.hasLargeIcon) {
            return;
        }
        try {
            Object object = Class.forName((String)"android.app.MiuiNotification").newInstance();
            Field field = object.getClass().getDeclaredField("customizedIcon");
            field.setAccessible(true);
            field.set(object, (Object)true);
            Field field2 = notification.getClass().getField("extraNotification");
            field2.setAccessible(true);
            field2.set((Object)notification, object);
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    private static void applyNotificationExtender(NotificationGenerationJob notificationGenerationJob, NotificationCompat.Builder builder) {
        if (notificationGenerationJob.overrideSettings != null) {
            if (notificationGenerationJob.overrideSettings.extender == null) {
                return;
            }
            try {
                Field field = NotificationCompat.Builder.class.getDeclaredField("mNotification");
                field.setAccessible(true);
                Notification notification = (Notification)field.get((Object)builder);
                notificationGenerationJob.orgFlags = notification.flags;
                notificationGenerationJob.orgSound = notification.sound;
                builder.extend(notificationGenerationJob.overrideSettings.extender);
                Notification notification2 = (Notification)field.get((Object)builder);
                Field field2 = NotificationCompat.Builder.class.getDeclaredField("mContentText");
                field2.setAccessible(true);
                CharSequence charSequence = (CharSequence)field2.get((Object)builder);
                Field field3 = NotificationCompat.Builder.class.getDeclaredField("mContentTitle");
                field3.setAccessible(true);
                CharSequence charSequence2 = (CharSequence)field3.get((Object)builder);
                notificationGenerationJob.overriddenBodyFromExtender = charSequence;
                notificationGenerationJob.overriddenTitleFromExtender = charSequence2;
                if (!notificationGenerationJob.restoring) {
                    notificationGenerationJob.overriddenFlags = notification2.flags;
                    notificationGenerationJob.overriddenSound = notification2.sound;
                }
                return;
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
                return;
            }
        }
    }

    private static int convertOSToAndroidPriority(int n) {
        if (n > 9) {
            return 2;
        }
        if (n > 7) {
            return 1;
        }
        if (n > 4) {
            return 0;
        }
        if (n > 2) {
            return -1;
        }
        return -2;
    }

    private static Intent createBaseSummaryIntent(int n, JSONObject jSONObject, String string) {
        return GenerateNotification.getNewBaseIntent(n).putExtra(BUNDLE_KEY_ONESIGNAL_DATA, jSONObject.toString()).putExtra("summary", string);
    }

    private static void createGenericPendingIntentsForGroup(NotificationCompat.Builder builder, JSONObject jSONObject, String string, int n) {
        SecureRandom secureRandom = new SecureRandom();
        builder.setContentIntent(GenerateNotification.getNewActionPendingIntent(secureRandom.nextInt(), GenerateNotification.getNewBaseIntent(n).putExtra(BUNDLE_KEY_ONESIGNAL_DATA, jSONObject.toString()).putExtra("grp", string)));
        builder.setDeleteIntent(GenerateNotification.getNewActionPendingIntent(secureRandom.nextInt(), GenerateNotification.getNewBaseDeleteIntent(n).putExtra("grp", string)));
        builder.setGroup(string);
        try {
            builder.setGroupAlertBehavior(1);
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    private static Notification createGenericPendingIntentsForNotif(NotificationCompat.Builder builder, JSONObject jSONObject, int n) {
        SecureRandom secureRandom = new SecureRandom();
        builder.setContentIntent(GenerateNotification.getNewActionPendingIntent(secureRandom.nextInt(), GenerateNotification.getNewBaseIntent(n).putExtra(BUNDLE_KEY_ONESIGNAL_DATA, jSONObject.toString())));
        builder.setDeleteIntent(GenerateNotification.getNewActionPendingIntent(secureRandom.nextInt(), GenerateNotification.getNewBaseDeleteIntent(n)));
        return builder.build();
    }

    private static void createGrouplessSummaryNotification(NotificationGenerationJob notificationGenerationJob, int n) {
        JSONObject jSONObject = notificationGenerationJob.jsonPayload;
        SecureRandom secureRandom = new SecureRandom();
        String string = OneSignalNotificationManager.getGrouplessSummaryKey();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(n);
        stringBuilder.append(" new messages");
        String string2 = stringBuilder.toString();
        int n2 = OneSignalNotificationManager.getGrouplessSummaryId();
        PendingIntent pendingIntent = GenerateNotification.getNewActionPendingIntent(secureRandom.nextInt(), GenerateNotification.createBaseSummaryIntent(n2, jSONObject, string));
        PendingIntent pendingIntent2 = GenerateNotification.getNewActionPendingIntent(secureRandom.nextInt(), GenerateNotification.getNewBaseDeleteIntent(0).putExtra("summary", string));
        NotificationCompat.Builder builder = GenerateNotification.getBaseOneSignalNotificationBuilder((NotificationGenerationJob)notificationGenerationJob).compatBuilder;
        if (notificationGenerationJob.overriddenSound != null) {
            builder.setSound(notificationGenerationJob.overriddenSound);
        }
        if (notificationGenerationJob.overriddenFlags != null) {
            builder.setDefaults(notificationGenerationJob.overriddenFlags.intValue());
        }
        builder.setContentIntent(pendingIntent).setDeleteIntent(pendingIntent2).setContentTitle(currentContext.getPackageManager().getApplicationLabel(currentContext.getApplicationInfo())).setContentText((CharSequence)string2).setNumber(n).setSmallIcon(GenerateNotification.getDefaultSmallIconId()).setLargeIcon(GenerateNotification.getDefaultLargeIcon()).setOnlyAlertOnce(true).setAutoCancel(false).setGroup(string).setGroupSummary(true);
        try {
            builder.setGroupAlertBehavior(1);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle();
        inboxStyle.setBigContentTitle((CharSequence)string2);
        builder.setStyle((NotificationCompat.Style)inboxStyle);
        Notification notification = builder.build();
        NotificationManagerCompat.from((Context)currentContext).notify(n2, notification);
    }

    private static Notification createSingleNotificationBeforeSummaryBuilder(NotificationGenerationJob notificationGenerationJob, NotificationCompat.Builder builder) {
        boolean bl = Build.VERSION.SDK_INT > 17 && Build.VERSION.SDK_INT < 24 && !notificationGenerationJob.restoring;
        if (bl && notificationGenerationJob.overriddenSound != null && !notificationGenerationJob.overriddenSound.equals((Object)notificationGenerationJob.orgSound)) {
            builder.setSound(null);
        }
        Notification notification = builder.build();
        if (bl) {
            builder.setSound(notificationGenerationJob.overriddenSound);
        }
        return notification;
    }

    private static void createSummaryIdDatabaseEntry(OneSignalDbHelper oneSignalDbHelper, String string, int n) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("android_notification_id", Integer.valueOf((int)n));
        contentValues.put("group_id", string);
        contentValues.put("is_summary", Integer.valueOf((int)1));
        oneSignalDbHelper.insertOrThrow("notification", null, contentValues);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void createSummaryNotification(NotificationGenerationJob var0, OneSignalNotificationBuilder var1_1) {
        block50 : {
            block55 : {
                block52 : {
                    block51 : {
                        block49 : {
                            block48 : {
                                var2_2 = "message";
                                var3_3 = "title";
                                var4_4 = "is_summary";
                                var5_5 = var0.restoring;
                                var6_6 = var0.jsonPayload;
                                var7_7 = var6_6.optString("grp", null);
                                var8_8 = new SecureRandom();
                                var9_9 = GenerateNotification.getNewActionPendingIntent(var8_8.nextInt(), GenerateNotification.getNewBaseDeleteIntent(0).putExtra("summary", var7_7));
                                var10_10 = null;
                                var11_11 = null;
                                var12_12 = OneSignalDbHelper.getInstance(GenerateNotification.currentContext);
                                var13_13 = null;
                                try {
                                    var14_14 = new String[]{"android_notification_id", "full_data", var4_4, var3_3, var2_2};
                                }
                                catch (Throwable var17_24) {
                                    // empty catch block
                                    break block50;
                                }
                                var15_15 = new String[]{var7_7};
                                if (var5_5) break block48;
                                try {
                                    if (var0.getAndroidId() == -1) break block48;
                                    var98_16 = new StringBuilder();
                                    var98_16.append("group_id = ? AND dismissed = 0 AND opened = 0");
                                    var98_16.append(" AND android_notification_id <> ");
                                    var98_16.append((Object)var0.getAndroidId());
                                    var16_17 = var98_16.toString();
                                    break block49;
                                }
                                catch (Throwable var17_18) {
                                    var13_13 = null;
                                    break block50;
                                }
                            }
                            var16_17 = "group_id = ? AND dismissed = 0 AND opened = 0";
                        }
                        var18_26 = var12_12.query("notification", var14_14, var16_17, var15_15, null, null, "_id DESC");
                        var19_27 = var18_26.moveToFirst();
                        var21_28 = null;
                        if (!var19_27) break block51;
                        try {
                            var67_30 = var66_29 = new ArrayList();
                            break block52;
                        }
                        catch (Throwable var17_21) {
                            var13_13 = var18_26;
                            break block50;
                        }
                    }
                    var22_48 = var6_6;
                    break block55;
                    catch (Throwable var17_22) {
                        var13_13 = var18_26;
                    }
                    break block50;
                    catch (Throwable var17_23) {
                        var13_13 = null;
                    }
                    break block50;
                }
                do lbl-1000: // 2 sources:
                {
                    var70_31 = var18_26.getInt(var18_26.getColumnIndex(var4_4));
                    var71_32 = var4_4;
                    if (var70_31 != 1) break block53;
                    break;
                } while (true);
                catch (Throwable var17_20) {
                    var13_13 = var18_26;
                    break block50;
                }
                {
                    block54 : {
                        block53 : {
                            var97_46 = var18_26.getInt(var18_26.getColumnIndex("android_notification_id"));
                            var78_37 = var2_2;
                            var21_28 = var97_46;
                            var79_38 = var3_3;
                            var86_42 = var67_30;
                            ** GOTO lbl99
                        }
                        var72_33 = var18_26.getString(var18_26.getColumnIndex(var3_3));
                        if (var72_33 == null) {
                            var76_35 = "";
                        } else {
                            var73_34 = new StringBuilder();
                            var73_34.append(var72_33);
                            var73_34.append(" ");
                            var76_35 = var73_34.toString();
                        }
                        var77_36 = var18_26.getString(var18_26.getColumnIndex(var2_2));
                        var78_37 = var2_2;
                        var79_38 = var3_3;
                        var80_39 = new StringBuilder();
                        var80_39.append(var76_35);
                        var80_39.append(var77_36);
                        var83_40 = new SpannableString((CharSequence)var80_39.toString());
                        var84_41 = var76_35.length();
                        if (var84_41 <= 0) break block54;
                        var93_44 = new StyleSpan(1);
                        var95_45 = var76_35.length();
                        var83_40.setSpan((Object)var93_44, 0, var95_45, 0);
                    }
                    var86_42 = var67_30;
                    try {
                        var86_42.add((Object)var83_40);
                        if (var10_10 == null) {
                            var10_10 = var18_26.getString(var18_26.getColumnIndex("full_data"));
                        }
lbl99: // 4 sources:
                        var90_43 = var18_26.moveToNext();
                        if (!var90_43) {
                            if (var5_5 && var10_10 != null) {
                                try {
                                    var91_47 = new JSONObject(var10_10);
                                    var11_11 = var86_42;
                                    var22_48 = var91_47;
                                    break block55;
                                }
                                catch (JSONException var92_49) {
                                    var92_49.printStackTrace();
                                }
                            }
                            var11_11 = var86_42;
                            var22_48 = var6_6;
                            break block55;
                        }
                        var67_30 = var86_42;
                        var4_4 = var71_32;
                        var2_2 = var78_37;
                        var3_3 = var79_38;
                        continue;
                    }
                    catch (Throwable var17_19) {
                        var13_13 = var18_26;
                        break block50;
                    }
                    ** while (true)
                }
            }
            if (var18_26 != null && !var18_26.isClosed()) {
                var18_26.close();
            }
            if (var21_28 == null) {
                var21_28 = var8_8.nextInt();
                GenerateNotification.createSummaryIdDatabaseEntry(var12_12, var7_7, var21_28);
            }
            var23_50 = GenerateNotification.getNewActionPendingIntent(var8_8.nextInt(), GenerateNotification.createBaseSummaryIntent(var21_28, var22_48, var7_7));
            if (var11_11 != null && (var5_5 && var11_11.size() > 1 || !var5_5 && var11_11.size() > 0)) {
                var29_51 = var11_11.size() + (var5_5 ^ true);
                var30_52 = var22_48.optString("grp_msg", null);
                if (var30_52 == null) {
                    var31_53 = new StringBuilder();
                    var31_53.append(var29_51);
                    var31_53.append(" new messages");
                    var34_54 = var31_53.toString();
                } else {
                    var63_55 = new StringBuilder();
                    var63_55.append("");
                    var63_55.append(var29_51);
                    var34_54 = var30_52.replace((CharSequence)"$[notif_count]", (CharSequence)var63_55.toString());
                }
                var35_56 = GenerateNotification.getBaseOneSignalNotificationBuilder((NotificationGenerationJob)var0).compatBuilder;
                if (var5_5) {
                    GenerateNotification.removeNotifyOptions(var35_56);
                } else {
                    if (var0.overriddenSound != null) {
                        var35_56.setSound(var0.overriddenSound);
                    }
                    if (var0.overriddenFlags != null) {
                        var35_56.setDefaults(var0.overriddenFlags.intValue());
                    }
                }
                var35_56.setContentIntent(var23_50).setDeleteIntent(var9_9).setContentTitle(GenerateNotification.currentContext.getPackageManager().getApplicationLabel(GenerateNotification.currentContext.getApplicationInfo())).setContentText((CharSequence)var34_54).setNumber(var29_51).setSmallIcon(GenerateNotification.getDefaultSmallIconId()).setLargeIcon(GenerateNotification.getDefaultLargeIcon()).setOnlyAlertOnce(var5_5).setAutoCancel(false).setGroup(var7_7).setGroupSummary(true);
                try {
                    var35_56.setGroupAlertBehavior(1);
                }
                catch (Throwable var37_57) {
                    // empty catch block
                }
                if (!var5_5) {
                    var35_56.setTicker((CharSequence)var34_54);
                }
                var38_58 = new NotificationCompat.InboxStyle();
                if (!var5_5) {
                    var43_59 = var0.getTitle();
                    var44_60 = null;
                    if (var43_59 != null) {
                        var44_60 = var0.getTitle().toString();
                    }
                    if (var44_60 == null) {
                        var48_61 = "";
                    } else {
                        var45_62 = new StringBuilder();
                        var45_62.append(var44_60);
                        var45_62.append(" ");
                        var48_61 = var45_62.toString();
                    }
                    var49_63 = var0.getBody().toString();
                    var50_64 = new StringBuilder();
                    var50_64.append(var48_61);
                    var50_64.append(var49_63);
                    var53_65 = new SpannableString((CharSequence)var50_64.toString());
                    if (var48_61.length() > 0) {
                        var54_66 = new StyleSpan(1);
                        var55_67 = var48_61.length();
                        var53_65.setSpan((Object)var54_66, 0, var55_67, 0);
                    }
                    var38_58.addLine((CharSequence)var53_65);
                }
                var39_68 = var11_11.iterator();
                while (var39_68.hasNext()) {
                    var38_58.addLine((CharSequence)((SpannableString)var39_68.next()));
                }
                var38_58.setBigContentTitle((CharSequence)var34_54);
                var35_56.setStyle((NotificationCompat.Style)var38_58);
                var27_69 = var35_56.build();
            } else {
                var24_70 = var1_1.compatBuilder;
                var24_70.mActions.clear();
                GenerateNotification.addNotificationActionButtons(var22_48, var24_70, var21_28, var7_7);
                var24_70.setContentIntent(var23_50).setDeleteIntent(var9_9).setOnlyAlertOnce(var5_5).setAutoCancel(false).setGroup(var7_7).setGroupSummary(true);
                try {
                    var24_70.setGroupAlertBehavior(1);
                }
                catch (Throwable var26_71) {
                    // empty catch block
                }
                var27_69 = var24_70.build();
                GenerateNotification.addXiaomiSettings(var1_1, var27_69);
            }
            NotificationManagerCompat.from((Context)GenerateNotification.currentContext).notify(var21_28.intValue(), var27_69);
            return;
        }
        if (var13_13 == null) throw var17_25;
        if (var13_13.isClosed() != false) throw var17_25;
        var13_13.close();
        throw var17_25;
    }

    static void fromJsonPayload(NotificationGenerationJob notificationGenerationJob) {
        GenerateNotification.setStatics(notificationGenerationJob.context);
        Activity activity = OneSignal.getCurrentActivity();
        if (!notificationGenerationJob.restoring && notificationGenerationJob.showAsAlert && activity != null) {
            GenerateNotification.showNotificationAsAlert(notificationGenerationJob.jsonPayload, activity, notificationGenerationJob.getAndroidId());
            return;
        }
        GenerateNotification.showNotification(notificationGenerationJob);
    }

    private static BigInteger getAccentColor(JSONObject jSONObject) {
        block6 : {
            String string;
            try {
                if (jSONObject.has("bgac")) {
                    BigInteger bigInteger = new BigInteger(jSONObject.optString("bgac", null), 16);
                    return bigInteger;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            try {
                string = OSUtils.getManifestMeta(currentContext, "com.onesignal.NotificationAccentColor.DEFAULT");
                if (string == null) break block6;
            }
            catch (Throwable throwable) {
                return null;
            }
            BigInteger bigInteger = new BigInteger(string, 16);
            return bigInteger;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static OneSignalNotificationBuilder getBaseOneSignalNotificationBuilder(NotificationGenerationJob notificationGenerationJob) {
        Bitmap bitmap;
        NotificationCompat.Builder builder;
        JSONObject jSONObject = notificationGenerationJob.jsonPayload;
        OneSignalNotificationBuilder oneSignalNotificationBuilder = new OneSignalNotificationBuilder();
        try {
            NotificationCompat.Builder builder2;
            String string = NotificationChannelManager.createNotificationChannel(notificationGenerationJob);
            builder = builder2 = new NotificationCompat.Builder(currentContext, string);
        }
        catch (Throwable throwable) {
            builder = new NotificationCompat.Builder(currentContext);
        }
        String string = jSONObject.optString("alert", null);
        builder.setAutoCancel(true).setSmallIcon(GenerateNotification.getSmallIconId(jSONObject)).setStyle((NotificationCompat.Style)new NotificationCompat.BigTextStyle().bigText((CharSequence)string)).setContentText((CharSequence)string).setTicker((CharSequence)string);
        if (Build.VERSION.SDK_INT < 24 || !jSONObject.optString("title").equals((Object)"")) {
            builder.setContentTitle(GenerateNotification.getTitle(jSONObject));
        }
        try {
            BigInteger bigInteger = GenerateNotification.getAccentColor(jSONObject);
            if (bigInteger != null) {
                builder.setColor(bigInteger.intValue());
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        int n = 1;
        try {
            if (jSONObject.has("vis")) {
                n = Integer.parseInt((String)jSONObject.optString("vis"));
            }
            builder.setVisibility(n);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        Bitmap bitmap2 = GenerateNotification.getLargeIcon(jSONObject);
        if (bitmap2 != null) {
            oneSignalNotificationBuilder.hasLargeIcon = true;
            builder.setLargeIcon(bitmap2);
        }
        if ((bitmap = GenerateNotification.getBitmap(jSONObject.optString("bicon", null))) != null) {
            builder.setStyle((NotificationCompat.Style)new NotificationCompat.BigPictureStyle().bigPicture(bitmap).setSummaryText((CharSequence)string));
        }
        if (notificationGenerationJob.shownTimeStamp != null) {
            try {
                builder.setWhen(1000L * notificationGenerationJob.shownTimeStamp);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        GenerateNotification.setAlertnessOptions(jSONObject, builder);
        oneSignalNotificationBuilder.compatBuilder = builder;
        return oneSignalNotificationBuilder;
    }

    private static Bitmap getBitmap(String string) {
        if (string == null) {
            return null;
        }
        String string2 = string.trim();
        if (!string2.startsWith("http://") && !string2.startsWith("https://")) {
            return GenerateNotification.getBitmapFromAssetsOrResourceName(string);
        }
        return GenerateNotification.getBitmapFromURL(string2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Bitmap getBitmapFromAssetsOrResourceName(String var0) {
        var1_1 = null;
        try {
            var1_1 = var14_2 = BitmapFactory.decodeStream((InputStream)GenerateNotification.currentContext.getAssets().open(var0));
        }
        catch (Throwable var2_3) {
            // empty catch block
        }
        if (var1_1 != null) {
            return var1_1;
        }
        ** for (var7_5 : Arrays.asList((Object[])new String[]{".png", ".webp", ".jpg", ".gif", ".bmp"}))
lbl-1000: // 1 sources:
        {
            try {
                var9_7 = GenerateNotification.currentContext.getAssets();
                var10_8 = new StringBuilder();
                var10_8.append(var0);
                var10_8.append(var7_5);
                var1_1 = var13_9 = BitmapFactory.decodeStream((InputStream)var9_7.open(var10_8.toString()));
            }
            catch (Throwable var8_6) {
                // empty catch block
            }
            if (var1_1 == null) continue;
            return var1_1;
        }
lbl22: // 1 sources:
        try {
            var5_10 = GenerateNotification.getResourceIcon(var0);
            if (var5_10 == 0) return null;
            return BitmapFactory.decodeResource((Resources)GenerateNotification.contextResources, (int)var5_10);
        }
        catch (Throwable var3_12) {
            // empty catch block
        }
        return null;
    }

    private static Bitmap getBitmapFromURL(String string) {
        try {
            Bitmap bitmap = BitmapFactory.decodeStream((InputStream)new URL(string).openConnection().getInputStream());
            return bitmap;
        }
        catch (Throwable throwable) {
            OneSignal.Log(OneSignal.LOG_LEVEL.WARN, "Could not download image!", throwable);
            return null;
        }
    }

    private static Bitmap getDefaultLargeIcon() {
        return GenerateNotification.resizeBitmapForLargeIconArea(GenerateNotification.getBitmapFromAssetsOrResourceName("ic_onesignal_large_icon_default"));
    }

    private static int getDefaultSmallIconId() {
        int n = GenerateNotification.getDrawableId("ic_stat_onesignal_default");
        if (n != 0) {
            return n;
        }
        int n2 = GenerateNotification.getDrawableId("corona_statusbar_icon_default");
        if (n2 != 0) {
            return n2;
        }
        int n3 = GenerateNotification.getDrawableId("ic_os_notification_fallback_white_24dp");
        if (n3 != 0) {
            return n3;
        }
        return 17301598;
    }

    private static int getDrawableId(String string) {
        return contextResources.getIdentifier(string, "drawable", packageName);
    }

    private static Bitmap getLargeIcon(JSONObject jSONObject) {
        Bitmap bitmap = GenerateNotification.getBitmap(jSONObject.optString("licon"));
        if (bitmap == null) {
            bitmap = GenerateNotification.getBitmapFromAssetsOrResourceName("ic_onesignal_large_icon_default");
        }
        if (bitmap == null) {
            return null;
        }
        return GenerateNotification.resizeBitmapForLargeIconArea(bitmap);
    }

    private static PendingIntent getNewActionPendingIntent(int n, Intent intent) {
        if (openerIsBroadcast) {
            return PendingIntent.getBroadcast((Context)currentContext, (int)n, (Intent)intent, (int)134217728);
        }
        return PendingIntent.getActivity((Context)currentContext, (int)n, (Intent)intent, (int)134217728);
    }

    private static Intent getNewBaseDeleteIntent(int n) {
        Intent intent = new Intent(currentContext, notificationOpenedClass).putExtra(BUNDLE_KEY_ANDROID_NOTIFICATION_ID, n).putExtra("dismissed", true);
        if (openerIsBroadcast) {
            return intent;
        }
        return intent.addFlags(402718720);
    }

    private static Intent getNewBaseIntent(int n) {
        Intent intent = new Intent(currentContext, notificationOpenedClass).putExtra(BUNDLE_KEY_ANDROID_NOTIFICATION_ID, n);
        if (openerIsBroadcast) {
            return intent;
        }
        return intent.addFlags(603979776);
    }

    private static int getResourceIcon(String string) {
        if (string == null) {
            return 0;
        }
        String string2 = string.trim();
        if (!OSUtils.isValidResourceName(string2)) {
            return 0;
        }
        int n = GenerateNotification.getDrawableId(string2);
        if (n != 0) {
            return n;
        }
        try {
            int n2 = R.drawable.class.getField(string).getInt(null);
            return n2;
        }
        catch (Throwable throwable) {
            return 0;
        }
    }

    private static int getSmallIconId(JSONObject jSONObject) {
        int n = GenerateNotification.getResourceIcon(jSONObject.optString("sicon", null));
        if (n != 0) {
            return n;
        }
        return GenerateNotification.getDefaultSmallIconId();
    }

    private static CharSequence getTitle(JSONObject jSONObject) {
        String string = jSONObject.optString("title", null);
        if (string != null) {
            return string;
        }
        return currentContext.getPackageManager().getApplicationLabel(currentContext.getApplicationInfo());
    }

    private static boolean isSoundEnabled(JSONObject jSONObject) {
        String string = jSONObject.optString("sound", null);
        if (!"null".equals((Object)string) && !"nil".equals((Object)string)) {
            return OneSignal.getSoundEnabled();
        }
        return false;
    }

    private static void removeNotifyOptions(NotificationCompat.Builder builder) {
        builder.setOnlyAlertOnce(true).setDefaults(0).setSound(null).setVibrate(null).setTicker(null);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Bitmap resizeBitmapForLargeIconArea(Bitmap bitmap) {
        int n;
        int n2;
        int n3;
        int n4;
        block6 : {
            if (bitmap == null) {
                return null;
            }
            try {
                int n5 = (int)contextResources.getDimension(17104902);
                int n6 = (int)contextResources.getDimension(17104901);
                n2 = bitmap.getHeight();
                n3 = bitmap.getWidth();
                if (n3 <= n6) {
                    if (n2 <= n5) return bitmap;
                }
                n4 = n6;
                n = n5;
                if (n2 <= n3) break block6;
            }
            catch (Throwable throwable) {
                return bitmap;
            }
            n4 = (int)((float)n3 / (float)n2 * (float)n);
            return Bitmap.createScaledBitmap((Bitmap)bitmap, (int)n4, (int)n, (boolean)true);
        }
        if (n3 <= n2) return Bitmap.createScaledBitmap((Bitmap)bitmap, (int)n4, (int)n, (boolean)true);
        n = (int)((float)n2 / (float)n3 * (float)n4);
        return Bitmap.createScaledBitmap((Bitmap)bitmap, (int)n4, (int)n, (boolean)true);
    }

    private static Integer safeGetColorFromHex(JSONObject jSONObject, String string) {
        if (jSONObject != null) {
            try {
                if (jSONObject.has(string)) {
                    Integer n = new BigInteger(jSONObject.optString(string), 16).intValue();
                    return n;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return null;
    }

    private static void setAlertnessOptions(JSONObject jSONObject, NotificationCompat.Builder builder) {
        int n;
        int n2 = GenerateNotification.convertOSToAndroidPriority(jSONObject.optInt("pri", 6));
        builder.setPriority(n2);
        boolean bl = n2 < 0;
        if (bl) {
            return;
        }
        if (jSONObject.has("ledc") && jSONObject.optInt("led", 1) == 1) {
            try {
                builder.setLights(new BigInteger(jSONObject.optString("ledc"), 16).intValue(), 2000, 5000);
                n = 0;
            }
            catch (Throwable throwable) {
                n = 0 | 4;
            }
        } else {
            n = 0 | 4;
        }
        if (OneSignal.getVibrate() && jSONObject.optInt("vib", 1) == 1) {
            if (jSONObject.has("vib_pt")) {
                long[] arrl = OSUtils.parseVibrationPattern(jSONObject);
                if (arrl != null) {
                    builder.setVibrate(arrl);
                }
            } else {
                n |= 2;
            }
        }
        if (GenerateNotification.isSoundEnabled(jSONObject)) {
            Uri uri = OSUtils.getSoundUri(currentContext, jSONObject.optString("sound", null));
            if (uri != null) {
                builder.setSound(uri);
            } else {
                n |= 1;
            }
        }
        builder.setDefaults(n);
    }

    private static void setStatics(Context context) {
        currentContext = context;
        packageName = context.getPackageName();
        contextResources = currentContext.getResources();
        PackageManager packageManager = currentContext.getPackageManager();
        Intent intent = new Intent(currentContext, NotificationOpenedReceiver.class);
        intent.setPackage(currentContext.getPackageName());
        if (packageManager.queryBroadcastReceivers(intent, 0).size() > 0) {
            openerIsBroadcast = true;
            notificationOpenedClass = NotificationOpenedReceiver.class;
            return;
        }
        notificationOpenedClass = NotificationOpenedActivity.class;
    }

    private static void setTextColor(RemoteViews remoteViews, JSONObject jSONObject, int n, String string, String string2) {
        Integer n2 = GenerateNotification.safeGetColorFromHex(jSONObject, string);
        if (n2 != null) {
            remoteViews.setTextColor(n, n2.intValue());
            return;
        }
        int n3 = contextResources.getIdentifier(string2, "color", packageName);
        if (n3 != 0) {
            remoteViews.setTextColor(n, AndroidSupportV4Compat.ContextCompat.getColor(currentContext, n3));
        }
    }

    private static void showNotification(NotificationGenerationJob notificationGenerationJob) {
        Notification notification;
        int n = notificationGenerationJob.getAndroidId();
        JSONObject jSONObject = notificationGenerationJob.jsonPayload;
        String string = jSONObject.optString("grp", null);
        ArrayList<StatusBarNotification> arrayList = new ArrayList<StatusBarNotification>();
        if (Build.VERSION.SDK_INT >= 24) {
            arrayList = OneSignalNotificationManager.getActiveGrouplessNotifications(currentContext);
            if (string == null && arrayList.size() >= 3) {
                string = OneSignalNotificationManager.getGrouplessSummaryKey();
                OneSignalNotificationManager.assignGrouplessNotifications(currentContext, arrayList);
            }
        }
        OneSignalNotificationBuilder oneSignalNotificationBuilder = GenerateNotification.getBaseOneSignalNotificationBuilder(notificationGenerationJob);
        NotificationCompat.Builder builder = oneSignalNotificationBuilder.compatBuilder;
        GenerateNotification.addNotificationActionButtons(jSONObject, builder, n, null);
        try {
            GenerateNotification.addBackgroundImage(jSONObject, builder);
        }
        catch (Throwable throwable) {
            OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Could not set background notification image!", throwable);
        }
        GenerateNotification.applyNotificationExtender(notificationGenerationJob, builder);
        if (notificationGenerationJob.restoring) {
            GenerateNotification.removeNotifyOptions(builder);
        }
        int n2 = 1;
        if (string != null) {
            n2 = 2;
        }
        NotificationLimitManager.clearOldestOverLimit(currentContext, n2);
        if (string != null) {
            GenerateNotification.createGenericPendingIntentsForGroup(builder, jSONObject, string, n);
            notification = GenerateNotification.createSingleNotificationBeforeSummaryBuilder(notificationGenerationJob, builder);
            if (Build.VERSION.SDK_INT >= 24 && string.equals((Object)OneSignalNotificationManager.getGrouplessSummaryKey())) {
                GenerateNotification.createGrouplessSummaryNotification(notificationGenerationJob, 1 + arrayList.size());
            } else {
                GenerateNotification.createSummaryNotification(notificationGenerationJob, oneSignalNotificationBuilder);
            }
        } else {
            notification = GenerateNotification.createGenericPendingIntentsForNotif(builder, jSONObject, n);
        }
        if (string == null || Build.VERSION.SDK_INT > 17) {
            GenerateNotification.addXiaomiSettings(oneSignalNotificationBuilder, notification);
            NotificationManagerCompat.from((Context)currentContext).notify(n, notification);
        }
    }

    private static void showNotificationAsAlert(final JSONObject jSONObject, final Activity activity, final int n) {
        activity.runOnUiThread(new Runnable(){

            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder((Context)activity);
                builder.setTitle(GenerateNotification.getTitle(jSONObject));
                builder.setMessage((CharSequence)jSONObject.optString("alert"));
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                GenerateNotification.addAlertButtons((Context)activity, jSONObject, (List<String>)((List)arrayList), (List<String>)((List)arrayList2));
                final Intent intent = GenerateNotification.getNewBaseIntent(n);
                intent.putExtra("action_button", true);
                intent.putExtra("from_alert", true);
                intent.putExtra(GenerateNotification.BUNDLE_KEY_ONESIGNAL_DATA, jSONObject.toString());
                if (jSONObject.has("grp")) {
                    intent.putExtra("grp", jSONObject.optString("grp"));
                }
                DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener((List)arrayList2, intent){
                    final /* synthetic */ List val$finalButtonIds;
                    final /* synthetic */ Intent val$finalButtonIntent;
                    {
                        this.val$finalButtonIds = list;
                        this.val$finalButtonIntent = intent;
                    }

                    public void onClick(DialogInterface dialogInterface, int n) {
                        int n2 = n + 3;
                        if (this.val$finalButtonIds.size() > 1) {
                            try {
                                JSONObject jSONObject = new JSONObject(jSONObject.toString());
                                jSONObject.put(GenerateNotification.BUNDLE_KEY_ACTION_ID, this.val$finalButtonIds.get(n2));
                                this.val$finalButtonIntent.putExtra(GenerateNotification.BUNDLE_KEY_ONESIGNAL_DATA, jSONObject.toString());
                                NotificationOpenedProcessor.processIntent((Context)activity, this.val$finalButtonIntent);
                            }
                            catch (Throwable throwable) {
                                // empty catch block
                            }
                            return;
                        }
                        NotificationOpenedProcessor.processIntent((Context)activity, this.val$finalButtonIntent);
                    }
                };
                builder.setOnCancelListener(new DialogInterface.OnCancelListener(){

                    public void onCancel(DialogInterface dialogInterface) {
                        NotificationOpenedProcessor.processIntent((Context)activity, intent);
                    }
                });
                for (int i = 0; i < arrayList.size(); ++i) {
                    if (i == 0) {
                        builder.setNeutralButton((CharSequence)arrayList.get(i), onClickListener);
                        continue;
                    }
                    if (i == 1) {
                        builder.setNegativeButton((CharSequence)arrayList.get(i), onClickListener);
                        continue;
                    }
                    if (i != 2) continue;
                    builder.setPositiveButton((CharSequence)arrayList.get(i), onClickListener);
                }
                AlertDialog alertDialog = builder.create();
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.show();
            }

        });
    }

    static void updateSummaryNotification(NotificationGenerationJob notificationGenerationJob) {
        GenerateNotification.setStatics(notificationGenerationJob.context);
        GenerateNotification.createSummaryNotification(notificationGenerationJob, null);
    }

    private static class OneSignalNotificationBuilder {
        NotificationCompat.Builder compatBuilder;
        boolean hasLargeIcon;

        private OneSignalNotificationBuilder() {
        }
    }

}

