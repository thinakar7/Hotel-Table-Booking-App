/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.OSNotification;
import com.onesignal.OSNotificationAction;
import org.json.JSONException;
import org.json.JSONObject;

public class OSNotificationOpenResult {
    public OSNotificationAction action;
    public OSNotification notification;

    @Deprecated
    public String stringify() {
        JSONObject jSONObject = new JSONObject();
        try {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("actionID", (Object)this.action.actionID);
            jSONObject2.put("type", this.action.type.ordinal());
            jSONObject.put("action", (Object)jSONObject2);
            jSONObject.put("notification", (Object)new JSONObject(this.notification.stringify()));
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
        }
        return jSONObject.toString();
    }

    public JSONObject toJSONObject() {
        JSONObject jSONObject = new JSONObject();
        try {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("actionID", (Object)this.action.actionID);
            jSONObject2.put("type", this.action.type.ordinal());
            jSONObject.put("action", (Object)jSONObject2);
            jSONObject.put("notification", (Object)this.notification.toJSONObject());
            return jSONObject;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return jSONObject;
        }
    }
}

