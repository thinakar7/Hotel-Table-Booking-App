/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.location.Location
 *  android.os.Bundle
 *  android.os.Handler
 *  com.google.android.gms.common.ConnectionResult
 *  com.google.android.gms.common.api.Api
 *  com.google.android.gms.common.api.GoogleApiClient
 *  com.google.android.gms.common.api.GoogleApiClient$Builder
 *  com.google.android.gms.common.api.GoogleApiClient$ConnectionCallbacks
 *  com.google.android.gms.common.api.GoogleApiClient$OnConnectionFailedListener
 *  com.google.android.gms.common.api.PendingResult
 *  com.google.android.gms.location.FusedLocationProviderApi
 *  com.google.android.gms.location.LocationListener
 *  com.google.android.gms.location.LocationRequest
 *  com.google.android.gms.location.LocationServices
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 */
package com.onesignal;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.location.FusedLocationProviderApi;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.onesignal.GoogleApiClientCompatProxy;
import com.onesignal.LocationController;
import com.onesignal.OneSignal;
import com.onesignal.PermissionsActivity;

class GMSLocationController
extends LocationController {
    static final int API_FALLBACK_TIME = 30000;
    private static GoogleApiClientCompatProxy googleApiClient;
    static LocationUpdateListener locationUpdateListener;

    GMSLocationController() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void fireFailedComplete() {
        Object object;
        Object object2 = object = syncLock;
        synchronized (object2) {
            GoogleApiClientCompatProxy googleApiClientCompatProxy = googleApiClient;
            if (googleApiClientCompatProxy != null) {
                googleApiClientCompatProxy.disconnect();
            }
            googleApiClient = null;
            return;
        }
    }

    private static int getApiFallbackWait() {
        return 30000;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void initGoogleLocation() {
        Object object;
        if (fallbackFailThread != null) {
            return;
        }
        Object object2 = object = syncLock;
        synchronized (object2) {
            GMSLocationController.startFallBackThread();
            if (googleApiClient != null && lastLocation != null) {
                if (lastLocation != null) {
                    GMSLocationController.fireCompleteForLocation(lastLocation);
                }
            } else {
                GoogleApiClientCompatProxy googleApiClientCompatProxy;
                GoogleApiClientListener googleApiClientListener = new GoogleApiClientListener();
                googleApiClient = googleApiClientCompatProxy = new GoogleApiClientCompatProxy(new GoogleApiClient.Builder(classContext).addApi(LocationServices.API).addConnectionCallbacks((GoogleApiClient.ConnectionCallbacks)googleApiClientListener).addOnConnectionFailedListener((GoogleApiClient.OnConnectionFailedListener)googleApiClientListener).setHandler(GMSLocationController.locationHandlerThread.mHandler).build());
                googleApiClientCompatProxy.connect();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void onFocusChange() {
        Object object;
        Object object2 = object = syncLock;
        synchronized (object2) {
            OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "GMSLocationController onFocusChange!");
            GoogleApiClientCompatProxy googleApiClientCompatProxy = googleApiClient;
            if (googleApiClientCompatProxy != null && googleApiClientCompatProxy.realInstance().isConnected()) {
                GoogleApiClientCompatProxy googleApiClientCompatProxy2 = googleApiClient;
                if (googleApiClientCompatProxy2 != null) {
                    GoogleApiClient googleApiClient = googleApiClientCompatProxy2.realInstance();
                    if (locationUpdateListener != null) {
                        LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, (LocationListener)locationUpdateListener);
                    }
                    locationUpdateListener = new LocationUpdateListener(googleApiClient);
                }
                return;
            }
            return;
        }
    }

    private static void startFallBackThread() {
        fallbackFailThread = new Thread(new Runnable(){

            public void run() {
                try {
                    Thread.sleep((long)GMSLocationController.getApiFallbackWait());
                    OneSignal.Log(OneSignal.LOG_LEVEL.WARN, "Location permission exists but GoogleApiClient timed out. Maybe related to mismatch google-play aar versions.");
                    LocationController.fireFailedComplete();
                    LocationController.scheduleUpdate(LocationController.classContext);
                    return;
                }
                catch (InterruptedException interruptedException) {
                    return;
                }
            }
        }, "OS_GMS_LOCATION_FALLBACK");
        fallbackFailThread.start();
    }

    static void startGetLocation() {
        GMSLocationController.initGoogleLocation();
    }

    static class FusedLocationApiWrapper {
        FusedLocationApiWrapper() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        static Location getLastLocation(GoogleApiClient googleApiClient) {
            Object object;
            Object object2 = object = GMSLocationController.syncLock;
            synchronized (object2) {
                if (!googleApiClient.isConnected()) return null;
                return LocationServices.FusedLocationApi.getLastLocation(googleApiClient);
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Converted monitor instructions to comments
         * Lifted jumps to return sites
         */
        static void requestLocationUpdates(GoogleApiClient googleApiClient, LocationRequest locationRequest, LocationListener locationListener) {
            try {
                Object object;
                Object object2 = object = GMSLocationController.syncLock;
                // MONITORENTER : object2
            }
            catch (Throwable throwable) {
                OneSignal.Log(OneSignal.LOG_LEVEL.WARN, "FusedLocationApi.requestLocationUpdates failed!", throwable);
                return;
            }
            if (googleApiClient.isConnected()) {
                LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, locationListener);
            }
            // MONITOREXIT : object2
        }
    }

    private static class GoogleApiClientListener
    implements GoogleApiClient.ConnectionCallbacks,
    GoogleApiClient.OnConnectionFailedListener {
        private GoogleApiClientListener() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void onConnected(Bundle bundle) {
            Object object;
            Object object2 = object = LocationController.syncLock;
            synchronized (object2) {
                PermissionsActivity.answered = false;
                if (googleApiClient != null && googleApiClient.realInstance() != null) {
                    OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("LocationController GoogleApiClientListener onConnected lastLocation: ");
                    stringBuilder.append((Object)LocationController.lastLocation);
                    OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                    if (LocationController.lastLocation == null) {
                        LocationController.lastLocation = FusedLocationApiWrapper.getLastLocation(googleApiClient.realInstance());
                        OneSignal.LOG_LEVEL lOG_LEVEL2 = OneSignal.LOG_LEVEL.DEBUG;
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("LocationController GoogleApiClientListener lastLocation: ");
                        stringBuilder2.append((Object)LocationController.lastLocation);
                        OneSignal.Log(lOG_LEVEL2, stringBuilder2.toString());
                        if (LocationController.lastLocation != null) {
                            LocationController.fireCompleteForLocation(LocationController.lastLocation);
                        }
                    }
                    GMSLocationController.locationUpdateListener = new LocationUpdateListener(googleApiClient.realInstance());
                    return;
                }
                return;
            }
        }

        public void onConnectionFailed(ConnectionResult connectionResult) {
            GMSLocationController.fireFailedComplete();
        }

        public void onConnectionSuspended(int n) {
            GMSLocationController.fireFailedComplete();
        }
    }

    static class LocationUpdateListener
    implements LocationListener {
        private GoogleApiClient googleApiClient;

        LocationUpdateListener(GoogleApiClient googleApiClient) {
            this.googleApiClient = googleApiClient;
            this.init();
        }

        private void init() {
            long l = 570000L;
            if (OneSignal.isForeground()) {
                l = 270000L;
            }
            if (this.googleApiClient != null) {
                LocationRequest locationRequest = LocationRequest.create().setFastestInterval(l).setInterval(l).setMaxWaitTime((long)(1.5 * (double)l)).setPriority(102);
                OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "GMSLocationController GoogleApiClient requestLocationUpdates!");
                FusedLocationApiWrapper.requestLocationUpdates(this.googleApiClient, locationRequest, this);
            }
        }

        public void onLocationChanged(Location location) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("GMSLocationController onLocationChanged: ");
            stringBuilder.append((Object)location);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            LocationController.lastLocation = location;
        }
    }

}

