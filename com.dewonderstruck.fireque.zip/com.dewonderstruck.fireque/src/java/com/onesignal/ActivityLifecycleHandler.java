/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.res.Configuration
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.view.View
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.view.Window
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ref.WeakReference
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 */
package com.onesignal;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import com.onesignal.OSSystemConditionController;
import com.onesignal.OSUtils;
import com.onesignal.OSViewUtils;
import com.onesignal.OneSignal;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

class ActivityLifecycleHandler
implements OSSystemConditionController.OSSystemConditionHandler {
    private static final String FOCUS_LOST_WORKER_TAG = "FOCUS_LOST_WORKER_TAG";
    private static final Object SYNC_LOCK = new Object();
    static FocusHandlerThread focusHandlerThread;
    private static final Map<String, ActivityAvailableListener> sActivityAvailableListeners;
    private static final Map<String, KeyboardListener> sKeyboardListeners;
    private static final Map<String, OSSystemConditionController.OSSystemConditionObserver> sSystemConditionObservers;
    private Activity curActivity = null;
    private boolean nextResumeIsFirstActivity = false;

    static {
        sActivityAvailableListeners = new ConcurrentHashMap();
        sSystemConditionObservers = new ConcurrentHashMap();
        sKeyboardListeners = new ConcurrentHashMap();
        focusHandlerThread = new FocusHandlerThread();
    }

    ActivityLifecycleHandler() {
    }

    private void handleFocus() {
        if (!focusHandlerThread.hasBackgrounded() && !this.nextResumeIsFirstActivity) {
            focusHandlerThread.stopScheduledRunnable();
            return;
        }
        this.setNextResumeIsFirstActivity(false);
        focusHandlerThread.resetBackgroundState();
        OneSignal.onAppFocus();
    }

    private void handleLostFocus() {
        focusHandlerThread.runRunnable(new AppFocusRunnable());
    }

    private void logCurActivity() {
        String string;
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("curActivity is NOW: ");
        if (this.curActivity != null) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("");
            stringBuilder2.append(this.curActivity.getClass().getName());
            stringBuilder2.append(":");
            stringBuilder2.append((Object)this.curActivity);
            string = stringBuilder2.toString();
        } else {
            string = "null";
        }
        stringBuilder.append(string);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
    }

    private void logOrientationChange(int n, Activity activity) {
        if (n == 2) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Configuration Orientation Change: LANDSCAPE (");
            stringBuilder.append(n);
            stringBuilder.append(") on activity: ");
            stringBuilder.append((Object)activity);
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            return;
        }
        if (n == 1) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Configuration Orientation Change: PORTRAIT (");
            stringBuilder.append(n);
            stringBuilder.append(") on activity: ");
            stringBuilder.append((Object)activity);
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        }
    }

    private void onOrientationChanged(Activity activity) {
        this.handleLostFocus();
        Iterator iterator = sActivityAvailableListeners.entrySet().iterator();
        while (iterator.hasNext()) {
            ((ActivityAvailableListener)((Map.Entry)iterator.next()).getValue()).stopped(activity);
        }
        Iterator iterator2 = sActivityAvailableListeners.entrySet().iterator();
        while (iterator2.hasNext()) {
            ((ActivityAvailableListener)((Map.Entry)iterator2.next()).getValue()).available(this.curActivity);
        }
        ViewTreeObserver viewTreeObserver = this.curActivity.getWindow().getDecorView().getViewTreeObserver();
        for (Map.Entry entry : sSystemConditionObservers.entrySet()) {
            KeyboardListener keyboardListener = new KeyboardListener(this, (OSSystemConditionController.OSSystemConditionObserver)entry.getValue(), (String)entry.getKey());
            viewTreeObserver.addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)keyboardListener);
            sKeyboardListeners.put(entry.getKey(), (Object)keyboardListener);
        }
        this.handleFocus();
    }

    void addActivityAvailableListener(String string, ActivityAvailableListener activityAvailableListener) {
        sActivityAvailableListeners.put((Object)string, (Object)activityAvailableListener);
        Activity activity = this.curActivity;
        if (activity != null) {
            activityAvailableListener.available(activity);
        }
    }

    void addSystemConditionObserver(String string, OSSystemConditionController.OSSystemConditionObserver oSSystemConditionObserver) {
        Activity activity = this.curActivity;
        if (activity != null) {
            ViewTreeObserver viewTreeObserver = activity.getWindow().getDecorView().getViewTreeObserver();
            KeyboardListener keyboardListener = new KeyboardListener(this, oSSystemConditionObserver, string);
            viewTreeObserver.addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)keyboardListener);
            sKeyboardListeners.put((Object)string, (Object)keyboardListener);
        }
        sSystemConditionObservers.put((Object)string, (Object)oSSystemConditionObserver);
    }

    public Activity getCurActivity() {
        return this.curActivity;
    }

    void onActivityCreated(Activity activity) {
    }

    void onActivityDestroyed(Activity activity) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onActivityDestroyed: ");
        stringBuilder.append((Object)activity);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        sKeyboardListeners.clear();
        if (activity == this.curActivity) {
            this.curActivity = null;
            this.handleLostFocus();
        }
        this.logCurActivity();
    }

    void onActivityPaused(Activity activity) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onActivityPaused: ");
        stringBuilder.append((Object)activity);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        if (activity == this.curActivity) {
            this.curActivity = null;
            this.handleLostFocus();
        }
        this.logCurActivity();
    }

    void onActivityResumed(Activity activity) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onActivityResumed: ");
        stringBuilder.append((Object)activity);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        this.setCurActivity(activity);
        this.logCurActivity();
        this.handleFocus();
    }

    void onActivityStarted(Activity activity) {
    }

    void onActivityStopped(Activity activity) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onActivityStopped: ");
        stringBuilder.append((Object)activity);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        if (activity == this.curActivity) {
            this.curActivity = null;
            this.handleLostFocus();
        }
        Iterator iterator = sActivityAvailableListeners.entrySet().iterator();
        while (iterator.hasNext()) {
            ((ActivityAvailableListener)((Map.Entry)iterator.next()).getValue()).stopped(activity);
        }
        this.logCurActivity();
    }

    void onConfigurationChanged(Configuration configuration, Activity activity) {
        Activity activity2 = this.curActivity;
        if (activity2 != null && OSUtils.hasConfigChangeFlag(activity2, 128)) {
            this.logOrientationChange(configuration.orientation, activity);
            this.onOrientationChanged(activity);
        }
    }

    void removeActivityAvailableListener(String string) {
        sActivityAvailableListeners.remove((Object)string);
    }

    @Override
    public void removeSystemConditionObserver(String string, KeyboardListener keyboardListener) {
        Activity activity = this.curActivity;
        if (activity != null) {
            ViewTreeObserver viewTreeObserver = activity.getWindow().getDecorView().getViewTreeObserver();
            if (Build.VERSION.SDK_INT < 16) {
                viewTreeObserver.removeGlobalOnLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)keyboardListener);
            } else {
                viewTreeObserver.removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)keyboardListener);
            }
        }
        sKeyboardListeners.remove((Object)string);
        sSystemConditionObservers.remove((Object)string);
    }

    public void setCurActivity(Activity activity) {
        this.curActivity = activity;
        Iterator iterator = sActivityAvailableListeners.entrySet().iterator();
        while (iterator.hasNext()) {
            ((ActivityAvailableListener)((Map.Entry)iterator.next()).getValue()).available(this.curActivity);
        }
        try {
            ViewTreeObserver viewTreeObserver = this.curActivity.getWindow().getDecorView().getViewTreeObserver();
            for (Map.Entry entry : sSystemConditionObservers.entrySet()) {
                KeyboardListener keyboardListener = new KeyboardListener(this, (OSSystemConditionController.OSSystemConditionObserver)entry.getValue(), (String)entry.getKey());
                viewTreeObserver.addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)keyboardListener);
                sKeyboardListeners.put(entry.getKey(), (Object)keyboardListener);
            }
            return;
        }
        catch (RuntimeException runtimeException) {
            runtimeException.printStackTrace();
            return;
        }
    }

    void setNextResumeIsFirstActivity(boolean bl) {
        this.nextResumeIsFirstActivity = bl;
    }

    static abstract class ActivityAvailableListener {
        ActivityAvailableListener() {
        }

        void available(Activity activity) {
        }

        void lostFocus() {
        }

        void stopped(Activity activity) {
        }
    }

    private static class AppFocusRunnable
    implements Runnable {
        private boolean backgrounded;
        private boolean completed;

        private AppFocusRunnable() {
        }

        public void run() {
            if (OneSignal.getCurrentActivity() != null) {
                return;
            }
            this.backgrounded = true;
            Iterator iterator = sActivityAvailableListeners.entrySet().iterator();
            while (iterator.hasNext()) {
                ((ActivityAvailableListener)((Map.Entry)iterator.next()).getValue()).lostFocus();
            }
            OneSignal.onAppLostFocus();
            this.completed = true;
        }
    }

    static class FocusHandlerThread
    extends HandlerThread {
        private AppFocusRunnable appFocusRunnable;
        private Handler mHandler;

        FocusHandlerThread() {
            super("FocusHandlerThread");
            this.start();
            this.mHandler = new Handler(this.getLooper());
        }

        Looper getHandlerLooper() {
            return this.mHandler.getLooper();
        }

        boolean hasBackgrounded() {
            AppFocusRunnable appFocusRunnable = this.appFocusRunnable;
            return appFocusRunnable != null && appFocusRunnable.backgrounded;
        }

        void resetBackgroundState() {
            AppFocusRunnable appFocusRunnable = this.appFocusRunnable;
            if (appFocusRunnable != null) {
                appFocusRunnable.backgrounded = false;
            }
        }

        void runRunnable(AppFocusRunnable appFocusRunnable) {
            AppFocusRunnable appFocusRunnable2 = this.appFocusRunnable;
            if (appFocusRunnable2 != null && appFocusRunnable2.backgrounded && !this.appFocusRunnable.completed) {
                return;
            }
            this.appFocusRunnable = appFocusRunnable;
            this.mHandler.removeCallbacksAndMessages(null);
            this.mHandler.postDelayed((Runnable)appFocusRunnable, 2000L);
        }

        void stopScheduledRunnable() {
            this.mHandler.removeCallbacksAndMessages(null);
        }
    }

    static class KeyboardListener
    implements ViewTreeObserver.OnGlobalLayoutListener {
        private final String key;
        private final OSSystemConditionController.OSSystemConditionObserver observer;
        private final OSSystemConditionController.OSSystemConditionHandler systemConditionListener;

        private KeyboardListener(OSSystemConditionController.OSSystemConditionHandler oSSystemConditionHandler, OSSystemConditionController.OSSystemConditionObserver oSSystemConditionObserver, String string) {
            this.systemConditionListener = oSSystemConditionHandler;
            this.observer = oSSystemConditionObserver;
            this.key = string;
        }

        public void onGlobalLayout() {
            if (!OSViewUtils.isKeyboardUp((WeakReference<Activity>)new WeakReference((Object)OneSignal.getCurrentActivity()))) {
                this.systemConditionListener.removeSystemConditionObserver(this.key, this);
                this.observer.systemConditionChanged();
            }
        }
    }

}

