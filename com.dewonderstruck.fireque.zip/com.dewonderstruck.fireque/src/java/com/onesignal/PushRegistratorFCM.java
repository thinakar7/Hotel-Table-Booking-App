/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  android.util.Base64
 *  com.google.firebase.FirebaseApp
 *  com.google.firebase.FirebaseOptions
 *  com.google.firebase.FirebaseOptions$Builder
 *  com.google.firebase.iid.FirebaseInstanceId
 *  com.google.firebase.iid.FirebaseInstanceIdService
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.NoClassDefFoundError
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Base64;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalRemoteParams;
import com.onesignal.PushRegistratorAbstractGoogle;

class PushRegistratorFCM
extends PushRegistratorAbstractGoogle {
    private static final String FCM_APP_NAME = "ONESIGNAL_SDK_FCM_APP_NAME";
    private static final String FCM_DEFAULT_API_KEY_BASE64 = "QUl6YVN5QW5UTG41LV80TWMyYTJQLWRLVWVFLWFCdGd5Q3JqbFlV";
    private static final String FCM_DEFAULT_APP_ID = "1:754795614042:android:c682b8144a8dd52bc1ad63";
    private static final String FCM_DEFAULT_PROJECT_ID = "onesignal-shared-public";
    private FirebaseApp firebaseApp;

    PushRegistratorFCM() {
    }

    static void disableFirebaseInstanceIdService(Context context) {
        int n = OSUtils.getResourceString(context, "gcm_defaultSenderId", null) == null ? 2 : 1;
        PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.setComponentEnabledSetting(new ComponentName(context, FirebaseInstanceIdService.class), n, 1);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return;
        }
        catch (NoClassDefFoundError noClassDefFoundError) {
            // empty catch block
        }
    }

    private static String getApiKey() {
        if (OneSignal.remoteParams.fcmParams.apiKey != null) {
            return OneSignal.remoteParams.fcmParams.apiKey;
        }
        return new String(Base64.decode((String)FCM_DEFAULT_API_KEY_BASE64, (int)0));
    }

    private static String getAppId() {
        if (OneSignal.remoteParams.fcmParams.appId != null) {
            return OneSignal.remoteParams.fcmParams.appId;
        }
        return FCM_DEFAULT_APP_ID;
    }

    private static String getProjectId() {
        if (OneSignal.remoteParams.fcmParams.projectId != null) {
            return OneSignal.remoteParams.fcmParams.projectId;
        }
        return FCM_DEFAULT_PROJECT_ID;
    }

    private void initFirebaseApp(String string2) {
        if (this.firebaseApp != null) {
            return;
        }
        FirebaseOptions firebaseOptions = new FirebaseOptions.Builder().setGcmSenderId(string2).setApplicationId(PushRegistratorFCM.getAppId()).setApiKey(PushRegistratorFCM.getApiKey()).setProjectId(PushRegistratorFCM.getProjectId()).build();
        this.firebaseApp = FirebaseApp.initializeApp((Context)OneSignal.appContext, (FirebaseOptions)firebaseOptions, (String)FCM_APP_NAME);
    }

    @Override
    String getProviderName() {
        return "FCM";
    }

    @Override
    String getToken(String string2) throws Throwable {
        this.initFirebaseApp(string2);
        return FirebaseInstanceId.getInstance((FirebaseApp)this.firebaseApp).getToken(string2, "FCM");
    }
}

