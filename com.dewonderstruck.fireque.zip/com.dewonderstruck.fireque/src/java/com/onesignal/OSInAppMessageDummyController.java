/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Map
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.OSInAppMessage;
import com.onesignal.OSInAppMessageController;
import com.onesignal.OneSignalDbHelper;
import java.util.Collection;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class OSInAppMessageDummyController
extends OSInAppMessageController {
    OSInAppMessageDummyController(OneSignalDbHelper oneSignalDbHelper) {
        super(oneSignalDbHelper);
    }

    @Override
    void addTriggers(Map<String, Object> map) {
    }

    @Override
    void displayPreviewMessage(String string2) {
    }

    @Override
    OSInAppMessage getCurrentDisplayedInAppMessage() {
        return null;
    }

    @Override
    Object getTriggerValue(String string2) {
        return null;
    }

    @Override
    public void initRedisplayData(OneSignalDbHelper oneSignalDbHelper) {
    }

    @Override
    void initWithCachedInAppMessages() {
    }

    @Override
    boolean isInAppMessageShowing() {
        return false;
    }

    @Override
    public void messageTriggerConditionChanged() {
    }

    @Override
    public void messageWasDismissed(OSInAppMessage oSInAppMessage) {
    }

    @Override
    void onMessageActionOccurredOnMessage(OSInAppMessage oSInAppMessage, JSONObject jSONObject) {
    }

    @Override
    void onMessageActionOccurredOnPreview(OSInAppMessage oSInAppMessage, JSONObject jSONObject) {
    }

    @Override
    void receivedInAppMessageJson(JSONArray jSONArray) throws JSONException {
    }

    @Override
    void removeTriggersForKeys(Collection<String> collection) {
    }

    @Override
    void setInAppMessagingEnabled(boolean bl) {
    }
}

