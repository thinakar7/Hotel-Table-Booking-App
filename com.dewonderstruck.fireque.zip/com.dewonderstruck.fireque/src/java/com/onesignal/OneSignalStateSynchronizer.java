/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.HashMap
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.LocationController;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.UserStateEmailSynchronizer;
import com.onesignal.UserStatePushSynchronizer;
import com.onesignal.UserStateSynchronizer;
import java.util.Collection;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

class OneSignalStateSynchronizer {
    private static HashMap<UserStateSynchronizerType, UserStateSynchronizer> userStateSynchronizers = new HashMap();

    OneSignalStateSynchronizer() {
    }

    static void clearLocation() {
        OneSignalStateSynchronizer.getPushStateSynchronizer().clearLocation();
        OneSignalStateSynchronizer.getEmailStateSynchronizer().clearLocation();
    }

    static UserStateEmailSynchronizer getEmailStateSynchronizer() {
        if (!userStateSynchronizers.containsKey((Object)UserStateSynchronizerType.EMAIL) || userStateSynchronizers.get((Object)UserStateSynchronizerType.EMAIL) == null) {
            userStateSynchronizers.put((Object)UserStateSynchronizerType.EMAIL, (Object)new UserStateEmailSynchronizer());
        }
        return (UserStateEmailSynchronizer)userStateSynchronizers.get((Object)UserStateSynchronizerType.EMAIL);
    }

    static UserStatePushSynchronizer getPushStateSynchronizer() {
        if (!userStateSynchronizers.containsKey((Object)UserStateSynchronizerType.PUSH) || userStateSynchronizers.get((Object)UserStateSynchronizerType.PUSH) == null) {
            userStateSynchronizers.put((Object)UserStateSynchronizerType.PUSH, (Object)new UserStatePushSynchronizer());
        }
        return (UserStatePushSynchronizer)userStateSynchronizers.get((Object)UserStateSynchronizerType.PUSH);
    }

    static String getRegistrationId() {
        return OneSignalStateSynchronizer.getPushStateSynchronizer().getRegistrationId();
    }

    static boolean getSubscribed() {
        return OneSignalStateSynchronizer.getPushStateSynchronizer().getSubscribed();
    }

    static boolean getSyncAsNewSession() {
        return OneSignalStateSynchronizer.getPushStateSynchronizer().getSyncAsNewSession() || OneSignalStateSynchronizer.getEmailStateSynchronizer().getSyncAsNewSession();
        {
        }
    }

    static UserStateSynchronizer.GetTagsResult getTags(boolean bl) {
        return OneSignalStateSynchronizer.getPushStateSynchronizer().getTags(bl);
    }

    static boolean getUserSubscribePreference() {
        return OneSignalStateSynchronizer.getPushStateSynchronizer().getUserSubscribePreference();
    }

    static void initUserState() {
        OneSignalStateSynchronizer.getPushStateSynchronizer().initUserState();
        OneSignalStateSynchronizer.getEmailStateSynchronizer().initUserState();
    }

    static void logoutEmail() {
        OneSignalStateSynchronizer.getPushStateSynchronizer().logoutEmail();
        OneSignalStateSynchronizer.getEmailStateSynchronizer().logoutEmail();
    }

    static boolean persist() {
        boolean bl;
        block5 : {
            block4 : {
                boolean bl2 = OneSignalStateSynchronizer.getPushStateSynchronizer().persist();
                boolean bl3 = OneSignalStateSynchronizer.getEmailStateSynchronizer().persist();
                if (bl3) {
                    boolean bl4 = OneSignalStateSynchronizer.getEmailStateSynchronizer().getRegistrationId() != null;
                    bl3 = bl4;
                }
                if (bl2) break block4;
                bl = false;
                if (!bl3) break block5;
            }
            bl = true;
        }
        return bl;
    }

    static void readyToUpdate(boolean bl) {
        OneSignalStateSynchronizer.getPushStateSynchronizer().readyToUpdate(bl);
        OneSignalStateSynchronizer.getEmailStateSynchronizer().readyToUpdate(bl);
    }

    static void refreshEmailState() {
        OneSignalStateSynchronizer.getEmailStateSynchronizer().refresh();
    }

    static void resetCurrentState() {
        OneSignalStateSynchronizer.getPushStateSynchronizer().resetCurrentState();
        OneSignalStateSynchronizer.getEmailStateSynchronizer().resetCurrentState();
        OneSignal.saveUserId(null);
        OneSignal.saveEmailId(null);
        OneSignal.setLastSessionTime(-3660L);
    }

    static void sendTags(JSONObject jSONObject, OneSignal.ChangeTagsUpdateHandler changeTagsUpdateHandler) {
        try {
            JSONObject jSONObject2 = new JSONObject().put("tags", (Object)jSONObject);
            OneSignalStateSynchronizer.getPushStateSynchronizer().sendTags(jSONObject2, changeTagsUpdateHandler);
            OneSignalStateSynchronizer.getEmailStateSynchronizer().sendTags(jSONObject2, changeTagsUpdateHandler);
            return;
        }
        catch (JSONException jSONException) {
            if (changeTagsUpdateHandler != null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Encountered an error attempting to serialize your tags into JSON: ");
                stringBuilder.append(jSONException.getMessage());
                stringBuilder.append("\n");
                stringBuilder.append((Object)jSONException.getStackTrace());
                changeTagsUpdateHandler.onFailure(new OneSignal.SendTagsError(-1, stringBuilder.toString()));
            }
            jSONException.printStackTrace();
            return;
        }
    }

    static void setEmail(String string2, String string3) {
        OneSignalStateSynchronizer.getPushStateSynchronizer().setEmail(string2, string3);
        OneSignalStateSynchronizer.getEmailStateSynchronizer().setEmail(string2, string3);
    }

    static void setExternalUserId(String string2, String string3, OneSignal.OSExternalUserIdUpdateCompletionHandler oSExternalUserIdUpdateCompletionHandler) throws JSONException {
        OneSignal.OSInternalExternalUserIdUpdateCompletionHandler oSInternalExternalUserIdUpdateCompletionHandler = new OneSignal.OSInternalExternalUserIdUpdateCompletionHandler(new JSONObject(), oSExternalUserIdUpdateCompletionHandler){
            final /* synthetic */ OneSignal.OSExternalUserIdUpdateCompletionHandler val$completionHandler;
            final /* synthetic */ JSONObject val$responses;
            {
                this.val$responses = jSONObject;
                this.val$completionHandler = oSExternalUserIdUpdateCompletionHandler;
            }

            @Override
            public void onComplete(String string2, boolean bl) {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.VERBOSE;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Completed request to update external user id for channel: ");
                stringBuilder.append(string2);
                stringBuilder.append(" and success: ");
                stringBuilder.append(bl);
                OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
                try {
                    this.val$responses.put(string2, (Object)new JSONObject().put("success", bl));
                }
                catch (JSONException jSONException) {
                    OneSignal.LOG_LEVEL lOG_LEVEL2 = OneSignal.LOG_LEVEL.ERROR;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Error while adding the success status of external id for channel: ");
                    stringBuilder2.append(string2);
                    OneSignal.onesignalLog(lOG_LEVEL2, stringBuilder2.toString());
                    jSONException.printStackTrace();
                }
                for (UserStateSynchronizer userStateSynchronizer : userStateSynchronizers.values()) {
                    if (!userStateSynchronizer.hasQueuedHandlers()) continue;
                    OneSignal.LOG_LEVEL lOG_LEVEL3 = OneSignal.LOG_LEVEL.VERBOSE;
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("External user id handlers are still being processed for channel: ");
                    stringBuilder3.append(userStateSynchronizer.getChannelString());
                    stringBuilder3.append(" , wait until finished before proceeding");
                    OneSignal.onesignalLog(lOG_LEVEL3, stringBuilder3.toString());
                    return;
                }
                OSUtils.runOnMainUIThread(new Runnable(){

                    public void run() {
                        if (1.this.val$completionHandler != null) {
                            1.this.val$completionHandler.onComplete(1.this.val$responses);
                        }
                    }
                });
            }

        };
        OneSignalStateSynchronizer.getPushStateSynchronizer().setExternalUserId(string2, string3, oSInternalExternalUserIdUpdateCompletionHandler);
        if (OneSignal.hasEmailId()) {
            OneSignalStateSynchronizer.getEmailStateSynchronizer().setExternalUserId(string2, string3, oSInternalExternalUserIdUpdateCompletionHandler);
        }
    }

    static void setNewSession() {
        OneSignalStateSynchronizer.getPushStateSynchronizer().setNewSession();
        OneSignalStateSynchronizer.getEmailStateSynchronizer().setNewSession();
    }

    static void setNewSessionForEmail() {
        OneSignalStateSynchronizer.getEmailStateSynchronizer().setNewSession();
    }

    static void setPermission(boolean bl) {
        OneSignalStateSynchronizer.getPushStateSynchronizer().setPermission(bl);
    }

    static void setSubscription(boolean bl) {
        OneSignalStateSynchronizer.getPushStateSynchronizer().setSubscription(bl);
    }

    static void syncHashedEmail(String string2) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("em_m", (Object)OSUtils.hexDigest(string2, "MD5"));
            jSONObject.put("em_s", (Object)OSUtils.hexDigest(string2, "SHA-1"));
            OneSignalStateSynchronizer.getPushStateSynchronizer().syncHashedEmail(jSONObject);
            return;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return;
        }
    }

    static void syncUserState(boolean bl) {
        OneSignalStateSynchronizer.getPushStateSynchronizer().syncUserState(bl);
        OneSignalStateSynchronizer.getEmailStateSynchronizer().syncUserState(bl);
    }

    static void updateDeviceInfo(JSONObject jSONObject) {
        OneSignalStateSynchronizer.getPushStateSynchronizer().updateDeviceInfo(jSONObject);
        OneSignalStateSynchronizer.getEmailStateSynchronizer().updateDeviceInfo(jSONObject);
    }

    static void updateLocation(LocationController.LocationPoint locationPoint) {
        OneSignalStateSynchronizer.getPushStateSynchronizer().updateLocation(locationPoint);
        OneSignalStateSynchronizer.getEmailStateSynchronizer().updateLocation(locationPoint);
    }

    static void updatePushState(JSONObject jSONObject) {
        OneSignalStateSynchronizer.getPushStateSynchronizer().updateState(jSONObject);
    }

    static final class UserStateSynchronizerType
    extends Enum<UserStateSynchronizerType> {
        private static final /* synthetic */ UserStateSynchronizerType[] $VALUES;
        public static final /* enum */ UserStateSynchronizerType EMAIL;
        public static final /* enum */ UserStateSynchronizerType PUSH;

        static {
            UserStateSynchronizerType userStateSynchronizerType;
            UserStateSynchronizerType userStateSynchronizerType2;
            PUSH = userStateSynchronizerType = new UserStateSynchronizerType();
            EMAIL = userStateSynchronizerType2 = new UserStateSynchronizerType();
            $VALUES = new UserStateSynchronizerType[]{userStateSynchronizerType, userStateSynchronizerType2};
        }

        public static UserStateSynchronizerType valueOf(String string2) {
            return (UserStateSynchronizerType)Enum.valueOf(UserStateSynchronizerType.class, (String)string2);
        }

        public static UserStateSynchronizerType[] values() {
            return (UserStateSynchronizerType[])$VALUES.clone();
        }

        public boolean isEmail() {
            return this.equals((Object)EMAIL);
        }

        public boolean isPush() {
            return this.equals((Object)PUSH);
        }
    }

}

