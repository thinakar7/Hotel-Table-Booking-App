/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.influence.model.OSInfluenceType;
import com.onesignal.outcomes.model.OSOutcomeEventParams;
import com.onesignal.outcomes.model.OSOutcomeSource;
import com.onesignal.outcomes.model.OSOutcomeSourceBody;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class OutcomeEvent {
    private static final String NOTIFICATION_IDS = "notification_ids";
    private static final String OUTCOME_ID = "id";
    private static final String SESSION = "session";
    private static final String TIMESTAMP = "timestamp";
    private static final String WEIGHT = "weight";
    private String name;
    private JSONArray notificationIds;
    private OSInfluenceType session;
    private long timestamp;
    private Float weight;

    public OutcomeEvent(OSInfluenceType oSInfluenceType, JSONArray jSONArray, String string2, long l, float f) {
        this.session = oSInfluenceType;
        this.notificationIds = jSONArray;
        this.name = string2;
        this.timestamp = l;
        this.weight = Float.valueOf((float)f);
    }

    public static OutcomeEvent fromOutcomeEventParamsV2toOutcomeEventV1(OSOutcomeEventParams oSOutcomeEventParams) {
        OSInfluenceType oSInfluenceType = OSInfluenceType.UNATTRIBUTED;
        OSOutcomeSource oSOutcomeSource = oSOutcomeEventParams.getOutcomeSource();
        JSONArray jSONArray = null;
        if (oSOutcomeSource != null) {
            OSOutcomeSource oSOutcomeSource2 = oSOutcomeEventParams.getOutcomeSource();
            if (oSOutcomeSource2.getDirectBody() != null && oSOutcomeSource2.getDirectBody().getNotificationIds() != null && oSOutcomeSource2.getDirectBody().getNotificationIds().length() > 0) {
                oSInfluenceType = OSInfluenceType.DIRECT;
                jSONArray = oSOutcomeSource2.getDirectBody().getNotificationIds();
            } else {
                OSOutcomeSourceBody oSOutcomeSourceBody = oSOutcomeSource2.getIndirectBody();
                jSONArray = null;
                if (oSOutcomeSourceBody != null) {
                    JSONArray jSONArray2 = oSOutcomeSource2.getIndirectBody().getNotificationIds();
                    jSONArray = null;
                    if (jSONArray2 != null) {
                        int n = oSOutcomeSource2.getIndirectBody().getNotificationIds().length();
                        jSONArray = null;
                        if (n > 0) {
                            oSInfluenceType = OSInfluenceType.INDIRECT;
                            jSONArray = oSOutcomeSource2.getIndirectBody().getNotificationIds();
                        }
                    }
                }
            }
        }
        String string2 = oSOutcomeEventParams.getOutcomeId();
        long l = oSOutcomeEventParams.getTimestamp();
        float f = oSOutcomeEventParams.getWeight().floatValue();
        OutcomeEvent outcomeEvent = new OutcomeEvent(oSInfluenceType, jSONArray, string2, l, f);
        return outcomeEvent;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null) {
            if (this.getClass() != object.getClass()) {
                return false;
            }
            OutcomeEvent outcomeEvent = (OutcomeEvent)object;
            return this.session.equals((Object)outcomeEvent.session) && this.notificationIds.equals((Object)outcomeEvent.notificationIds) && this.name.equals((Object)outcomeEvent.name) && this.timestamp == outcomeEvent.timestamp && this.weight.equals((Object)outcomeEvent.weight);
        }
        return false;
    }

    public String getName() {
        return this.name;
    }

    public JSONArray getNotificationIds() {
        return this.notificationIds;
    }

    public OSInfluenceType getSession() {
        return this.session;
    }

    public long getTimestamp() {
        return this.timestamp;
    }

    public float getWeight() {
        return this.weight.floatValue();
    }

    public int hashCode() {
        Object[] arrobject = new Object[]{this.session, this.notificationIds, this.name, this.timestamp, this.weight};
        int n = 1;
        for (Object object : arrobject) {
            int n2 = n * 31;
            int n3 = object == null ? 0 : object.hashCode();
            n = n2 + n3;
        }
        return n;
    }

    public JSONObject toJSONObject() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(SESSION, (Object)this.session);
        jSONObject.put(NOTIFICATION_IDS, (Object)this.notificationIds);
        jSONObject.put(OUTCOME_ID, (Object)this.name);
        jSONObject.put(TIMESTAMP, this.timestamp);
        jSONObject.put(WEIGHT, (Object)this.weight);
        return jSONObject;
    }

    public JSONObject toJSONObjectForMeasure() throws JSONException {
        long l;
        JSONObject jSONObject = new JSONObject();
        JSONArray jSONArray = this.notificationIds;
        if (jSONArray != null && jSONArray.length() > 0) {
            jSONObject.put(NOTIFICATION_IDS, (Object)this.notificationIds);
        }
        jSONObject.put(OUTCOME_ID, (Object)this.name);
        if (this.weight.floatValue() > 0.0f) {
            jSONObject.put(WEIGHT, (Object)this.weight);
        }
        if ((l = this.timestamp) > 0L) {
            jSONObject.put(TIMESTAMP, l);
        }
        return jSONObject;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OutcomeEvent{session=");
        stringBuilder.append((Object)this.session);
        stringBuilder.append(", notificationIds=");
        stringBuilder.append((Object)this.notificationIds);
        stringBuilder.append(", name='");
        stringBuilder.append(this.name);
        stringBuilder.append('\'');
        stringBuilder.append(", timestamp=");
        stringBuilder.append(this.timestamp);
        stringBuilder.append(", weight=");
        stringBuilder.append((Object)this.weight);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

