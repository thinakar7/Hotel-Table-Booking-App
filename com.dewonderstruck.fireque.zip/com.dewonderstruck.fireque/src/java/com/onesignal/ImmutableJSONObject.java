/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import org.json.JSONException;
import org.json.JSONObject;

class ImmutableJSONObject {
    private final JSONObject jsonObject;

    public ImmutableJSONObject() {
        this.jsonObject = new JSONObject();
    }

    public ImmutableJSONObject(JSONObject jSONObject) {
        this.jsonObject = jSONObject;
    }

    public long getLong(String string) throws JSONException {
        return this.jsonObject.getLong(string);
    }

    public boolean has(String string) {
        return this.jsonObject.has(string);
    }

    public Object opt(String string) {
        return this.jsonObject.opt(string);
    }

    public boolean optBoolean(String string) {
        return this.jsonObject.optBoolean(string);
    }

    public boolean optBoolean(String string, boolean bl) {
        return this.jsonObject.optBoolean(string, bl);
    }

    public int optInt(String string) {
        return this.jsonObject.optInt(string);
    }

    public int optInt(String string, int n) {
        return this.jsonObject.optInt(string, n);
    }

    public JSONObject optJSONObject(String string) {
        return this.jsonObject.optJSONObject(string);
    }

    public long optLong(String string) {
        return this.jsonObject.optLong(string);
    }

    public String optString(String string) {
        return this.jsonObject.optString(string);
    }

    public String optString(String string, String string2) {
        return this.jsonObject.optString(string, string2);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ImmutableJSONObject{jsonObject=");
        stringBuilder.append((Object)this.jsonObject);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

