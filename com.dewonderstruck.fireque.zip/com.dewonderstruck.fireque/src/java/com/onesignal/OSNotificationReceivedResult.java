/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.onesignal;

import com.onesignal.OSNotificationPayload;

public class OSNotificationReceivedResult {
    public boolean isAppInFocus;
    public OSNotificationPayload payload;
    public boolean restoring;
}

