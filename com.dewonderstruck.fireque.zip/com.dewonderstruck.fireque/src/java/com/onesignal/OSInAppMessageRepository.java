/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  java.util.Set
 *  org.json.JSONArray
 *  org.json.JSONException
 */
package com.onesignal;

import android.content.ContentValues;
import android.database.Cursor;
import com.onesignal.OSInAppMessage;
import com.onesignal.OSInAppMessageRedisplayStats;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalDbHelper;
import com.onesignal.OneSignalPrefs;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;

class OSInAppMessageRepository {
    static final long IAM_CACHE_DATA_LIFETIME = 15552000L;
    private final OneSignalDbHelper dbHelper;

    OSInAppMessageRepository(OneSignalDbHelper oneSignalDbHelper) {
        this.dbHelper = oneSignalDbHelper;
    }

    private void cleanInAppMessageClickedClickIds(Set<String> set) {
        Set<String> set2;
        if (set != null && set.size() > 0 && (set2 = OneSignalPrefs.getStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_CLICKED_CLICK_IDS_IAMS", null)) != null && set2.size() > 0) {
            set2.removeAll(set);
            OneSignalPrefs.saveStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_CLICKED_CLICK_IDS_IAMS", set2);
        }
    }

    private void cleanInAppMessageIds(Set<String> set) {
        if (set != null && set.size() > 0) {
            Set<String> set2 = OneSignalPrefs.getStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_DISPLAYED_IAMS", null);
            Set<String> set3 = OneSignalPrefs.getStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_IMPRESSIONED_IAMS", null);
            if (set2 != null && set2.size() > 0) {
                set2.removeAll(set);
                OneSignalPrefs.saveStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_DISPLAYED_IAMS", set2);
            }
            if (set3 != null && set3.size() > 0) {
                set3.removeAll(set);
                OneSignalPrefs.saveStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_IMPRESSIONED_IAMS", set3);
            }
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    void cleanCachedInAppMessages() {
        block20 : {
            block21 : {
                block18 : {
                    block19 : {
                        var15_1 = this;
                        // MONITORENTER : var15_1
                        var1_2 = new String[]{"message_id", "click_ids"};
                        var2_3 = new String[]{String.valueOf((long)(System.currentTimeMillis() / 1000L - 15552000L))};
                        var4_4 = OSUtils.newConcurrentSet();
                        var5_5 = OSUtils.newConcurrentSet();
                        var6_6 = null;
                        var6_6 = this.dbHelper.query("in_app_message", var1_2, "last_display < ?", var2_3, null, null, null);
                        if (var6_6 != null && var6_6.getCount() != 0) {
                            var9_7 = var6_6.moveToFirst();
                            if (!var9_7) break block18;
                            break block19;
                        }
                        OneSignal.onesignalLog(OneSignal.LOG_LEVEL.DEBUG, "Attempted to clean 6 month old IAM data, but none exists!");
                        if (var6_6 != null && !var6_6.isClosed()) {
                            var6_6.close();
                        }
                        // MONITOREXIT : var15_1
                        return;
                    }
                    try {
                        do {
                            var10_8 = var6_6.getString(var6_6.getColumnIndex("message_id"));
                            var11_9 = var6_6.getString(var6_6.getColumnIndex("click_ids"));
                            var4_4.add((Object)var10_8);
                            var5_5.addAll(OSUtils.newStringSetFromJSONArray(new JSONArray(var11_9)));
                        } while (var14_10 = var6_6.moveToNext());
                    }
                    catch (Throwable var8_11) {
                        break block20;
                    }
                    catch (JSONException var7_14) {
                        ** GOTO lbl-1000
                    }
                }
                if (var6_6 != null && !var6_6.isClosed()) {
                    var6_6.close();
                }
                break block21;
                catch (Throwable var8_12) {
                    break block20;
                }
                catch (JSONException var7_15) {
                    // empty catch block
                }
lbl-1000: // 2 sources:
                {
                    var7_16.printStackTrace();
                }
                if (var6_6 != null && !var6_6.isClosed()) {
                    var6_6.close();
                }
            }
            this.dbHelper.delete("in_app_message", "last_display < ?", var2_3);
            this.cleanInAppMessageIds(var4_4);
            this.cleanInAppMessageClickedClickIds(var5_5);
            // MONITOREXIT : var15_1
            return;
        }
        if (var6_6 == null) throw var8_13;
        if (var6_6.isClosed() != false) throw var8_13;
        var6_6.close();
        throw var8_13;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    List<OSInAppMessage> getCachedInAppMessages() {
        block17 : {
            block14 : {
                var17_1 = this;
                // MONITORENTER : var17_1
                var1_2 = new ArrayList();
                var2_3 = null;
                try {
                    var2_3 = this.dbHelper.query("in_app_message", null, null, null, null, null, null);
                    var6_4 = var2_3.moveToFirst();
                    if (!var6_4) break block14;
                }
                catch (Throwable var5_14) {
                    break block17;
                }
                catch (JSONException var3_17) {
                    // empty catch block
                }
                do {
                    block16 : {
                        block15 : {
                            try {
                                var7_5 = var2_3.getString(var2_3.getColumnIndex("message_id"));
                                var8_6 = var2_3.getString(var2_3.getColumnIndex("click_ids"));
                                var9_7 = var2_3.getInt(var2_3.getColumnIndex("display_quantity"));
                                var10_8 = var2_3.getLong(var2_3.getColumnIndex("last_display"));
                                var12_9 = var2_3.getInt(var2_3.getColumnIndex("displayed_in_session"));
                                var13_10 = true;
                                if (var12_9 != var13_10) break block15;
                                break block16;
                            }
                            catch (Throwable var5_13) {
                                break block17;
                            }
                            catch (JSONException var3_16) {
                                ** GOTO lbl-1000
                            }
                        }
                        var13_10 = false;
                    }
                    var14_11 = var13_10;
                    var1_2.add((Object)new OSInAppMessage(var7_5, OSUtils.newStringSetFromJSONArray(new JSONArray(var8_6)), var14_11, new OSInAppMessageRedisplayStats(var9_7, var10_8)));
                } while (var16_12 = var2_3.moveToNext());
            }
            if (var2_3 == null || var2_3.isClosed()) return var1_2;
            {
                var2_3.close();
                return var1_2;
            }
lbl-1000: // 2 sources:
            {
                OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Generating JSONArray from iam click ids:JSON Failed.", (Throwable)var3_18);
            }
            if (var2_3 != null && !var2_3.isClosed()) {
                var2_3.close();
            }
            // MONITOREXIT : var17_1
            return var1_2;
        }
        if (var2_3 == null) throw var5_15;
        if (var2_3.isClosed() != false) throw var5_15;
        var2_3.close();
        throw var5_15;
    }

    void saveInAppMessage(OSInAppMessage oSInAppMessage) {
        OSInAppMessageRepository oSInAppMessageRepository = this;
        synchronized (oSInAppMessageRepository) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("message_id", oSInAppMessage.messageId);
            contentValues.put("display_quantity", Integer.valueOf((int)oSInAppMessage.getRedisplayStats().getDisplayQuantity()));
            contentValues.put("last_display", Long.valueOf((long)oSInAppMessage.getRedisplayStats().getLastDisplayTime()));
            contentValues.put("click_ids", oSInAppMessage.getClickedClickIds().toString());
            contentValues.put("displayed_in_session", Boolean.valueOf((boolean)oSInAppMessage.isDisplayedInSession()));
            OneSignalDbHelper oneSignalDbHelper = this.dbHelper;
            String[] arrstring = new String[]{oSInAppMessage.messageId};
            if (oneSignalDbHelper.update("in_app_message", contentValues, "message_id = ?", arrstring) == 0) {
                this.dbHelper.insert("in_app_message", null, contentValues);
            }
            return;
        }
    }
}

