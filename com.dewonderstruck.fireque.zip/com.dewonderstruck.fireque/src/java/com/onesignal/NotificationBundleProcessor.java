/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.Intent
 *  android.database.Cursor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.SystemClock
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Set
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import com.onesignal.BadgeCountUpdater;
import com.onesignal.BundleCompat;
import com.onesignal.GenerateNotification;
import com.onesignal.NotificationExtenderService;
import com.onesignal.NotificationGenerationJob;
import com.onesignal.OSNotificationFormatHelper;
import com.onesignal.OSNotificationPayload;
import com.onesignal.OSReceiveReceiptController;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalDbHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class NotificationBundleProcessor {
    static final String DEFAULT_ACTION = "__DEFAULT__";
    private static final String IAM_PREVIEW_KEY = "os_in_app_message_preview_id";
    public static final String PUSH_ADDITIONAL_DATA_KEY = "a";
    public static final String PUSH_MINIFIED_BUTTONS_LIST = "o";
    public static final String PUSH_MINIFIED_BUTTON_ICON = "p";
    public static final String PUSH_MINIFIED_BUTTON_ID = "i";
    public static final String PUSH_MINIFIED_BUTTON_TEXT = "n";

    NotificationBundleProcessor() {
    }

    /*
     * Exception decompiling
     */
    static OSNotificationPayload OSNotificationPayloadFrom(JSONObject var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void ProcessFromGCMIntentService(Context context, BundleCompat bundleCompat, NotificationExtenderService.OverrideSettings overrideSettings) {
        OneSignal.setAppContext(context);
        try {
            String string = bundleCompat.getString("json_payload");
            if (string == null) {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("json_payload key is nonexistent from mBundle passed to ProcessFromGCMIntentService: ");
                stringBuilder.append((Object)bundleCompat);
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                return;
            }
            NotificationGenerationJob notificationGenerationJob = new NotificationGenerationJob(context);
            notificationGenerationJob.restoring = bundleCompat.getBoolean("restoring", false);
            notificationGenerationJob.shownTimeStamp = bundleCompat.getLong("timestamp");
            notificationGenerationJob.jsonPayload = new JSONObject(string);
            String string2 = NotificationBundleProcessor.inAppPreviewPushUUID(notificationGenerationJob.jsonPayload);
            boolean bl = false;
            if (string2 != null) {
                bl = true;
            }
            notificationGenerationJob.isInAppPreviewPush = bl;
            if (!notificationGenerationJob.restoring && !notificationGenerationJob.isInAppPreviewPush && OneSignal.notValidOrDuplicated(context, notificationGenerationJob.jsonPayload)) {
                return;
            }
            if (bundleCompat.containsKey("android_notif_id")) {
                if (overrideSettings == null) {
                    overrideSettings = new NotificationExtenderService.OverrideSettings();
                }
                overrideSettings.androidNotificationId = bundleCompat.getInt("android_notif_id");
            }
            notificationGenerationJob.overrideSettings = overrideSettings;
            NotificationBundleProcessor.ProcessJobForDisplay(notificationGenerationJob);
            if (notificationGenerationJob.restoring) {
                OSUtils.sleep(100);
            }
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    static int ProcessJobForDisplay(NotificationGenerationJob notificationGenerationJob) {
        boolean bl = OneSignal.getInAppAlertNotificationEnabled() && OneSignal.isAppActive();
        notificationGenerationJob.showAsAlert = bl;
        NotificationBundleProcessor.processCollapseKey(notificationGenerationJob);
        if (NotificationBundleProcessor.shouldDisplayNotif(notificationGenerationJob)) {
            GenerateNotification.fromJsonPayload(notificationGenerationJob);
        }
        if (!notificationGenerationJob.restoring && !notificationGenerationJob.isInAppPreviewPush) {
            NotificationBundleProcessor.processNotification(notificationGenerationJob, false);
            try {
                JSONObject jSONObject = new JSONObject(notificationGenerationJob.jsonPayload.toString());
                jSONObject.put("androidNotificationId", (Object)notificationGenerationJob.getAndroidId());
                OneSignal.handleNotificationReceived(NotificationBundleProcessor.newJsonArray(jSONObject), true, notificationGenerationJob.showAsAlert);
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
            }
        }
        return notificationGenerationJob.getAndroidId();
    }

    static JSONObject bundleAsJSONObject(Bundle bundle) {
        JSONObject jSONObject = new JSONObject();
        for (String string : bundle.keySet()) {
            try {
                jSONObject.put(string, bundle.get(string));
            }
            catch (JSONException jSONException) {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("bundleAsJSONObject error for key: ");
                stringBuilder.append(string);
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString(), jSONException);
            }
        }
        return jSONObject;
    }

    private static JSONArray bundleAsJsonArray(Bundle bundle) {
        JSONArray jSONArray = new JSONArray();
        jSONArray.put((Object)NotificationBundleProcessor.bundleAsJSONObject(bundle));
        return jSONArray;
    }

    static JSONObject getCustomJSONObject(JSONObject jSONObject) throws JSONException {
        return new JSONObject(jSONObject.optString("custom"));
    }

    static boolean hasRemoteResource(Bundle bundle) {
        return NotificationBundleProcessor.isBuildKeyRemote(bundle, "licon") || NotificationBundleProcessor.isBuildKeyRemote(bundle, "bicon") || bundle.getString("bg_img", null) != null;
        {
        }
    }

    static String inAppPreviewPushUUID(JSONObject jSONObject) {
        JSONObject jSONObject2;
        try {
            jSONObject2 = NotificationBundleProcessor.getCustomJSONObject(jSONObject);
        }
        catch (JSONException jSONException) {
            return null;
        }
        if (!jSONObject2.has(PUSH_ADDITIONAL_DATA_KEY)) {
            return null;
        }
        JSONObject jSONObject3 = jSONObject2.optJSONObject(PUSH_ADDITIONAL_DATA_KEY);
        if (jSONObject3.has(IAM_PREVIEW_KEY)) {
            return jSONObject3.optString(IAM_PREVIEW_KEY);
        }
        return null;
    }

    private static boolean isBuildKeyRemote(Bundle bundle, String string) {
        String string2 = bundle.getString(string, "").trim();
        return string2.startsWith("http://") || string2.startsWith("https://");
        {
        }
    }

    static void markRestoredNotificationAsDismissed(NotificationGenerationJob notificationGenerationJob) {
        if (notificationGenerationJob.getAndroidIdWithoutCreate() == -1) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("android_notification_id = ");
        stringBuilder.append(notificationGenerationJob.getAndroidIdWithoutCreate());
        String string = stringBuilder.toString();
        OneSignalDbHelper oneSignalDbHelper = OneSignalDbHelper.getInstance(notificationGenerationJob.context);
        ContentValues contentValues = new ContentValues();
        contentValues.put("dismissed", Integer.valueOf((int)1));
        oneSignalDbHelper.update("notification", contentValues, string, null);
        BadgeCountUpdater.update(oneSignalDbHelper, notificationGenerationJob.context);
    }

    static JSONArray newJsonArray(JSONObject jSONObject) {
        return new JSONArray().put((Object)jSONObject);
    }

    static ProcessedBundleResult processBundleFromReceiver(Context context, final Bundle bundle) {
        ProcessedBundleResult processedBundleResult = new ProcessedBundleResult();
        if (!OSNotificationFormatHelper.isOneSignalBundle(bundle)) {
            return processedBundleResult;
        }
        processedBundleResult.isOneSignalPayload = true;
        NotificationBundleProcessor.unMinifyButtonsFromBundle(bundle);
        JSONObject jSONObject = NotificationBundleProcessor.bundleAsJSONObject(bundle);
        String string = NotificationBundleProcessor.inAppPreviewPushUUID(jSONObject);
        if (string != null) {
            if (OneSignal.isAppActive()) {
                processedBundleResult.inAppPreviewShown = true;
                OneSignal.getInAppMessageController().displayPreviewMessage(string);
            }
            return processedBundleResult;
        }
        if (NotificationBundleProcessor.startExtenderService(context, bundle, processedBundleResult)) {
            return processedBundleResult;
        }
        processedBundleResult.isDup = OneSignal.notValidOrDuplicated(context, jSONObject);
        if (processedBundleResult.isDup) {
            return processedBundleResult;
        }
        if (!NotificationBundleProcessor.shouldDisplay(bundle.getString("alert"))) {
            NotificationBundleProcessor.saveAndProcessNotification(context, bundle, true, -1);
            new Thread(new Runnable(){

                public void run() {
                    OneSignal.handleNotificationReceived(NotificationBundleProcessor.bundleAsJsonArray(bundle), false, false);
                }
            }, "OS_PROC_BUNDLE").start();
        }
        return processedBundleResult;
    }

    private static void processCollapseKey(NotificationGenerationJob notificationGenerationJob) {
        if (notificationGenerationJob.restoring) {
            return;
        }
        if (notificationGenerationJob.jsonPayload.has("collapse_key")) {
            if ("do_not_collapse".equals((Object)notificationGenerationJob.jsonPayload.optString("collapse_key"))) {
                return;
            }
            String string = notificationGenerationJob.jsonPayload.optString("collapse_key");
            Cursor cursor = OneSignalDbHelper.getInstance(notificationGenerationJob.context).query("notification", new String[]{"android_notification_id"}, "collapse_id = ? AND dismissed = 0 AND opened = 0 ", new String[]{string}, null, null, null);
            if (cursor.moveToFirst()) {
                notificationGenerationJob.setAndroidIdWithOutOverriding(cursor.getInt(cursor.getColumnIndex("android_notification_id")));
            }
            cursor.close();
            return;
        }
    }

    static void processNotification(NotificationGenerationJob notificationGenerationJob, boolean bl) {
        NotificationBundleProcessor.saveNotification(notificationGenerationJob, bl);
        if (!notificationGenerationJob.isNotificationToDisplay()) {
            return;
        }
        String string = notificationGenerationJob.getApiNotificationId();
        OneSignal.getSessionManager().onNotificationReceived(string);
        OSReceiveReceiptController.getInstance().sendReceiveReceipt(string);
    }

    private static void saveAndProcessNotification(Context context, Bundle bundle, boolean bl, int n) {
        NotificationGenerationJob notificationGenerationJob = new NotificationGenerationJob(context);
        notificationGenerationJob.jsonPayload = NotificationBundleProcessor.bundleAsJSONObject(bundle);
        notificationGenerationJob.overrideSettings = new NotificationExtenderService.OverrideSettings();
        notificationGenerationJob.overrideSettings.androidNotificationId = n;
        NotificationBundleProcessor.processNotification(notificationGenerationJob, bl);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void saveNotification(NotificationGenerationJob notificationGenerationJob, boolean bl) {
        OneSignalDbHelper oneSignalDbHelper;
        ContentValues contentValues;
        int n;
        Context context = notificationGenerationJob.context;
        JSONObject jSONObject = notificationGenerationJob.jsonPayload;
        try {
            JSONObject jSONObject2 = NotificationBundleProcessor.getCustomJSONObject(notificationGenerationJob.jsonPayload);
            oneSignalDbHelper = OneSignalDbHelper.getInstance(notificationGenerationJob.context);
            boolean bl2 = notificationGenerationJob.isNotificationToDisplay();
            n = 1;
            if (bl2) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("android_notification_id = ");
                stringBuilder.append(notificationGenerationJob.getAndroidIdWithoutCreate());
                String string = stringBuilder.toString();
                ContentValues contentValues2 = new ContentValues();
                contentValues2.put("dismissed", Integer.valueOf((int)n));
                oneSignalDbHelper.update("notification", contentValues2, string, null);
                BadgeCountUpdater.update(oneSignalDbHelper, context);
            }
            contentValues = new ContentValues();
            contentValues.put("notification_id", jSONObject2.optString(PUSH_MINIFIED_BUTTON_ID));
            if (jSONObject.has("grp")) {
                contentValues.put("group_id", jSONObject.optString("grp"));
            }
            if (jSONObject.has("collapse_key") && !"do_not_collapse".equals((Object)jSONObject.optString("collapse_key"))) {
                contentValues.put("collapse_id", jSONObject.optString("collapse_key"));
            }
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
        if (!bl) {
            n = 0;
        }
        contentValues.put("opened", Integer.valueOf((int)n));
        if (!bl) {
            contentValues.put("android_notification_id", Integer.valueOf((int)notificationGenerationJob.getAndroidIdWithoutCreate()));
        }
        if (notificationGenerationJob.getTitle() != null) {
            contentValues.put("title", notificationGenerationJob.getTitle().toString());
        }
        if (notificationGenerationJob.getBody() != null) {
            contentValues.put("message", notificationGenerationJob.getBody().toString());
        }
        contentValues.put("expire_time", Long.valueOf((long)(jSONObject.optLong("google.sent_time", SystemClock.currentThreadTimeMillis()) / 1000L + (long)jSONObject.optInt("google.ttl", 259200))));
        contentValues.put("full_data", jSONObject.toString());
        oneSignalDbHelper.insertOrThrow("notification", null, contentValues);
        if (!bl) {
            BadgeCountUpdater.update(oneSignalDbHelper, context);
        }
    }

    private static void setActionButtons(OSNotificationPayload oSNotificationPayload) throws Throwable {
        if (oSNotificationPayload.additionalData != null && oSNotificationPayload.additionalData.has("actionButtons")) {
            JSONArray jSONArray = oSNotificationPayload.additionalData.getJSONArray("actionButtons");
            oSNotificationPayload.actionButtons = new ArrayList();
            for (int i = 0; i < jSONArray.length(); ++i) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                OSNotificationPayload.ActionButton actionButton = new OSNotificationPayload.ActionButton();
                actionButton.id = jSONObject.optString("id", null);
                actionButton.text = jSONObject.optString("text", null);
                actionButton.icon = jSONObject.optString("icon", null);
                oSNotificationPayload.actionButtons.add((Object)actionButton);
            }
            oSNotificationPayload.additionalData.remove("actionId");
            oSNotificationPayload.additionalData.remove("actionButtons");
        }
    }

    private static void setBackgroundImageLayout(OSNotificationPayload oSNotificationPayload, JSONObject jSONObject) throws Throwable {
        String string = jSONObject.optString("bg_img", null);
        if (string != null) {
            JSONObject jSONObject2 = new JSONObject(string);
            oSNotificationPayload.backgroundImageLayout = new OSNotificationPayload.BackgroundImageLayout();
            oSNotificationPayload.backgroundImageLayout.image = jSONObject2.optString("img");
            oSNotificationPayload.backgroundImageLayout.titleTextColor = jSONObject2.optString("tc");
            oSNotificationPayload.backgroundImageLayout.bodyTextColor = jSONObject2.optString("bc");
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static boolean shouldDisplay(String string) {
        boolean bl = true;
        boolean bl2 = string != null && !"".equals((Object)string);
        boolean bl3 = OneSignal.getInAppAlertNotificationEnabled();
        boolean bl4 = OneSignal.isAppActive();
        if (!bl2) return false;
        if (OneSignal.getNotificationsWhenActiveEnabled()) return bl;
        if (bl3) return bl;
        if (bl4) return false;
        return bl;
    }

    private static boolean shouldDisplayNotif(NotificationGenerationJob notificationGenerationJob) {
        boolean bl;
        block5 : {
            block4 : {
                if (notificationGenerationJob.isInAppPreviewPush && Build.VERSION.SDK_INT <= 18) {
                    return false;
                }
                if (notificationGenerationJob.hasExtender()) break block4;
                boolean bl2 = NotificationBundleProcessor.shouldDisplay(notificationGenerationJob.jsonPayload.optString("alert"));
                bl = false;
                if (!bl2) break block5;
            }
            bl = true;
        }
        return bl;
    }

    private static boolean startExtenderService(Context context, Bundle bundle, ProcessedBundleResult processedBundleResult) {
        Intent intent = NotificationExtenderService.getIntent(context);
        if (intent == null) {
            return false;
        }
        intent.putExtra("json_payload", NotificationBundleProcessor.bundleAsJSONObject(bundle).toString());
        intent.putExtra("timestamp", System.currentTimeMillis() / 1000L);
        int n = Integer.parseInt((String)bundle.getString("pri", "0"));
        boolean bl = false;
        if (n > 9) {
            bl = true;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            NotificationExtenderService.enqueueWork(context, intent.getComponent(), 2071862121, intent, bl);
        } else {
            context.startService(intent);
        }
        processedBundleResult.hasExtenderService = true;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void unMinifyButtonsFromBundle(Bundle bundle) {
        JSONObject jSONObject;
        JSONArray jSONArray;
        int n;
        JSONObject jSONObject2;
        if (!bundle.containsKey(PUSH_MINIFIED_BUTTONS_LIST)) {
            return;
        }
        try {
            jSONObject2 = new JSONObject(bundle.getString("custom"));
            jSONObject = jSONObject2.has(PUSH_ADDITIONAL_DATA_KEY) ? jSONObject2.getJSONObject(PUSH_ADDITIONAL_DATA_KEY) : new JSONObject();
            jSONArray = new JSONArray(bundle.getString(PUSH_MINIFIED_BUTTONS_LIST));
            bundle.remove(PUSH_MINIFIED_BUTTONS_LIST);
            n = 0;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
        do {
            if (n < jSONArray.length()) {
                String string;
                JSONObject jSONObject3 = jSONArray.getJSONObject(n);
                String string2 = jSONObject3.getString(PUSH_MINIFIED_BUTTON_TEXT);
                jSONObject3.remove(PUSH_MINIFIED_BUTTON_TEXT);
                if (jSONObject3.has(PUSH_MINIFIED_BUTTON_ID)) {
                    string = jSONObject3.getString(PUSH_MINIFIED_BUTTON_ID);
                    jSONObject3.remove(PUSH_MINIFIED_BUTTON_ID);
                } else {
                    string = string2;
                }
                jSONObject3.put("id", (Object)string);
                jSONObject3.put("text", (Object)string2);
                if (jSONObject3.has(PUSH_MINIFIED_BUTTON_ICON)) {
                    jSONObject3.put("icon", (Object)jSONObject3.getString(PUSH_MINIFIED_BUTTON_ICON));
                    jSONObject3.remove(PUSH_MINIFIED_BUTTON_ICON);
                }
            } else {
                jSONObject.put("actionButtons", (Object)jSONArray);
                jSONObject.put("actionId", (Object)DEFAULT_ACTION);
                if (!jSONObject2.has(PUSH_ADDITIONAL_DATA_KEY)) {
                    jSONObject2.put(PUSH_ADDITIONAL_DATA_KEY, (Object)jSONObject);
                }
                bundle.putString("custom", jSONObject2.toString());
                return;
            }
            ++n;
        } while (true);
    }

    static class ProcessedBundleResult {
        boolean hasExtenderService;
        boolean inAppPreviewShown;
        boolean isDup;
        boolean isOneSignalPayload;

        ProcessedBundleResult() {
        }

        boolean processed() {
            return !this.isOneSignalPayload || this.hasExtenderService || this.isDup || this.inAppPreviewShown;
            {
            }
        }
    }

}

