/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.OSNotificationPayload;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class OSNotification {
    public int androidNotificationId;
    public DisplayType displayType;
    public List<OSNotificationPayload> groupedNotifications;
    public boolean isAppInFocus;
    public OSNotificationPayload payload;
    public boolean shown;

    public OSNotification() {
    }

    public OSNotification(JSONObject jSONObject) {
        this.isAppInFocus = jSONObject.optBoolean("isAppInFocus");
        this.shown = jSONObject.optBoolean("shown", this.shown);
        this.androidNotificationId = jSONObject.optInt("androidNotificationId");
        this.displayType = DisplayType.values()[jSONObject.optInt("displayType")];
        if (jSONObject.has("groupedNotifications")) {
            JSONArray jSONArray = jSONObject.optJSONArray("groupedNotifications");
            this.groupedNotifications = new ArrayList();
            for (int i = 0; i < jSONArray.length(); ++i) {
                this.groupedNotifications.add((Object)new OSNotificationPayload(jSONArray.optJSONObject(i)));
            }
        }
        if (jSONObject.has("payload")) {
            this.payload = new OSNotificationPayload(jSONObject.optJSONObject("payload"));
        }
    }

    @Deprecated
    public String stringify() {
        JSONObject jSONObject = this.toJSONObject();
        try {
            if (jSONObject.has("additionalData")) {
                jSONObject.put("additionalData", (Object)jSONObject.optJSONObject("additionalData").toString());
            }
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
        }
        return jSONObject.toString();
    }

    public JSONObject toJSONObject() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("isAppInFocus", this.isAppInFocus);
            jSONObject.put("shown", this.shown);
            jSONObject.put("androidNotificationId", this.androidNotificationId);
            jSONObject.put("displayType", this.displayType.ordinal());
            if (this.groupedNotifications != null) {
                JSONArray jSONArray = new JSONArray();
                Iterator iterator = this.groupedNotifications.iterator();
                while (iterator.hasNext()) {
                    jSONArray.put((Object)((OSNotificationPayload)iterator.next()).toJSONObject());
                }
                jSONObject.put("groupedNotifications", (Object)jSONArray);
            }
            jSONObject.put("payload", (Object)this.payload.toJSONObject());
            return jSONObject;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return jSONObject;
        }
    }

    public static final class DisplayType
    extends Enum<DisplayType> {
        private static final /* synthetic */ DisplayType[] $VALUES;
        public static final /* enum */ DisplayType InAppAlert;
        public static final /* enum */ DisplayType None;
        public static final /* enum */ DisplayType Notification;

        static {
            DisplayType displayType;
            DisplayType displayType2;
            DisplayType displayType3;
            Notification = displayType2 = new DisplayType();
            InAppAlert = displayType = new DisplayType();
            None = displayType3 = new DisplayType();
            $VALUES = new DisplayType[]{displayType2, displayType, displayType3};
        }

        public static DisplayType valueOf(String string2) {
            return (DisplayType)Enum.valueOf(DisplayType.class, (String)string2);
        }

        public static DisplayType[] values() {
            return (DisplayType[])$VALUES.clone();
        }
    }

}

