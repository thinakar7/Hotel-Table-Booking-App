/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.util.DisplayMetrics
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.RelativeLayout
 *  androidx.core.view.ViewCompat
 *  androidx.customview.widget.ViewDragHelper
 *  androidx.customview.widget.ViewDragHelper$Callback
 *  java.lang.Object
 */
package com.onesignal;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.core.view.ViewCompat;
import androidx.customview.widget.ViewDragHelper;
import com.onesignal.OSViewUtils;

class DraggableRelativeLayout
extends RelativeLayout {
    private static final int EXTRA_PX_DISMISS;
    private static final int MARGIN_PX_SIZE;
    private boolean dismissing;
    private ViewDragHelper mDragHelper;
    private DraggableListener mListener;
    private Params params;

    static {
        MARGIN_PX_SIZE = OSViewUtils.dpToPx(28);
        EXTRA_PX_DISMISS = OSViewUtils.dpToPx(64);
    }

    public DraggableRelativeLayout(Context context) {
        super(context);
        this.setClipChildren(false);
        this.createDragHelper();
    }

    private void createDragHelper() {
        this.mDragHelper = ViewDragHelper.create((ViewGroup)this, (float)1.0f, (ViewDragHelper.Callback)new ViewDragHelper.Callback(){
            private int lastYPos;

            public int clampViewPositionHorizontal(View view, int n, int n2) {
                return DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).maxXPos;
            }

            public int clampViewPositionVertical(View view, int n, int n2) {
                this.lastYPos = n;
                if (DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).dragDirection == 1) {
                    if (n >= DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).dragThresholdY && DraggableRelativeLayout.this.mListener != null) {
                        DraggableRelativeLayout.this.mListener.onDragStart();
                    }
                    if (n < DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).maxYPos) {
                        return DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).maxYPos;
                    }
                } else {
                    if (n <= DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).dragThresholdY && DraggableRelativeLayout.this.mListener != null) {
                        DraggableRelativeLayout.this.mListener.onDragStart();
                    }
                    if (n > DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).maxYPos) {
                        return DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).maxYPos;
                    }
                }
                return n;
            }

            public void onViewReleased(View view, float f, float f2) {
                int n = DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).maxYPos;
                if (!DraggableRelativeLayout.this.dismissing) {
                    if (DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).dragDirection == 1) {
                        if (this.lastYPos > DraggableRelativeLayout.this.params.dismissingYPos || f2 > (float)DraggableRelativeLayout.this.params.dismissingYVelocity) {
                            n = DraggableRelativeLayout.this.params.offScreenYPos;
                            DraggableRelativeLayout.this.dismissing = true;
                            if (DraggableRelativeLayout.this.mListener != null) {
                                DraggableRelativeLayout.this.mListener.onDismiss();
                            }
                        }
                    } else if (this.lastYPos < DraggableRelativeLayout.this.params.dismissingYPos || f2 < (float)DraggableRelativeLayout.this.params.dismissingYVelocity) {
                        n = DraggableRelativeLayout.this.params.offScreenYPos;
                        DraggableRelativeLayout.this.dismissing = true;
                        if (DraggableRelativeLayout.this.mListener != null) {
                            DraggableRelativeLayout.this.mListener.onDismiss();
                        }
                    }
                }
                if (DraggableRelativeLayout.this.mDragHelper.settleCapturedViewAt(DraggableRelativeLayout.access$300((DraggableRelativeLayout)DraggableRelativeLayout.this).maxXPos, n)) {
                    ViewCompat.postInvalidateOnAnimation((View)DraggableRelativeLayout.this);
                }
            }

            public boolean tryCaptureView(View view, int n) {
                return true;
            }
        });
    }

    public void computeScroll() {
        super.computeScroll();
        if (this.mDragHelper.continueSettling(true)) {
            ViewCompat.postInvalidateOnAnimation((View)this);
        }
    }

    public void dismiss() {
        this.dismissing = true;
        this.mDragHelper.smoothSlideViewTo((View)this, this.getLeft(), this.params.offScreenYPos);
        ViewCompat.postInvalidateOnAnimation((View)this);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        DraggableListener draggableListener;
        if (this.dismissing) {
            return true;
        }
        int n = motionEvent.getAction();
        if ((n == 0 || n == 5) && (draggableListener = this.mListener) != null) {
            draggableListener.onDragEnd();
        }
        this.mDragHelper.processTouchEvent(motionEvent);
        return false;
    }

    void setListener(DraggableListener draggableListener) {
        this.mListener = draggableListener;
    }

    void setParams(Params params) {
        this.params = params;
        params.offScreenYPos = params.messageHeight + params.posY + (Resources.getSystem().getDisplayMetrics().heightPixels - params.messageHeight - params.posY) + DraggableRelativeLayout.EXTRA_PX_DISMISS;
        params.dismissingYVelocity = OSViewUtils.dpToPx(3000);
        if (params.dragDirection == 0) {
            params.offScreenYPos = -params.messageHeight - DraggableRelativeLayout.MARGIN_PX_SIZE;
            params.dismissingYVelocity = -params.dismissingYVelocity;
            params.dismissingYPos = params.offScreenYPos / 3;
            return;
        }
        params.dismissingYPos = params.messageHeight / 3 + 2 * params.maxYPos;
    }

    static interface DraggableListener {
        public void onDismiss();

        public void onDragEnd();

        public void onDragStart();
    }

    static class Params {
        static final int DRAGGABLE_DIRECTION_DOWN = 1;
        static final int DRAGGABLE_DIRECTION_UP;
        private int dismissingYPos;
        private int dismissingYVelocity;
        int dragDirection;
        int dragThresholdY;
        int height;
        int maxXPos;
        int maxYPos;
        int messageHeight;
        private int offScreenYPos;
        int posY;

        Params() {
        }
    }

}

