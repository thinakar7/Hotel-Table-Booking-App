/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.device.iap.PurchasingListener
 *  com.amazon.device.iap.PurchasingService
 *  com.amazon.device.iap.model.Product
 *  com.amazon.device.iap.model.ProductDataResponse
 *  com.amazon.device.iap.model.ProductDataResponse$RequestStatus
 *  com.amazon.device.iap.model.PurchaseResponse
 *  com.amazon.device.iap.model.PurchaseResponse$RequestStatus
 *  com.amazon.device.iap.model.PurchaseUpdatesResponse
 *  com.amazon.device.iap.model.Receipt
 *  com.amazon.device.iap.model.RequestId
 *  com.amazon.device.iap.model.UserData
 *  com.amazon.device.iap.model.UserDataResponse
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.NoSuchFieldError
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Set
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.content.Context;
import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.PurchasingService;
import com.amazon.device.iap.model.Product;
import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.RequestId;
import com.amazon.device.iap.model.UserData;
import com.amazon.device.iap.model.UserDataResponse;
import com.onesignal.OneSignal;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class TrackAmazonPurchase {
    private boolean canTrack = false;
    private Context context;
    private Field listenerHandlerField;
    private Object listenerHandlerObject;
    private OSPurchasingListener osPurchasingListener;

    TrackAmazonPurchase(Context context) {
        this.context = context;
        try {
            OSPurchasingListener oSPurchasingListener;
            Field field;
            Class class_ = Class.forName((String)"com.amazon.device.iap.internal.d");
            this.listenerHandlerObject = class_.getMethod("d", new Class[0]).invoke(null, new Object[0]);
            this.listenerHandlerField = field = class_.getDeclaredField("f");
            field.setAccessible(true);
            this.osPurchasingListener = oSPurchasingListener = new OSPurchasingListener();
            oSPurchasingListener.orgPurchasingListener = (PurchasingListener)this.listenerHandlerField.get(this.listenerHandlerObject);
            this.canTrack = true;
            this.setListener();
        }
        catch (NoSuchFieldException noSuchFieldException) {
            TrackAmazonPurchase.logAmazonIAPListenerError((Exception)((Object)noSuchFieldException));
            return;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            TrackAmazonPurchase.logAmazonIAPListenerError((Exception)((Object)noSuchMethodException));
        }
        catch (InvocationTargetException invocationTargetException) {
            TrackAmazonPurchase.logAmazonIAPListenerError((Exception)((Object)invocationTargetException));
        }
        catch (IllegalAccessException illegalAccessException) {
            TrackAmazonPurchase.logAmazonIAPListenerError((Exception)((Object)illegalAccessException));
        }
        catch (ClassNotFoundException classNotFoundException) {
            TrackAmazonPurchase.logAmazonIAPListenerError((Exception)((Object)classNotFoundException));
        }
    }

    private static void logAmazonIAPListenerError(Exception exception) {
        OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Error adding Amazon IAP listener.", exception);
        exception.printStackTrace();
    }

    private void setListener() {
        PurchasingService.registerListener((Context)this.context, (PurchasingListener)this.osPurchasingListener);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    void checkListener() {
        PurchasingListener purchasingListener;
        if (!this.canTrack) {
            return;
        }
        try {
            purchasingListener = (PurchasingListener)this.listenerHandlerField.get(this.listenerHandlerObject);
            OSPurchasingListener oSPurchasingListener = this.osPurchasingListener;
            if (purchasingListener == oSPurchasingListener) return;
        }
        catch (IllegalAccessException illegalAccessException) {
            illegalAccessException.printStackTrace();
            return;
        }
        oSPurchasingListener.orgPurchasingListener = purchasingListener;
        this.setListener();
    }

    private class OSPurchasingListener
    implements PurchasingListener {
        private String currentMarket;
        private RequestId lastRequestId;
        PurchasingListener orgPurchasingListener;

        private OSPurchasingListener() {
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        private String marketToCurrencyCode(String var1_1) {
            block20 : {
                block11 : {
                    block12 : {
                        block13 : {
                            block14 : {
                                block15 : {
                                    block16 : {
                                        block17 : {
                                            block18 : {
                                                block19 : {
                                                    var2_2 = var1_1.hashCode();
                                                    if (var2_2 == 2100) break block11;
                                                    if (var2_2 == 2128) break block12;
                                                    if (var2_2 == 2142) break block13;
                                                    if (var2_2 == 2177) break block14;
                                                    if (var2_2 == 2222) break block15;
                                                    if (var2_2 == 2252) break block16;
                                                    if (var2_2 == 2267) break block17;
                                                    if (var2_2 == 2347) break block18;
                                                    if (var2_2 == 2374) break block19;
                                                    if (var2_2 != 2718 || !var1_1.equals((Object)"US")) ** GOTO lbl-1000
                                                    var3_3 = 0;
                                                    break block20;
                                                }
                                                if (!var1_1.equals((Object)"JP")) ** GOTO lbl-1000
                                                var3_3 = 6;
                                                break block20;
                                            }
                                            if (!var1_1.equals((Object)"IT")) ** GOTO lbl-1000
                                            var3_3 = 5;
                                            break block20;
                                        }
                                        if (!var1_1.equals((Object)"GB")) ** GOTO lbl-1000
                                        var3_3 = 1;
                                        break block20;
                                    }
                                    if (!var1_1.equals((Object)"FR")) ** GOTO lbl-1000
                                    var3_3 = 3;
                                    break block20;
                                }
                                if (!var1_1.equals((Object)"ES")) ** GOTO lbl-1000
                                var3_3 = 4;
                                break block20;
                            }
                            if (!var1_1.equals((Object)"DE")) ** GOTO lbl-1000
                            var3_3 = 2;
                            break block20;
                        }
                        if (!var1_1.equals((Object)"CA")) ** GOTO lbl-1000
                        var3_3 = 7;
                        break block20;
                    }
                    if (!var1_1.equals((Object)"BR")) ** GOTO lbl-1000
                    var3_3 = 8;
                    break block20;
                }
                if (var1_1.equals((Object)"AU")) {
                    var3_3 = 9;
                } else lbl-1000: // 10 sources:
                {
                    var3_3 = -1;
                }
            }
            switch (var3_3) {
                default: {
                    return "";
                }
                case 9: {
                    return "AUD";
                }
                case 8: {
                    return "BRL";
                }
                case 7: {
                    return "CDN";
                }
                case 6: {
                    return "JPY";
                }
                case 2: 
                case 3: 
                case 4: 
                case 5: {
                    return "EUR";
                }
                case 1: {
                    return "GBP";
                }
                case 0: 
            }
            return "USD";
        }

        public void onProductDataResponse(ProductDataResponse productDataResponse) {
            RequestId requestId = this.lastRequestId;
            if (requestId != null && requestId.toString().equals((Object)productDataResponse.getRequestId().toString())) {
                try {
                    if (1.$SwitchMap$com$amazon$device$iap$model$ProductDataResponse$RequestStatus[productDataResponse.getRequestStatus().ordinal()] == 1) {
                        JSONArray jSONArray = new JSONArray();
                        Map map = productDataResponse.getProductData();
                        Iterator iterator = map.keySet().iterator();
                        while (iterator.hasNext()) {
                            Product product = (Product)map.get((Object)((String)iterator.next()));
                            JSONObject jSONObject = new JSONObject();
                            jSONObject.put("sku", (Object)product.getSku());
                            jSONObject.put("iso", (Object)this.marketToCurrencyCode(this.currentMarket));
                            String string2 = product.getPrice();
                            if (!string2.matches("^[0-9]")) {
                                string2 = string2.substring(1);
                            }
                            jSONObject.put("amount", (Object)string2);
                            jSONArray.put((Object)jSONObject);
                        }
                        OneSignal.sendPurchases(jSONArray, false, null);
                    }
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                }
                return;
            }
            PurchasingListener purchasingListener = this.orgPurchasingListener;
            if (purchasingListener != null) {
                purchasingListener.onProductDataResponse(productDataResponse);
            }
        }

        public void onPurchaseResponse(PurchaseResponse purchaseResponse) {
            PurchasingListener purchasingListener;
            if (purchaseResponse.getRequestStatus() == PurchaseResponse.RequestStatus.SUCCESSFUL) {
                this.currentMarket = purchaseResponse.getUserData().getMarketplace();
                HashSet hashSet = new HashSet();
                hashSet.add((Object)purchaseResponse.getReceipt().getSku());
                this.lastRequestId = PurchasingService.getProductData((Set)hashSet);
            }
            if ((purchasingListener = this.orgPurchasingListener) != null) {
                purchasingListener.onPurchaseResponse(purchaseResponse);
            }
        }

        public void onPurchaseUpdatesResponse(PurchaseUpdatesResponse purchaseUpdatesResponse) {
            PurchasingListener purchasingListener = this.orgPurchasingListener;
            if (purchasingListener != null) {
                purchasingListener.onPurchaseUpdatesResponse(purchaseUpdatesResponse);
            }
        }

        public void onUserDataResponse(UserDataResponse userDataResponse) {
            PurchasingListener purchasingListener = this.orgPurchasingListener;
            if (purchasingListener != null) {
                purchasingListener.onUserDataResponse(userDataResponse);
            }
        }
    }

}

