/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.onesignal.GcmBroadcastReceiver;
import com.onesignal.NotificationBundleProcessor;
import com.onesignal.NotificationOpenedProcessor;
import com.onesignal.OSNotificationFormatHelper;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class NotificationPayloadProcessorHMS {
    NotificationPayloadProcessorHMS() {
    }

    private static JSONObject covertHMSOpenIntentToJson(Intent intent) {
        if (!OSNotificationFormatHelper.isOneSignalIntent(intent)) {
            return null;
        }
        JSONObject jSONObject = NotificationBundleProcessor.bundleAsJSONObject(intent.getExtras());
        NotificationPayloadProcessorHMS.reformatButtonClickAction(jSONObject);
        return jSONObject;
    }

    static void handleHMSNotificationOpenIntent(Activity activity, Intent intent) {
        OneSignal.setAppContext((Context)activity);
        if (intent == null) {
            return;
        }
        JSONObject jSONObject = NotificationPayloadProcessorHMS.covertHMSOpenIntentToJson(intent);
        if (jSONObject == null) {
            return;
        }
        NotificationPayloadProcessorHMS.handleProcessJsonOpenData(activity, jSONObject);
    }

    private static void handleProcessJsonOpenData(Activity activity, JSONObject jSONObject) {
        if (NotificationOpenedProcessor.handleIAMPreviewOpen((Context)activity, jSONObject)) {
            return;
        }
        OneSignal.handleNotificationOpen((Context)activity, new JSONArray().put((Object)jSONObject), false, OSNotificationFormatHelper.getOSNotificationIdFromJson(jSONObject));
    }

    public static void processDataMessageReceived(Context context, String string) {
        OneSignal.setAppContext(context);
        if (string == null) {
            return;
        }
        Bundle bundle = OSUtils.jsonStringToBundle(string);
        if (bundle == null) {
            return;
        }
        if (NotificationBundleProcessor.processBundleFromReceiver(context, bundle).processed()) {
            return;
        }
        GcmBroadcastReceiver.startGCMService(context, bundle);
    }

    private static void reformatButtonClickAction(JSONObject jSONObject) {
        String string;
        block3 : {
            try {
                string = (String)NotificationBundleProcessor.getCustomJSONObject(jSONObject).remove("actionId");
                if (string != null) break block3;
                return;
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
                return;
            }
        }
        jSONObject.put("actionId", (Object)string);
    }
}

