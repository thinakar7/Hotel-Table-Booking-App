/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Bundle
 *  android.os.IBinder
 *  androidx.core.app.NotificationCompat
 *  androidx.core.app.NotificationCompat$Extender
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.List
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import com.onesignal.GcmBroadcastReceiver;
import com.onesignal.JobIntentService;
import com.onesignal.NotificationBundleProcessor;
import com.onesignal.NotificationGenerationJob;
import com.onesignal.OSNotificationDisplayedResult;
import com.onesignal.OSNotificationPayload;
import com.onesignal.OSNotificationReceivedResult;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class NotificationExtenderService
extends JobIntentService {
    static final int EXTENDER_SERVICE_JOB_ID = 2071862121;
    private OverrideSettings currentBaseOverrideSettings = null;
    private JSONObject currentJsonPayload;
    private boolean currentlyRestoring;
    private OSNotificationDisplayedResult osNotificationDisplayedResult;
    private Long restoreTimestamp;

    private NotificationGenerationJob createNotifJobFromCurrent() {
        NotificationGenerationJob notificationGenerationJob = new NotificationGenerationJob((Context)this);
        notificationGenerationJob.restoring = this.currentlyRestoring;
        notificationGenerationJob.jsonPayload = this.currentJsonPayload;
        notificationGenerationJob.shownTimeStamp = this.restoreTimestamp;
        notificationGenerationJob.overrideSettings = this.currentBaseOverrideSettings;
        return notificationGenerationJob;
    }

    static Intent getIntent(Context context) {
        Intent intent;
        PackageManager packageManager = context.getPackageManager();
        List list = packageManager.queryIntentServices(intent = new Intent().setAction("com.onesignal.NotificationExtender").setPackage(context.getPackageName()), 128);
        if (list.size() < 1) {
            return null;
        }
        intent.setComponent(new ComponentName(context, ((ResolveInfo)list.get((int)0)).serviceInfo.name));
        return intent;
    }

    private void processIntent(Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle == null) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No extras sent to NotificationExtenderService in its Intent!\n");
            stringBuilder.append((Object)intent);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            return;
        }
        String string = bundle.getString("json_payload");
        if (string == null) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("json_payload key is nonexistent from bundle passed to NotificationExtenderService: ");
            stringBuilder.append((Object)bundle);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            return;
        }
        try {
            this.currentJsonPayload = new JSONObject(string);
            this.currentlyRestoring = bundle.getBoolean("restoring", false);
            if (bundle.containsKey("android_notif_id")) {
                OverrideSettings overrideSettings;
                this.currentBaseOverrideSettings = overrideSettings = new OverrideSettings();
                overrideSettings.androidNotificationId = bundle.getInt("android_notif_id");
            }
            if (!this.currentlyRestoring && OneSignal.notValidOrDuplicated((Context)this, this.currentJsonPayload)) {
                return;
            }
            this.restoreTimestamp = bundle.getLong("timestamp");
            this.processJsonObject(this.currentJsonPayload, this.currentlyRestoring);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    protected final OSNotificationDisplayedResult displayNotification(OverrideSettings overrideSettings) {
        if (this.osNotificationDisplayedResult == null && overrideSettings != null) {
            overrideSettings.override(this.currentBaseOverrideSettings);
            this.osNotificationDisplayedResult = new OSNotificationDisplayedResult();
            NotificationGenerationJob notificationGenerationJob = this.createNotifJobFromCurrent();
            notificationGenerationJob.overrideSettings = overrideSettings;
            this.osNotificationDisplayedResult.androidNotificationId = NotificationBundleProcessor.ProcessJobForDisplay(notificationGenerationJob);
            return this.osNotificationDisplayedResult;
        }
        return null;
    }

    @Override
    protected final void onHandleWork(Intent intent) {
        if (intent == null) {
            return;
        }
        this.processIntent(intent);
        GcmBroadcastReceiver.completeWakefulIntent((Intent)intent);
    }

    protected abstract boolean onNotificationProcessing(OSNotificationReceivedResult var1);

    void processJsonObject(JSONObject jSONObject, boolean bl) {
        OSNotificationReceivedResult oSNotificationReceivedResult = new OSNotificationReceivedResult();
        oSNotificationReceivedResult.payload = NotificationBundleProcessor.OSNotificationPayloadFrom(jSONObject);
        oSNotificationReceivedResult.restoring = bl;
        oSNotificationReceivedResult.isAppInFocus = OneSignal.isAppActive();
        this.osNotificationDisplayedResult = null;
        boolean bl2 = false;
        try {
            boolean bl3;
            bl2 = bl3 = this.onNotificationProcessing(oSNotificationReceivedResult);
        }
        catch (Throwable throwable) {
            if (this.osNotificationDisplayedResult == null) {
                OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "onNotificationProcessing throw an exception. Displaying normal OneSignal notification.", throwable);
                bl2 = false;
            }
            OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "onNotificationProcessing throw an exception. Extended notification displayed but custom processing did not finish.", throwable);
        }
        if (this.osNotificationDisplayedResult == null) {
            boolean bl4 = !bl2 && NotificationBundleProcessor.shouldDisplay(jSONObject.optString("alert"));
            if (!bl4) {
                if (!bl) {
                    NotificationGenerationJob notificationGenerationJob = new NotificationGenerationJob((Context)this);
                    notificationGenerationJob.jsonPayload = jSONObject;
                    notificationGenerationJob.overrideSettings = new OverrideSettings();
                    notificationGenerationJob.overrideSettings.androidNotificationId = -1;
                    NotificationBundleProcessor.processNotification(notificationGenerationJob, true);
                    OneSignal.handleNotificationReceived(NotificationBundleProcessor.newJsonArray(jSONObject), false, false);
                } else if (this.currentBaseOverrideSettings != null) {
                    NotificationBundleProcessor.markRestoredNotificationAsDismissed(this.createNotifJobFromCurrent());
                }
            } else {
                NotificationBundleProcessor.ProcessJobForDisplay(this.createNotifJobFromCurrent());
            }
            if (bl) {
                OSUtils.sleep(100);
            }
        }
    }

    public static class OverrideSettings {
        public Integer androidNotificationId;
        public NotificationCompat.Extender extender;

        void override(OverrideSettings overrideSettings) {
            if (overrideSettings == null) {
                return;
            }
            Integer n = overrideSettings.androidNotificationId;
            if (n != null) {
                this.androidNotificationId = n;
            }
        }
    }

}

