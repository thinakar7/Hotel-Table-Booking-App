/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.lang.String
 */
package com.onesignal;

import android.content.Context;
import com.onesignal.OneSignal;

class DelayedConsentInitializationParameters {
    public String appId;
    public Context context;
    public String googleProjectNumber;
    public OneSignal.NotificationOpenedHandler openedHandler;
    public OneSignal.NotificationReceivedHandler receivedHandler;

    DelayedConsentInitializationParameters(Context context, String string, String string2, OneSignal.NotificationOpenedHandler notificationOpenedHandler, OneSignal.NotificationReceivedHandler notificationReceivedHandler) {
        this.context = context;
        this.googleProjectNumber = string;
        this.appId = string2;
        this.openedHandler = notificationOpenedHandler;
        this.receivedHandler = notificationReceivedHandler;
    }
}

