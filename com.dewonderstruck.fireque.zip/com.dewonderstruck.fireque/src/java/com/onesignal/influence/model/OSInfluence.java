/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal.influence.model;

import com.onesignal.influence.model.OSInfluenceChannel;
import com.onesignal.influence.model.OSInfluenceType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class OSInfluence {
    private static final String INFLUENCE_CHANNEL = "influence_channel";
    private static final String INFLUENCE_IDS = "influence_ids";
    private static final String INFLUENCE_TYPE = "influence_type";
    private JSONArray ids;
    private OSInfluenceChannel influenceChannel;
    private OSInfluenceType influenceType;

    private OSInfluence() {
    }

    OSInfluence(Builder builder) {
        this.ids = builder.ids;
        this.influenceType = builder.influenceType;
        this.influenceChannel = builder.influenceChannel;
    }

    public OSInfluence(String string2) throws JSONException {
        JSONObject jSONObject = new JSONObject(string2);
        String string3 = jSONObject.getString(INFLUENCE_CHANNEL);
        String string4 = jSONObject.getString(INFLUENCE_TYPE);
        String string5 = jSONObject.getString(INFLUENCE_IDS);
        this.influenceChannel = OSInfluenceChannel.fromString(string3);
        this.influenceType = OSInfluenceType.fromString(string4);
        JSONArray jSONArray = string5.isEmpty() ? null : new JSONArray(string5);
        this.ids = jSONArray;
    }

    public OSInfluence copy() {
        OSInfluence oSInfluence = new OSInfluence();
        oSInfluence.ids = this.ids;
        oSInfluence.influenceType = this.influenceType;
        oSInfluence.influenceChannel = this.influenceChannel;
        return oSInfluence;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null) {
            if (this.getClass() != object.getClass()) {
                return false;
            }
            OSInfluence oSInfluence = (OSInfluence)object;
            return this.influenceChannel == oSInfluence.influenceChannel && this.influenceType == oSInfluence.influenceType;
        }
        return false;
    }

    public String getDirectId() throws JSONException {
        JSONArray jSONArray = this.ids;
        if (jSONArray != null && jSONArray.length() > 0) {
            return this.ids.getString(0);
        }
        return null;
    }

    public JSONArray getIds() {
        return this.ids;
    }

    public OSInfluenceChannel getInfluenceChannel() {
        return this.influenceChannel;
    }

    public OSInfluenceType getInfluenceType() {
        return this.influenceType;
    }

    public int hashCode() {
        return 31 * this.influenceChannel.hashCode() + this.influenceType.hashCode();
    }

    public void setIds(JSONArray jSONArray) {
        this.ids = jSONArray;
    }

    public String toJSONString() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(INFLUENCE_CHANNEL, (Object)this.influenceChannel.toString());
        jSONObject.put(INFLUENCE_TYPE, (Object)this.influenceType.toString());
        JSONArray jSONArray = this.ids;
        String string2 = jSONArray != null ? jSONArray.toString() : "";
        jSONObject.put(INFLUENCE_IDS, (Object)string2);
        return jSONObject.toString();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SessionInfluence{influenceChannel=");
        stringBuilder.append((Object)this.influenceChannel);
        stringBuilder.append(", influenceType=");
        stringBuilder.append((Object)this.influenceType);
        stringBuilder.append(", ids=");
        stringBuilder.append((Object)this.ids);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public static class Builder {
        private JSONArray ids;
        private OSInfluenceChannel influenceChannel;
        private OSInfluenceType influenceType;

        private Builder() {
        }

        public static Builder newInstance() {
            return new Builder();
        }

        public OSInfluence build() {
            return new OSInfluence(this);
        }

        public Builder setIds(JSONArray jSONArray) {
            this.ids = jSONArray;
            return this;
        }

        public Builder setInfluenceChannel(OSInfluenceChannel oSInfluenceChannel) {
            this.influenceChannel = oSInfluenceChannel;
            return this;
        }

        public Builder setInfluenceType(OSInfluenceType oSInfluenceType) {
            this.influenceType = oSInfluenceType;
            return this;
        }
    }

}

