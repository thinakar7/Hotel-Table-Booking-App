/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.onesignal.influence.model;

public final class OSInfluenceType
extends Enum<OSInfluenceType> {
    private static final /* synthetic */ OSInfluenceType[] $VALUES;
    public static final /* enum */ OSInfluenceType DIRECT;
    public static final /* enum */ OSInfluenceType DISABLED;
    public static final /* enum */ OSInfluenceType INDIRECT;
    public static final /* enum */ OSInfluenceType UNATTRIBUTED;

    static {
        OSInfluenceType oSInfluenceType;
        OSInfluenceType oSInfluenceType2;
        OSInfluenceType oSInfluenceType3;
        OSInfluenceType oSInfluenceType4;
        DIRECT = oSInfluenceType = new OSInfluenceType();
        INDIRECT = oSInfluenceType2 = new OSInfluenceType();
        UNATTRIBUTED = oSInfluenceType4 = new OSInfluenceType();
        DISABLED = oSInfluenceType3 = new OSInfluenceType();
        $VALUES = new OSInfluenceType[]{oSInfluenceType, oSInfluenceType2, oSInfluenceType4, oSInfluenceType3};
    }

    public static OSInfluenceType fromString(String string2) {
        if (string2 != null && !string2.isEmpty()) {
            for (OSInfluenceType oSInfluenceType : OSInfluenceType.values()) {
                if (!oSInfluenceType.name().equalsIgnoreCase(string2)) continue;
                return oSInfluenceType;
            }
            return UNATTRIBUTED;
        }
        return UNATTRIBUTED;
    }

    public static OSInfluenceType valueOf(String string2) {
        return (OSInfluenceType)Enum.valueOf(OSInfluenceType.class, (String)string2);
    }

    public static OSInfluenceType[] values() {
        return (OSInfluenceType[])$VALUES.clone();
    }

    public boolean isAttributed() {
        return this.isDirect() || this.isIndirect();
        {
        }
    }

    public boolean isDirect() {
        return this.equals((Object)DIRECT);
    }

    public boolean isDisabled() {
        return this.equals((Object)DISABLED);
    }

    public boolean isIndirect() {
        return this.equals((Object)INDIRECT);
    }

    public boolean isUnattributed() {
        return this.equals((Object)UNATTRIBUTED);
    }
}

