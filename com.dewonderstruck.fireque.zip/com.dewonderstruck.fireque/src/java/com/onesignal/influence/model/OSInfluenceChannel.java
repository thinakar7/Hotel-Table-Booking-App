/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.onesignal.influence.model;

public final class OSInfluenceChannel
extends Enum<OSInfluenceChannel> {
    private static final /* synthetic */ OSInfluenceChannel[] $VALUES;
    public static final /* enum */ OSInfluenceChannel IAM;
    public static final /* enum */ OSInfluenceChannel NOTIFICATION;
    private final String name;

    static {
        OSInfluenceChannel oSInfluenceChannel;
        OSInfluenceChannel oSInfluenceChannel2;
        IAM = oSInfluenceChannel2 = new OSInfluenceChannel("iam");
        NOTIFICATION = oSInfluenceChannel = new OSInfluenceChannel("notification");
        $VALUES = new OSInfluenceChannel[]{oSInfluenceChannel2, oSInfluenceChannel};
    }

    private OSInfluenceChannel(String string3) {
        this.name = string3;
    }

    public static OSInfluenceChannel fromString(String string2) {
        if (string2 != null && !string2.isEmpty()) {
            for (OSInfluenceChannel oSInfluenceChannel : OSInfluenceChannel.values()) {
                if (!oSInfluenceChannel.equalsName(string2)) continue;
                return oSInfluenceChannel;
            }
            return NOTIFICATION;
        }
        return NOTIFICATION;
    }

    public static OSInfluenceChannel valueOf(String string2) {
        return (OSInfluenceChannel)Enum.valueOf(OSInfluenceChannel.class, (String)string2);
    }

    public static OSInfluenceChannel[] values() {
        return (OSInfluenceChannel[])$VALUES.clone();
    }

    public boolean equalsName(String string2) {
        return this.name.equals((Object)string2);
    }

    public String toString() {
        return this.name;
    }
}

