/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal.influence;

import com.onesignal.OSLogger;
import com.onesignal.influence.OSChannelTracker;
import com.onesignal.influence.OSInfluenceDataRepository;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.influence.model.OSInfluenceChannel;
import com.onesignal.influence.model.OSInfluenceType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class OSInAppMessageTracker
extends OSChannelTracker {
    private static final String IAM_ID = "iam_id";
    public static final String TAG = OSInAppMessageTracker.class.getCanonicalName();

    OSInAppMessageTracker(OSInfluenceDataRepository oSInfluenceDataRepository, OSLogger oSLogger) {
        super(oSInfluenceDataRepository, oSLogger);
    }

    @Override
    void addSessionData(JSONObject jSONObject, OSInfluence oSInfluence) {
    }

    @Override
    public void cacheState() {
        OSInfluenceType oSInfluenceType = this.influenceType == null ? OSInfluenceType.UNATTRIBUTED : this.influenceType;
        OSInfluenceDataRepository oSInfluenceDataRepository = this.dataRepository;
        OSInfluenceType oSInfluenceType2 = oSInfluenceType == OSInfluenceType.DIRECT ? OSInfluenceType.INDIRECT : oSInfluenceType;
        oSInfluenceDataRepository.cacheIAMInfluenceType(oSInfluenceType2);
    }

    @Override
    int getChannelLimit() {
        return this.dataRepository.getIAMLimit();
    }

    @Override
    OSInfluenceChannel getChannelType() {
        return OSInfluenceChannel.IAM;
    }

    @Override
    public String getIdTag() {
        return IAM_ID;
    }

    @Override
    int getIndirectAttributionWindow() {
        return this.dataRepository.getIAMIndirectAttributionWindow();
    }

    @Override
    JSONArray getLastChannelObjects() throws JSONException {
        return this.dataRepository.getLastIAMsReceivedData();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    JSONArray getLastChannelObjectsReceivedByNewId(String string2) {
        JSONArray jSONArray2;
        JSONArray jSONArray;
        try {
            jSONArray2 = this.getLastChannelObjects();
        }
        catch (JSONException jSONException) {
            this.logger.error("Generating IAM tracker getLastChannelObjects JSONObject ", jSONException);
            return new JSONArray();
        }
        try {
            jSONArray = new JSONArray();
        }
        catch (JSONException jSONException) {
            this.logger.error("Before KITKAT API, Generating tracker lastChannelObjectReceived get JSONObject ", jSONException);
            return jSONArray2;
        }
        for (int n = 0; n < jSONArray2.length(); ++n) {
            if (string2.equals((Object)jSONArray2.getJSONObject(n).getString(this.getIdTag()))) continue;
            jSONArray.put((Object)jSONArray2.getJSONObject(n));
        }
        return jSONArray;
    }

    @Override
    void initInfluencedTypeFromCache() {
        this.setInfluenceType(this.dataRepository.getIAMCachedInfluenceType());
        if (this.influenceType != null && this.influenceType.isIndirect()) {
            this.setIndirectIds(this.getLastReceivedIds());
        }
        OSLogger oSLogger = this.logger;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OneSignal InAppMessageTracker initInfluencedTypeFromCache: ");
        stringBuilder.append(this.toString());
        oSLogger.debug(stringBuilder.toString());
    }

    @Override
    void saveChannelObjects(JSONArray jSONArray) {
        this.dataRepository.saveIAMs(jSONArray);
    }
}

