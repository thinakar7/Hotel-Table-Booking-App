/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal.influence;

import com.onesignal.OSLogger;
import com.onesignal.influence.OSInfluenceDataRepository;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.influence.model.OSInfluenceChannel;
import com.onesignal.influence.model.OSInfluenceType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class OSChannelTracker {
    private static final String TIME = "time";
    OSInfluenceDataRepository dataRepository;
    String directId;
    JSONArray indirectIds;
    OSInfluenceType influenceType;
    protected OSLogger logger;

    OSChannelTracker(OSInfluenceDataRepository oSInfluenceDataRepository, OSLogger oSLogger) {
        this.dataRepository = oSInfluenceDataRepository;
        this.logger = oSLogger;
    }

    private boolean isDirectSessionEnabled() {
        return this.dataRepository.isDirectInfluenceEnabled();
    }

    private boolean isIndirectSessionEnabled() {
        return this.dataRepository.isIndirectInfluenceEnabled();
    }

    private boolean isUnattributedSessionEnabled() {
        return this.dataRepository.isUnattributedInfluenceEnabled();
    }

    abstract void addSessionData(JSONObject var1, OSInfluence var2);

    public abstract void cacheState();

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null) {
            if (this.getClass() != object.getClass()) {
                return false;
            }
            OSChannelTracker oSChannelTracker = (OSChannelTracker)object;
            return this.influenceType == oSChannelTracker.influenceType && oSChannelTracker.getIdTag().equals((Object)this.getIdTag());
        }
        return false;
    }

    abstract int getChannelLimit();

    abstract OSInfluenceChannel getChannelType();

    public OSInfluence getCurrentSessionInfluence() {
        OSInfluence.Builder builder = OSInfluence.Builder.newInstance().setInfluenceType(OSInfluenceType.DISABLED);
        if (this.influenceType == null) {
            this.initInfluencedTypeFromCache();
        }
        if (this.influenceType.isDirect()) {
            if (this.isDirectSessionEnabled()) {
                JSONArray jSONArray = new JSONArray().put((Object)this.directId);
                builder = OSInfluence.Builder.newInstance().setIds(jSONArray).setInfluenceType(OSInfluenceType.DIRECT);
            }
        } else if (this.influenceType.isIndirect()) {
            if (this.isIndirectSessionEnabled()) {
                builder = OSInfluence.Builder.newInstance().setIds(this.indirectIds).setInfluenceType(OSInfluenceType.INDIRECT);
            }
        } else if (this.isUnattributedSessionEnabled()) {
            builder = OSInfluence.Builder.newInstance().setInfluenceType(OSInfluenceType.UNATTRIBUTED);
        }
        return builder.setInfluenceChannel(this.getChannelType()).build();
    }

    public String getDirectId() {
        return this.directId;
    }

    public abstract String getIdTag();

    abstract int getIndirectAttributionWindow();

    public JSONArray getIndirectIds() {
        return this.indirectIds;
    }

    public OSInfluenceType getInfluenceType() {
        return this.influenceType;
    }

    abstract JSONArray getLastChannelObjects() throws JSONException;

    abstract JSONArray getLastChannelObjectsReceivedByNewId(String var1);

    public JSONArray getLastReceivedIds() {
        long l;
        long l2;
        int n;
        JSONArray jSONArray;
        JSONArray jSONArray2 = new JSONArray();
        try {
            jSONArray = this.getLastChannelObjects();
            OSLogger oSLogger = this.logger;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("OneSignal ChannelTracker getLastReceivedIds lastChannelObjectReceived: ");
            stringBuilder.append((Object)jSONArray);
            oSLogger.debug(stringBuilder.toString());
            l = 1000L * (long)(60 * this.getIndirectAttributionWindow());
            l2 = System.currentTimeMillis();
            n = 0;
        }
        catch (JSONException jSONException) {
            this.logger.error("Generating tracker getLastReceivedIds JSONObject ", jSONException);
            return jSONArray2;
        }
        do {
            block4 : {
                if (n >= jSONArray.length()) break;
                JSONObject jSONObject = jSONArray.getJSONObject(n);
                if (l2 - jSONObject.getLong("time") > l) break block4;
                jSONArray2.put((Object)jSONObject.getString(this.getIdTag()));
            }
            ++n;
        } while (true);
        return jSONArray2;
    }

    public int hashCode() {
        return 31 * this.influenceType.hashCode() + this.getIdTag().hashCode();
    }

    abstract void initInfluencedTypeFromCache();

    public void resetAndInitInfluence() {
        JSONArray jSONArray;
        this.directId = null;
        this.indirectIds = jSONArray = this.getLastReceivedIds();
        OSInfluenceType oSInfluenceType = jSONArray.length() > 0 ? OSInfluenceType.INDIRECT : OSInfluenceType.UNATTRIBUTED;
        this.influenceType = oSInfluenceType;
        this.cacheState();
        OSLogger oSLogger = this.logger;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OneSignal OSChannelTracker resetAndInitInfluence: ");
        stringBuilder.append(this.getIdTag());
        stringBuilder.append(" finish with influenceType: ");
        stringBuilder.append((Object)((Object)this.influenceType));
        oSLogger.debug(stringBuilder.toString());
    }

    abstract void saveChannelObjects(JSONArray var1);

    public void saveLastId(String string2) {
        OSLogger oSLogger = this.logger;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OneSignal OSChannelTracker for: ");
        stringBuilder.append(this.getIdTag());
        stringBuilder.append(" saveLastId: ");
        stringBuilder.append(string2);
        oSLogger.debug(stringBuilder.toString());
        if (string2 != null) {
            if (string2.isEmpty()) {
                return;
            }
            JSONArray jSONArray = this.getLastChannelObjectsReceivedByNewId(string2);
            OSLogger oSLogger2 = this.logger;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("OneSignal OSChannelTracker for: ");
            stringBuilder2.append(this.getIdTag());
            stringBuilder2.append(" saveLastId with lastChannelObjectsReceived: ");
            stringBuilder2.append((Object)jSONArray);
            oSLogger2.debug(stringBuilder2.toString());
            try {
                jSONArray.put((Object)new JSONObject().put(this.getIdTag(), (Object)string2).put("time", System.currentTimeMillis()));
            }
            catch (JSONException jSONException) {
                this.logger.error("Generating tracker newInfluenceId JSONObject ", jSONException);
                return;
            }
            int n = this.getChannelLimit();
            JSONArray jSONArray2 = jSONArray;
            if (jSONArray.length() > n) {
                int n2 = jSONArray.length() - n;
                jSONArray2 = new JSONArray();
                for (int i = n2; i < jSONArray.length(); ++i) {
                    try {
                        jSONArray2.put(jSONArray.get(i));
                        continue;
                    }
                    catch (JSONException jSONException) {
                        this.logger.error("Before KITKAT API, Generating tracker lastChannelObjectsReceived get JSONObject ", jSONException);
                    }
                }
            }
            OSLogger oSLogger3 = this.logger;
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("OneSignal OSChannelTracker for: ");
            stringBuilder3.append(this.getIdTag());
            stringBuilder3.append(" with channelObjectToSave: ");
            stringBuilder3.append((Object)jSONArray2);
            oSLogger3.debug(stringBuilder3.toString());
            this.saveChannelObjects(jSONArray2);
            return;
        }
    }

    public void setDirectId(String string2) {
        this.directId = string2;
    }

    public void setIndirectIds(JSONArray jSONArray) {
        this.indirectIds = jSONArray;
    }

    public void setInfluenceType(OSInfluenceType oSInfluenceType) {
        this.influenceType = oSInfluenceType;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OSChannelTracker{tag=");
        stringBuilder.append(this.getIdTag());
        stringBuilder.append(", influenceType=");
        stringBuilder.append((Object)((Object)this.influenceType));
        stringBuilder.append(", indirectIds=");
        stringBuilder.append((Object)this.indirectIds);
        stringBuilder.append(", directId='");
        stringBuilder.append(this.directId);
        stringBuilder.append('\'');
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

