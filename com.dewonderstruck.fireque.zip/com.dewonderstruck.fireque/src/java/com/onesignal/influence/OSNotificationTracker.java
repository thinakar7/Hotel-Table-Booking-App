/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal.influence;

import com.onesignal.OSLogger;
import com.onesignal.influence.OSChannelTracker;
import com.onesignal.influence.OSInfluenceDataRepository;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.influence.model.OSInfluenceChannel;
import com.onesignal.influence.model.OSInfluenceType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class OSNotificationTracker
extends OSChannelTracker {
    private static final String DIRECT_TAG = "direct";
    private static final String NOTIFICATIONS_IDS = "notification_ids";
    private static final String NOTIFICATION_ID = "notification_id";
    public static final String TAG = OSNotificationTracker.class.getCanonicalName();

    OSNotificationTracker(OSInfluenceDataRepository oSInfluenceDataRepository, OSLogger oSLogger) {
        super(oSInfluenceDataRepository, oSLogger);
    }

    @Override
    void addSessionData(JSONObject jSONObject, OSInfluence oSInfluence) {
        if (oSInfluence.getInfluenceType().isAttributed()) {
            try {
                jSONObject.put(DIRECT_TAG, oSInfluence.getInfluenceType().isDirect());
                jSONObject.put(NOTIFICATIONS_IDS, (Object)oSInfluence.getIds());
                return;
            }
            catch (JSONException jSONException) {
                this.logger.error("Generating notification tracker addSessionData JSONObject ", jSONException);
            }
        }
    }

    @Override
    public void cacheState() {
        OSInfluenceDataRepository oSInfluenceDataRepository = this.dataRepository;
        OSInfluenceType oSInfluenceType = this.influenceType == null ? OSInfluenceType.UNATTRIBUTED : this.influenceType;
        oSInfluenceDataRepository.cacheNotificationInfluenceType(oSInfluenceType);
        this.dataRepository.cacheNotificationOpenId(this.directId);
    }

    @Override
    int getChannelLimit() {
        return this.dataRepository.getNotificationLimit();
    }

    @Override
    OSInfluenceChannel getChannelType() {
        return OSInfluenceChannel.NOTIFICATION;
    }

    @Override
    public String getIdTag() {
        return NOTIFICATION_ID;
    }

    @Override
    int getIndirectAttributionWindow() {
        return this.dataRepository.getNotificationIndirectAttributionWindow();
    }

    @Override
    JSONArray getLastChannelObjects() throws JSONException {
        return this.dataRepository.getLastNotificationsReceivedData();
    }

    @Override
    JSONArray getLastChannelObjectsReceivedByNewId(String string2) {
        try {
            JSONArray jSONArray = this.getLastChannelObjects();
            return jSONArray;
        }
        catch (JSONException jSONException) {
            this.logger.error("Generating Notification tracker getLastChannelObjects JSONObject ", jSONException);
            return new JSONArray();
        }
    }

    @Override
    void initInfluencedTypeFromCache() {
        OSInfluenceType oSInfluenceType = this.dataRepository.getNotificationCachedInfluenceType();
        this.setInfluenceType(oSInfluenceType);
        if (oSInfluenceType.isIndirect()) {
            this.setIndirectIds(this.getLastReceivedIds());
        } else if (oSInfluenceType.isDirect()) {
            this.setDirectId(this.dataRepository.getCachedNotificationOpenId());
        }
        OSLogger oSLogger = this.logger;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OneSignal NotificationTracker initInfluencedTypeFromCache: ");
        stringBuilder.append(this.toString());
        oSLogger.debug(stringBuilder.toString());
    }

    @Override
    void saveChannelObjects(JSONArray jSONArray) {
        this.dataRepository.saveNotifications(jSONArray);
    }
}

