/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.ConcurrentHashMap
 *  org.json.JSONObject
 */
package com.onesignal.influence;

import com.onesignal.OSLogger;
import com.onesignal.OSSharedPreferences;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalRemoteParams;
import com.onesignal.influence.OSChannelTracker;
import com.onesignal.influence.OSInAppMessageTracker;
import com.onesignal.influence.OSInfluenceDataRepository;
import com.onesignal.influence.OSNotificationTracker;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.influence.model.OSInfluenceChannel;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

public class OSTrackerFactory {
    private OSInfluenceDataRepository dataRepository;
    private ConcurrentHashMap<String, OSChannelTracker> trackers = new ConcurrentHashMap();

    public OSTrackerFactory(OSSharedPreferences oSSharedPreferences, OSLogger oSLogger) {
        this.dataRepository = new OSInfluenceDataRepository(oSSharedPreferences);
        this.trackers.put((Object)OSInAppMessageTracker.TAG, (Object)new OSInAppMessageTracker(this.dataRepository, oSLogger));
        this.trackers.put((Object)OSNotificationTracker.TAG, (Object)new OSNotificationTracker(this.dataRepository, oSLogger));
    }

    public void addSessionData(JSONObject jSONObject, List<OSInfluence> list) {
        for (OSInfluence oSInfluence : list) {
            if (1.$SwitchMap$com$onesignal$influence$model$OSInfluenceChannel[oSInfluence.getInfluenceChannel().ordinal()] != 1) continue;
            this.getNotificationChannelTracker().addSessionData(jSONObject, oSInfluence);
        }
    }

    public OSChannelTracker getChannelByEntryAction(OneSignal.AppEntryAction appEntryAction) {
        if (appEntryAction.isNotificationClick()) {
            return this.getNotificationChannelTracker();
        }
        return null;
    }

    public List<OSChannelTracker> getChannels() {
        OSChannelTracker oSChannelTracker;
        ArrayList arrayList = new ArrayList();
        OSChannelTracker oSChannelTracker2 = this.getNotificationChannelTracker();
        if (oSChannelTracker2 != null) {
            arrayList.add((Object)oSChannelTracker2);
        }
        if ((oSChannelTracker = this.getIAMChannelTracker()) != null) {
            arrayList.add((Object)oSChannelTracker);
        }
        return arrayList;
    }

    public List<OSChannelTracker> getChannelsToResetByEntryAction(OneSignal.AppEntryAction appEntryAction) {
        OSChannelTracker oSChannelTracker;
        OSChannelTracker oSChannelTracker2;
        ArrayList arrayList = new ArrayList();
        if (appEntryAction.isAppClose()) {
            return arrayList;
        }
        if (appEntryAction.isAppOpen() && (oSChannelTracker2 = this.getNotificationChannelTracker()) != null) {
            arrayList.add((Object)oSChannelTracker2);
        }
        if ((oSChannelTracker = this.getIAMChannelTracker()) != null) {
            arrayList.add((Object)oSChannelTracker);
        }
        return arrayList;
    }

    public OSChannelTracker getIAMChannelTracker() {
        return (OSChannelTracker)this.trackers.get((Object)OSInAppMessageTracker.TAG);
    }

    public List<OSInfluence> getInfluences() {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.trackers.values().iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((OSChannelTracker)iterator.next()).getCurrentSessionInfluence());
        }
        return arrayList;
    }

    public OSChannelTracker getNotificationChannelTracker() {
        return (OSChannelTracker)this.trackers.get((Object)OSNotificationTracker.TAG);
    }

    public List<OSInfluence> getSessionInfluences() {
        ArrayList arrayList = new ArrayList();
        for (OSChannelTracker oSChannelTracker : this.trackers.values()) {
            if (oSChannelTracker instanceof OSInAppMessageTracker) continue;
            arrayList.add((Object)oSChannelTracker.getCurrentSessionInfluence());
        }
        return arrayList;
    }

    public void initFromCache() {
        Iterator iterator = this.trackers.values().iterator();
        while (iterator.hasNext()) {
            ((OSChannelTracker)iterator.next()).initInfluencedTypeFromCache();
        }
    }

    public void saveInfluenceParams(OneSignalRemoteParams.InfluenceParams influenceParams) {
        this.dataRepository.saveInfluenceParams(influenceParams);
    }

}

