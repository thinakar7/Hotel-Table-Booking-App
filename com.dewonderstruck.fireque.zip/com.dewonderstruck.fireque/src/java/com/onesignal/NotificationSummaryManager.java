/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.NotificationManager
 *  android.content.ContentValues
 *  android.content.Context
 *  android.database.Cursor
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import com.onesignal.GenerateNotification;
import com.onesignal.NotificationGenerationJob;
import com.onesignal.NotificationRestorer;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalDb;
import com.onesignal.OneSignalDbHelper;
import com.onesignal.OneSignalNotificationManager;
import org.json.JSONException;
import org.json.JSONObject;

class NotificationSummaryManager {
    NotificationSummaryManager() {
    }

    static void clearNotificationOnSummaryClick(Context context, OneSignalDbHelper oneSignalDbHelper, String string) {
        Integer n = NotificationSummaryManager.getSummaryNotificationId(oneSignalDbHelper, string);
        boolean bl = string.equals((Object)OneSignalNotificationManager.getGrouplessSummaryKey());
        NotificationManager notificationManager = OneSignalNotificationManager.getNotificationManager(context);
        Integer n2 = OneSignalNotificationManager.getMostRecentNotifIdFromGroup(oneSignalDbHelper, string, bl);
        if (n2 != null) {
            if (OneSignal.getClearGroupSummaryClick()) {
                if (bl) {
                    n = OneSignalNotificationManager.getGrouplessSummaryId();
                }
                if (n != null) {
                    notificationManager.cancel(n.intValue());
                    return;
                }
            } else {
                OneSignal.cancelNotification(n2);
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static Integer getSummaryNotificationId(OneSignalDb var0, String var1_1) {
        block5 : {
            var2_2 = null;
            var3_3 = null;
            var4_4 = new String[]{var1_1};
            try {
                var3_3 = var0.query("notification", new String[]{"android_notification_id"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 1", var4_4, null, null, null);
                var11_5 = var3_3.moveToFirst();
                var2_2 = null;
                if (var11_5) break block5;
                var3_3.close();
                if (var3_3 == null) return null;
            }
            catch (Throwable var5_6) {
                try {
                    var7_7 = OneSignal.LOG_LEVEL.ERROR;
                    var8_8 = new StringBuilder();
                    var8_8.append("Error getting android notification id for summary notification group: ");
                    var8_8.append(var1_1);
                    OneSignal.Log(var7_7, var8_8.toString(), var5_6);
                    if (var3_3 == null) return var2_2;
                }
                catch (Throwable var6_9) {
                    if (var3_3 == null) throw var6_9;
                    if (var3_3.isClosed() != false) throw var6_9;
                    var3_3.close();
                    throw var6_9;
                }
                if (var3_3.isClosed() != false) return var2_2;
lbl25: // 2 sources:
                var3_3.close();
                return var2_2;
            }
            if (var3_3.isClosed() != false) return null;
            var3_3.close();
            return null;
        }
        var2_2 = var3_3.getInt(var3_3.getColumnIndex("android_notification_id"));
        var3_3.close();
        if (var3_3 == null) return var2_2;
        if (var3_3.isClosed() != false) return var2_2;
        ** GOTO lbl25
    }

    private static Cursor internalUpdateSummaryNotificationAfterChildRemoved(Context context, OneSignalDb oneSignalDb, String string, boolean bl) {
        Long l;
        Cursor cursor;
        block7 : {
            cursor = oneSignalDb.query("notification", new String[]{"android_notification_id", "created_time"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", new String[]{string}, null, null, "_id DESC");
            int n = cursor.getCount();
            if (n == 0) {
                cursor.close();
                Integer n2 = NotificationSummaryManager.getSummaryNotificationId(oneSignalDb, string);
                if (n2 == null) {
                    return cursor;
                }
                OneSignalNotificationManager.getNotificationManager(context).cancel(n2.intValue());
                ContentValues contentValues = new ContentValues();
                String string2 = bl ? "dismissed" : "opened";
                contentValues.put(string2, Integer.valueOf((int)1));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("android_notification_id = ");
                stringBuilder.append((Object)n2);
                oneSignalDb.update("notification", contentValues, stringBuilder.toString(), null);
                return cursor;
            }
            if (n == 1) {
                cursor.close();
                if (NotificationSummaryManager.getSummaryNotificationId(oneSignalDb, string) == null) {
                    return cursor;
                }
                NotificationSummaryManager.restoreSummary(context, string);
                return cursor;
            }
            try {
                cursor.moveToFirst();
                l = cursor.getLong(cursor.getColumnIndex("created_time"));
                cursor.close();
                if (NotificationSummaryManager.getSummaryNotificationId(oneSignalDb, string) != null) break block7;
                return cursor;
            }
            catch (JSONException jSONException) {
                return cursor;
            }
        }
        NotificationGenerationJob notificationGenerationJob = new NotificationGenerationJob(context);
        notificationGenerationJob.restoring = true;
        notificationGenerationJob.shownTimeStamp = l;
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("grp", (Object)string);
        notificationGenerationJob.jsonPayload = jSONObject;
        GenerateNotification.updateSummaryNotification(notificationGenerationJob);
        return cursor;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void restoreSummary(Context var0, String var1_1) {
        var2_2 = OneSignalDbHelper.getInstance(var0);
        var3_3 = null;
        var4_4 = new String[]{var1_1};
        try {
            var3_3 = var2_2.query("notification", NotificationRestorer.COLUMNS_FOR_RESTORE, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", var4_4, null, null, null);
            NotificationRestorer.showNotificationsFromCursor(var0, var3_3, 0);
            if (var3_3 == null) return;
        }
        catch (Throwable var5_5) {
            try {
                OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Error restoring notification records! ", var5_5);
                if (var3_3 == null) return;
            }
            catch (Throwable var6_6) {
                if (var3_3 == null) throw var6_6;
                if (var3_3.isClosed() != false) throw var6_6;
                var3_3.close();
                throw var6_6;
            }
            if (var3_3.isClosed() != false) return;
lbl18: // 2 sources:
            var3_3.close();
            return;
        }
        if (var3_3.isClosed() != false) return;
        ** GOTO lbl18
    }

    static void updatePossibleDependentSummaryOnDismiss(Context context, OneSignalDb oneSignalDb, int n) {
        String[] arrstring = new String[]{"group_id"};
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("android_notification_id = ");
        stringBuilder.append(n);
        Cursor cursor = oneSignalDb.query("notification", arrstring, stringBuilder.toString(), null, null, null, null);
        if (cursor.moveToFirst()) {
            String string = cursor.getString(cursor.getColumnIndex("group_id"));
            cursor.close();
            if (string != null) {
                NotificationSummaryManager.updateSummaryNotificationAfterChildRemoved(context, oneSignalDb, string, true);
            }
            return;
        }
        cursor.close();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static void updateSummaryNotificationAfterChildRemoved(Context var0, OneSignalDb var1_1, String var2_2, boolean var3_3) {
        try {
            var6_5 = var7_4 = NotificationSummaryManager.internalUpdateSummaryNotificationAfterChildRemoved(var0, var1_1, var2_2, var3_3);
            if (var6_5 == null) return;
        }
        catch (Throwable var4_6) {
            try {
                OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Error running updateSummaryNotificationAfterChildRemoved!", var4_6);
                if (false == false) return;
            }
            catch (Throwable var5_7) {
                if (false == false) throw var5_7;
                if (null.isClosed() != false) throw var5_7;
                null.close();
                throw var5_7;
            }
            if (null.isClosed() != false) return;
            var6_5 = null;
lbl15: // 2 sources:
            var6_5.close();
            return;
        }
        if (var6_5.isClosed() != false) return;
        ** GOTO lbl15
    }
}

