/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalRestClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class OneSignalRemoteParams {
    public static final int DEFAULT_INDIRECT_ATTRIBUTION_WINDOW = 1440;
    public static final int DEFAULT_NOTIFICATION_LIMIT = 10;
    private static final String DIRECT_PARAM = "direct";
    private static final String ENABLED_PARAM = "enabled";
    private static final String FCM_API_KEY = "api_key";
    private static final String FCM_APP_ID = "app_id";
    private static final String FCM_PARENT_PARAM = "fcm";
    private static final String FCM_PROJECT_ID = "project_id";
    private static final String IAM_ATTRIBUTION_PARAM = "in_app_message_attribution";
    private static final int INCREASE_BETWEEN_RETRIES = 10000;
    private static final String INDIRECT_PARAM = "indirect";
    private static final int MAX_WAIT_BETWEEN_RETRIES = 90000;
    private static final int MIN_WAIT_BETWEEN_RETRIES = 30000;
    private static final String NOTIFICATION_ATTRIBUTION_PARAM = "notification_attribution";
    private static final String OUTCOMES_V2_SERVICE_PARAM = "v2_enabled";
    private static final String OUTCOME_PARAM = "outcomes";
    private static final String UNATTRIBUTED_PARAM = "unattributed";
    private static int androidParamsRetries = 0;

    static /* synthetic */ int access$008() {
        int n = androidParamsRetries;
        androidParamsRetries = n + 1;
        return n;
    }

    static void makeAndroidParamsRequest(final CallBack callBack) {
        OneSignalRestClient.ResponseHandler responseHandler = new OneSignalRestClient.ResponseHandler(){

            @Override
            void onFailure(int n, String string2, Throwable throwable) {
                if (n == 403) {
                    OneSignal.Log(OneSignal.LOG_LEVEL.FATAL, "403 error getting OneSignal params, omitting further retries!");
                    return;
                }
                new Thread(new Runnable(){

                    public void run() {
                        int n = 30000 + 10000 * androidParamsRetries;
                        if (n > 90000) {
                            n = 90000;
                        }
                        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.INFO;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Failed to get Android parameters, trying again in ");
                        stringBuilder.append(n / 1000);
                        stringBuilder.append(" seconds.");
                        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                        OSUtils.sleep(n);
                        OneSignalRemoteParams.access$008();
                        OneSignalRemoteParams.makeAndroidParamsRequest(callBack);
                    }
                }, "OS_PARAMS_REQUEST").start();
            }

            @Override
            void onSuccess(String string2) {
                OneSignalRemoteParams.processJson(string2, callBack);
            }

        };
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("apps/");
        stringBuilder.append(OneSignal.appId);
        stringBuilder.append("/android_params.js");
        String string2 = stringBuilder.toString();
        String string3 = OneSignal.getUserId();
        if (string3 != null) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string2);
            stringBuilder2.append("?player_id=");
            stringBuilder2.append(string3);
            string2 = stringBuilder2.toString();
        }
        OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "Starting request to get Android parameters.");
        OneSignalRestClient.get(string2, responseHandler, "CACHE_KEY_REMOTE_PARAMS");
    }

    private static void processJson(String string2, CallBack callBack) {
        JSONObject jSONObject;
        void var3_5;
        try {
            jSONObject = new JSONObject(string2);
        }
        catch (JSONException jSONException) {
        }
        catch (NullPointerException nullPointerException) {
            // empty catch block
        }
        callBack.complete(new Params(){
            {
                this.enterprise = jSONObject3.optBoolean("enterp", false);
                this.useEmailAuth = jSONObject3.optBoolean("require_email_auth", false);
                this.useUserIdAuth = jSONObject3.optBoolean("require_user_id_auth", false);
                this.notificationChannels = jSONObject3.optJSONArray("chnl_lst");
                this.firebaseAnalytics = jSONObject3.optBoolean("fba", false);
                this.restoreTTLFilter = jSONObject3.optBoolean("restore_ttl_filter", true);
                this.googleProjectNumber = jSONObject3.optString("android_sender_id", null);
                this.clearGroupOnSummaryClick = jSONObject3.optBoolean("clear_group_on_summary_click", true);
                this.receiveReceiptEnabled = jSONObject3.optBoolean("receive_receipts_enable", false);
                this.influenceParams = new InfluenceParams();
                if (jSONObject3.has(OneSignalRemoteParams.OUTCOME_PARAM)) {
                    OneSignalRemoteParams.processOutcomeJson(jSONObject3.optJSONObject(OneSignalRemoteParams.OUTCOME_PARAM), this.influenceParams);
                }
                this.fcmParams = new FCMParams();
                if (jSONObject3.has(OneSignalRemoteParams.FCM_PARENT_PARAM)) {
                    JSONObject jSONObject2 = jSONObject3.optJSONObject(OneSignalRemoteParams.FCM_PARENT_PARAM);
                    this.fcmParams.apiKey = jSONObject2.optString(OneSignalRemoteParams.FCM_API_KEY, null);
                    this.fcmParams.appId = jSONObject2.optString(OneSignalRemoteParams.FCM_APP_ID, null);
                    this.fcmParams.projectId = jSONObject2.optString(OneSignalRemoteParams.FCM_PROJECT_ID, null);
                }
            }
        });
        return;
        OneSignal.Log(OneSignal.LOG_LEVEL.FATAL, "Error parsing android_params!: ", (Throwable)var3_5);
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.FATAL;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Response that errored from android_params!: ");
        stringBuilder.append(string2);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
    }

    private static void processOutcomeJson(JSONObject jSONObject, InfluenceParams influenceParams) {
        if (jSONObject.has(OUTCOMES_V2_SERVICE_PARAM)) {
            influenceParams.outcomesV2ServiceEnabled = jSONObject.optBoolean(OUTCOMES_V2_SERVICE_PARAM);
        }
        if (jSONObject.has(DIRECT_PARAM)) {
            influenceParams.directEnabled = jSONObject.optJSONObject(DIRECT_PARAM).optBoolean(ENABLED_PARAM);
        }
        if (jSONObject.has(INDIRECT_PARAM)) {
            JSONObject jSONObject2 = jSONObject.optJSONObject(INDIRECT_PARAM);
            influenceParams.indirectEnabled = jSONObject2.optBoolean(ENABLED_PARAM);
            if (jSONObject2.has(NOTIFICATION_ATTRIBUTION_PARAM)) {
                JSONObject jSONObject3 = jSONObject2.optJSONObject(NOTIFICATION_ATTRIBUTION_PARAM);
                influenceParams.indirectNotificationAttributionWindow = jSONObject3.optInt("minutes_since_displayed", 1440);
                influenceParams.notificationLimit = jSONObject3.optInt("limit", 10);
            }
            if (jSONObject2.has(IAM_ATTRIBUTION_PARAM)) {
                JSONObject jSONObject4 = jSONObject2.optJSONObject(IAM_ATTRIBUTION_PARAM);
                influenceParams.indirectIAMAttributionWindow = jSONObject4.optInt("minutes_since_displayed", 1440);
                influenceParams.iamLimit = jSONObject4.optInt("limit", 10);
            }
        }
        if (jSONObject.has(UNATTRIBUTED_PARAM)) {
            influenceParams.unattributedEnabled = jSONObject.optJSONObject(UNATTRIBUTED_PARAM).optBoolean(ENABLED_PARAM);
        }
    }

    static interface CallBack {
        public void complete(Params var1);
    }

    static class FCMParams {
        String apiKey;
        String appId;
        String projectId;

        FCMParams() {
        }
    }

    public static class InfluenceParams {
        boolean directEnabled = false;
        int iamLimit = 10;
        boolean indirectEnabled = false;
        int indirectIAMAttributionWindow = 1440;
        int indirectNotificationAttributionWindow = 1440;
        int notificationLimit = 10;
        boolean outcomesV2ServiceEnabled = false;
        boolean unattributedEnabled = false;

        public int getIamLimit() {
            return this.iamLimit;
        }

        public int getIndirectIAMAttributionWindow() {
            return this.indirectIAMAttributionWindow;
        }

        public int getIndirectNotificationAttributionWindow() {
            return this.indirectNotificationAttributionWindow;
        }

        public int getNotificationLimit() {
            return this.notificationLimit;
        }

        public boolean isDirectEnabled() {
            return this.directEnabled;
        }

        public boolean isIndirectEnabled() {
            return this.indirectEnabled;
        }

        public boolean isUnattributedEnabled() {
            return this.unattributedEnabled;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("InfluenceParams{indirectNotificationAttributionWindow=");
            stringBuilder.append(this.indirectNotificationAttributionWindow);
            stringBuilder.append(", notificationLimit=");
            stringBuilder.append(this.notificationLimit);
            stringBuilder.append(", indirectIAMAttributionWindow=");
            stringBuilder.append(this.indirectIAMAttributionWindow);
            stringBuilder.append(", iamLimit=");
            stringBuilder.append(this.iamLimit);
            stringBuilder.append(", directEnabled=");
            stringBuilder.append(this.directEnabled);
            stringBuilder.append(", indirectEnabled=");
            stringBuilder.append(this.indirectEnabled);
            stringBuilder.append(", unattributedEnabled=");
            stringBuilder.append(this.unattributedEnabled);
            stringBuilder.append('}');
            return stringBuilder.toString();
        }
    }

    static class Params {
        boolean clearGroupOnSummaryClick;
        boolean enterprise;
        FCMParams fcmParams;
        boolean firebaseAnalytics;
        String googleProjectNumber;
        InfluenceParams influenceParams;
        JSONArray notificationChannels;
        boolean receiveReceiptEnabled;
        boolean restoreTTLFilter;
        boolean useEmailAuth;
        boolean useUserIdAuth;

        Params() {
        }
    }

}

