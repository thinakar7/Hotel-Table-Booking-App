/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.ImmutableJSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class JSONUtils {
    JSONUtils() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static boolean compareJSONArrays(JSONArray jSONArray, JSONArray jSONArray2) {
        if (jSONArray == null && jSONArray2 == null) {
            return true;
        }
        if (jSONArray == null) {
            return false;
        }
        if (jSONArray2 == null) {
            return false;
        }
        if (jSONArray.length() != jSONArray2.length()) {
            return false;
        }
        int n = 0;
        block2 : do {
            block9 : {
                try {
                    if (n < jSONArray.length()) {
                        break block9;
                    }
                    return true;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return false;
                }
            }
            for (int n2 = 0; n2 < jSONArray2.length(); ++n2) {
                boolean bl = JSONUtils.normalizeType(jSONArray.get(n)).equals(JSONUtils.normalizeType(jSONArray2.get(n2)));
                if (!bl) continue;
                ++n;
                continue block2;
            }
            break;
        } while (true);
        return false;
    }

    private static Object convertNestedJSONType(Object object) throws JSONException {
        if (object instanceof JSONObject) {
            return JSONUtils.jsonObjectToMapNonNull((JSONObject)object);
        }
        if (object instanceof JSONArray) {
            return JSONUtils.jsonArrayToListNonNull((JSONArray)object);
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static JSONObject generateJsonDiff(JSONObject jSONObject, JSONObject jSONObject2, JSONObject jSONObject3, Set<String> set) {
        if (jSONObject == null) {
            return null;
        }
        if (jSONObject2 == null) {
            return jSONObject3;
        }
        Iterator iterator = jSONObject2.keys();
        JSONObject jSONObject4 = jSONObject3 != null ? jSONObject3 : new JSONObject();
        while (iterator.hasNext()) {
            try {
                String string = (String)iterator.next();
                Object object = jSONObject2.get(string);
                if (jSONObject.has(string)) {
                    if (object instanceof JSONObject) {
                        String string2;
                        JSONObject jSONObject5 = jSONObject.getJSONObject(string);
                        JSONObject jSONObject6 = null;
                        if (jSONObject3 != null) {
                            boolean bl = jSONObject3.has(string);
                            jSONObject6 = null;
                            if (bl) {
                                jSONObject6 = jSONObject3.getJSONObject(string);
                            }
                        }
                        if ((string2 = JSONUtils.generateJsonDiff(jSONObject5, (JSONObject)object, jSONObject6, set).toString()).equals((Object)"{}")) continue;
                        jSONObject4.put(string, (Object)new JSONObject(string2));
                        continue;
                    }
                    if (object instanceof JSONArray) {
                        JSONUtils.handleJsonArray(string, (JSONArray)object, jSONObject.getJSONArray(string), jSONObject4);
                        continue;
                    }
                    if (set != null && set.contains((Object)string)) {
                        jSONObject4.put(string, object);
                        continue;
                    }
                    Object object2 = jSONObject.get(string);
                    if (object.equals(object2)) continue;
                    if (object2 instanceof Integer && !"".equals(object)) {
                        if (((Number)object2).doubleValue() == ((Number)object).doubleValue()) continue;
                        jSONObject4.put(string, object);
                        continue;
                    }
                    jSONObject4.put(string, object);
                    continue;
                }
                if (object instanceof JSONObject) {
                    jSONObject4.put(string, (Object)new JSONObject(object.toString()));
                    continue;
                }
                if (object instanceof JSONArray) {
                    JSONUtils.handleJsonArray(string, (JSONArray)object, null, jSONObject4);
                    continue;
                }
                jSONObject4.put(string, object);
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
                continue;
            }
            break;
        }
        return jSONObject4;
    }

    static JSONObject getJSONObjectWithoutBlankValues(ImmutableJSONObject immutableJSONObject, String string) {
        if (!immutableJSONObject.has(string)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = immutableJSONObject.optJSONObject(string);
        Iterator iterator = jSONObject2.keys();
        while (iterator.hasNext()) {
            String string2 = (String)iterator.next();
            try {
                Object object = jSONObject2.get(string2);
                if ("".equals(object)) continue;
                jSONObject.put(string2, object);
            }
            catch (JSONException jSONException) {}
        }
        return jSONObject;
    }

    private static void handleJsonArray(String string, JSONArray jSONArray, JSONArray jSONArray2, JSONObject jSONObject) throws JSONException {
        if (!string.endsWith("_a") && !string.endsWith("_d")) {
            String string2 = JSONUtils.toStringNE(jSONArray);
            JSONArray jSONArray3 = new JSONArray();
            JSONArray jSONArray4 = new JSONArray();
            String string3 = jSONArray2 == null ? null : JSONUtils.toStringNE(jSONArray2);
            for (int i = 0; i < jSONArray.length(); ++i) {
                String string4 = (String)jSONArray.get(i);
                if (jSONArray2 != null && string3.contains((CharSequence)string4)) continue;
                jSONArray3.put((Object)string4);
            }
            if (jSONArray2 != null) {
                for (int i = 0; i < jSONArray2.length(); ++i) {
                    String string5 = jSONArray2.getString(i);
                    if (string2.contains((CharSequence)string5)) continue;
                    jSONArray4.put((Object)string5);
                }
            }
            if (!jSONArray3.toString().equals((Object)"[]")) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string);
                stringBuilder.append("_a");
                jSONObject.put(stringBuilder.toString(), (Object)jSONArray3);
            }
            if (!jSONArray4.toString().equals((Object)"[]")) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string);
                stringBuilder.append("_d");
                jSONObject.put(stringBuilder.toString(), (Object)jSONArray4);
            }
            return;
        }
        jSONObject.put(string, (Object)jSONArray);
    }

    static List<Object> jsonArrayToList(JSONArray jSONArray) throws JSONException {
        if (jSONArray == null) {
            return null;
        }
        return JSONUtils.jsonArrayToListNonNull(jSONArray);
    }

    private static List<Object> jsonArrayToListNonNull(JSONArray jSONArray) throws JSONException {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); ++i) {
            arrayList.add(JSONUtils.convertNestedJSONType(jSONArray.get(i)));
        }
        return arrayList;
    }

    static Map<String, Object> jsonObjectToMap(JSONObject jSONObject) throws JSONException {
        if (jSONObject != null && jSONObject != JSONObject.NULL) {
            return JSONUtils.jsonObjectToMapNonNull(jSONObject);
        }
        return null;
    }

    private static Map<String, Object> jsonObjectToMapNonNull(JSONObject jSONObject) throws JSONException {
        HashMap hashMap = new HashMap();
        Iterator iterator = jSONObject.keys();
        while (iterator.hasNext()) {
            String string = (String)iterator.next();
            hashMap.put((Object)string, JSONUtils.convertNestedJSONType(jSONObject.get(string)));
        }
        return hashMap;
    }

    public static Object normalizeType(Object object) {
        Class class_ = object.getClass();
        if (class_.equals(Integer.class)) {
            return (long)((Integer)object).intValue();
        }
        if (class_.equals(Float.class)) {
            return (double)((Float)object).floatValue();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static String toStringNE(JSONArray jSONArray) {
        String string = "[";
        try {
            for (int i = 0; i < jSONArray.length(); ++i) {
                String string2;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string);
                stringBuilder.append("\"");
                stringBuilder.append(jSONArray.getString(i));
                stringBuilder.append("\"");
                string = string2 = stringBuilder.toString();
            }
        }
        catch (JSONException jSONException) {
            // empty catch block
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

