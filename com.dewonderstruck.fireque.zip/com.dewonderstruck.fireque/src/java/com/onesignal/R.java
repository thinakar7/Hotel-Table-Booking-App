/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.onesignal;

public final class R {
    private R() {
    }

    public static final class anim {
        public static final int onesignal_fade_in = 2130771996;
        public static final int onesignal_fade_out = 2130771997;

        private anim() {
        }
    }

    public static final class attr {
        public static final int buttonSize = 2130903134;
        public static final int cardBackgroundColor = 2130903146;
        public static final int cardCornerRadius = 2130903147;
        public static final int cardElevation = 2130903148;
        public static final int cardMaxElevation = 2130903149;
        public static final int cardPreventCornerOverlap = 2130903150;
        public static final int cardUseCompatPadding = 2130903151;
        public static final int cardViewStyle = 2130903152;
        public static final int circleCrop = 2130903178;
        public static final int colorScheme = 2130903206;
        public static final int contentPadding = 2130903224;
        public static final int contentPaddingBottom = 2130903225;
        public static final int contentPaddingLeft = 2130903226;
        public static final int contentPaddingRight = 2130903227;
        public static final int contentPaddingTop = 2130903228;
        public static final int coordinatorLayoutStyle = 2130903231;
        public static final int font = 2130903296;
        public static final int fontProviderAuthority = 2130903299;
        public static final int fontProviderCerts = 2130903300;
        public static final int fontProviderFetchStrategy = 2130903301;
        public static final int fontProviderFetchTimeout = 2130903302;
        public static final int fontProviderPackage = 2130903303;
        public static final int fontProviderQuery = 2130903304;
        public static final int fontStyle = 2130903305;
        public static final int fontWeight = 2130903307;
        public static final int imageAspectRatio = 2130903334;
        public static final int imageAspectRatioAdjust = 2130903335;
        public static final int keylines = 2130903355;
        public static final int layout_anchor = 2130903364;
        public static final int layout_anchorGravity = 2130903365;
        public static final int layout_behavior = 2130903366;
        public static final int layout_dodgeInsetEdges = 2130903410;
        public static final int layout_insetEdge = 2130903419;
        public static final int layout_keyline = 2130903420;
        public static final int scopeUris = 2130903507;
        public static final int statusBarBackground = 2130903564;

        private attr() {
        }
    }

    public static final class bool {
        public static final int abc_action_bar_embed_tabs = 2130968576;

        private bool() {
        }
    }

    public static final class color {
        public static final int browser_actions_bg_grey = 2131034159;
        public static final int browser_actions_divider_color = 2131034160;
        public static final int browser_actions_text_color = 2131034161;
        public static final int browser_actions_title_color = 2131034162;
        public static final int cardview_dark_background = 2131034167;
        public static final int cardview_light_background = 2131034168;
        public static final int cardview_shadow_end_color = 2131034169;
        public static final int cardview_shadow_start_color = 2131034170;
        public static final int common_google_signin_btn_text_dark = 2131034174;
        public static final int common_google_signin_btn_text_dark_default = 2131034175;
        public static final int common_google_signin_btn_text_dark_disabled = 2131034176;
        public static final int common_google_signin_btn_text_dark_focused = 2131034177;
        public static final int common_google_signin_btn_text_dark_pressed = 2131034178;
        public static final int common_google_signin_btn_text_light = 2131034179;
        public static final int common_google_signin_btn_text_light_default = 2131034180;
        public static final int common_google_signin_btn_text_light_disabled = 2131034181;
        public static final int common_google_signin_btn_text_light_focused = 2131034182;
        public static final int common_google_signin_btn_text_light_pressed = 2131034183;
        public static final int common_google_signin_btn_tint = 2131034184;
        public static final int notification_action_color_filter = 2131034262;
        public static final int notification_icon_bg_color = 2131034263;
        public static final int notification_material_background_media_default_color = 2131034264;
        public static final int primary_text_default_material_dark = 2131034269;
        public static final int ripple_material_light = 2131034279;
        public static final int secondary_text_default_material_dark = 2131034283;
        public static final int secondary_text_default_material_light = 2131034284;

        private color() {
        }
    }

    public static final class dimen {
        public static final int browser_actions_context_menu_max_width = 2131099726;
        public static final int browser_actions_context_menu_min_padding = 2131099727;
        public static final int cardview_compat_inset_shadow = 2131099728;
        public static final int cardview_default_elevation = 2131099729;
        public static final int cardview_default_radius = 2131099730;
        public static final int compat_button_inset_horizontal_material = 2131099731;
        public static final int compat_button_inset_vertical_material = 2131099732;
        public static final int compat_button_padding_horizontal_material = 2131099733;
        public static final int compat_button_padding_vertical_material = 2131099734;
        public static final int compat_control_corner_material = 2131099735;
        public static final int notification_action_icon_size = 2131099845;
        public static final int notification_action_text_size = 2131099846;
        public static final int notification_big_circle_margin = 2131099847;
        public static final int notification_content_margin_start = 2131099848;
        public static final int notification_large_icon_height = 2131099849;
        public static final int notification_large_icon_width = 2131099850;
        public static final int notification_main_column_padding_top = 2131099851;
        public static final int notification_media_narrow_margin = 2131099852;
        public static final int notification_right_icon_size = 2131099853;
        public static final int notification_right_side_padding_top = 2131099854;
        public static final int notification_small_icon_background_padding = 2131099855;
        public static final int notification_small_icon_size_as_large = 2131099856;
        public static final int notification_subtext_size = 2131099857;
        public static final int notification_top_pad = 2131099858;
        public static final int notification_top_pad_large_text = 2131099859;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int common_full_open_on_phone = 2131165293;
        public static final int common_google_signin_btn_icon_dark = 2131165294;
        public static final int common_google_signin_btn_icon_dark_focused = 2131165295;
        public static final int common_google_signin_btn_icon_dark_normal = 2131165296;
        public static final int common_google_signin_btn_icon_dark_normal_background = 2131165297;
        public static final int common_google_signin_btn_icon_disabled = 2131165298;
        public static final int common_google_signin_btn_icon_light = 2131165299;
        public static final int common_google_signin_btn_icon_light_focused = 2131165300;
        public static final int common_google_signin_btn_icon_light_normal = 2131165301;
        public static final int common_google_signin_btn_icon_light_normal_background = 2131165302;
        public static final int common_google_signin_btn_text_dark = 2131165303;
        public static final int common_google_signin_btn_text_dark_focused = 2131165304;
        public static final int common_google_signin_btn_text_dark_normal = 2131165305;
        public static final int common_google_signin_btn_text_dark_normal_background = 2131165306;
        public static final int common_google_signin_btn_text_disabled = 2131165307;
        public static final int common_google_signin_btn_text_light = 2131165308;
        public static final int common_google_signin_btn_text_light_focused = 2131165309;
        public static final int common_google_signin_btn_text_light_normal = 2131165310;
        public static final int common_google_signin_btn_text_light_normal_background = 2131165311;
        public static final int googleg_disabled_color_18 = 2131165330;
        public static final int googleg_standard_color_18 = 2131165331;
        public static final int ic_os_notification_fallback_white_24dp = 2131165350;
        public static final int notification_action_background = 2131165382;
        public static final int notification_bg = 2131165383;
        public static final int notification_bg_low = 2131165384;
        public static final int notification_bg_low_normal = 2131165385;
        public static final int notification_bg_low_pressed = 2131165386;
        public static final int notification_bg_normal = 2131165387;
        public static final int notification_bg_normal_pressed = 2131165388;
        public static final int notification_icon_background = 2131165389;
        public static final int notification_template_icon_bg = 2131165390;
        public static final int notification_template_icon_low_bg = 2131165391;
        public static final int notification_tile_bg = 2131165392;
        public static final int notify_panel_notification_icon_bg = 2131165393;

        private drawable() {
        }
    }

    public static final class id {
        public static final int action0 = 2131230779;
        public static final int action_container = 2131230787;
        public static final int action_divider = 2131230789;
        public static final int action_image = 2131230791;
        public static final int action_text = 2131230798;
        public static final int actions = 2131230799;
        public static final int adjust_height = 2131230802;
        public static final int adjust_width = 2131230803;
        public static final int async = 2131230808;
        public static final int auto = 2131230809;
        public static final int blocking = 2131230812;
        public static final int bottom = 2131230813;
        public static final int browser_actions_header_text = 2131230814;
        public static final int browser_actions_menu_item_icon = 2131230815;
        public static final int browser_actions_menu_item_text = 2131230816;
        public static final int browser_actions_menu_items = 2131230817;
        public static final int browser_actions_menu_view = 2131230818;
        public static final int cancel_action = 2131230830;
        public static final int chronometer = 2131230838;
        public static final int dark = 2131230853;
        public static final int end = 2131230891;
        public static final int end_padder = 2131230892;
        public static final int forever = 2131230903;
        public static final int icon = 2131230914;
        public static final int icon_group = 2131230915;
        public static final int icon_only = 2131230916;
        public static final int info = 2131230941;
        public static final int italic = 2131230943;
        public static final int left = 2131230947;
        public static final int light = 2131230948;
        public static final int line1 = 2131230949;
        public static final int line3 = 2131230950;
        public static final int media_actions = 2131230970;
        public static final int none = 2131230981;
        public static final int normal = 2131230982;
        public static final int notification_background = 2131230983;
        public static final int notification_main_column = 2131230984;
        public static final int notification_main_column_container = 2131230985;
        public static final int os_bgimage_notif_bgimage = 2131230988;
        public static final int os_bgimage_notif_bgimage_align_layout = 2131230989;
        public static final int os_bgimage_notif_bgimage_right_aligned = 2131230990;
        public static final int os_bgimage_notif_body = 2131230991;
        public static final int os_bgimage_notif_title = 2131230992;
        public static final int right = 2131231032;
        public static final int right_icon = 2131231033;
        public static final int right_side = 2131231034;
        public static final int standard = 2131231085;
        public static final int start = 2131231086;
        public static final int status_bar_latest_event_content = 2131231087;
        public static final int tag_transition_group = 2131231098;
        public static final int text = 2131231102;
        public static final int text2 = 2131231103;
        public static final int time = 2131231166;
        public static final int title = 2131231167;
        public static final int top = 2131231180;
        public static final int wide = 2131231204;

        private id() {
        }
    }

    public static final class integer {
        public static final int cancel_button_image_alpha = 2131296260;
        public static final int google_play_services_version = 2131296264;
        public static final int status_bar_notification_info_maxnum = 2131296273;

        private integer() {
        }
    }

    public static final class layout {
        public static final int browser_actions_context_menu_page = 2131427369;
        public static final int browser_actions_context_menu_row = 2131427370;
        public static final int notification_action = 2131427402;
        public static final int notification_action_tombstone = 2131427403;
        public static final int notification_media_action = 2131427404;
        public static final int notification_media_cancel_action = 2131427405;
        public static final int notification_template_big_media = 2131427406;
        public static final int notification_template_big_media_custom = 2131427407;
        public static final int notification_template_big_media_narrow = 2131427408;
        public static final int notification_template_big_media_narrow_custom = 2131427409;
        public static final int notification_template_custom_big = 2131427410;
        public static final int notification_template_icon_group = 2131427411;
        public static final int notification_template_lines_media = 2131427412;
        public static final int notification_template_media = 2131427413;
        public static final int notification_template_media_custom = 2131427414;
        public static final int notification_template_part_chronometer = 2131427415;
        public static final int notification_template_part_time = 2131427416;
        public static final int onesignal_bgimage_notif_layout = 2131427417;

        private layout() {
        }
    }

    public static final class raw {
        public static final int consumer_onesignal_keep = 2131623936;

        private raw() {
        }
    }

    public static final class string {
        public static final int common_google_play_services_enable_button = 2131689535;
        public static final int common_google_play_services_enable_text = 2131689536;
        public static final int common_google_play_services_enable_title = 2131689537;
        public static final int common_google_play_services_install_button = 2131689538;
        public static final int common_google_play_services_install_text = 2131689539;
        public static final int common_google_play_services_install_title = 2131689540;
        public static final int common_google_play_services_notification_channel_name = 2131689541;
        public static final int common_google_play_services_notification_ticker = 2131689542;
        public static final int common_google_play_services_unknown_issue = 2131689543;
        public static final int common_google_play_services_unsupported_text = 2131689544;
        public static final int common_google_play_services_update_button = 2131689545;
        public static final int common_google_play_services_update_text = 2131689546;
        public static final int common_google_play_services_update_title = 2131689547;
        public static final int common_google_play_services_updating_text = 2131689548;
        public static final int common_google_play_services_wear_update_text = 2131689549;
        public static final int common_open_on_phone = 2131689550;
        public static final int common_signin_button_text = 2131689551;
        public static final int common_signin_button_text_long = 2131689552;
        public static final int location_not_available_message = 2131689612;
        public static final int location_not_available_open_settings_message = 2131689613;
        public static final int location_not_available_open_settings_option = 2131689614;
        public static final int location_not_available_title = 2131689615;
        public static final int status_bar_notification_info_overflow = 2131689681;

        private string() {
        }
    }

    public static final class style {
        public static final int Base_CardView = 2131755026;
        public static final int CardView = 2131755210;
        public static final int CardView_Dark = 2131755211;
        public static final int CardView_Light = 2131755212;
        public static final int TextAppearance_Compat_Notification = 2131755299;
        public static final int TextAppearance_Compat_Notification_Info = 2131755300;
        public static final int TextAppearance_Compat_Notification_Info_Media = 2131755301;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131755302;
        public static final int TextAppearance_Compat_Notification_Line2_Media = 2131755303;
        public static final int TextAppearance_Compat_Notification_Media = 2131755304;
        public static final int TextAppearance_Compat_Notification_Time = 2131755305;
        public static final int TextAppearance_Compat_Notification_Time_Media = 2131755306;
        public static final int TextAppearance_Compat_Notification_Title = 2131755307;
        public static final int TextAppearance_Compat_Notification_Title_Media = 2131755308;
        public static final int Widget_Compat_NotificationActionContainer = 2131755481;
        public static final int Widget_Compat_NotificationActionText = 2131755482;
        public static final int Widget_Support_CoordinatorLayout = 2131755529;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] CardView = new int[]{16843071, 16843072, 2130903146, 2130903147, 2130903148, 2130903149, 2130903150, 2130903151, 2130903224, 2130903225, 2130903226, 2130903227, 2130903228};
        public static final int CardView_android_minHeight = 1;
        public static final int CardView_android_minWidth = 0;
        public static final int CardView_cardBackgroundColor = 2;
        public static final int CardView_cardCornerRadius = 3;
        public static final int CardView_cardElevation = 4;
        public static final int CardView_cardMaxElevation = 5;
        public static final int CardView_cardPreventCornerOverlap = 6;
        public static final int CardView_cardUseCompatPadding = 7;
        public static final int CardView_contentPadding = 8;
        public static final int CardView_contentPaddingBottom = 9;
        public static final int CardView_contentPaddingLeft = 10;
        public static final int CardView_contentPaddingRight = 11;
        public static final int CardView_contentPaddingTop = 12;
        public static final int[] CoordinatorLayout = new int[]{2130903355, 2130903564};
        public static final int[] CoordinatorLayout_Layout = new int[]{16842931, 2130903364, 2130903365, 2130903366, 2130903410, 2130903419, 2130903420};
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 1;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static final int CoordinatorLayout_Layout_layout_behavior = 3;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 6;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] FontFamily = new int[]{2130903299, 2130903300, 2130903301, 2130903302, 2130903303, 2130903304};
        public static final int[] FontFamilyFont = new int[]{16844082, 16844083, 16844095, 16844143, 16844144, 2130903296, 2130903305, 2130903306, 2130903307, 2130903664};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] LoadingImageView = new int[]{2130903178, 2130903334, 2130903335};
        public static final int LoadingImageView_circleCrop = 0;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 2;
        public static final int[] SignInButton = new int[]{2130903134, 2130903206, 2130903507};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_colorScheme = 1;
        public static final int SignInButton_scopeUris = 2;

        private styleable() {
        }
    }

}

