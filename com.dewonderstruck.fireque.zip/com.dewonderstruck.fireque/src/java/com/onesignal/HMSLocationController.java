/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.location.Location
 *  android.os.Looper
 *  com.huawei.hmf.tasks.OnFailureListener
 *  com.huawei.hmf.tasks.OnSuccessListener
 *  com.huawei.hmf.tasks.Task
 *  com.huawei.hms.location.FusedLocationProviderClient
 *  com.huawei.hms.location.LocationCallback
 *  com.huawei.hms.location.LocationRequest
 *  com.huawei.hms.location.LocationResult
 *  com.huawei.hms.location.LocationServices
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.onesignal;

import android.content.Context;
import android.location.Location;
import android.os.Looper;
import com.huawei.hmf.tasks.OnFailureListener;
import com.huawei.hmf.tasks.OnSuccessListener;
import com.huawei.hmf.tasks.Task;
import com.huawei.hms.location.FusedLocationProviderClient;
import com.huawei.hms.location.LocationCallback;
import com.huawei.hms.location.LocationRequest;
import com.huawei.hms.location.LocationResult;
import com.huawei.hms.location.LocationServices;
import com.onesignal.LocationController;
import com.onesignal.OneSignal;

class HMSLocationController
extends LocationController {
    private static FusedLocationProviderClient hmsFusedLocationClient;
    static LocationUpdateListener locationUpdateListener;

    HMSLocationController() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void fireFailedComplete() {
        Object object;
        Object object2 = object = syncLock;
        synchronized (object2) {
            hmsFusedLocationClient = null;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void initHuaweiLocation() {
        Object object;
        Object object2 = object = syncLock;
        synchronized (object2) {
            FusedLocationProviderClient fusedLocationProviderClient = hmsFusedLocationClient;
            if (fusedLocationProviderClient == null) {
                try {
                    hmsFusedLocationClient = LocationServices.getFusedLocationProviderClient((Context)classContext);
                }
                catch (Exception exception) {
                    OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Huawei LocationServices getFusedLocationProviderClient failed! ");
                    stringBuilder.append((Object)exception);
                    OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                    HMSLocationController.fireFailedComplete();
                    return;
                }
            }
            if (lastLocation != null) {
                HMSLocationController.fireCompleteForLocation(lastLocation);
            } else {
                hmsFusedLocationClient.getLastLocation().addOnSuccessListener((OnSuccessListener)new OnSuccessListener<Location>(){

                    public void onSuccess(Location location) {
                        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.WARN;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Huawei LocationServices getLastLocation returned location: ");
                        stringBuilder.append((Object)location);
                        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                        if (location == null) {
                            HMSLocationController.fireFailedComplete();
                            return;
                        }
                        LocationController.lastLocation = location;
                        LocationController.fireCompleteForLocation(LocationController.lastLocation);
                        HMSLocationController.locationUpdateListener = new LocationUpdateListener(hmsFusedLocationClient);
                    }
                }).addOnFailureListener(new OnFailureListener(){

                    public void onFailure(Exception exception) {
                        OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Huawei LocationServices getLastLocation failed!", exception);
                        HMSLocationController.fireFailedComplete();
                    }
                });
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void onFocusChange() {
        Object object;
        Object object2 = object = syncLock;
        synchronized (object2) {
            OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "HMSLocationController onFocusChange!");
            if (HMSLocationController.isHMSAvailable() && hmsFusedLocationClient == null) {
                return;
            }
            FusedLocationProviderClient fusedLocationProviderClient = hmsFusedLocationClient;
            if (fusedLocationProviderClient != null) {
                LocationUpdateListener locationUpdateListener = HMSLocationController.locationUpdateListener;
                if (locationUpdateListener != null) {
                    fusedLocationProviderClient.removeLocationUpdates((LocationCallback)locationUpdateListener);
                }
                HMSLocationController.locationUpdateListener = new LocationUpdateListener(hmsFusedLocationClient);
            }
            return;
        }
    }

    static void startGetLocation() {
        HMSLocationController.initHuaweiLocation();
    }

    static class LocationUpdateListener
    extends LocationCallback {
        private FusedLocationProviderClient huaweiFusedLocationProviderClient;

        LocationUpdateListener(FusedLocationProviderClient fusedLocationProviderClient) {
            this.huaweiFusedLocationProviderClient = fusedLocationProviderClient;
            this.init();
        }

        private void init() {
            long l = 570000L;
            if (OneSignal.isForeground()) {
                l = 270000L;
            }
            LocationRequest locationRequest = LocationRequest.create().setFastestInterval(l).setInterval(l).setMaxWaitTime((long)(1.5 * (double)l)).setPriority(102);
            OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "HMSLocationController Huawei LocationServices requestLocationUpdates!");
            this.huaweiFusedLocationProviderClient.requestLocationUpdates(locationRequest, (LocationCallback)this, LocationController.locationHandlerThread.getLooper());
        }

        public void onLocationResult(LocationResult locationResult) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("HMSLocationController onLocationResult: ");
            stringBuilder.append((Object)locationResult);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            if (locationResult != null) {
                LocationController.lastLocation = locationResult.getLastLocation();
            }
        }
    }

}

