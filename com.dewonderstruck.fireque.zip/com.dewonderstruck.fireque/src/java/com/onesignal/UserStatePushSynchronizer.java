/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Set
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.ImmutableJSONObject;
import com.onesignal.JSONUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalRestClient;
import com.onesignal.OneSignalStateSynchronizer;
import com.onesignal.UserState;
import com.onesignal.UserStatePush;
import com.onesignal.UserStateSynchronizer;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

class UserStatePushSynchronizer
extends UserStateSynchronizer {
    private static boolean serverSuccess;

    UserStatePushSynchronizer() {
        super(OneSignalStateSynchronizer.UserStateSynchronizerType.PUSH);
    }

    @Override
    protected void addOnSessionOrCreateExtras(JSONObject jSONObject) {
    }

    @Override
    protected void fireEventsForUpdateFailure(JSONObject jSONObject) {
        if (jSONObject.has("email")) {
            OneSignal.fireEmailUpdateFailure();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    String getExternalId(boolean bl) {
        Object object;
        Object object2 = object = this.LOCK;
        synchronized (object2) {
            return this.toSyncUserState.getSyncValues().optString("external_user_id", null);
        }
    }

    @Override
    protected String getId() {
        return OneSignal.getUserId();
    }

    @Override
    protected OneSignal.LOG_LEVEL getLogLevel() {
        return OneSignal.LOG_LEVEL.ERROR;
    }

    @Override
    boolean getSubscribed() {
        return this.getToSyncUserState().isSubscribed();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    UserStateSynchronizer.GetTagsResult getTags(boolean bl) {
        Object object;
        if (bl) {
            String string2 = OneSignal.getUserId();
            String string3 = OneSignal.getSavedAppId();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("players/");
            stringBuilder.append(string2);
            stringBuilder.append("?app_id=");
            stringBuilder.append(string3);
            OneSignalRestClient.getSync(stringBuilder.toString(), new OneSignalRestClient.ResponseHandler(){

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 * Converted monitor instructions to comments
                 * Lifted jumps to return sites
                 */
                @Override
                void onSuccess(String string2) {
                    UserStatePushSynchronizer userStatePushSynchronizer;
                    JSONObject jSONObject;
                    serverSuccess = true;
                    if (string2 == null || string2.isEmpty()) {
                        string2 = "{}";
                    }
                    try {
                        Object object;
                        jSONObject = new JSONObject(string2);
                        if (!jSONObject.has("tags")) return;
                        Object object2 = object = UserStatePushSynchronizer.this.LOCK;
                        // MONITORENTER : object2
                        userStatePushSynchronizer = UserStatePushSynchronizer.this;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                    JSONObject jSONObject2 = userStatePushSynchronizer.generateJsonDiff(userStatePushSynchronizer.currentUserState.getSyncValues().optJSONObject("tags"), UserStatePushSynchronizer.this.getToSyncUserState().getSyncValues().optJSONObject("tags"), null, null);
                    UserStatePushSynchronizer.this.currentUserState.putOnSyncValues("tags", (Object)jSONObject.optJSONObject("tags"));
                    UserStatePushSynchronizer.this.currentUserState.persistState();
                    UserStatePushSynchronizer.this.getToSyncUserState().mergeTags(jSONObject, jSONObject2);
                    UserStatePushSynchronizer.this.getToSyncUserState().persistState();
                    // MONITOREXIT : object2
                }
            }, "CACHE_KEY_GET_TAGS");
        }
        Object object2 = object = this.LOCK;
        synchronized (object2) {
            return new UserStateSynchronizer.GetTagsResult(serverSuccess, JSONUtils.getJSONObjectWithoutBlankValues(this.toSyncUserState.getSyncValues(), "tags"));
        }
    }

    @Override
    public boolean getUserSubscribePreference() {
        return this.getToSyncUserState().getDependValues().optBoolean("userSubscribePref", true);
    }

    @Override
    void logoutEmail() {
        try {
            this.getUserStateForModification().putOnDependValues("logoutEmail", true);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    @Override
    protected UserState newUserState(String string2, boolean bl) {
        return new UserStatePush(string2, bl);
    }

    @Override
    protected void onSuccessfulSync(JSONObject jSONObject) {
        if (jSONObject.has("email")) {
            OneSignal.fireEmailUpdateSuccess();
        }
        if (jSONObject.has("identifier")) {
            OneSignal.fireIdsAvailableCallback();
        }
    }

    @Override
    protected void scheduleSyncToServer() {
        this.getNetworkHandlerThread(0).runNewJobDelayed();
    }

    void setEmail(String string2, String string3) {
        try {
            UserState userState = this.getUserStateForModification();
            userState.putOnDependValues("email_auth_hash", string3);
            userState.generateJsonDiffFromIntoSyncValued(new JSONObject().put("email", (Object)string2), null);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    @Override
    public void setPermission(boolean bl) {
        try {
            this.getUserStateForModification().putOnDependValues("androidPermission", bl);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    @Override
    void setSubscription(boolean bl) {
        try {
            this.getUserStateForModification().putOnDependValues("userSubscribePref", bl);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    @Override
    void updateIdDependents(String string2) {
        OneSignal.updateUserIdDependents(string2);
    }

    @Override
    void updateState(JSONObject jSONObject) {
        try {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.putOpt("identifier", (Object)jSONObject.optString("identifier", null));
            if (jSONObject.has("device_type")) {
                jSONObject2.put("device_type", jSONObject.optInt("device_type"));
            }
            jSONObject2.putOpt("parent_player_id", (Object)jSONObject.optString("parent_player_id", null));
            this.getUserStateForModification().generateJsonDiffFromIntoSyncValued(jSONObject2, null);
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
        }
        try {
            JSONObject jSONObject3 = new JSONObject();
            if (jSONObject.has("subscribableStatus")) {
                jSONObject3.put("subscribableStatus", jSONObject.optInt("subscribableStatus"));
            }
            if (jSONObject.has("androidPermission")) {
                jSONObject3.put("androidPermission", jSONObject.optBoolean("androidPermission"));
            }
            this.getUserStateForModification().generateJsonDiffFromIntoDependValues(jSONObject3, null);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

}

