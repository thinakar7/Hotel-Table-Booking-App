/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.onesignal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class OSNotificationPayload {
    public List<ActionButton> actionButtons;
    public JSONObject additionalData;
    public BackgroundImageLayout backgroundImageLayout;
    public String bigPicture;
    public String body;
    public String collapseId;
    public String fromProjectNumber;
    public String groupKey;
    public String groupMessage;
    public String largeIcon;
    public String launchURL;
    public String ledColor;
    public int lockScreenVisibility = 1;
    public String notificationID;
    public int priority;
    public String rawPayload;
    public String smallIcon;
    public String smallIconAccentColor;
    public String sound;
    public String templateId;
    public String templateName;
    public String title;

    public OSNotificationPayload() {
    }

    public OSNotificationPayload(JSONObject jSONObject) {
        this.notificationID = jSONObject.optString("notificationID");
        this.title = jSONObject.optString("title");
        this.body = jSONObject.optString("body");
        this.additionalData = jSONObject.optJSONObject("additionalData");
        this.smallIcon = jSONObject.optString("smallIcon");
        this.largeIcon = jSONObject.optString("largeIcon");
        this.bigPicture = jSONObject.optString("bigPicture");
        this.smallIconAccentColor = jSONObject.optString("smallIconAccentColor");
        this.launchURL = jSONObject.optString("launchURL");
        this.sound = jSONObject.optString("sound");
        this.ledColor = jSONObject.optString("ledColor");
        this.lockScreenVisibility = jSONObject.optInt("lockScreenVisibility");
        this.groupKey = jSONObject.optString("groupKey");
        this.groupMessage = jSONObject.optString("groupMessage");
        if (jSONObject.has("actionButtons")) {
            this.actionButtons = new ArrayList();
            JSONArray jSONArray = jSONObject.optJSONArray("actionButtons");
            for (int i = 0; i < jSONArray.length(); ++i) {
                this.actionButtons.add((Object)new ActionButton(jSONArray.optJSONObject(i)));
            }
        }
        this.fromProjectNumber = jSONObject.optString("fromProjectNumber");
        this.collapseId = jSONObject.optString("collapseId");
        this.priority = jSONObject.optInt("priority");
        this.rawPayload = jSONObject.optString("rawPayload");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public JSONObject toJSONObject() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("notificationID", (Object)this.notificationID);
            jSONObject.put("title", (Object)this.title);
            jSONObject.put("body", (Object)this.body);
            JSONObject jSONObject2 = this.additionalData;
            if (jSONObject2 != null) {
                jSONObject.put("additionalData", (Object)jSONObject2);
            }
            jSONObject.put("smallIcon", (Object)this.smallIcon);
            jSONObject.put("largeIcon", (Object)this.largeIcon);
            jSONObject.put("bigPicture", (Object)this.bigPicture);
            jSONObject.put("smallIconAccentColor", (Object)this.smallIconAccentColor);
            jSONObject.put("launchURL", (Object)this.launchURL);
            jSONObject.put("sound", (Object)this.sound);
            jSONObject.put("ledColor", (Object)this.ledColor);
            jSONObject.put("lockScreenVisibility", this.lockScreenVisibility);
            jSONObject.put("groupKey", (Object)this.groupKey);
            jSONObject.put("groupMessage", (Object)this.groupMessage);
            if (this.actionButtons != null) {
                JSONArray jSONArray = new JSONArray();
                Iterator iterator = this.actionButtons.iterator();
                while (iterator.hasNext()) {
                    jSONArray.put((Object)((ActionButton)iterator.next()).toJSONObject());
                }
                jSONObject.put("actionButtons", (Object)jSONArray);
            }
            jSONObject.put("fromProjectNumber", (Object)this.fromProjectNumber);
            jSONObject.put("collapseId", (Object)this.collapseId);
            jSONObject.put("priority", this.priority);
            jSONObject.put("rawPayload", (Object)this.rawPayload);
            return jSONObject;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return jSONObject;
        }
    }

    public static class ActionButton {
        public String icon;
        public String id;
        public String text;

        public ActionButton() {
        }

        public ActionButton(JSONObject jSONObject) {
            this.id = jSONObject.optString("id");
            this.text = jSONObject.optString("text");
            this.icon = jSONObject.optString("icon");
        }

        public JSONObject toJSONObject() {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("id", (Object)this.id);
                jSONObject.put("text", (Object)this.text);
                jSONObject.put("icon", (Object)this.icon);
                return jSONObject;
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
                return jSONObject;
            }
        }
    }

    public static class BackgroundImageLayout {
        public String bodyTextColor;
        public String image;
        public String titleTextColor;
    }

}

