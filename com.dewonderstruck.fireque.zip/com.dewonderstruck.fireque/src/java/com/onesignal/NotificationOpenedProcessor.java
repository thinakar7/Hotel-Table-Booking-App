/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.Intent
 *  android.database.Cursor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  androidx.core.app.NotificationManagerCompat
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import androidx.core.app.NotificationManagerCompat;
import com.onesignal.BadgeCountUpdater;
import com.onesignal.NotificationBundleProcessor;
import com.onesignal.NotificationSummaryManager;
import com.onesignal.OSNotificationFormatHelper;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalDbHelper;
import com.onesignal.OneSignalNotificationManager;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class NotificationOpenedProcessor {
    private static final String TAG = NotificationOpenedProcessor.class.getCanonicalName();

    NotificationOpenedProcessor() {
    }

    private static void addChildNotifications(JSONArray jSONArray, String string, OneSignalDbHelper oneSignalDbHelper) {
        Cursor cursor = oneSignalDbHelper.query("notification", new String[]{"full_data"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", new String[]{string}, null, null, null);
        if (cursor.getCount() > 1) {
            cursor.moveToFirst();
            do {
                try {
                    jSONArray.put((Object)new JSONObject(cursor.getString(cursor.getColumnIndex("full_data"))));
                }
                catch (JSONException jSONException) {
                    OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Could not parse JSON of sub notification in group: ");
                    stringBuilder.append(string);
                    OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private static void clearStatusBarNotifications(Context context, OneSignalDbHelper oneSignalDbHelper, String string) {
        if (string != null) {
            NotificationSummaryManager.clearNotificationOnSummaryClick(context, oneSignalDbHelper, string);
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && OneSignalNotificationManager.getGrouplessNotifsCount(context) < 1) {
            int n = OneSignalNotificationManager.getGrouplessSummaryId();
            OneSignalNotificationManager.getNotificationManager(context).cancel(n);
        }
    }

    private static void handleDismissFromActionButtonPress(Context context, Intent intent) {
        if (intent.getBooleanExtra("action_button", false)) {
            NotificationManagerCompat.from((Context)context).cancel(intent.getIntExtra("androidNotificationId", 0));
            context.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        }
    }

    static boolean handleIAMPreviewOpen(Context context, JSONObject jSONObject) {
        String string = NotificationBundleProcessor.inAppPreviewPushUUID(jSONObject);
        if (string == null) {
            return false;
        }
        OneSignal.startOrResumeApp(context);
        OneSignal.getInAppMessageController().displayPreviewMessage(string);
        return true;
    }

    private static boolean isOneSignalIntent(Intent intent) {
        return intent.hasExtra("onesignalData") || intent.hasExtra("summary") || intent.hasExtra("androidNotificationId");
        {
        }
    }

    private static void markNotificationsConsumed(Context context, Intent intent, OneSignalDbHelper oneSignalDbHelper, boolean bl) {
        String string;
        String string2 = intent.getStringExtra("summary");
        String[] arrstring = null;
        if (string2 != null) {
            boolean bl2 = string2.equals((Object)OneSignalNotificationManager.getGrouplessSummaryKey());
            if (bl2) {
                string = "group_id IS NULL";
                arrstring = null;
            } else {
                string = "group_id = ?";
                arrstring = new String[]{string2};
            }
            if (!bl && !OneSignal.getClearGroupSummaryClick()) {
                String string3 = String.valueOf((Object)OneSignalNotificationManager.getMostRecentNotifIdFromGroup(oneSignalDbHelper, string2, bl2));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string);
                stringBuilder.append(" AND android_notification_id = ?");
                string = stringBuilder.toString();
                String[] arrstring2 = bl2 ? new String[]{string3} : new String[]{string2, string3};
                arrstring = arrstring2;
            }
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("android_notification_id = ");
            stringBuilder.append(intent.getIntExtra("androidNotificationId", 0));
            string = stringBuilder.toString();
        }
        NotificationOpenedProcessor.clearStatusBarNotifications(context, oneSignalDbHelper, string2);
        oneSignalDbHelper.update("notification", NotificationOpenedProcessor.newContentValuesWithConsumed(intent), string, arrstring);
        BadgeCountUpdater.update(oneSignalDbHelper, context);
    }

    private static ContentValues newContentValuesWithConsumed(Intent intent) {
        ContentValues contentValues = new ContentValues();
        boolean bl = intent.getBooleanExtra("dismissed", false);
        Integer n = 1;
        if (bl) {
            contentValues.put("dismissed", n);
            return contentValues;
        }
        contentValues.put("opened", n);
        return contentValues;
    }

    static void processFromContext(Context context, Intent intent) {
        if (!NotificationOpenedProcessor.isOneSignalIntent(intent)) {
            return;
        }
        OneSignal.setAppContext(context);
        NotificationOpenedProcessor.handleDismissFromActionButtonPress(context, intent);
        NotificationOpenedProcessor.processIntent(context, intent);
    }

    static void processIntent(Context context, Intent intent) {
        String string;
        String string2 = intent.getStringExtra("summary");
        boolean bl = intent.getBooleanExtra("dismissed", false);
        JSONArray jSONArray = null;
        JSONObject jSONObject = null;
        if (!bl) {
            try {
                JSONArray jSONArray2;
                jSONObject = new JSONObject(intent.getStringExtra("onesignalData"));
                if (NotificationOpenedProcessor.handleIAMPreviewOpen(context, jSONObject)) {
                    return;
                }
                jSONObject.put("androidNotificationId", intent.getIntExtra("androidNotificationId", 0));
                intent.putExtra("onesignalData", jSONObject.toString());
                jSONArray = jSONArray2 = NotificationBundleProcessor.newJsonArray(new JSONObject(intent.getStringExtra("onesignalData")));
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
            }
        }
        OneSignalDbHelper oneSignalDbHelper = OneSignalDbHelper.getInstance(context);
        if (!bl && string2 != null) {
            NotificationOpenedProcessor.addChildNotifications(jSONArray, string2, oneSignalDbHelper);
        }
        NotificationOpenedProcessor.markNotificationsConsumed(context, intent, oneSignalDbHelper, bl);
        if (string2 == null && (string = intent.getStringExtra("grp")) != null) {
            NotificationSummaryManager.updateSummaryNotificationAfterChildRemoved(context, oneSignalDbHelper, string, bl);
        }
        if (!bl) {
            OneSignal.handleNotificationOpen(context, jSONArray, intent.getBooleanExtra("from_alert", false), OSNotificationFormatHelper.getOSNotificationIdFromJson(jSONObject));
        }
    }
}

