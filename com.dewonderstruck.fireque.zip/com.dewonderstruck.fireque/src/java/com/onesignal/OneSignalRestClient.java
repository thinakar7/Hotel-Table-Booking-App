/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.TrafficStats
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Class
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Thread$State
 *  java.lang.Throwable
 *  java.net.ConnectException
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.net.URLConnection
 *  java.net.UnknownHostException
 *  java.util.Scanner
 *  org.json.JSONObject
 */
package com.onesignal;

import android.net.TrafficStats;
import android.os.Build;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalPrefs;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.util.Scanner;
import org.json.JSONObject;

class OneSignalRestClient {
    private static final String BASE_URL = "https://api.onesignal.com/";
    static final String CACHE_KEY_GET_TAGS = "CACHE_KEY_GET_TAGS";
    static final String CACHE_KEY_REMOTE_PARAMS = "CACHE_KEY_REMOTE_PARAMS";
    private static final int GET_TIMEOUT = 60000;
    private static final String OS_ACCEPT_HEADER = "application/vnd.onesignal.v1+json";
    private static final String OS_API_VERSION = "1";
    private static final int THREAD_ID = 10000;
    private static final int TIMEOUT = 120000;

    OneSignalRestClient() {
    }

    private static Thread callResponseHandlerOnFailure(final ResponseHandler responseHandler, final int n, final String string2, final Throwable throwable) {
        if (responseHandler == null) {
            return null;
        }
        Thread thread = new Thread(new Runnable(){

            public void run() {
                responseHandler.onFailure(n, string2, throwable);
            }
        }, "OS_REST_FAILURE_CALLBACK");
        thread.start();
        return thread;
    }

    private static Thread callResponseHandlerOnSuccess(final ResponseHandler responseHandler, final String string2) {
        if (responseHandler == null) {
            return null;
        }
        Thread thread = new Thread(new Runnable(){

            public void run() {
                responseHandler.onSuccess(string2);
            }
        }, "OS_REST_SUCCESS_CALLBACK");
        thread.start();
        return thread;
    }

    public static void get(final String string2, final ResponseHandler responseHandler, final String string3) {
        new Thread(new Runnable(){

            public void run() {
                OneSignalRestClient.makeRequest(string2, null, null, responseHandler, 60000, string3);
            }
        }, "OS_REST_ASYNC_GET").start();
    }

    public static void getSync(String string2, ResponseHandler responseHandler, String string3) {
        OneSignalRestClient.makeRequest(string2, null, null, responseHandler, 60000, string3);
    }

    private static int getThreadTimeout(int n) {
        return n + 5000;
    }

    private static void makeRequest(final String string2, final String string3, final JSONObject jSONObject, final ResponseHandler responseHandler, final int n, final String string4) {
        if (!OSUtils.isRunningOnMainThread()) {
            if (string3 != null && OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName(null)) {
                return;
            }
            final Thread[] arrthread = new Thread[1];
            Runnable runnable = new Runnable(){

                public void run() {
                    arrthread[0] = OneSignalRestClient.startHTTPConnection(string2, string3, jSONObject, responseHandler, n, string4);
                }
            };
            Thread thread = new Thread(runnable, "OS_HTTPConnection");
            thread.start();
            try {
                thread.join((long)OneSignalRestClient.getThreadTimeout(n));
                if (thread.getState() != Thread.State.TERMINATED) {
                    thread.interrupt();
                }
                if (arrthread[0] != null) {
                    arrthread[0].join();
                }
                return;
            }
            catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
                return;
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Method: ");
        stringBuilder.append(string3);
        stringBuilder.append(" was called from the Main Thread!");
        throw new OneSignalNetworkCallException(stringBuilder.toString());
    }

    private static HttpURLConnection newHttpURLConnection(String string2) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(BASE_URL);
        stringBuilder.append(string2);
        return (HttpURLConnection)new URL(stringBuilder.toString()).openConnection();
    }

    public static void post(final String string2, final JSONObject jSONObject, final ResponseHandler responseHandler) {
        new Thread(new Runnable(){

            public void run() {
                OneSignalRestClient.makeRequest(string2, "POST", jSONObject, responseHandler, 120000, null);
            }
        }, "OS_REST_ASYNC_POST").start();
    }

    public static void postSync(String string2, JSONObject jSONObject, ResponseHandler responseHandler) {
        OneSignalRestClient.makeRequest(string2, "POST", jSONObject, responseHandler, 120000, null);
    }

    public static void put(final String string2, final JSONObject jSONObject, final ResponseHandler responseHandler) {
        new Thread(new Runnable(){

            public void run() {
                OneSignalRestClient.makeRequest(string2, "PUT", jSONObject, responseHandler, 120000, null);
            }
        }, "OS_REST_ASYNC_PUT").start();
    }

    public static void putSync(String string2, JSONObject jSONObject, ResponseHandler responseHandler) {
        OneSignalRestClient.makeRequest(string2, "PUT", jSONObject, responseHandler, 120000, null);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Thread startHTTPConnection(String var0, String var1_1, JSONObject var2_2, ResponseHandler var3_3, int var4_4, String var5_5) {
        block27 : {
            block31 : {
                block30 : {
                    block29 : {
                        block28 : {
                            block32 : {
                                block26 : {
                                    var6_6 = -1;
                                    var7_7 = null;
                                    if (Build.VERSION.SDK_INT >= 26) {
                                        TrafficStats.setThreadStatsTag((int)10000);
                                    }
                                    var20_8 = OneSignal.LOG_LEVEL.DEBUG;
                                    var21_9 = new StringBuilder();
                                    var21_9.append("OneSignalRestClient: Making request to: https://api.onesignal.com/");
                                    var21_9.append(var0);
                                    OneSignal.Log(var20_8, var21_9.toString());
                                    var7_7 = OneSignalRestClient.newHttpURLConnection(var0);
                                    var7_7.setUseCaches(false);
                                    var7_7.setConnectTimeout(var4_4);
                                    var7_7.setReadTimeout(var4_4);
                                    var7_7.setRequestProperty("SDK-Version", "onesignal/android/031507");
                                    var7_7.setRequestProperty("Accept", "application/vnd.onesignal.v1+json");
                                    if (var2_2 != null) {
                                        var7_7.setDoInput(true);
                                    }
                                    if (var1_1 != null) {
                                        var7_7.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                                        var7_7.setRequestMethod(var1_1);
                                        var7_7.setDoOutput(true);
                                    }
                                    if (var2_2 != null) {
                                        var103_10 = var2_2.toString();
                                        var104_11 = OneSignal.LOG_LEVEL.DEBUG;
                                        var105_12 = new StringBuilder();
                                        var105_12.append("OneSignalRestClient: ");
                                        var105_12.append(var1_1);
                                        var105_12.append(" SEND JSON: ");
                                        var105_12.append(var103_10);
                                        OneSignal.Log(var104_11, var105_12.toString());
                                        var110_13 = var103_10.getBytes("UTF-8");
                                        var7_7.setFixedLengthStreamingMode(var110_13.length);
                                        var7_7.getOutputStream().write(var110_13);
                                    }
                                    if (var5_5 != null) {
                                        var94_14 = OneSignalPrefs.PREFS_ONESIGNAL;
                                        var95_15 = new StringBuilder();
                                        var95_15.append("PREFS_OS_ETAG_PREFIX_");
                                        var95_15.append(var5_5);
                                        var98_16 = OneSignalPrefs.getString(var94_14, var95_15.toString(), null);
                                        if (var98_16 != null) {
                                            var7_7.setRequestProperty("if-none-match", var98_16);
                                            var99_17 = OneSignal.LOG_LEVEL.DEBUG;
                                            var100_18 = new StringBuilder();
                                            var100_18.append("OneSignalRestClient: Adding header if-none-match: ");
                                            var100_18.append(var98_16);
                                            OneSignal.Log(var99_17, var100_18.toString());
                                        }
                                    }
                                    var6_6 = var24_19 = var7_7.getResponseCode();
                                    try {
                                        var26_20 = OneSignal.LOG_LEVEL.VERBOSE;
                                        var27_21 = new StringBuilder();
                                        var27_21.append("OneSignalRestClient: After con.getResponseCode to: https://api.onesignal.com/");
                                        var27_21.append(var0);
                                        OneSignal.Log(var26_20, var27_21.toString());
                                        var30_22 = "";
                                        var31_23 = "GET";
                                        if (var6_6 == 200 || var6_6 == 202) break block26;
                                        if (var6_6 == 304) ** GOTO lbl95
                                    }
                                    catch (Throwable var8_56) {}
                                    var74_24 = OneSignal.LOG_LEVEL.DEBUG;
                                    var75_25 = new StringBuilder();
                                    var75_25.append("OneSignalRestClient: Failed request to: https://api.onesignal.com/");
                                    var75_25.append(var0);
                                    OneSignal.Log(var74_24, var75_25.toString());
                                    var78_26 = var7_7.getErrorStream();
                                    if (var78_26 == null) {
                                        var78_26 = var7_7.getInputStream();
                                    }
                                    var79_27 = null;
                                    if (var78_26 != null) {
                                        var80_28 = new Scanner(var78_26, "UTF-8");
                                        if (var80_28.useDelimiter("\\A").hasNext()) {
                                            var30_22 = var80_28.next();
                                        }
                                        var79_27 = var30_22;
                                        var80_28.close();
                                        var81_29 = OneSignal.LOG_LEVEL.WARN;
                                        var82_30 = new StringBuilder();
                                        var82_30.append("OneSignalRestClient: ");
                                        var82_30.append(var1_1);
                                        var82_30.append(" RECEIVED JSON: ");
                                        var82_30.append(var79_27);
                                        OneSignal.Log(var81_29, var82_30.toString());
                                    } else {
                                        var87_31 = OneSignal.LOG_LEVEL.WARN;
                                        var88_32 = new StringBuilder();
                                        var88_32.append("OneSignalRestClient: ");
                                        var88_32.append(var1_1);
                                        var88_32.append(" HTTP Code: ");
                                        var88_32.append(var6_6);
                                        var88_32.append(" No response body!");
                                        OneSignal.Log(var87_31, var88_32.toString());
                                    }
                                    var60_33 = OneSignalRestClient.callResponseHandlerOnFailure(var3_3, var6_6, var79_27, null);
                                    var34_34 = var6_6;
                                    break block27;
lbl95: // 1 sources:
                                    var62_35 = OneSignalPrefs.PREFS_ONESIGNAL;
                                    var63_36 = new StringBuilder();
                                    var63_36.append("PREFS_OS_HTTP_CACHE_PREFIX_");
                                    var63_36.append(var5_5);
                                    var66_37 = OneSignalPrefs.getString(var62_35, var63_36.toString(), null);
                                    var67_38 = OneSignal.LOG_LEVEL.DEBUG;
                                    var68_39 = new StringBuilder();
                                    var68_39.append("OneSignalRestClient: ");
                                    if (var1_1 != null) break block28;
                                    break block29;
                                }
                                var32_41 = OneSignal.LOG_LEVEL.DEBUG;
                                var33_42 = new StringBuilder();
                                var34_34 = var6_6;
                                try {
                                    var33_42.append("OneSignalRestClient: Successfully finished request to: https://api.onesignal.com/");
                                    var33_42.append(var0);
                                    OneSignal.Log(var32_41, var33_42.toString());
                                    var37_43 = new Scanner(var7_7.getInputStream(), "UTF-8");
                                    if (var37_43.useDelimiter("\\A").hasNext()) {
                                        var30_22 = var37_43.next();
                                    }
                                    var38_44 = var30_22;
                                    var37_43.close();
                                    var39_45 = OneSignal.LOG_LEVEL.DEBUG;
                                    var40_46 = new StringBuilder();
                                    var40_46.append("OneSignalRestClient: ");
                                    if (var1_1 != null) break block30;
                                    break block31;
                                }
                                catch (Throwable var8_55) {
                                    var6_6 = var34_34;
                                    break block32;
                                }
                                break block32;
                                catch (Throwable var8_57) {
                                    // empty catch block
                                }
                            }
                            try {
                                if (!(var8_58 instanceof ConnectException) && !(var8_58 instanceof UnknownHostException)) {
                                    var15_59 = OneSignal.LOG_LEVEL.WARN;
                                    var16_60 = new StringBuilder();
                                    var16_60.append("OneSignalRestClient: ");
                                    var16_60.append(var1_1);
                                    var16_60.append(" Error thrown from network stack. ");
                                    OneSignal.Log(var15_59, var16_60.toString(), (Throwable)var8_58);
                                } else {
                                    var10_61 = OneSignal.LOG_LEVEL.INFO;
                                    var11_62 = new StringBuilder();
                                    var11_62.append("OneSignalRestClient: Could not send last request, device is offline. Throwable: ");
                                    var11_62.append(var8_58.getClass().getName());
                                    OneSignal.Log(var10_61, var11_62.toString());
                                }
                                var14_63 = OneSignalRestClient.callResponseHandlerOnFailure(var3_3, var6_6, null, (Throwable)var8_58);
                                return var14_63;
                            }
                            finally {
                                if (var7_7 != null) {
                                    var7_7.disconnect();
                                }
                            }
                        }
                        var31_23 = var1_1;
                    }
                    var68_39.append(var31_23);
                    var68_39.append(" - Using Cached response due to 304: ");
                    var68_39.append(var66_37);
                    OneSignal.Log(var67_38, var68_39.toString());
                    var60_33 = var73_40 = OneSignalRestClient.callResponseHandlerOnSuccess(var3_3, var66_37);
                    var34_34 = var6_6;
                    break block27;
                }
                var31_23 = var1_1;
            }
            var40_46.append(var31_23);
            var40_46.append(" RECEIVED JSON: ");
            var40_46.append(var38_44);
            OneSignal.Log(var39_45, var40_46.toString());
            if (var5_5 != null && (var45_47 = var7_7.getHeaderField("etag")) != null) {
                var46_48 = OneSignal.LOG_LEVEL.DEBUG;
                var47_49 = new StringBuilder();
                var47_49.append("OneSignalRestClient: Response has etag of ");
                var47_49.append(var45_47);
                var47_49.append(" so caching the response.");
                OneSignal.Log(var46_48, var47_49.toString());
                var51_50 = OneSignalPrefs.PREFS_ONESIGNAL;
                var52_51 = new StringBuilder();
                var52_51.append("PREFS_OS_ETAG_PREFIX_");
                var52_51.append(var5_5);
                OneSignalPrefs.saveString(var51_50, var52_51.toString(), var45_47);
                var55_52 = OneSignalPrefs.PREFS_ONESIGNAL;
                var56_53 = new StringBuilder();
                var56_53.append("PREFS_OS_HTTP_CACHE_PREFIX_");
                var56_53.append(var5_5);
                OneSignalPrefs.saveString(var55_52, var56_53.toString(), var38_44);
            }
            var60_33 = var59_54 = OneSignalRestClient.callResponseHandlerOnSuccess(var3_3, var38_44);
        }
        if (var7_7 == null) return var60_33;
        var7_7.disconnect();
        return var60_33;
    }

    private static class OneSignalNetworkCallException
    extends RuntimeException {
        public OneSignalNetworkCallException(String string2) {
            super(string2);
        }
    }

    static abstract class ResponseHandler {
        ResponseHandler() {
        }

        void onFailure(int n, String string2, Throwable throwable) {
        }

        void onSuccess(String string2) {
        }
    }

}

