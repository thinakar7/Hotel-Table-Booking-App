/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  com.onesignal.R
 *  com.onesignal.R$string
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import com.onesignal.OSDynamicTriggerController;
import com.onesignal.OSInAppMessage;
import com.onesignal.OSInAppMessageAction;
import com.onesignal.OSInAppMessageOutcome;
import com.onesignal.OSInAppMessagePrompt;
import com.onesignal.OSInAppMessageRedisplayStats;
import com.onesignal.OSInAppMessageRepository;
import com.onesignal.OSInAppMessageTag;
import com.onesignal.OSSystemConditionController;
import com.onesignal.OSTrigger;
import com.onesignal.OSTriggerController;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalChromeTab;
import com.onesignal.OneSignalDbHelper;
import com.onesignal.OneSignalPrefs;
import com.onesignal.OneSignalRestClient;
import com.onesignal.R;
import com.onesignal.WebViewManager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class OSInAppMessageController
implements OSDynamicTriggerController.OSDynamicTriggerControllerObserver,
OSSystemConditionController.OSSystemConditionObserver {
    public static final String IN_APP_MESSAGES_JSON_KEY = "in_app_messages";
    private static final Object LOCK;
    private static final String OS_SAVE_IN_APP_MESSAGE = "OS_SAVE_IN_APP_MESSAGE";
    private static ArrayList<String> PREFERRED_VARIANT_ORDER;
    private final Set<String> clickedClickIds;
    private OSInAppMessagePrompt currentPrompt = null;
    private final Set<String> dismissedMessages;
    private int htmlNetworkRequestAttemptCount = 0;
    private final Set<String> impressionedMessages;
    private OSInAppMessageRepository inAppMessageRepository;
    private boolean inAppMessageShowing = false;
    private boolean inAppMessagingEnabled = true;
    Date lastTimeInAppDismissed = null;
    private final ArrayList<OSInAppMessage> messageDisplayQueue;
    private ArrayList<OSInAppMessage> messages = new ArrayList();
    private List<OSInAppMessage> redisplayedInAppMessages;
    private OSSystemConditionController systemConditionController;
    OSTriggerController triggerController;

    static {
        PREFERRED_VARIANT_ORDER = new ArrayList<String>(){
            {
                this.add((Object)"android");
                this.add((Object)"app");
                this.add((Object)"all");
            }
        };
        LOCK = new Object();
    }

    protected OSInAppMessageController(OneSignalDbHelper oneSignalDbHelper) {
        Set<String> set;
        Set<String> set2;
        Set set3 = OSUtils.newConcurrentSet();
        this.dismissedMessages = set3;
        this.messageDisplayQueue = new ArrayList();
        Set set4 = OSUtils.newConcurrentSet();
        this.impressionedMessages = set4;
        Set set5 = OSUtils.newConcurrentSet();
        this.clickedClickIds = set5;
        this.triggerController = new OSTriggerController(this);
        this.systemConditionController = new OSSystemConditionController(this);
        Set<String> set6 = OneSignalPrefs.getStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_DISPLAYED_IAMS", null);
        if (set6 != null) {
            set3.addAll(set6);
        }
        if ((set = OneSignalPrefs.getStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_IMPRESSIONED_IAMS", null)) != null) {
            set4.addAll(set);
        }
        if ((set2 = OneSignalPrefs.getStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_CLICKED_CLICK_IDS_IAMS", null)) != null) {
            set5.addAll(set2);
        }
        this.initRedisplayData(oneSignalDbHelper);
    }

    static /* synthetic */ int access$908(OSInAppMessageController oSInAppMessageController) {
        int n = oSInAppMessageController.htmlNetworkRequestAttemptCount;
        oSInAppMessageController.htmlNetworkRequestAttemptCount = n + 1;
        return n;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void attemptToShowInAppMessage() {
        ArrayList<OSInAppMessage> arrayList;
        ArrayList<OSInAppMessage> arrayList2 = arrayList = this.messageDisplayQueue;
        synchronized (arrayList2) {
            if (!this.systemConditionController.systemConditionsAvailable()) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.WARN, "In app message not showing due to system condition not correct");
                return;
            }
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("displayFirstIAMOnQueue: ");
            stringBuilder.append(this.messageDisplayQueue);
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            if (this.messageDisplayQueue.size() > 0 && !this.isInAppMessageShowing()) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.DEBUG, "No IAM showing currently, showing first item in the queue!");
                this.displayMessage((OSInAppMessage)this.messageDisplayQueue.get(0));
                return;
            }
            OneSignal.onesignalLog(OneSignal.LOG_LEVEL.DEBUG, "In app message is currently showing or there are no IAMs left in the queue!");
            return;
        }
    }

    private void beginProcessingPrompts(OSInAppMessage oSInAppMessage, List<OSInAppMessagePrompt> list) {
        if (list.size() > 0) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("IAM showing prompts from IAM: ");
            stringBuilder.append(oSInAppMessage.toString());
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            WebViewManager.dismissCurrentInAppMessage();
            this.showMultiplePrompts(oSInAppMessage, list);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void dismissCurrentMessage(OSInAppMessage oSInAppMessage) {
        ArrayList<OSInAppMessage> arrayList;
        OneSignal.getSessionManager().onDirectInfluenceFromIAMClickFinished();
        if (this.currentPrompt != null) {
            OneSignal.onesignalLog(OneSignal.LOG_LEVEL.DEBUG, "Stop evaluateMessageDisplayQueue because prompt is currently displayed");
            return;
        }
        this.inAppMessageShowing = false;
        ArrayList<OSInAppMessage> arrayList2 = arrayList = this.messageDisplayQueue;
        synchronized (arrayList2) {
            if (this.messageDisplayQueue.size() > 0) {
                if (oSInAppMessage != null && !this.messageDisplayQueue.contains((Object)oSInAppMessage)) {
                    OneSignal.onesignalLog(OneSignal.LOG_LEVEL.DEBUG, "Message already removed from the queue!");
                    return;
                }
                String string = ((OSInAppMessage)this.messageDisplayQueue.remove((int)0)).messageId;
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("In app message with id, ");
                stringBuilder.append(string);
                stringBuilder.append(", dismissed (removed) from the queue!");
                OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            }
            if (this.messageDisplayQueue.size() > 0) {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("In app message on queue available: ");
                stringBuilder.append(((OSInAppMessage)this.messageDisplayQueue.get((int)0)).messageId);
                OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
                this.displayMessage((OSInAppMessage)this.messageDisplayQueue.get(0));
            } else {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.DEBUG, "In app message dismissed evaluating messages");
                this.evaluateInAppMessages();
            }
            return;
        }
    }

    private void displayMessage(final OSInAppMessage oSInAppMessage) {
        if (!this.inAppMessagingEnabled) {
            OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "In app messaging is currently paused, iam will not be shown!");
            return;
        }
        this.inAppMessageShowing = true;
        OneSignalRestClient.get(OSInAppMessageController.htmlPathForMessage(oSInAppMessage), new OneSignalRestClient.ResponseHandler(){

            @Override
            void onFailure(int n, String string, Throwable throwable) {
                OSInAppMessageController.this.inAppMessageShowing = false;
                OSInAppMessageController.printHttpErrorForInAppMessageRequest("html", n, string);
                if (OSUtils.shouldRetryNetworkRequest(n) && OSInAppMessageController.this.htmlNetworkRequestAttemptCount < OSUtils.MAX_NETWORK_REQUEST_ATTEMPT_COUNT) {
                    OSInAppMessageController.access$908(OSInAppMessageController.this);
                    OSInAppMessageController.this.queueMessageForDisplay(oSInAppMessage);
                    return;
                }
                OSInAppMessageController.this.htmlNetworkRequestAttemptCount = 0;
                OSInAppMessageController.this.messageWasDismissed(oSInAppMessage, true);
            }

            @Override
            void onSuccess(String string) {
                OSInAppMessageController.this.htmlNetworkRequestAttemptCount = 0;
                try {
                    JSONObject jSONObject = new JSONObject(string);
                    String string2 = jSONObject.getString("html");
                    double d = jSONObject.optDouble("display_duration");
                    oSInAppMessage.setDisplayDuration(d);
                    OneSignal.getSessionManager().onInAppMessageReceived(oSInAppMessage.messageId);
                    WebViewManager.showHTMLString(oSInAppMessage, string2);
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        }, null);
    }

    private void evaluateInAppMessages() {
        OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "Starting evaluateInAppMessages");
        for (OSInAppMessage oSInAppMessage : this.messages) {
            if (!this.triggerController.evaluateMessageTriggers(oSInAppMessage)) continue;
            this.setDataForRedisplay(oSInAppMessage);
            if (this.dismissedMessages.contains((Object)oSInAppMessage.messageId) || oSInAppMessage.isFinished()) continue;
            this.queueMessageForDisplay(oSInAppMessage);
        }
    }

    private void fireClickAction(OSInAppMessageAction oSInAppMessageAction) {
        if (oSInAppMessageAction.clickUrl != null && !oSInAppMessageAction.clickUrl.isEmpty()) {
            if (oSInAppMessageAction.urlTarget == OSInAppMessageAction.OSInAppMessageActionUrlType.BROWSER) {
                OSUtils.openURLInBrowser(oSInAppMessageAction.clickUrl);
                return;
            }
            if (oSInAppMessageAction.urlTarget == OSInAppMessageAction.OSInAppMessageActionUrlType.IN_APP_WEBVIEW) {
                OneSignalChromeTab.open(oSInAppMessageAction.clickUrl, true);
            }
        }
    }

    private void fireOutcomesForClick(String string, List<OSInAppMessageOutcome> list) {
        OneSignal.getSessionManager().onDirectInfluenceFromIAMClick(string);
        OneSignal.sendClickActionOutcomes(list);
    }

    private void firePublicClickHandler(final String string, final OSInAppMessageAction oSInAppMessageAction) {
        if (OneSignal.mInitBuilder.mInAppMessageClickHandler == null) {
            return;
        }
        OSUtils.runOnMainUIThread(new Runnable(){

            public void run() {
                OneSignal.getSessionManager().onDirectInfluenceFromIAMClick(string);
                OneSignal.mInitBuilder.mInAppMessageClickHandler.inAppMessageClicked(oSInAppMessageAction);
            }
        });
    }

    private void fireRESTCallForClick(OSInAppMessage oSInAppMessage, final OSInAppMessageAction oSInAppMessageAction) {
        final String string = OSInAppMessageController.variantIdForMessage(oSInAppMessage);
        if (string == null) {
            return;
        }
        final String string2 = oSInAppMessageAction.clickId;
        boolean bl = oSInAppMessage.getRedisplayStats().isRedisplayEnabled() && oSInAppMessage.isClickAvailable(string2);
        if (!bl && this.clickedClickIds.contains((Object)string2)) {
            return;
        }
        this.clickedClickIds.add((Object)string2);
        oSInAppMessage.addClickId(string2);
        try {
            JSONObject jSONObject = new JSONObject(){
                {
                    this.put("app_id", (Object)OneSignal.getSavedAppId());
                    this.put("device_type", new OSUtils().getDeviceType());
                    this.put("player_id", (Object)OneSignal.getUserId());
                    this.put("click_id", (Object)string3);
                    this.put("variant_id", (Object)string22);
                    if (oSInAppMessageAction2.firstClick) {
                        this.put("first_click", true);
                    }
                }
            };
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("in_app_messages/");
            stringBuilder.append(oSInAppMessage.messageId);
            stringBuilder.append("/click");
            OneSignalRestClient.post(stringBuilder.toString(), jSONObject, new OneSignalRestClient.ResponseHandler(){

                @Override
                void onFailure(int n, String string, Throwable throwable) {
                    OSInAppMessageController.printHttpErrorForInAppMessageRequest("engagement", n, string);
                    OSInAppMessageController.this.clickedClickIds.remove((Object)oSInAppMessageAction.clickId);
                }

                @Override
                void onSuccess(String string) {
                    OSInAppMessageController.printHttpSuccessForInAppMessageRequest("engagement", string);
                    OneSignalPrefs.saveStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_CLICKED_CLICK_IDS_IAMS", (Set<String>)OSInAppMessageController.this.clickedClickIds);
                }
            });
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            OneSignal.onesignalLog(OneSignal.LOG_LEVEL.ERROR, "Unable to execute in-app message action HTTP request due to invalid JSON");
            return;
        }
    }

    private void fireTagCallForClick(OSInAppMessageAction oSInAppMessageAction) {
        if (oSInAppMessageAction.tags != null) {
            OSInAppMessageTag oSInAppMessageTag = oSInAppMessageAction.tags;
            if (oSInAppMessageTag.getTagsToAdd() != null) {
                OneSignal.sendTags(oSInAppMessageTag.getTagsToAdd());
            }
            if (oSInAppMessageTag.getTagsToRemove() != null) {
                OneSignal.deleteTags(oSInAppMessageTag.getTagsToRemove(), null);
            }
        }
    }

    private boolean hasMessageTriggerChanged(OSInAppMessage oSInAppMessage) {
        boolean bl = this.triggerController.messageHasOnlyDynamicTriggers(oSInAppMessage);
        boolean bl2 = true;
        if (bl) {
            return bl2 ^ oSInAppMessage.isDisplayedInSession();
        }
        boolean bl3 = !oSInAppMessage.isDisplayedInSession() && oSInAppMessage.triggers.isEmpty();
        if (!oSInAppMessage.isTriggerChanged()) {
            if (bl3) {
                return bl2;
            }
            bl2 = false;
        }
        return bl2;
    }

    private static String htmlPathForMessage(OSInAppMessage oSInAppMessage) {
        String string = OSInAppMessageController.variantIdForMessage(oSInAppMessage);
        if (string == null) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to find a variant for in-app message ");
            stringBuilder.append(oSInAppMessage.messageId);
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("in_app_messages/");
        stringBuilder.append(oSInAppMessage.messageId);
        stringBuilder.append("/variants/");
        stringBuilder.append(string);
        stringBuilder.append("/html?app_id=");
        stringBuilder.append(OneSignal.appId);
        return stringBuilder.toString();
    }

    private void logInAppMessagePreviewActions(OSInAppMessageAction oSInAppMessageAction) {
        if (oSInAppMessageAction.tags != null) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Tags detected inside of the action click payload, ignoring because action came from IAM preview:: ");
            stringBuilder.append(oSInAppMessageAction.tags.toString());
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        }
        if (oSInAppMessageAction.outcomes.size() > 0) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Outcomes detected inside of the action click payload, ignoring because action came from IAM preview: ");
            stringBuilder.append(oSInAppMessageAction.outcomes.toString());
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        }
    }

    private void makeRedisplayMessagesAvailableWithTriggers(Collection<String> collection) {
        for (OSInAppMessage oSInAppMessage : this.messages) {
            if (oSInAppMessage.isTriggerChanged() || !this.redisplayedInAppMessages.contains((Object)oSInAppMessage) || !this.triggerController.isTriggerOnMessage(oSInAppMessage, collection)) continue;
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Trigger changed for message: ");
            stringBuilder.append(oSInAppMessage.toString());
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            oSInAppMessage.setTriggerChanged(true);
        }
    }

    private void persistInAppMessage(final OSInAppMessage oSInAppMessage) {
        long l = System.currentTimeMillis() / 1000L;
        oSInAppMessage.getRedisplayStats().setLastDisplayTime(l);
        oSInAppMessage.getRedisplayStats().incrementDisplayQuantity();
        oSInAppMessage.setTriggerChanged(false);
        oSInAppMessage.setDisplayedInSession(true);
        new Thread(new Runnable(){

            public void run() {
                Thread.currentThread().setPriority(10);
                OSInAppMessageController.this.inAppMessageRepository.saveInAppMessage(oSInAppMessage);
            }
        }, OS_SAVE_IN_APP_MESSAGE).start();
        int n = this.redisplayedInAppMessages.indexOf((Object)oSInAppMessage);
        if (n != -1) {
            this.redisplayedInAppMessages.set(n, (Object)oSInAppMessage);
        } else {
            this.redisplayedInAppMessages.add((Object)oSInAppMessage);
        }
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("persistInAppMessageForRedisplay: ");
        stringBuilder.append(oSInAppMessage.toString());
        stringBuilder.append(" with msg array data: ");
        stringBuilder.append(this.redisplayedInAppMessages.toString());
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
    }

    private static void printHttpErrorForInAppMessageRequest(String string, int n, String string2) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Encountered a ");
        stringBuilder.append(n);
        stringBuilder.append(" error while attempting in-app message ");
        stringBuilder.append(string);
        stringBuilder.append(" request: ");
        stringBuilder.append(string2);
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
    }

    private static void printHttpSuccessForInAppMessageRequest(String string, String string2) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Successful post for in-app message ");
        stringBuilder.append(string);
        stringBuilder.append(" request: ");
        stringBuilder.append(string2);
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void processInAppMessageJson(JSONArray jSONArray) throws JSONException {
        Object object;
        Object object2 = object = LOCK;
        synchronized (object2) {
            ArrayList arrayList = new ArrayList();
            int n = 0;
            do {
                if (n >= jSONArray.length()) {
                    this.messages = arrayList;
                    // MONITOREXIT [3, 4, 5] lbl8 : w: MONITOREXIT : var7_3
                    this.evaluateInAppMessages();
                    return;
                }
                arrayList.add((Object)new OSInAppMessage(jSONArray.getJSONObject(n)));
                ++n;
            } while (true);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void queueMessageForDisplay(OSInAppMessage oSInAppMessage) {
        ArrayList<OSInAppMessage> arrayList;
        ArrayList<OSInAppMessage> arrayList2 = arrayList = this.messageDisplayQueue;
        synchronized (arrayList2) {
            if (!this.messageDisplayQueue.contains((Object)oSInAppMessage)) {
                this.messageDisplayQueue.add((Object)oSInAppMessage);
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("In app message with id, ");
                stringBuilder.append(oSInAppMessage.messageId);
                stringBuilder.append(", added to the queue");
                OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            }
            this.attemptToShowInAppMessage();
            return;
        }
    }

    private void resetRedisplayMessagesBySession() {
        Iterator iterator = this.redisplayedInAppMessages.iterator();
        while (iterator.hasNext()) {
            ((OSInAppMessage)iterator.next()).setDisplayedInSession(false);
        }
    }

    private void setDataForRedisplay(OSInAppMessage oSInAppMessage) {
        boolean bl = this.dismissedMessages.contains((Object)oSInAppMessage.messageId);
        int n = this.redisplayedInAppMessages.indexOf((Object)oSInAppMessage);
        if (bl && n != -1) {
            OSInAppMessage oSInAppMessage2 = (OSInAppMessage)this.redisplayedInAppMessages.get(n);
            oSInAppMessage.getRedisplayStats().setDisplayStats(oSInAppMessage2.getRedisplayStats());
            oSInAppMessage.setDisplayedInSession(oSInAppMessage2.isDisplayedInSession());
            boolean bl2 = this.hasMessageTriggerChanged(oSInAppMessage);
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("setDataForRedisplay: ");
            stringBuilder.append(oSInAppMessage.toString());
            stringBuilder.append(" triggerHasChanged: ");
            stringBuilder.append(bl2);
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            if (bl2 && oSInAppMessage.getRedisplayStats().isDelayTimeSatisfied() && oSInAppMessage.getRedisplayStats().shouldDisplayAgain()) {
                OneSignal.LOG_LEVEL lOG_LEVEL2 = OneSignal.LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("setDataForRedisplay message available for redisplay: ");
                stringBuilder2.append(oSInAppMessage.messageId);
                OneSignal.onesignalLog(lOG_LEVEL2, stringBuilder2.toString());
                this.dismissedMessages.remove((Object)oSInAppMessage.messageId);
                this.impressionedMessages.remove((Object)oSInAppMessage.messageId);
                oSInAppMessage.clearClickIds();
            }
        }
    }

    private void showAlertDialogMessage(final OSInAppMessage oSInAppMessage, final List<OSInAppMessagePrompt> list) {
        String string2 = OneSignal.appContext.getString(R.string.location_not_available_title);
        String string3 = OneSignal.appContext.getString(R.string.location_not_available_message);
        new AlertDialog.Builder((Context)OneSignal.getCurrentActivity()).setTitle((CharSequence)string2).setMessage((CharSequence)string3).setPositiveButton(17039370, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n) {
                OSInAppMessageController.this.showMultiplePrompts(oSInAppMessage, (List<OSInAppMessagePrompt>)list);
            }
        }).show();
    }

    private void showMultiplePrompts(final OSInAppMessage oSInAppMessage, final List<OSInAppMessagePrompt> list) {
        for (OSInAppMessagePrompt oSInAppMessagePrompt : list) {
            if (oSInAppMessagePrompt.hasPrompted()) continue;
            this.currentPrompt = oSInAppMessagePrompt;
            break;
        }
        if (this.currentPrompt != null) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("IAM prompt to handle: ");
            stringBuilder.append(this.currentPrompt.toString());
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            this.currentPrompt.setPrompted(true);
            this.currentPrompt.handlePrompt(new OneSignal.OSPromptActionCompletionCallback(){

                @Override
                public void onCompleted(OneSignal.PromptActionResult promptActionResult) {
                    OSInAppMessageController.this.currentPrompt = null;
                    OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("IAM prompt to handle finished with result: ");
                    stringBuilder.append((Object)promptActionResult);
                    OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
                    if (oSInAppMessage.isPreview && promptActionResult == OneSignal.PromptActionResult.LOCATION_PERMISSIONS_MISSING_MANIFEST) {
                        OSInAppMessageController.this.showAlertDialogMessage(oSInAppMessage, (List<OSInAppMessagePrompt>)list);
                        return;
                    }
                    OSInAppMessageController.this.showMultiplePrompts(oSInAppMessage, (List<OSInAppMessagePrompt>)list);
                }
            });
            return;
        }
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No IAM prompt to handle, dismiss message: ");
        stringBuilder.append(oSInAppMessage.messageId);
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        this.messageWasDismissed(oSInAppMessage);
    }

    private static String variantIdForMessage(OSInAppMessage oSInAppMessage) {
        String string2 = OSUtils.getCorrectedLanguage();
        for (String string3 : PREFERRED_VARIANT_ORDER) {
            if (!oSInAppMessage.variants.containsKey((Object)string3)) continue;
            HashMap hashMap = (HashMap)oSInAppMessage.variants.get((Object)string3);
            if (hashMap.containsKey((Object)string2)) {
                return (String)hashMap.get((Object)string2);
            }
            return (String)hashMap.get((Object)"default");
        }
        return null;
    }

    void addTriggers(Map<String, Object> map) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Add trigger called with: ");
        stringBuilder.append(map.toString());
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        this.triggerController.addTriggers(map);
        this.makeRedisplayMessagesAvailableWithTriggers((Collection<String>)map.keySet());
        this.evaluateInAppMessages();
    }

    void displayPreviewMessage(String string2) {
        this.inAppMessageShowing = true;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("in_app_messages/device_preview?preview_id=");
        stringBuilder.append(string2);
        stringBuilder.append("&app_id=");
        stringBuilder.append(OneSignal.appId);
        OneSignalRestClient.get(stringBuilder.toString(), new OneSignalRestClient.ResponseHandler(){

            @Override
            void onFailure(int n, String string, Throwable throwable) {
                OSInAppMessageController.printHttpErrorForInAppMessageRequest("html", n, string);
                OSInAppMessageController.this.dismissCurrentMessage(null);
            }

            @Override
            void onSuccess(String string) {
                try {
                    JSONObject jSONObject = new JSONObject(string);
                    String string2 = jSONObject.getString("html");
                    OSInAppMessage oSInAppMessage = new OSInAppMessage(true);
                    oSInAppMessage.setDisplayDuration(jSONObject.optDouble("display_duration"));
                    WebViewManager.showHTMLString(oSInAppMessage, string2);
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        }, null);
    }

    OSInAppMessage getCurrentDisplayedInAppMessage() {
        if (this.inAppMessageShowing) {
            return (OSInAppMessage)this.messageDisplayQueue.get(0);
        }
        return null;
    }

    public ArrayList<OSInAppMessage> getInAppMessageDisplayQueue() {
        return this.messageDisplayQueue;
    }

    OSInAppMessageRepository getInAppMessageRepository(OneSignalDbHelper oneSignalDbHelper) {
        if (this.inAppMessageRepository == null) {
            this.inAppMessageRepository = new OSInAppMessageRepository(oneSignalDbHelper);
        }
        return this.inAppMessageRepository;
    }

    public List<OSInAppMessage> getRedisplayedInAppMessages() {
        return this.redisplayedInAppMessages;
    }

    Object getTriggerValue(String string2) {
        return this.triggerController.getTriggerValue(string2);
    }

    protected void initRedisplayData(OneSignalDbHelper oneSignalDbHelper) {
        OSInAppMessageRepository oSInAppMessageRepository;
        this.inAppMessageRepository = oSInAppMessageRepository = this.getInAppMessageRepository(oneSignalDbHelper);
        this.redisplayedInAppMessages = oSInAppMessageRepository.getCachedInAppMessages();
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("redisplayedInAppMessages: ");
        stringBuilder.append(this.redisplayedInAppMessages.toString());
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void initWithCachedInAppMessages() {
        Object object;
        if (!this.messages.isEmpty()) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("initWithCachedInAppMessages with already in memory messages: ");
            stringBuilder.append(this.messages);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            return;
        }
        String string2 = OneSignalPrefs.getString(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_CACHED_IAMS", null);
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("initWithCachedInAppMessages: ");
        stringBuilder.append(string2);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        if (string2 == null) {
            return;
        }
        if (string2.isEmpty()) {
            return;
        }
        Object object2 = object = LOCK;
        synchronized (object2) {
            try {
                block9 : {
                    boolean bl = this.messages.isEmpty();
                    if (bl) break block9;
                    return;
                }
                try {
                    this.processInAppMessageJson(new JSONArray(string2));
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                }
                return;
            }
            catch (Throwable throwable2) {}
            throw throwable2;
        }
    }

    boolean isInAppMessageShowing() {
        return this.inAppMessageShowing;
    }

    @Override
    public void messageDynamicTriggerCompleted(String string2) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("messageDynamicTriggerCompleted called with triggerId: ");
        stringBuilder.append(string2);
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        HashSet hashSet = new HashSet();
        hashSet.add((Object)string2);
        this.makeRedisplayMessagesAvailableWithTriggers((Collection<String>)hashSet);
    }

    @Override
    public void messageTriggerConditionChanged() {
        OneSignal.onesignalLog(OneSignal.LOG_LEVEL.DEBUG, "messageTriggerConditionChanged called");
        this.evaluateInAppMessages();
    }

    void messageWasDismissed(OSInAppMessage oSInAppMessage) {
        this.messageWasDismissed(oSInAppMessage, false);
    }

    void messageWasDismissed(OSInAppMessage oSInAppMessage, boolean bl) {
        if (!oSInAppMessage.isPreview) {
            this.dismissedMessages.add((Object)oSInAppMessage.messageId);
            if (!bl) {
                OneSignalPrefs.saveStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_DISPLAYED_IAMS", this.dismissedMessages);
                this.lastTimeInAppDismissed = new Date();
                this.persistInAppMessage(oSInAppMessage);
            }
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("OSInAppMessageController messageWasDismissed dismissedMessages: ");
            stringBuilder.append(this.dismissedMessages.toString());
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        }
        this.dismissCurrentMessage(oSInAppMessage);
    }

    void messageWasDismissedByBackPress(OSInAppMessage oSInAppMessage) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OSInAppMessageController messageWasDismissed by back press: ");
        stringBuilder.append(oSInAppMessage.toString());
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        this.dismissCurrentMessage(oSInAppMessage);
    }

    void onMessageActionOccurredOnMessage(OSInAppMessage oSInAppMessage, JSONObject jSONObject) throws JSONException {
        OSInAppMessageAction oSInAppMessageAction = new OSInAppMessageAction(jSONObject);
        oSInAppMessageAction.firstClick = oSInAppMessage.takeActionAsUnique();
        this.firePublicClickHandler(oSInAppMessage.messageId, oSInAppMessageAction);
        this.beginProcessingPrompts(oSInAppMessage, oSInAppMessageAction.prompts);
        this.fireClickAction(oSInAppMessageAction);
        this.fireRESTCallForClick(oSInAppMessage, oSInAppMessageAction);
        this.fireTagCallForClick(oSInAppMessageAction);
        this.fireOutcomesForClick(oSInAppMessage.messageId, oSInAppMessageAction.outcomes);
    }

    void onMessageActionOccurredOnPreview(OSInAppMessage oSInAppMessage, JSONObject jSONObject) throws JSONException {
        OSInAppMessageAction oSInAppMessageAction = new OSInAppMessageAction(jSONObject);
        oSInAppMessageAction.firstClick = oSInAppMessage.takeActionAsUnique();
        this.firePublicClickHandler(oSInAppMessage.messageId, oSInAppMessageAction);
        this.beginProcessingPrompts(oSInAppMessage, oSInAppMessageAction.prompts);
        this.fireClickAction(oSInAppMessageAction);
        this.logInAppMessagePreviewActions(oSInAppMessageAction);
    }

    void onMessageWasShown(final OSInAppMessage oSInAppMessage) {
        if (oSInAppMessage.isPreview) {
            return;
        }
        if (this.impressionedMessages.contains((Object)oSInAppMessage.messageId)) {
            return;
        }
        this.impressionedMessages.add((Object)oSInAppMessage.messageId);
        final String string2 = OSInAppMessageController.variantIdForMessage(oSInAppMessage);
        if (string2 == null) {
            return;
        }
        try {
            JSONObject jSONObject = new JSONObject(){
                {
                    this.put("app_id", (Object)OneSignal.appId);
                    this.put("player_id", (Object)OneSignal.getUserId());
                    this.put("variant_id", (Object)string);
                    this.put("device_type", new OSUtils().getDeviceType());
                    this.put("first_impression", true);
                }
            };
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("in_app_messages/");
            stringBuilder.append(oSInAppMessage.messageId);
            stringBuilder.append("/impression");
            OneSignalRestClient.post(stringBuilder.toString(), jSONObject, new OneSignalRestClient.ResponseHandler(){

                @Override
                void onFailure(int n, String string, Throwable throwable) {
                    OSInAppMessageController.printHttpErrorForInAppMessageRequest("impression", n, string);
                    OSInAppMessageController.this.impressionedMessages.remove((Object)oSInAppMessage.messageId);
                }

                @Override
                void onSuccess(String string) {
                    OSInAppMessageController.printHttpSuccessForInAppMessageRequest("impression", string);
                    OneSignalPrefs.saveStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_IMPRESSIONED_IAMS", (Set<String>)OSInAppMessageController.this.impressionedMessages);
                }
            });
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            OneSignal.onesignalLog(OneSignal.LOG_LEVEL.ERROR, "Unable to execute in-app message impression HTTP request due to invalid JSON");
            return;
        }
    }

    void receivedInAppMessageJson(JSONArray jSONArray) throws JSONException {
        OneSignalPrefs.saveString(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_CACHED_IAMS", jSONArray.toString());
        this.resetRedisplayMessagesBySession();
        this.processInAppMessageJson(jSONArray);
    }

    void removeTriggersForKeys(Collection<String> collection) {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Remove trigger called with keys: ");
        stringBuilder.append(collection);
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        this.triggerController.removeTriggersForKeys(collection);
        this.makeRedisplayMessagesAvailableWithTriggers(collection);
        this.evaluateInAppMessages();
    }

    void resetSessionLaunchTime() {
        OSDynamicTriggerController.resetSessionLaunchTime();
    }

    void setInAppMessagingEnabled(boolean bl) {
        this.inAppMessagingEnabled = bl;
        if (bl) {
            this.evaluateInAppMessages();
        }
    }

    @Override
    public void systemConditionChanged() {
        this.attemptToShowInAppMessage();
    }

}

