/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  org.json.JSONArray
 */
package com.onesignal;

import com.onesignal.OSInAppMessageOutcome;
import com.onesignal.OSSessionManager;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalApiResponseHandler;
import com.onesignal.OutcomeEvent;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.influence.model.OSInfluenceChannel;
import com.onesignal.influence.model.OSInfluenceType;
import com.onesignal.outcomes.OSOutcomeEventsFactory;
import com.onesignal.outcomes.domain.OSOutcomeEventsRepository;
import com.onesignal.outcomes.model.OSOutcomeEventParams;
import com.onesignal.outcomes.model.OSOutcomeSource;
import com.onesignal.outcomes.model.OSOutcomeSourceBody;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;

class OSOutcomeEventsController {
    private static final String OS_SAVE_OUTCOMES = "OS_SAVE_OUTCOMES";
    private static final String OS_SAVE_UNIQUE_OUTCOME_NOTIFICATIONS = "OS_SAVE_UNIQUE_OUTCOME_NOTIFICATIONS";
    private static final String OS_SEND_SAVED_OUTCOMES = "OS_SEND_SAVED_OUTCOMES";
    private final OSSessionManager osSessionManager;
    private final OSOutcomeEventsFactory outcomeEventsFactory;
    private Set<String> unattributedUniqueOutcomeEventsSentOnSession;

    public OSOutcomeEventsController(OSSessionManager oSSessionManager, OSOutcomeEventsFactory oSOutcomeEventsFactory) {
        this.osSessionManager = oSSessionManager;
        this.outcomeEventsFactory = oSOutcomeEventsFactory;
        this.initUniqueOutcomeEventsSentSets();
    }

    private List<OSInfluence> getUniqueIds(String string2, List<OSInfluence> list) {
        List<OSInfluence> list2 = this.outcomeEventsFactory.getRepository().getNotCachedUniqueOutcome(string2, list);
        if (list2.size() > 0) {
            return list2;
        }
        return null;
    }

    private void initUniqueOutcomeEventsSentSets() {
        this.unattributedUniqueOutcomeEventsSentOnSession = OSUtils.newConcurrentSet();
        Set<String> set = this.outcomeEventsFactory.getRepository().getUnattributedUniqueOutcomeEventsSent();
        if (set != null) {
            this.unattributedUniqueOutcomeEventsSentOnSession = set;
        }
    }

    private List<OSInfluence> removeDisabledInfluences(List<OSInfluence> list) {
        ArrayList arrayList = new ArrayList(list);
        for (OSInfluence oSInfluence : list) {
            if (!oSInfluence.getInfluenceType().isDisabled()) continue;
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Outcomes disabled for channel: ");
            stringBuilder.append(oSInfluence.getInfluenceChannel().toString());
            OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
            arrayList.remove((Object)oSInfluence);
        }
        return arrayList;
    }

    private void saveAttributedUniqueOutcomeNotifications(final OSOutcomeEventParams oSOutcomeEventParams) {
        new Thread(new Runnable(){

            public void run() {
                Thread.currentThread().setPriority(10);
                OSOutcomeEventsController.this.outcomeEventsFactory.getRepository().saveUniqueOutcomeNotifications(oSOutcomeEventParams);
            }
        }, OS_SAVE_UNIQUE_OUTCOME_NOTIFICATIONS).start();
    }

    private void saveUnattributedUniqueOutcomeEvents() {
        this.outcomeEventsFactory.getRepository().saveUnattributedUniqueOutcomeEventsSent(this.unattributedUniqueOutcomeEventsSentOnSession);
    }

    private void saveUniqueOutcome(OSOutcomeEventParams oSOutcomeEventParams) {
        if (oSOutcomeEventParams.isUnattributed()) {
            this.saveUnattributedUniqueOutcomeEvents();
            return;
        }
        this.saveAttributedUniqueOutcomeNotifications(oSOutcomeEventParams);
    }

    private void sendAndCreateOutcomeEvent(final String string2, float f, List<OSInfluence> list, final OneSignal.OutcomeCallback outcomeCallback) {
        final long l = System.currentTimeMillis() / 1000L;
        int n = new OSUtils().getDeviceType();
        String string3 = OneSignal.appId;
        Iterator iterator = list.iterator();
        OSOutcomeSourceBody oSOutcomeSourceBody = null;
        OSOutcomeSourceBody oSOutcomeSourceBody2 = null;
        boolean bl = false;
        while (iterator.hasNext()) {
            OSInfluence oSInfluence = (OSInfluence)iterator.next();
            int n2 = 5.$SwitchMap$com$onesignal$influence$model$OSInfluenceType[oSInfluence.getInfluenceType().ordinal()];
            if (n2 != 1) {
                if (n2 != 2) {
                    if (n2 != 3) {
                        if (n2 != 4) continue;
                        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.VERBOSE;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Outcomes disabled for channel: ");
                        stringBuilder.append((Object)oSInfluence.getInfluenceChannel());
                        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                        if (outcomeCallback != null) {
                            outcomeCallback.onSuccess(null);
                        }
                        return;
                    }
                    bl = true;
                    continue;
                }
                OSOutcomeSourceBody oSOutcomeSourceBody3 = oSOutcomeSourceBody2 == null ? new OSOutcomeSourceBody() : oSOutcomeSourceBody2;
                oSOutcomeSourceBody2 = this.setSourceChannelIds(oSInfluence, oSOutcomeSourceBody3);
                continue;
            }
            OSOutcomeSourceBody oSOutcomeSourceBody4 = oSOutcomeSourceBody == null ? new OSOutcomeSourceBody() : oSOutcomeSourceBody;
            oSOutcomeSourceBody = this.setSourceChannelIds(oSInfluence, oSOutcomeSourceBody4);
        }
        if (oSOutcomeSourceBody == null && oSOutcomeSourceBody2 == null && !bl) {
            OneSignal.Log(OneSignal.LOG_LEVEL.VERBOSE, "Outcomes disabled for all channels");
            if (outcomeCallback != null) {
                outcomeCallback.onSuccess(null);
            }
            return;
        }
        final OSOutcomeEventParams oSOutcomeEventParams = new OSOutcomeEventParams(string2, new OSOutcomeSource(oSOutcomeSourceBody, oSOutcomeSourceBody2), f);
        OneSignalApiResponseHandler oneSignalApiResponseHandler = new OneSignalApiResponseHandler(){

            @Override
            public void onFailure(int n, String string22, Throwable throwable) {
                new Thread(new Runnable(){

                    public void run() {
                        Thread.currentThread().setPriority(10);
                        oSOutcomeEventParams.setTimestamp(l);
                        OSOutcomeEventsController.this.outcomeEventsFactory.getRepository().saveOutcomeEvent(oSOutcomeEventParams);
                    }
                }, OSOutcomeEventsController.OS_SAVE_OUTCOMES).start();
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.WARN;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Sending outcome with name: ");
                stringBuilder.append(string2);
                stringBuilder.append(" failed with status code: ");
                stringBuilder.append(n);
                stringBuilder.append(" and response: ");
                stringBuilder.append(string22);
                stringBuilder.append("\nOutcome event was cached and will be reattempted on app cold start");
                OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
                OneSignal.OutcomeCallback outcomeCallback2 = outcomeCallback;
                if (outcomeCallback2 != null) {
                    outcomeCallback2.onSuccess(null);
                }
            }

            @Override
            public void onSuccess(String string22) {
                OSOutcomeEventsController.this.saveUniqueOutcome(oSOutcomeEventParams);
                OneSignal.OutcomeCallback outcomeCallback2 = outcomeCallback;
                if (outcomeCallback2 != null) {
                    outcomeCallback2.onSuccess(OutcomeEvent.fromOutcomeEventParamsV2toOutcomeEventV1(oSOutcomeEventParams));
                }
            }

        };
        this.outcomeEventsFactory.getRepository().requestMeasureOutcomeEvent(string3, n, oSOutcomeEventParams, oneSignalApiResponseHandler);
    }

    private void sendSavedOutcomeEvent(final OSOutcomeEventParams oSOutcomeEventParams) {
        int n = new OSUtils().getDeviceType();
        String string2 = OneSignal.appId;
        OneSignalApiResponseHandler oneSignalApiResponseHandler = new OneSignalApiResponseHandler(){

            @Override
            public void onFailure(int n, String string2, Throwable throwable) {
            }

            @Override
            public void onSuccess(String string2) {
                OSOutcomeEventsController.this.outcomeEventsFactory.getRepository().removeEvent(oSOutcomeEventParams);
            }
        };
        this.outcomeEventsFactory.getRepository().requestMeasureOutcomeEvent(string2, n, oSOutcomeEventParams, oneSignalApiResponseHandler);
    }

    private void sendUniqueOutcomeEvent(String string2, List<OSInfluence> list, OneSignal.OutcomeCallback outcomeCallback) {
        boolean bl;
        List<OSInfluence> list2;
        block7 : {
            list2 = this.removeDisabledInfluences(list);
            if (list2.isEmpty()) {
                OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "Unique Outcome disabled for current session");
                return;
            }
            Iterator iterator = list2.iterator();
            do {
                boolean bl2 = iterator.hasNext();
                bl = false;
                if (!bl2) break block7;
            } while (!((OSInfluence)iterator.next()).getInfluenceType().isAttributed());
            bl = true;
        }
        if (bl) {
            List<OSInfluence> list3 = this.getUniqueIds(string2, list2);
            if (list3 == null) {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Measure endpoint will not send because unique outcome already sent for: \nSessionInfluences: ");
                stringBuilder.append(list2.toString());
                stringBuilder.append("\nOutcome name: ");
                stringBuilder.append(string2);
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                if (outcomeCallback != null) {
                    outcomeCallback.onSuccess(null);
                }
                return;
            }
            this.sendAndCreateOutcomeEvent(string2, 0.0f, list3, outcomeCallback);
            return;
        }
        if (this.unattributedUniqueOutcomeEventsSentOnSession.contains((Object)string2)) {
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Measure endpoint will not send because unique outcome already sent for: \nSession: ");
            stringBuilder.append((Object)OSInfluenceType.UNATTRIBUTED);
            stringBuilder.append("\nOutcome name: ");
            stringBuilder.append(string2);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            if (outcomeCallback != null) {
                outcomeCallback.onSuccess(null);
            }
            return;
        }
        this.unattributedUniqueOutcomeEventsSentOnSession.add((Object)string2);
        this.sendAndCreateOutcomeEvent(string2, 0.0f, list2, outcomeCallback);
    }

    private OSOutcomeSourceBody setSourceChannelIds(OSInfluence oSInfluence, OSOutcomeSourceBody oSOutcomeSourceBody) {
        int n = 5.$SwitchMap$com$onesignal$influence$model$OSInfluenceChannel[oSInfluence.getInfluenceChannel().ordinal()];
        if (n != 1) {
            if (n != 2) {
                return oSOutcomeSourceBody;
            }
            oSOutcomeSourceBody.setNotificationIds(oSInfluence.getIds());
            return oSOutcomeSourceBody;
        }
        oSOutcomeSourceBody.setInAppMessagesIds(oSInfluence.getIds());
        return oSOutcomeSourceBody;
    }

    void cleanOutcomes() {
        OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "OneSignal cleanOutcomes for session");
        this.unattributedUniqueOutcomeEventsSentOnSession = OSUtils.newConcurrentSet();
        this.saveUnattributedUniqueOutcomeEvents();
    }

    void sendClickActionOutcomes(List<OSInAppMessageOutcome> list) {
        for (OSInAppMessageOutcome oSInAppMessageOutcome : list) {
            String string2 = oSInAppMessageOutcome.getName();
            if (oSInAppMessageOutcome.isUnique()) {
                this.sendUniqueOutcomeEvent(string2, null);
                continue;
            }
            if (oSInAppMessageOutcome.getWeight() > 0.0f) {
                this.sendOutcomeEventWithValue(string2, oSInAppMessageOutcome.getWeight(), null);
                continue;
            }
            this.sendOutcomeEvent(string2, null);
        }
    }

    void sendOutcomeEvent(String string2, OneSignal.OutcomeCallback outcomeCallback) {
        this.sendAndCreateOutcomeEvent(string2, 0.0f, this.osSessionManager.getInfluences(), outcomeCallback);
    }

    void sendOutcomeEventWithValue(String string2, float f, OneSignal.OutcomeCallback outcomeCallback) {
        this.sendAndCreateOutcomeEvent(string2, f, this.osSessionManager.getInfluences(), outcomeCallback);
    }

    void sendSavedOutcomes() {
        new Thread(new Runnable(){

            public void run() {
                Thread.currentThread().setPriority(10);
                for (OSOutcomeEventParams oSOutcomeEventParams : OSOutcomeEventsController.this.outcomeEventsFactory.getRepository().getSavedOutcomeEvents()) {
                    OSOutcomeEventsController.this.sendSavedOutcomeEvent(oSOutcomeEventParams);
                }
            }
        }, OS_SEND_SAVED_OUTCOMES).start();
    }

    void sendUniqueOutcomeEvent(String string2, OneSignal.OutcomeCallback outcomeCallback) {
        this.sendUniqueOutcomeEvent(string2, this.osSessionManager.getInfluences(), outcomeCallback);
    }

}

