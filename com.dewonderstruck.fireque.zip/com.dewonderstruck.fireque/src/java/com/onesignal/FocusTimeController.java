/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.SystemClock
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  java.util.concurrent.atomic.AtomicBoolean
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.content.Context;
import android.os.SystemClock;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalPrefs;
import com.onesignal.OneSignalRestClient;
import com.onesignal.OneSignalSyncServiceUtils;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.influence.model.OSInfluenceType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

class FocusTimeController {
    private static FocusTimeController sInstance;
    private List<FocusTimeProcessorBase> focusTimeProcessors;
    private Long timeFocusedAtMs;

    private FocusTimeController() {
        Object[] arrobject = new FocusTimeProcessorBase[]{new FocusTimeProcessorUnattributed(), new FocusTimeProcessorAttributed()};
        this.focusTimeProcessors = Arrays.asList((Object[])arrobject);
    }

    public static FocusTimeController getInstance() {
        Class<FocusTimeController> class_ = FocusTimeController.class;
        synchronized (FocusTimeController.class) {
            if (sInstance == null) {
                sInstance = new FocusTimeController();
            }
            FocusTimeController focusTimeController = sInstance;
            // ** MonitorExit[var2] (shouldn't be in output)
            return focusTimeController;
        }
    }

    private Long getTimeFocusedElapsed() {
        if (this.timeFocusedAtMs == null) {
            return null;
        }
        long l = (long)(0.5 + (double)(SystemClock.elapsedRealtime() - this.timeFocusedAtMs) / 1000.0);
        if (l >= 1L) {
            if (l > 86400L) {
                return null;
            }
            return l;
        }
        return null;
    }

    private boolean giveProcessorsValidFocusTime(List<OSInfluence> list, FocusEventType focusEventType) {
        Long l = this.getTimeFocusedElapsed();
        if (l == null) {
            return false;
        }
        Iterator iterator = this.focusTimeProcessors.iterator();
        while (iterator.hasNext()) {
            ((FocusTimeProcessorBase)iterator.next()).addTime(l, (List<OSInfluence>)list, focusEventType);
        }
        return true;
    }

    void appBackgrounded() {
        this.giveProcessorsValidFocusTime(OneSignal.getSessionManager().getSessionInfluences(), FocusEventType.BACKGROUND);
        this.timeFocusedAtMs = null;
    }

    void appForegrounded() {
        this.timeFocusedAtMs = SystemClock.elapsedRealtime();
    }

    void doBlockingBackgroundSyncOfUnsentTime() {
        if (OneSignal.isForeground()) {
            return;
        }
        Iterator iterator = this.focusTimeProcessors.iterator();
        while (iterator.hasNext()) {
            ((FocusTimeProcessorBase)iterator.next()).syncUnsentTimeFromSyncJob();
        }
    }

    void onSessionEnded(List<OSInfluence> list) {
        FocusEventType focusEventType = FocusEventType.END_SESSION;
        if (!this.giveProcessorsValidFocusTime(list, focusEventType)) {
            Iterator iterator = this.focusTimeProcessors.iterator();
            while (iterator.hasNext()) {
                ((FocusTimeProcessorBase)iterator.next()).sendUnsentTimeNow(focusEventType);
            }
        }
    }

    private static final class FocusEventType
    extends Enum<FocusEventType> {
        private static final /* synthetic */ FocusEventType[] $VALUES;
        public static final /* enum */ FocusEventType BACKGROUND;
        public static final /* enum */ FocusEventType END_SESSION;

        static {
            FocusEventType focusEventType;
            FocusEventType focusEventType2;
            BACKGROUND = focusEventType = new FocusEventType();
            END_SESSION = focusEventType2 = new FocusEventType();
            $VALUES = new FocusEventType[]{focusEventType, focusEventType2};
        }

        public static FocusEventType valueOf(String string) {
            return (FocusEventType)Enum.valueOf(FocusEventType.class, (String)string);
        }

        public static FocusEventType[] values() {
            return (FocusEventType[])$VALUES.clone();
        }
    }

    private static class FocusTimeProcessorAttributed
    extends FocusTimeProcessorBase {
        FocusTimeProcessorAttributed() {
            super();
            this.MIN_ON_FOCUS_TIME_SEC = 1L;
            this.PREF_KEY_FOR_UNSENT_TIME = "OS_UNSENT_ATTRIBUTED_ACTIVE_TIME";
        }

        private List<OSInfluence> getInfluences() {
            ArrayList arrayList = new ArrayList();
            for (String string : OneSignalPrefs.getStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_ATTRIBUTED_INFLUENCES", (Set<String>)new HashSet())) {
                try {
                    arrayList.add((Object)new OSInfluence(string));
                }
                catch (JSONException jSONException) {
                    OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(this.getClass().getSimpleName());
                    stringBuilder.append(": error generation OSInfluence from json object: ");
                    stringBuilder.append((Object)jSONException);
                    OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                }
            }
            return arrayList;
        }

        @Override
        protected void additionalFieldsToAddToOnFocusPayload(JSONObject jSONObject) {
            OneSignal.getSessionManager().addSessionIds(jSONObject, this.getInfluences());
        }

        @Override
        protected void saveInfluences(List<OSInfluence> list) {
            HashSet hashSet = new HashSet();
            for (OSInfluence oSInfluence : list) {
                try {
                    hashSet.add((Object)oSInfluence.toJSONString());
                }
                catch (JSONException jSONException) {
                    OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.ERROR;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(this.getClass().getSimpleName());
                    stringBuilder.append(": error generation json object OSInfluence: ");
                    stringBuilder.append((Object)jSONException);
                    OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                }
            }
            OneSignalPrefs.saveStringSet(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_ATTRIBUTED_INFLUENCES", (Set<String>)hashSet);
        }

        @Override
        protected void sendTime(FocusEventType focusEventType) {
            if (focusEventType.equals((Object)FocusEventType.END_SESSION)) {
                this.syncOnFocusTime();
                return;
            }
            OneSignalSyncServiceUtils.scheduleSyncTask(OneSignal.appContext);
        }

        @Override
        protected boolean timeTypeApplies(List<OSInfluence> list) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                if (!((OSInfluence)iterator.next()).getInfluenceType().isAttributed()) continue;
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(this.getClass().getSimpleName());
                stringBuilder.append(":timeTypeApplies for influences: ");
                stringBuilder.append(list.toString());
                stringBuilder.append(" true");
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                return true;
            }
            return false;
        }
    }

    private static abstract class FocusTimeProcessorBase {
        protected long MIN_ON_FOCUS_TIME_SEC;
        protected String PREF_KEY_FOR_UNSENT_TIME;
        private final AtomicBoolean runningOnFocusTime = new AtomicBoolean();
        private Long unsentActiveTime = null;

        private FocusTimeProcessorBase() {
        }

        private void addTime(long l, List<OSInfluence> list, FocusEventType focusEventType) {
            if (!this.timeTypeApplies(list)) {
                return;
            }
            this.saveInfluences(list);
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.getClass().getSimpleName());
            stringBuilder.append(":addTime with lastFocusTimeInfluences: ");
            stringBuilder.append(list.toString());
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            this.saveUnsentActiveTime(l + this.getUnsentActiveTime());
            this.sendUnsentTimeNow(focusEventType);
        }

        private JSONObject generateOnFocusPayload(long l) throws JSONException {
            JSONObject jSONObject = new JSONObject().put("app_id", (Object)OneSignal.getSavedAppId()).put("type", 1).put("state", (Object)"ping").put("active_time", l).put("device_type", new OSUtils().getDeviceType());
            OneSignal.addNetType(jSONObject);
            return jSONObject;
        }

        private long getUnsentActiveTime() {
            if (this.unsentActiveTime == null) {
                this.unsentActiveTime = OneSignalPrefs.getLong(OneSignalPrefs.PREFS_ONESIGNAL, this.PREF_KEY_FOR_UNSENT_TIME, 0L);
            }
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.getClass().getSimpleName());
            stringBuilder.append(":getUnsentActiveTime: ");
            stringBuilder.append((Object)this.unsentActiveTime);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            return this.unsentActiveTime;
        }

        private boolean hasMinSyncTime() {
            return this.getUnsentActiveTime() >= this.MIN_ON_FOCUS_TIME_SEC;
        }

        private void saveUnsentActiveTime(long l) {
            this.unsentActiveTime = l;
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.getClass().getSimpleName());
            stringBuilder.append(":saveUnsentActiveTime: ");
            stringBuilder.append((Object)this.unsentActiveTime);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            OneSignalPrefs.saveLong(OneSignalPrefs.PREFS_ONESIGNAL, this.PREF_KEY_FOR_UNSENT_TIME, l);
        }

        private void sendOnFocus(long l) {
            try {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(this.getClass().getSimpleName());
                stringBuilder.append(":sendOnFocus with totalTimeActive: ");
                stringBuilder.append(l);
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                JSONObject jSONObject = this.generateOnFocusPayload(l);
                this.additionalFieldsToAddToOnFocusPayload(jSONObject);
                this.sendOnFocusToPlayer(OneSignal.getUserId(), jSONObject);
                if (OneSignal.hasEmailId()) {
                    this.sendOnFocusToPlayer(OneSignal.getEmailId(), this.generateOnFocusPayload(l));
                }
                return;
            }
            catch (JSONException jSONException) {
                OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Generating on_focus:JSON Failed.", jSONException);
                return;
            }
        }

        private void sendOnFocusToPlayer(String string, JSONObject jSONObject) {
            OneSignalRestClient.ResponseHandler responseHandler = new OneSignalRestClient.ResponseHandler(){

                @Override
                void onFailure(int n, String string, Throwable throwable) {
                    OneSignal.logHttpError("sending on_focus Failed", n, throwable, string);
                }

                @Override
                void onSuccess(String string) {
                    FocusTimeProcessorBase.this.saveUnsentActiveTime(0L);
                }
            };
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("players/");
            stringBuilder.append(string);
            stringBuilder.append("/on_focus");
            OneSignalRestClient.postSync(stringBuilder.toString(), jSONObject, responseHandler);
        }

        private void sendUnsentTimeNow(FocusEventType focusEventType) {
            if (!OneSignal.hasUserId()) {
                return;
            }
            this.sendTime(focusEventType);
        }

        private void syncUnsentTimeFromSyncJob() {
            if (this.hasMinSyncTime()) {
                this.syncOnFocusTime();
            }
        }

        protected void additionalFieldsToAddToOnFocusPayload(JSONObject jSONObject) {
        }

        protected abstract void saveInfluences(List<OSInfluence> var1);

        protected abstract void sendTime(FocusEventType var1);

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected void syncOnFocusTime() {
            AtomicBoolean atomicBoolean;
            if (this.runningOnFocusTime.get()) {
                return;
            }
            AtomicBoolean atomicBoolean2 = atomicBoolean = this.runningOnFocusTime;
            synchronized (atomicBoolean2) {
                this.runningOnFocusTime.set(true);
                if (this.hasMinSyncTime()) {
                    this.sendOnFocus(this.getUnsentActiveTime());
                }
                this.runningOnFocusTime.set(false);
                return;
            }
        }

        protected void syncUnsentTimeOnBackgroundEvent() {
            if (!this.hasMinSyncTime()) {
                return;
            }
            OneSignalSyncServiceUtils.scheduleSyncTask(OneSignal.appContext);
            this.syncOnFocusTime();
        }

        protected abstract boolean timeTypeApplies(List<OSInfluence> var1);

    }

    private static class FocusTimeProcessorUnattributed
    extends FocusTimeProcessorBase {
        FocusTimeProcessorUnattributed() {
            this.MIN_ON_FOCUS_TIME_SEC = 60L;
            this.PREF_KEY_FOR_UNSENT_TIME = "GT_UNSENT_ACTIVE_TIME";
        }

        @Override
        protected void saveInfluences(List<OSInfluence> list) {
        }

        @Override
        protected void sendTime(FocusEventType focusEventType) {
            if (focusEventType.equals((Object)FocusEventType.END_SESSION)) {
                return;
            }
            this.syncUnsentTimeOnBackgroundEvent();
        }

        @Override
        protected boolean timeTypeApplies(List<OSInfluence> list) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                if (!((OSInfluence)iterator.next()).getInfluenceType().isAttributed()) continue;
                return false;
            }
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.getClass().getSimpleName());
            stringBuilder.append(":timeTypeApplies for influences: ");
            stringBuilder.append(list.toString());
            stringBuilder.append(" true");
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            return true;
        }
    }

}

