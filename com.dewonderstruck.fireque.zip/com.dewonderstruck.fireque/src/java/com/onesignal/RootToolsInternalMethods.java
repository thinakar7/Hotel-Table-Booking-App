/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.onesignal;

import java.io.File;

class RootToolsInternalMethods {
    RootToolsInternalMethods() {
    }

    static boolean isRooted() {
        int n;
        String[] arrstring = new String[]{"/sbin/", "/system/bin/", "/system/xbin/", "/data/local/xbin/", "/data/local/bin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/"};
        try {
            n = arrstring.length;
        }
        catch (Throwable throwable) {
            return false;
        }
        for (int i = 0; i < n; ++i) {
            String string2 = arrstring[i];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append("su");
            boolean bl = new File(stringBuilder.toString()).exists();
            if (!bl) continue;
            return true;
        }
        return false;
    }
}

