/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.onesignal;

import com.onesignal.UserState;

class UserStateEmail
extends UserState {
    UserStateEmail(String string2, boolean bl) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("email");
        stringBuilder.append(string2);
        super(stringBuilder.toString(), bl);
    }

    @Override
    protected void addDependFields() {
    }

    @Override
    boolean isSubscribed() {
        return true;
    }

    @Override
    UserState newInstance(String string2) {
        return new UserStateEmail(string2, false);
    }
}

