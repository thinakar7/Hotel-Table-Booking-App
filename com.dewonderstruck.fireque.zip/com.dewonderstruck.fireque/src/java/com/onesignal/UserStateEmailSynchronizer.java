/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Set
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import com.onesignal.ImmutableJSONObject;
import com.onesignal.OSEmailSubscriptionState;
import com.onesignal.OSPermissionSubscriptionState;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalStateSynchronizer;
import com.onesignal.UserState;
import com.onesignal.UserStateEmail;
import com.onesignal.UserStateSynchronizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

class UserStateEmailSynchronizer
extends UserStateSynchronizer {
    UserStateEmailSynchronizer() {
        super(OneSignalStateSynchronizer.UserStateSynchronizerType.EMAIL);
    }

    @Override
    protected void addOnSessionOrCreateExtras(JSONObject jSONObject) {
        try {
            jSONObject.put("device_type", 11);
            jSONObject.putOpt("device_player_id", (Object)OneSignal.getUserId());
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    @Override
    protected void fireEventsForUpdateFailure(JSONObject jSONObject) {
        if (jSONObject.has("identifier")) {
            OneSignal.fireEmailUpdateFailure();
        }
    }

    @Override
    String getExternalId(boolean bl) {
        return null;
    }

    @Override
    protected String getId() {
        return OneSignal.getEmailId();
    }

    @Override
    protected OneSignal.LOG_LEVEL getLogLevel() {
        return OneSignal.LOG_LEVEL.INFO;
    }

    @Override
    boolean getSubscribed() {
        return false;
    }

    @Override
    UserStateSynchronizer.GetTagsResult getTags(boolean bl) {
        return null;
    }

    @Override
    public boolean getUserSubscribePreference() {
        return false;
    }

    @Override
    void logoutEmail() {
        OneSignal.saveEmailId("");
        this.resetCurrentState();
        this.getToSyncUserState().removeFromSyncValues("identifier");
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)"email_auth_hash");
        arrayList.add((Object)"device_player_id");
        arrayList.add((Object)"external_user_id");
        this.toSyncUserState.removeFromSyncValues((List<String>)arrayList);
        this.toSyncUserState.persistState();
        OneSignal.getPermissionSubscriptionState().emailSubscriptionStatus.clearEmailAndId();
    }

    @Override
    protected UserState newUserState(String string2, boolean bl) {
        return new UserStateEmail(string2, bl);
    }

    @Override
    protected void onSuccessfulSync(JSONObject jSONObject) {
        if (jSONObject.has("identifier")) {
            OneSignal.fireEmailUpdateSuccess();
        }
    }

    void refresh() {
        this.scheduleSyncToServer();
    }

    @Override
    protected void scheduleSyncToServer() {
        boolean bl = this.getId() == null && this.getRegistrationId() == null;
        if (!bl) {
            if (OneSignal.getUserId() == null) {
                return;
            }
            this.getNetworkHandlerThread(0).runNewJobDelayed();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void setEmail(String string2, String string3) {
        String string4;
        String string5;
        UserState userState = this.getUserStateForModification();
        ImmutableJSONObject immutableJSONObject = userState.getSyncValues();
        boolean bl = string2.equals((Object)immutableJSONObject.optString("identifier")) && (string4 = immutableJSONObject.optString("email_auth_hash")).equals((Object)(string5 = string3 == null ? "" : string3));
        if (bl) {
            OneSignal.fireEmailUpdateSuccess();
            return;
        }
        String string6 = immutableJSONObject.optString("identifier", null);
        if (string6 == null) {
            this.setNewSession();
        }
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("identifier", (Object)string2);
            if (string3 != null) {
                jSONObject.put("email_auth_hash", (Object)string3);
            }
            if (string3 == null && string6 != null && !string6.equals((Object)string2)) {
                OneSignal.saveEmailId("");
                this.resetCurrentState();
                this.setNewSession();
            }
            userState.generateJsonDiffFromIntoSyncValued(jSONObject, null);
            this.scheduleSyncToServer();
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    @Override
    public void setPermission(boolean bl) {
    }

    @Override
    void setSubscription(boolean bl) {
    }

    @Override
    void updateIdDependents(String string2) {
        OneSignal.updateEmailIdDependents(string2);
    }

    @Override
    void updateState(JSONObject jSONObject) {
    }
}

