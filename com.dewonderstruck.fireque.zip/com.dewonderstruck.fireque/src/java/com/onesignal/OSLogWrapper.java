/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.onesignal;

import com.onesignal.OSLogger;
import com.onesignal.OneSignal;

class OSLogWrapper
implements OSLogger {
    OSLogWrapper() {
    }

    @Override
    public void debug(String string2) {
        OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, string2);
    }

    @Override
    public void error(String string2, Throwable throwable) {
        OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, string2, throwable);
    }

    @Override
    public void verbose(String string2) {
        OneSignal.Log(OneSignal.LOG_LEVEL.VERBOSE, string2);
    }

    @Override
    public void warning(String string2) {
        OneSignal.Log(OneSignal.LOG_LEVEL.WARN, string2);
    }
}

