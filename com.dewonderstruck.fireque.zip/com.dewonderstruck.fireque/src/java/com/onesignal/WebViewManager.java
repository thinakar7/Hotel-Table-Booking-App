/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.graphics.Paint
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Base64
 *  android.webkit.JavascriptInterface
 *  android.webkit.ValueCallback
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  java.io.UnsupportedEncodingException
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.onesignal.ActivityLifecycleHandler;
import com.onesignal.ActivityLifecycleListener;
import com.onesignal.InAppMessageView;
import com.onesignal.OSInAppMessage;
import com.onesignal.OSUtils;
import com.onesignal.OSViewUtils;
import com.onesignal.OSWebView;
import com.onesignal.OneSignal;
import java.io.UnsupportedEncodingException;
import org.json.JSONException;
import org.json.JSONObject;

class WebViewManager
extends ActivityLifecycleHandler.ActivityAvailableListener {
    private static final int IN_APP_MESSAGE_INIT_DELAY = 200;
    private static final int MARGIN_PX_SIZE;
    private static final String TAG;
    protected static WebViewManager lastInstance;
    private Activity activity;
    private String currentActivityName = null;
    private Integer lastPageHeight = null;
    private OSInAppMessage message;
    private InAppMessageView messageView;
    private OSWebView webView;

    static {
        TAG = WebViewManager.class.getCanonicalName();
        MARGIN_PX_SIZE = OSViewUtils.dpToPx(24);
        lastInstance = null;
    }

    protected WebViewManager(OSInAppMessage oSInAppMessage, Activity activity) {
        this.message = oSInAppMessage;
        this.activity = activity;
    }

    private void blurryRenderingWebViewForKitKatWorkAround(WebView webView) {
        if (Build.VERSION.SDK_INT == 19) {
            webView.setLayerType(1, null);
        }
    }

    private void calculateHeightAndShowWebViewAfterNewActivity() {
        InAppMessageView inAppMessageView = this.messageView;
        if (inAppMessageView == null) {
            return;
        }
        if (inAppMessageView.getDisplayPosition() == Position.FULL_SCREEN) {
            this.showMessageView(null);
            return;
        }
        OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "In app message new activity, calculate height and show ");
        OSViewUtils.decorViewReady(this.activity, new Runnable(){

            public void run() {
                WebViewManager webViewManager = WebViewManager.this;
                webViewManager.setWebViewToMaxSize(webViewManager.activity);
                WebViewManager.this.webView.evaluateJavascript("getPageMetaData()", (ValueCallback)new ValueCallback<String>(){

                    public void onReceiveValue(String string2) {
                        try {
                            int n = WebViewManager.pageRectToViewHeight(WebViewManager.this.activity, new JSONObject(string2));
                            WebViewManager.this.showMessageView(n);
                            return;
                        }
                        catch (JSONException jSONException) {
                            jSONException.printStackTrace();
                            return;
                        }
                    }
                });
            }

        });
    }

    private void createNewInAppMessageView(Position position, int n, boolean bl) {
        InAppMessageView inAppMessageView;
        this.lastPageHeight = n;
        this.messageView = inAppMessageView = new InAppMessageView(this.webView, position, n, this.message.getDisplayDuration());
        inAppMessageView.setMessageController(new InAppMessageView.InAppMessageViewListener(){

            @Override
            public void onMessageWasDismissed() {
                OneSignal.getInAppMessageController().messageWasDismissed(WebViewManager.this.message);
                WebViewManager.this.removeActivityListener();
            }

            @Override
            public void onMessageWasShown() {
                OneSignal.getInAppMessageController().onMessageWasShown(WebViewManager.this.message);
            }
        });
        ActivityLifecycleHandler activityLifecycleHandler = ActivityLifecycleListener.getActivityLifecycleHandler();
        if (activityLifecycleHandler != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(TAG);
            stringBuilder.append(this.message.messageId);
            activityLifecycleHandler.addActivityAvailableListener(stringBuilder.toString(), this);
        }
    }

    static void dismissCurrentInAppMessage() {
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WebViewManager IAM dismissAndAwaitNextMessage lastInstance: ");
        stringBuilder.append((Object)lastInstance);
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        WebViewManager webViewManager = lastInstance;
        if (webViewManager != null) {
            webViewManager.dismissAndAwaitNextMessage(null);
        }
    }

    private static void enableWebViewRemoteDebugging() {
        if (Build.VERSION.SDK_INT >= 19 && OneSignal.atLogLevel(OneSignal.LOG_LEVEL.DEBUG)) {
            WebView.setWebContentsDebuggingEnabled((boolean)true);
        }
    }

    private static int getWebViewMaxSizeX(Activity activity) {
        return OSViewUtils.getWindowWidth(activity) - 2 * MARGIN_PX_SIZE;
    }

    private static int getWebViewMaxSizeY(Activity activity) {
        return OSViewUtils.getWindowHeight(activity) - 2 * MARGIN_PX_SIZE;
    }

    private static void initInAppMessage(final Activity activity, OSInAppMessage oSInAppMessage, String string2) {
        try {
            WebViewManager webViewManager;
            final String string3 = Base64.encodeToString((byte[])string2.getBytes("UTF-8"), (int)2);
            lastInstance = webViewManager = new WebViewManager(oSInAppMessage, activity);
            OSUtils.runOnMainUIThread(new Runnable(){

                public void run() {
                    webViewManager.setupWebView(activity, string3);
                }
            });
            return;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Catch on initInAppMessage: ", unsupportedEncodingException);
            unsupportedEncodingException.printStackTrace();
            return;
        }
    }

    private static int pageRectToViewHeight(Activity activity, JSONObject jSONObject) {
        int n;
        block3 : {
            int n2;
            try {
                n = OSViewUtils.dpToPx(jSONObject.getJSONObject("rect").getInt("height"));
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("getPageHeightData:pxHeight: ");
                stringBuilder.append(n);
                OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
                n2 = WebViewManager.getWebViewMaxSizeY(activity);
                if (n <= n2) break block3;
                n = n2;
            }
            catch (JSONException jSONException) {
                OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "pageRectToViewHeight could not get page height", jSONException);
                return -1;
            }
            OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("getPageHeightData:pxHeight is over screen max: ");
            stringBuilder.append(n2);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        }
        return n;
    }

    private void removeActivityListener() {
        ActivityLifecycleHandler activityLifecycleHandler = ActivityLifecycleListener.getActivityLifecycleHandler();
        if (activityLifecycleHandler != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(TAG);
            stringBuilder.append(this.message.messageId);
            activityLifecycleHandler.removeActivityAvailableListener(stringBuilder.toString());
        }
    }

    private void setWebViewToMaxSize(Activity activity) {
        this.webView.layout(0, 0, WebViewManager.getWebViewMaxSizeX(activity), WebViewManager.getWebViewMaxSizeY(activity));
    }

    private void setupWebView(final Activity activity, final String string2) {
        OSWebView oSWebView;
        WebViewManager.enableWebViewRemoteDebugging();
        this.webView = oSWebView = new OSWebView((Context)activity);
        oSWebView.setOverScrollMode(2);
        this.webView.setVerticalScrollBarEnabled(false);
        this.webView.setHorizontalScrollBarEnabled(false);
        this.webView.getSettings().setJavaScriptEnabled(true);
        this.webView.addJavascriptInterface((Object)new OSJavaScriptInterface(), "OSAndroid");
        this.blurryRenderingWebViewForKitKatWorkAround(this.webView);
        OSViewUtils.decorViewReady(activity, new Runnable(){

            public void run() {
                WebViewManager.this.setWebViewToMaxSize(activity);
                WebViewManager.this.webView.loadData(string2, "text/html; charset=utf-8", "base64");
            }
        });
    }

    static void showHTMLString(final OSInAppMessage oSInAppMessage, final String string2) {
        final Activity activity = OneSignal.getCurrentActivity();
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("in app message showHTMLString on currentActivity: ");
        stringBuilder.append((Object)activity);
        OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
        if (activity != null) {
            if (lastInstance != null && oSInAppMessage.isPreview) {
                lastInstance.dismissAndAwaitNextMessage(new OneSignalGenericCallback(){

                    @Override
                    public void onComplete() {
                        WebViewManager.lastInstance = null;
                        WebViewManager.initInAppMessage(activity, oSInAppMessage, string2);
                    }
                });
                return;
            }
            WebViewManager.initInAppMessage(activity, oSInAppMessage, string2);
            return;
        }
        Looper.prepare();
        new Handler().postDelayed(new Runnable(){

            public void run() {
                WebViewManager.showHTMLString(oSInAppMessage, string2);
            }
        }, 200L);
    }

    private void showMessageView(Integer n) {
        if (this.messageView == null) {
            OneSignal.Log(OneSignal.LOG_LEVEL.WARN, "No messageView found to update a with a new height.");
            return;
        }
        OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("In app message, showing first one with height: ");
        stringBuilder.append((Object)n);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        this.messageView.setWebView(this.webView);
        if (n != null) {
            this.lastPageHeight = n;
            this.messageView.updateHeight(n);
        }
        this.messageView.showView(this.activity);
        this.messageView.checkIfShouldDismiss();
    }

    @Override
    void available(Activity activity) {
        String string2;
        String string3 = this.currentActivityName;
        this.activity = activity;
        this.currentActivityName = string2 = activity.getLocalClassName();
        if (string3 == null) {
            this.showMessageView(null);
            return;
        }
        if (!string3.equals((Object)string2)) {
            InAppMessageView inAppMessageView = this.messageView;
            if (inAppMessageView != null) {
                inAppMessageView.removeAllViews();
            }
            this.showMessageView(this.lastPageHeight);
            return;
        }
        this.calculateHeightAndShowWebViewAfterNewActivity();
    }

    protected void dismissAndAwaitNextMessage(final OneSignalGenericCallback oneSignalGenericCallback) {
        InAppMessageView inAppMessageView = this.messageView;
        if (inAppMessageView == null) {
            if (oneSignalGenericCallback != null) {
                oneSignalGenericCallback.onComplete();
            }
            return;
        }
        inAppMessageView.dismissAndAwaitNextMessage(new OneSignalGenericCallback(){

            @Override
            public void onComplete() {
                WebViewManager.this.messageView = null;
                OneSignalGenericCallback oneSignalGenericCallback2 = oneSignalGenericCallback;
                if (oneSignalGenericCallback2 != null) {
                    oneSignalGenericCallback2.onComplete();
                }
            }
        });
    }

    @Override
    void lostFocus() {
        OneSignal.getInAppMessageController().messageWasDismissedByBackPress(this.message);
        this.removeActivityListener();
        this.messageView = null;
    }

    @Override
    void stopped(Activity activity) {
        OneSignal.Log(OneSignal.LOG_LEVEL.DEBUG, "In app message activity stopped, cleaning views");
        if (this.messageView != null && this.currentActivityName.equals((Object)activity.getLocalClassName())) {
            this.messageView.removeAllViews();
        }
    }

    class OSJavaScriptInterface {
        static final String EVENT_TYPE_ACTION_TAKEN = "action_taken";
        static final String EVENT_TYPE_KEY = "type";
        static final String EVENT_TYPE_RENDERING_COMPLETE = "rendering_complete";
        static final String GET_PAGE_META_DATA_JS_FUNCTION = "getPageMetaData()";
        static final String IAM_DISPLAY_LOCATION_KEY = "displayLocation";
        static final String IAM_DRAG_TO_DISMISS_DISABLED_KEY = "dragToDismissDisabled";
        static final String IAM_PAGE_META_DATA_KEY = "pageMetaData";
        static final String JS_OBJ_NAME = "OSAndroid";

        OSJavaScriptInterface() {
        }

        private Position getDisplayLocation(JSONObject jSONObject) {
            Position position = Position.FULL_SCREEN;
            try {
                if (jSONObject.has(IAM_DISPLAY_LOCATION_KEY) && !jSONObject.get(IAM_DISPLAY_LOCATION_KEY).equals((Object)"")) {
                    Position position2;
                    position = position2 = Position.valueOf(jSONObject.optString(IAM_DISPLAY_LOCATION_KEY, "FULL_SCREEN").toUpperCase());
                }
                return position;
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
                return position;
            }
        }

        private boolean getDragToDismissDisabled(JSONObject jSONObject) {
            try {
                boolean bl = jSONObject.getBoolean(IAM_DRAG_TO_DISMISS_DISABLED_KEY);
                return bl;
            }
            catch (JSONException jSONException) {
                return false;
            }
        }

        private int getPageHeightData(JSONObject jSONObject) {
            try {
                int n = WebViewManager.pageRectToViewHeight(WebViewManager.this.activity, jSONObject.getJSONObject(IAM_PAGE_META_DATA_KEY));
                return n;
            }
            catch (JSONException jSONException) {
                return -1;
            }
        }

        private void handleActionTaken(JSONObject jSONObject) throws JSONException {
            JSONObject jSONObject2 = jSONObject.getJSONObject("body");
            String string2 = jSONObject2.optString("id", null);
            if (WebViewManager.access$600((WebViewManager)WebViewManager.this).isPreview) {
                OneSignal.getInAppMessageController().onMessageActionOccurredOnPreview(WebViewManager.this.message, jSONObject2);
            } else if (string2 != null) {
                OneSignal.getInAppMessageController().onMessageActionOccurredOnMessage(WebViewManager.this.message, jSONObject2);
            }
            if (jSONObject2.getBoolean("close")) {
                WebViewManager.this.dismissAndAwaitNextMessage(null);
            }
        }

        private void handleRenderComplete(JSONObject jSONObject) {
            Position position = this.getDisplayLocation(jSONObject);
            int n = position == Position.FULL_SCREEN ? -1 : this.getPageHeightData(jSONObject);
            boolean bl = this.getDragToDismissDisabled(jSONObject);
            WebViewManager.this.createNewInAppMessageView(position, n, bl);
        }

        @JavascriptInterface
        public void postMessage(String string2) {
            try {
                OneSignal.LOG_LEVEL lOG_LEVEL = OneSignal.LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("OSJavaScriptInterface:postMessage: ");
                stringBuilder.append(string2);
                OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
                JSONObject jSONObject = new JSONObject(string2);
                String string3 = jSONObject.getString(EVENT_TYPE_KEY);
                if (string3.equals((Object)EVENT_TYPE_RENDERING_COMPLETE)) {
                    this.handleRenderComplete(jSONObject);
                } else if (string3.equals((Object)EVENT_TYPE_ACTION_TAKEN) && !WebViewManager.this.messageView.isDragging()) {
                    this.handleActionTaken(jSONObject);
                }
                return;
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
                return;
            }
        }
    }

    static interface OneSignalGenericCallback {
        public void onComplete();
    }

    static final class Position
    extends Enum<Position> {
        private static final /* synthetic */ Position[] $VALUES;
        public static final /* enum */ Position BOTTOM_BANNER;
        public static final /* enum */ Position CENTER_MODAL;
        public static final /* enum */ Position FULL_SCREEN;
        public static final /* enum */ Position TOP_BANNER;

        static {
            Position position;
            Position position2;
            Position position3;
            Position position4;
            TOP_BANNER = position = new Position();
            BOTTOM_BANNER = position2 = new Position();
            CENTER_MODAL = position3 = new Position();
            FULL_SCREEN = position4 = new Position();
            $VALUES = new Position[]{position, position2, position3, position4};
        }

        public static Position valueOf(String string2) {
            return (Position)Enum.valueOf(Position.class, (String)string2);
        }

        public static Position[] values() {
            return (Position[])$VALUES.clone();
        }

        boolean isBanner() {
            int n = 8.$SwitchMap$com$onesignal$WebViewManager$Position[this.ordinal()];
            return n == 1 || n == 2;
        }
    }

}

