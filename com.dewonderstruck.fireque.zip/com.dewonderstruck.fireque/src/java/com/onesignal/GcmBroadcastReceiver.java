/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  androidx.legacy.content.WakefulBroadcastReceiver
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.legacy.content.WakefulBroadcastReceiver;
import com.onesignal.BundleCompat;
import com.onesignal.BundleCompatBundle;
import com.onesignal.BundleCompatFactory;
import com.onesignal.GcmIntentJobService;
import com.onesignal.GcmIntentService;
import com.onesignal.NotificationBundleProcessor;
import com.onesignal.OneSignal;

public class GcmBroadcastReceiver
extends WakefulBroadcastReceiver {
    private static final String GCM_RECEIVE_ACTION = "com.google.android.c2dm.intent.RECEIVE";
    private static final String GCM_TYPE = "gcm";
    private static final String MESSAGE_TYPE_EXTRA_KEY = "message_type";

    private static boolean isGcmMessage(Intent intent) {
        block2 : {
            boolean bl;
            block4 : {
                block3 : {
                    if (!GCM_RECEIVE_ACTION.equals((Object)intent.getAction())) break block2;
                    String string = intent.getStringExtra(MESSAGE_TYPE_EXTRA_KEY);
                    if (string == null) break block3;
                    boolean bl2 = GCM_TYPE.equals((Object)string);
                    bl = false;
                    if (!bl2) break block4;
                }
                bl = true;
            }
            return bl;
        }
        return false;
    }

    private static NotificationBundleProcessor.ProcessedBundleResult processOrderBroadcast(Context context, Intent intent, Bundle bundle) {
        if (!GcmBroadcastReceiver.isGcmMessage(intent)) {
            return null;
        }
        NotificationBundleProcessor.ProcessedBundleResult processedBundleResult = NotificationBundleProcessor.processBundleFromReceiver(context, bundle);
        if (processedBundleResult.processed()) {
            return processedBundleResult;
        }
        GcmBroadcastReceiver.startGCMService(context, bundle);
        return processedBundleResult;
    }

    private void setAbort() {
        if (this.isOrderedBroadcast()) {
            this.abortBroadcast();
            this.setResultCode(-1);
        }
    }

    private static BundleCompat setCompatBundleForServer(Bundle bundle, BundleCompat bundleCompat) {
        bundleCompat.putString("json_payload", NotificationBundleProcessor.bundleAsJSONObject(bundle).toString());
        bundleCompat.putLong("timestamp", System.currentTimeMillis() / 1000L);
        return bundleCompat;
    }

    private void setSuccessfulResultCode() {
        if (this.isOrderedBroadcast()) {
            this.setResultCode(-1);
        }
    }

    static void startGCMService(Context context, Bundle bundle) {
        if (!NotificationBundleProcessor.hasRemoteResource(bundle)) {
            NotificationBundleProcessor.ProcessFromGCMIntentService(context, GcmBroadcastReceiver.setCompatBundleForServer(bundle, BundleCompatFactory.getInstance()), null);
            return;
        }
        boolean bl = Integer.parseInt((String)bundle.getString("pri", "0")) > 9;
        if (!bl && Build.VERSION.SDK_INT >= 26) {
            GcmBroadcastReceiver.startGCMServiceWithJobIntentService(context, bundle);
            return;
        }
        try {
            GcmBroadcastReceiver.startGCMServiceWithWakefulService(context, bundle);
            return;
        }
        catch (IllegalStateException illegalStateException) {
            if (Build.VERSION.SDK_INT >= 21) {
                GcmBroadcastReceiver.startGCMServiceWithJobIntentService(context, bundle);
                return;
            }
            throw illegalStateException;
        }
    }

    private static void startGCMServiceWithJobIntentService(Context context, Bundle bundle) {
        BundleCompat bundleCompat = GcmBroadcastReceiver.setCompatBundleForServer(bundle, BundleCompatFactory.getInstance());
        Intent intent = new Intent(context, GcmIntentJobService.class);
        intent.putExtra("Bundle:Parcelable:Extras", (Parcelable)bundleCompat.getBundle());
        GcmIntentJobService.enqueueWork(context, intent);
    }

    private static void startGCMServiceWithWakefulService(Context context, Bundle bundle) {
        ComponentName componentName = new ComponentName(context.getPackageName(), GcmIntentService.class.getName());
        BundleCompat bundleCompat = GcmBroadcastReceiver.setCompatBundleForServer(bundle, new BundleCompatBundle());
        GcmBroadcastReceiver.startWakefulService((Context)context, (Intent)new Intent().replaceExtras((Bundle)bundleCompat.getBundle()).setComponent(componentName));
    }

    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            if ("google.com/iid".equals((Object)bundle.getString("from"))) {
                return;
            }
            OneSignal.setAppContext(context);
            NotificationBundleProcessor.ProcessedBundleResult processedBundleResult = GcmBroadcastReceiver.processOrderBroadcast(context, intent, bundle);
            if (processedBundleResult == null) {
                this.setSuccessfulResultCode();
                return;
            }
            if (!processedBundleResult.isDup && !processedBundleResult.hasExtenderService) {
                if (processedBundleResult.isOneSignalPayload && OneSignal.getFilterOtherGCMReceivers(context)) {
                    this.setAbort();
                    return;
                }
                this.setSuccessfulResultCode();
                return;
            }
            this.setAbort();
            return;
        }
    }
}

