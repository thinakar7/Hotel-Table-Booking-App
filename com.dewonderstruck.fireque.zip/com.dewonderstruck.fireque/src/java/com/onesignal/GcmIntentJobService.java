/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  java.lang.String
 */
package com.onesignal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import com.onesignal.BundleCompat;
import com.onesignal.BundleCompatFactory;
import com.onesignal.JobIntentService;
import com.onesignal.NotificationBundleProcessor;

public class GcmIntentJobService
extends JobIntentService {
    public static final String BUNDLE_EXTRA = "Bundle:Parcelable:Extras";
    private static final int JOB_ID = 123890;

    public static void enqueueWork(Context context, Intent intent) {
        GcmIntentJobService.enqueueWork(context, GcmIntentJobService.class, 123890, intent, false);
    }

    @Override
    protected void onHandleWork(Intent intent) {
        BundleCompat bundleCompat = BundleCompatFactory.getInstance();
        bundleCompat.setBundle(intent.getExtras().getParcelable(BUNDLE_EXTRA));
        NotificationBundleProcessor.ProcessFromGCMIntentService((Context)this, bundleCompat, null);
    }
}

