/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AlarmManager
 *  android.app.PendingIntent
 *  android.app.job.JobInfo
 *  android.app.job.JobInfo$Builder
 *  android.app.job.JobScheduler
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.database.Cursor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.service.notification.StatusBarNotification
 *  android.text.TextUtils
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayList
 */
package com.onesignal;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import com.onesignal.BadgeCountUpdater;
import com.onesignal.NotificationExtenderService;
import com.onesignal.NotificationLimitManager;
import com.onesignal.NotificationRestoreService;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalDbHelper;
import com.onesignal.OneSignalNotificationManager;
import com.onesignal.RestoreJobService;
import com.onesignal.RestoreKickoffJobService;
import java.io.Serializable;
import java.util.ArrayList;

class NotificationRestorer {
    static final String[] COLUMNS_FOR_RESTORE = new String[]{"android_notification_id", "full_data", "created_time"};
    static final int DEFAULT_TTL_IF_NOT_IN_PAYLOAD = 259200;
    private static final int DELAY_BETWEEN_NOTIFICATION_RESTORES_MS = 200;
    private static final int RESTORE_KICKOFF_REQUEST_CODE = 2071862120;
    private static final int RESTORE_NOTIFICATIONS_DELAY_MS = 15000;
    public static boolean restored;

    NotificationRestorer() {
    }

    private static Intent addRestoreExtras(Intent intent, Cursor cursor) {
        int n = cursor.getInt(cursor.getColumnIndex("android_notification_id"));
        String string = cursor.getString(cursor.getColumnIndex("full_data"));
        Long l = cursor.getLong(cursor.getColumnIndex("created_time"));
        intent.putExtra("json_payload", string).putExtra("android_notif_id", n).putExtra("restoring", true).putExtra("timestamp", (Serializable)l);
        return intent;
    }

    static void asyncRestore(final Context context) {
        new Thread(new Runnable(){

            public void run() {
                Thread.currentThread().setPriority(10);
                NotificationRestorer.restore(context);
            }
        }, "OS_RESTORE_NOTIFS").start();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void queryAndRestoreNotificationsAndBadgeCount(Context var0, OneSignalDbHelper var1_1, StringBuilder var2_2) {
        var3_3 = OneSignal.LOG_LEVEL.INFO;
        var4_4 = new StringBuilder();
        var4_4.append("Querying DB for notifs to restore: ");
        var4_4.append(var2_2.toString());
        OneSignal.Log(var3_3, var4_4.toString());
        var7_5 = null;
        try {
            var7_5 = var1_1.query("notification", NotificationRestorer.COLUMNS_FOR_RESTORE, var2_2.toString(), null, null, null, "_id DESC", NotificationLimitManager.MAX_NUMBER_OF_NOTIFICATIONS_STR);
            NotificationRestorer.showNotificationsFromCursor(var0, var7_5, 200);
            BadgeCountUpdater.update(var1_1, var0);
            if (var7_5 == null) return;
        }
        catch (Throwable var8_6) {
            try {
                OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Error restoring notification records! ", var8_6);
                if (var7_5 == null) return;
            }
            catch (Throwable var9_7) {
                if (var7_5 == null) throw var9_7;
                if (var7_5.isClosed() != false) throw var9_7;
                var7_5.close();
                throw var9_7;
            }
            if (var7_5.isClosed() != false) return;
lbl22: // 2 sources:
            var7_5.close();
            return;
        }
        if (var7_5.isClosed() != false) return;
        ** GOTO lbl22
    }

    public static void restore(Context context) {
        if (!OSUtils.areNotificationsEnabled(context)) {
            return;
        }
        if (restored) {
            return;
        }
        restored = true;
        OneSignal.Log(OneSignal.LOG_LEVEL.INFO, "Restoring notifications");
        OneSignalDbHelper oneSignalDbHelper = OneSignalDbHelper.getInstance(context);
        StringBuilder stringBuilder = OneSignalDbHelper.recentUninteractedWithNotificationsWhere();
        NotificationRestorer.skipVisibleNotifications(context, stringBuilder);
        NotificationRestorer.queryAndRestoreNotificationsAndBadgeCount(context, oneSignalDbHelper, stringBuilder);
    }

    static void showNotificationsFromCursor(Context context, Cursor cursor, int n) {
        if (!cursor.moveToFirst()) {
            return;
        }
        boolean bl = NotificationExtenderService.getIntent(context) != null;
        do {
            if (bl) {
                Intent intent = NotificationExtenderService.getIntent(context);
                NotificationRestorer.addRestoreExtras(intent, cursor);
                NotificationExtenderService.enqueueWork(context, intent.getComponent(), 2071862121, intent, false);
            } else {
                Intent intent = NotificationRestorer.addRestoreExtras(new Intent(), cursor);
                RestoreJobService.enqueueWork(context, new ComponentName(context, RestoreJobService.class), 2071862122, intent, false);
            }
            if (n <= 0) continue;
            OSUtils.sleep(n);
        } while (cursor.moveToNext());
    }

    private static void skipVisibleNotifications(Context context, StringBuilder stringBuilder) {
        if (Build.VERSION.SDK_INT < 23) {
            return;
        }
        StatusBarNotification[] arrstatusBarNotification = OneSignalNotificationManager.getActiveNotifications(context);
        if (arrstatusBarNotification.length == 0) {
            return;
        }
        ArrayList arrayList = new ArrayList();
        int n = arrstatusBarNotification.length;
        for (int i = 0; i < n; ++i) {
            arrayList.add((Object)arrstatusBarNotification[i].getId());
        }
        stringBuilder.append(" AND android_notification_id NOT IN (");
        stringBuilder.append(TextUtils.join((CharSequence)",", (Iterable)arrayList));
        stringBuilder.append(")");
    }

    static void startDelayedRestoreTaskFromReceiver(Context context) {
        if (Build.VERSION.SDK_INT >= 21) {
            OneSignal.Log(OneSignal.LOG_LEVEL.INFO, "scheduleRestoreKickoffJob");
            JobInfo jobInfo = new JobInfo.Builder(2071862120, new ComponentName(context, RestoreKickoffJobService.class)).setOverrideDeadline(15000L).setMinimumLatency(15000L).build();
            ((JobScheduler)context.getSystemService("jobscheduler")).schedule(jobInfo);
            return;
        }
        OneSignal.Log(OneSignal.LOG_LEVEL.INFO, "scheduleRestoreKickoffAlarmTask");
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context.getPackageName(), NotificationRestoreService.class.getName()));
        PendingIntent pendingIntent = PendingIntent.getService((Context)context, (int)2071862120, (Intent)intent, (int)134217728);
        long l = 15000L + System.currentTimeMillis();
        ((AlarmManager)context.getSystemService("alarm")).set(1, l, pendingIntent);
    }

}

