/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.Application
 *  android.app.NotificationManager
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.database.Cursor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.text.TextUtils
 *  android.util.Log
 *  com.onesignal.OneSignal$21$1
 *  com.onesignal.PushRegistratorFCM
 *  com.onesignal.PushRegistratorGCM
 *  java.io.PrintWriter
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Deprecated
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Collection
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.TimeZone
 *  java.util.concurrent.ConcurrentLinkedQueue
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Executors
 *  java.util.concurrent.Future
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.ThreadFactory
 *  java.util.concurrent.atomic.AtomicLong
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.onesignal;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import com.onesignal.ActivityLifecycleHandler;
import com.onesignal.ActivityLifecycleListener;
import com.onesignal.AdvertisingIdProviderGPS;
import com.onesignal.AdvertisingIdentifierProvider;
import com.onesignal.BadgeCountUpdater;
import com.onesignal.DelayedConsentInitializationParameters;
import com.onesignal.FocusTimeController;
import com.onesignal.JSONUtils;
import com.onesignal.LocationController;
import com.onesignal.NotificationBundleProcessor;
import com.onesignal.NotificationChannelManager;
import com.onesignal.NotificationRestorer;
import com.onesignal.NotificationSummaryManager;
import com.onesignal.OSDevice;
import com.onesignal.OSEmailSubscriptionChangedInternalObserver;
import com.onesignal.OSEmailSubscriptionObserver;
import com.onesignal.OSEmailSubscriptionState;
import com.onesignal.OSEmailSubscriptionStateChanges;
import com.onesignal.OSInAppMessageAction;
import com.onesignal.OSInAppMessageController;
import com.onesignal.OSInAppMessageControllerFactory;
import com.onesignal.OSInAppMessageOutcome;
import com.onesignal.OSLogWrapper;
import com.onesignal.OSLogger;
import com.onesignal.OSNotification;
import com.onesignal.OSNotificationAction;
import com.onesignal.OSNotificationFormatHelper;
import com.onesignal.OSNotificationOpenResult;
import com.onesignal.OSNotificationPayload;
import com.onesignal.OSObservable;
import com.onesignal.OSOutcomeEventsController;
import com.onesignal.OSPermissionChangedInternalObserver;
import com.onesignal.OSPermissionObserver;
import com.onesignal.OSPermissionState;
import com.onesignal.OSPermissionStateChanges;
import com.onesignal.OSPermissionSubscriptionState;
import com.onesignal.OSSessionManager;
import com.onesignal.OSSharedPreferences;
import com.onesignal.OSSharedPreferencesWrapper;
import com.onesignal.OSSubscriptionChangedInternalObserver;
import com.onesignal.OSSubscriptionObserver;
import com.onesignal.OSSubscriptionState;
import com.onesignal.OSSubscriptionStateChanges;
import com.onesignal.OSUtils;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalAPIClient;
import com.onesignal.OneSignalCacheCleaner;
import com.onesignal.OneSignalChromeTabAndroidFrame;
import com.onesignal.OneSignalDb;
import com.onesignal.OneSignalDbHelper;
import com.onesignal.OneSignalNotificationManager;
import com.onesignal.OneSignalPrefs;
import com.onesignal.OneSignalRemoteParams;
import com.onesignal.OneSignalRestClient;
import com.onesignal.OneSignalRestClientWrapper;
import com.onesignal.OneSignalStateSynchronizer;
import com.onesignal.OneSignalSyncServiceUtils;
import com.onesignal.OutcomeEvent;
import com.onesignal.PushRegistrator;
import com.onesignal.PushRegistratorADM;
import com.onesignal.PushRegistratorFCM;
import com.onesignal.PushRegistratorGCM;
import com.onesignal.PushRegistratorHMS;
import com.onesignal.RootToolsInternalMethods;
import com.onesignal.TrackAmazonPurchase;
import com.onesignal.TrackFirebaseAnalytics;
import com.onesignal.TrackGooglePurchase;
import com.onesignal.UserStateSynchronizer;
import com.onesignal.influence.OSTrackerFactory;
import com.onesignal.influence.model.OSInfluence;
import com.onesignal.outcomes.OSOutcomeEventsFactory;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicLong;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class OneSignal {
    static final long MIN_ON_SESSION_TIME_MILLIS = 30000L;
    public static final String VERSION = "031507";
    private static AdvertisingIdentifierProvider adIdProvider;
    private static OneSignalAPIClient apiClient;
    static Context appContext;
    private static AppEntryAction appEntryState;
    static String appId;
    private static OSEmailSubscriptionState currentEmailSubscriptionState;
    private static OSPermissionState currentPermissionState;
    private static OSSubscriptionState currentSubscriptionState;
    static DelayedConsentInitializationParameters delayedInitParams;
    private static String emailId;
    private static EmailUpdateHandler emailLogoutHandler;
    private static OSObservable<OSEmailSubscriptionObserver, OSEmailSubscriptionStateChanges> emailSubscriptionStateChangesObserver;
    private static EmailUpdateHandler emailUpdateHandler;
    private static boolean foreground;
    private static boolean getTagsCall;
    private static IAPUpdateJob iapUpdateJob;
    private static IdsAvailableHandler idsAvailableHandler;
    private static OSInAppMessageControllerFactory inAppMessageControllerFactory;
    private static boolean inForeground;
    private static boolean initDone;
    static OSEmailSubscriptionState lastEmailSubscriptionState;
    private static LocationController.LocationPoint lastLocationPoint;
    static OSPermissionState lastPermissionState;
    private static String lastRegistrationId;
    static OSSubscriptionState lastSubscriptionState;
    static AtomicLong lastTaskId;
    private static boolean locationFired;
    private static LOG_LEVEL logCatLevel;
    private static OSLogger logger;
    private static String mGoogleProjectNumber;
    static Builder mInitBuilder;
    private static PushRegistrator mPushRegistrator;
    private static OSUtils osUtils;
    private static OSOutcomeEventsController outcomeEventsController;
    private static OSOutcomeEventsFactory outcomeEventsFactory;
    private static ArrayList<GetTagsHandler> pendingGetTagsHandlers;
    static ExecutorService pendingTaskExecutor;
    private static OSObservable<OSPermissionObserver, OSPermissionStateChanges> permissionStateChangesObserver;
    private static HashSet<String> postedOpenedNotifIds;
    private static OSSharedPreferences preferences;
    private static boolean promptedLocation;
    private static boolean registerForPushFired;
    static OneSignalRemoteParams.Params remoteParams;
    static boolean requiresUserPrivacyConsent;
    public static String sdkType;
    private static OSSessionManager.SessionListener sessionListener;
    private static OSSessionManager sessionManager;
    static boolean shareLocation;
    private static int subscribableStatus;
    private static OSObservable<OSSubscriptionObserver, OSSubscriptionStateChanges> subscriptionStateChangesObserver;
    public static ConcurrentLinkedQueue<Runnable> taskQueueWaitingForInit;
    private static TrackAmazonPurchase trackAmazonPurchase;
    private static TrackFirebaseAnalytics trackFirebaseAnalytics;
    private static TrackGooglePurchase trackGooglePurchase;
    private static OSTrackerFactory trackerFactory;
    private static Collection<JSONArray> unprocessedOpenedNotifis;
    private static OSDevice userDevice;
    private static String userId;
    private static LOG_LEVEL visualLogLevel;
    private static boolean waitingToPostStateSync;

    static {
        OSTrackerFactory oSTrackerFactory;
        visualLogLevel = LOG_LEVEL.NONE;
        logCatLevel = LOG_LEVEL.WARN;
        userId = null;
        emailId = null;
        appEntryState = AppEntryAction.APP_CLOSE;
        taskQueueWaitingForInit = new ConcurrentLinkedQueue();
        lastTaskId = new AtomicLong();
        sessionListener = new OSSessionManager.SessionListener(){

            @Override
            public void onSessionEnding(List<OSInfluence> list) {
                if (outcomeEventsController == null) {
                    OneSignal.Log(LOG_LEVEL.WARN, "OneSignal onSessionEnding called before init!");
                }
                if (outcomeEventsController != null) {
                    outcomeEventsController.cleanOutcomes();
                }
                FocusTimeController.getInstance().onSessionEnded(list);
            }
        };
        inAppMessageControllerFactory = new OSInAppMessageControllerFactory();
        logger = new OSLogWrapper();
        apiClient = new OneSignalRestClientWrapper();
        OSSharedPreferencesWrapper oSSharedPreferencesWrapper = new OSSharedPreferencesWrapper();
        preferences = oSSharedPreferencesWrapper;
        trackerFactory = oSTrackerFactory = new OSTrackerFactory(oSSharedPreferencesWrapper, logger);
        sessionManager = new OSSessionManager(sessionListener, oSTrackerFactory, logger);
        sdkType = "native";
        osUtils = new OSUtils();
        shareLocation = true;
        mInitBuilder = new Builder();
        unprocessedOpenedNotifis = new ArrayList();
        postedOpenedNotifIds = new HashSet();
        pendingGetTagsHandlers = new ArrayList();
        requiresUserPrivacyConsent = false;
    }

    static void Log(LOG_LEVEL lOG_LEVEL, String string2) {
        OneSignal.Log(lOG_LEVEL, string2, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void Log(final LOG_LEVEL lOG_LEVEL, String string2, Throwable throwable) {
        if (lOG_LEVEL.compareTo((Enum)logCatLevel) < 1) {
            if (lOG_LEVEL == LOG_LEVEL.VERBOSE) {
                Log.v((String)"OneSignal", (String)string2, (Throwable)throwable);
            } else if (lOG_LEVEL == LOG_LEVEL.DEBUG) {
                Log.d((String)"OneSignal", (String)string2, (Throwable)throwable);
            } else if (lOG_LEVEL == LOG_LEVEL.INFO) {
                Log.i((String)"OneSignal", (String)string2, (Throwable)throwable);
            } else if (lOG_LEVEL == LOG_LEVEL.WARN) {
                Log.w((String)"OneSignal", (String)string2, (Throwable)throwable);
            } else if (lOG_LEVEL == LOG_LEVEL.ERROR || lOG_LEVEL == LOG_LEVEL.FATAL) {
                Log.e((String)"OneSignal", (String)string2, (Throwable)throwable);
            }
        }
        if (lOG_LEVEL.compareTo((Enum)visualLogLevel) < 1 && OneSignal.getCurrentActivity() != null) {
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string2);
                stringBuilder.append("\n");
                final String string3 = stringBuilder.toString();
                if (throwable != null) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(string3);
                    stringBuilder2.append(throwable.getMessage());
                    String string4 = stringBuilder2.toString();
                    StringWriter stringWriter = new StringWriter();
                    throwable.printStackTrace(new PrintWriter((Writer)stringWriter));
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(string4);
                    stringBuilder3.append(stringWriter.toString());
                    string3 = stringBuilder3.toString();
                }
                OSUtils.runOnMainUIThread(new Runnable(){

                    public void run() {
                        Activity activity = OneSignal.getCurrentActivity();
                        if (activity != null) {
                            new AlertDialog.Builder((Context)activity).setTitle((CharSequence)lOG_LEVEL.toString()).setMessage((CharSequence)string3).show();
                        }
                    }
                });
                return;
            }
            catch (Throwable throwable2) {
                Log.e((String)"OneSignal", (String)"Error showing logging message.", (Throwable)throwable2);
            }
        }
    }

    public static void addEmailSubscriptionObserver(OSEmailSubscriptionObserver oSEmailSubscriptionObserver) {
        if (appContext == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Could not add email subscription observer");
            return;
        }
        OneSignal.getEmailSubscriptionStateChangesObserver().addObserver(oSEmailSubscriptionObserver);
        if (OneSignal.getCurrentEmailSubscriptionState(appContext).compare(OneSignal.getLastEmailSubscriptionState(appContext))) {
            OSEmailSubscriptionChangedInternalObserver.fireChangesToPublicObserver(OneSignal.getCurrentEmailSubscriptionState(appContext));
        }
    }

    static void addNetType(JSONObject jSONObject) {
        try {
            jSONObject.put("net_type", (Object)osUtils.getNetType());
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    public static void addPermissionObserver(OSPermissionObserver oSPermissionObserver) {
        if (appContext == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Could not add permission observer");
            return;
        }
        OneSignal.getPermissionStateChangesObserver().addObserver(oSPermissionObserver);
        if (OneSignal.getCurrentPermissionState(appContext).compare(OneSignal.getLastPermissionState(appContext))) {
            OSPermissionChangedInternalObserver.fireChangesToPublicObserver(OneSignal.getCurrentPermissionState(appContext));
        }
    }

    public static void addSubscriptionObserver(OSSubscriptionObserver oSSubscriptionObserver) {
        if (appContext == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Could not add subscription observer");
            return;
        }
        OneSignal.getSubscriptionStateChangesObserver().addObserver(oSSubscriptionObserver);
        if (OneSignal.getCurrentSubscriptionState(appContext).compare(OneSignal.getLastSubscriptionState(appContext))) {
            OSSubscriptionChangedInternalObserver.fireChangesToPublicObserver(OneSignal.getCurrentSubscriptionState(appContext));
        }
    }

    private static void addTaskToQueue(PendingTaskRunnable pendingTaskRunnable) {
        pendingTaskRunnable.taskId = OneSignal.lastTaskId.incrementAndGet();
        ExecutorService executorService = pendingTaskExecutor;
        if (executorService == null) {
            LOG_LEVEL lOG_LEVEL = LOG_LEVEL.INFO;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Adding a task to the pending queue with ID: ");
            stringBuilder.append(pendingTaskRunnable.taskId);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            taskQueueWaitingForInit.add((Object)pendingTaskRunnable);
            return;
        }
        if (!executorService.isShutdown()) {
            LOG_LEVEL lOG_LEVEL = LOG_LEVEL.INFO;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Executor is still running, add to the executor with ID: ");
            stringBuilder.append(pendingTaskRunnable.taskId);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            try {
                pendingTaskExecutor.submit((Runnable)pendingTaskRunnable);
                return;
            }
            catch (RejectedExecutionException rejectedExecutionException) {
                LOG_LEVEL lOG_LEVEL2 = LOG_LEVEL.INFO;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Executor is shutdown, running task manually with ID: ");
                stringBuilder2.append(pendingTaskRunnable.taskId);
                OneSignal.Log(lOG_LEVEL2, stringBuilder2.toString());
                pendingTaskRunnable.run();
                rejectedExecutionException.printStackTrace();
            }
        }
    }

    public static void addTrigger(String string2, Object object) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)string2, object);
        OneSignal.getInAppMessageController().addTriggers((Map<String, Object>)hashMap);
    }

    public static void addTriggers(Map<String, Object> map) {
        OneSignal.getInAppMessageController().addTriggers(map);
    }

    public static void addTriggersFromJsonString(String string2) {
        try {
            OneSignal.addTriggers(JSONUtils.jsonObjectToMap(new JSONObject(string2)));
            return;
        }
        catch (JSONException jSONException) {
            OneSignal.Log(LOG_LEVEL.ERROR, "addTriggersFromJsonString, invalid json", jSONException);
            return;
        }
    }

    static boolean areNotificationsEnabledForSubscribedState() {
        if (OneSignal.mInitBuilder.mUnsubscribeWhenNotificationsAreDisabled) {
            return OSUtils.areNotificationsEnabled(appContext);
        }
        return true;
    }

    static boolean atLogLevel(LOG_LEVEL lOG_LEVEL) {
        int n;
        int n2 = lOG_LEVEL.compareTo((Enum)visualLogLevel);
        if (n2 >= (n = 1)) {
            if (lOG_LEVEL.compareTo((Enum)logCatLevel) < n) {
                return (boolean)n;
            }
            n = 0;
        }
        return (boolean)n;
    }

    public static void cancelGroupedNotifications(final String string2) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("cancelGroupedNotifications()")) {
            return;
        }
        Runnable runnable = new Runnable(){

            public void run() {
                NotificationManager notificationManager = OneSignalNotificationManager.getNotificationManager(OneSignal.appContext);
                OneSignalDbHelper oneSignalDbHelper = OneSignalDbHelper.getInstance(OneSignal.appContext);
                String[] arrstring = new String[]{"android_notification_id"};
                String[] arrstring2 = new String[]{string2};
                Cursor cursor = oneSignalDbHelper.query("notification", arrstring, "group_id = ? AND dismissed = 0 AND opened = 0", arrstring2, null, null, null);
                while (cursor.moveToNext()) {
                    int n = cursor.getInt(cursor.getColumnIndex("android_notification_id"));
                    if (n == -1) continue;
                    notificationManager.cancel(n);
                }
                cursor.close();
                ContentValues contentValues = new ContentValues();
                contentValues.put("dismissed", Integer.valueOf((int)1));
                oneSignalDbHelper.update("notification", contentValues, "group_id = ? AND opened = 0 AND dismissed = 0", arrstring2);
                BadgeCountUpdater.update(oneSignalDbHelper, OneSignal.appContext);
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        LOG_LEVEL lOG_LEVEL = LOG_LEVEL.ERROR;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OneSignal.init has not been called. Could not clear notifications part of group ");
        stringBuilder.append(string2);
        stringBuilder.append(" - movingthis operation to a waiting task queue.");
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    public static void cancelNotification(final int n) {
        Runnable runnable = new Runnable(){

            public void run() {
                OneSignalDbHelper oneSignalDbHelper = OneSignalDbHelper.getInstance(OneSignal.appContext);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("android_notification_id = ");
                stringBuilder.append(n);
                stringBuilder.append(" AND ");
                stringBuilder.append("opened");
                stringBuilder.append(" = 0 AND ");
                stringBuilder.append("dismissed");
                stringBuilder.append(" = 0");
                String string2 = stringBuilder.toString();
                ContentValues contentValues = new ContentValues();
                contentValues.put("dismissed", Integer.valueOf((int)1));
                if (oneSignalDbHelper.update("notification", contentValues, string2, null) > 0) {
                    NotificationSummaryManager.updatePossibleDependentSummaryOnDismiss(OneSignal.appContext, oneSignalDbHelper, n);
                }
                BadgeCountUpdater.update(oneSignalDbHelper, OneSignal.appContext);
                OneSignalNotificationManager.getNotificationManager(OneSignal.appContext).cancel(n);
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        LOG_LEVEL lOG_LEVEL = LOG_LEVEL.ERROR;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OneSignal.init has not been called. Could not clear notification id: ");
        stringBuilder.append(n);
        stringBuilder.append(" at this time - movingthis operation to a waiting task queue. The notification will still be canceledfrom NotificationManager at this time.");
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        taskQueueWaitingForInit.add((Object)runnable);
    }

    public static void clearOneSignalNotifications() {
        Runnable runnable = new Runnable(){

            public void run() {
                NotificationManager notificationManager = OneSignalNotificationManager.getNotificationManager(OneSignal.appContext);
                OneSignalDbHelper oneSignalDbHelper = OneSignalDbHelper.getInstance(OneSignal.appContext);
                Cursor cursor = oneSignalDbHelper.query("notification", new String[]{"android_notification_id"}, "dismissed = 0 AND opened = 0", null, null, null, null);
                if (cursor.moveToFirst()) {
                    do {
                        notificationManager.cancel(cursor.getInt(cursor.getColumnIndex("android_notification_id")));
                    } while (cursor.moveToNext());
                }
                ContentValues contentValues = new ContentValues();
                contentValues.put("dismissed", Integer.valueOf((int)1));
                oneSignalDbHelper.update("notification", contentValues, "opened = 0", null);
                BadgeCountUpdater.updateCount(0, OneSignal.appContext);
                cursor.close();
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Could not clear notifications at this time - moving this operation toa waiting task queue.");
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    private static Builder createInitBuilder(NotificationOpenedHandler notificationOpenedHandler, NotificationReceivedHandler notificationReceivedHandler) {
        OneSignal.mInitBuilder.mDisplayOptionCarryOver = false;
        OneSignal.mInitBuilder.mNotificationOpenedHandler = notificationOpenedHandler;
        OneSignal.mInitBuilder.mNotificationReceivedHandler = notificationReceivedHandler;
        return mInitBuilder;
    }

    public static OSInFocusDisplayOption currentInFocusDisplayOption() {
        return OneSignal.mInitBuilder.mDisplayOption;
    }

    public static void deleteTag(String string2) {
        OneSignal.deleteTag(string2, null);
    }

    public static void deleteTag(String string2, ChangeTagsUpdateHandler changeTagsUpdateHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("deleteTag()")) {
            return;
        }
        ArrayList arrayList = new ArrayList(1);
        arrayList.add((Object)string2);
        OneSignal.deleteTags((Collection<String>)arrayList, changeTagsUpdateHandler);
    }

    public static void deleteTags(String string2) {
        OneSignal.deleteTags(string2, null);
    }

    public static void deleteTags(String string2, ChangeTagsUpdateHandler changeTagsUpdateHandler) {
        try {
            OneSignal.deleteTags(new JSONArray(string2), changeTagsUpdateHandler);
            return;
        }
        catch (Throwable throwable) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Failed to generate JSON for deleteTags.", throwable);
            return;
        }
    }

    public static void deleteTags(Collection<String> collection) {
        OneSignal.deleteTags(collection, null);
    }

    public static void deleteTags(Collection<String> collection, ChangeTagsUpdateHandler changeTagsUpdateHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("deleteTags()")) {
            return;
        }
        try {
            JSONObject jSONObject = new JSONObject();
            Iterator iterator = collection.iterator();
            while (iterator.hasNext()) {
                jSONObject.put((String)iterator.next(), (Object)"");
            }
            OneSignal.sendTags(jSONObject, changeTagsUpdateHandler);
            return;
        }
        catch (Throwable throwable) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Failed to generate JSON for deleteTags.", throwable);
            return;
        }
    }

    public static void deleteTags(JSONArray jSONArray, ChangeTagsUpdateHandler changeTagsUpdateHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("deleteTags()")) {
            return;
        }
        JSONObject jSONObject = new JSONObject();
        int n = 0;
        do {
            if (n >= jSONArray.length()) break;
            jSONObject.put(jSONArray.getString(n), (Object)"");
            ++n;
        } while (true);
        try {
            OneSignal.sendTags(jSONObject, changeTagsUpdateHandler);
            return;
        }
        catch (Throwable throwable) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Failed to generate JSON for deleteTags.", throwable);
            return;
        }
    }

    private static void doSessionInit() {
        if (OneSignal.isPastOnSessionTime()) {
            OneSignal.onesignalLog(LOG_LEVEL.DEBUG, "Starting new session");
            OneSignalStateSynchronizer.setNewSession();
            if (foreground) {
                outcomeEventsController.cleanOutcomes();
                sessionManager.restartSessionIfNeeded(OneSignal.getAppEntryState());
                OneSignal.getInAppMessageController().resetSessionLaunchTime();
            }
        } else if (foreground) {
            OneSignal.onesignalLog(LOG_LEVEL.DEBUG, "Continue on same session");
            sessionManager.attemptSessionUpgrade(OneSignal.getAppEntryState());
        }
        OneSignal.getInAppMessageController().initWithCachedInAppMessages();
        if (!foreground && OneSignal.hasUserId()) {
            return;
        }
        OneSignal.setLastSessionTime(System.currentTimeMillis());
        OneSignal.startRegistrationOrOnSession();
    }

    public static void enableSound(boolean bl) {
        if (appContext == null) {
            return;
        }
        OneSignalPrefs.saveBool(OneSignalPrefs.PREFS_ONESIGNAL, "GT_SOUND_ENABLED", bl);
    }

    public static void enableVibrate(boolean bl) {
        if (appContext == null) {
            return;
        }
        OneSignalPrefs.saveBool(OneSignalPrefs.PREFS_ONESIGNAL, "GT_VIBRATE_ENABLED", bl);
    }

    private static void fireCallbackForOpenedNotifications() {
        Iterator iterator = unprocessedOpenedNotifis.iterator();
        while (iterator.hasNext()) {
            OneSignal.runNotificationOpenedCallback((JSONArray)iterator.next(), true, false);
        }
        unprocessedOpenedNotifis.clear();
    }

    static void fireEmailUpdateFailure() {
        EmailUpdateHandler emailUpdateHandler = OneSignal.emailUpdateHandler;
        if (emailUpdateHandler != null) {
            emailUpdateHandler.onFailure(new EmailUpdateError(EmailErrorType.NETWORK, "Failed due to network failure. Will retry on next sync."));
            OneSignal.emailUpdateHandler = null;
        }
    }

    static void fireEmailUpdateSuccess() {
        EmailUpdateHandler emailUpdateHandler = OneSignal.emailUpdateHandler;
        if (emailUpdateHandler != null) {
            emailUpdateHandler.onSuccess();
            OneSignal.emailUpdateHandler = null;
        }
    }

    static void fireIdsAvailableCallback() {
        if (idsAvailableHandler != null) {
            OSUtils.runOnMainUIThread(new Runnable(){

                public void run() {
                    OneSignal.internalFireIdsAvailableCallback();
                }
            });
        }
    }

    private static void fireNotificationOpenedHandler(final OSNotificationOpenResult oSNotificationOpenResult) {
        OSUtils.runOnMainUIThread(new Runnable(){

            public void run() {
                OneSignal.mInitBuilder.mNotificationOpenedHandler.notificationOpened(oSNotificationOpenResult);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static OSNotificationOpenResult generateOsNotificationOpenResult(JSONArray jSONArray, boolean bl, boolean bl2) {
        int n = jSONArray.length();
        boolean bl3 = true;
        OSNotificationOpenResult oSNotificationOpenResult = new OSNotificationOpenResult();
        OSNotification oSNotification = new OSNotification();
        oSNotification.isAppInFocus = OneSignal.isAppActive();
        oSNotification.shown = bl;
        oSNotification.androidNotificationId = jSONArray.optJSONObject(0).optInt("androidNotificationId");
        String string2 = null;
        int n2 = 0;
        do {
            block10 : {
                block9 : {
                    if (n2 < n) {
                        try {
                            JSONObject jSONObject = jSONArray.getJSONObject(n2);
                            oSNotification.payload = NotificationBundleProcessor.OSNotificationPayloadFrom(jSONObject);
                            if (string2 == null && jSONObject.has("actionId")) {
                                string2 = jSONObject.optString("actionId", null);
                            }
                            break block9;
                        }
                        catch (Throwable throwable) {
                            LOG_LEVEL lOG_LEVEL = LOG_LEVEL.ERROR;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Error parsing JSON item ");
                            stringBuilder.append(n2);
                            stringBuilder.append("/");
                            stringBuilder.append(n);
                            stringBuilder.append(" for callback.");
                            OneSignal.Log(lOG_LEVEL, stringBuilder.toString(), throwable);
                            break block10;
                        }
                    }
                    oSNotificationOpenResult.notification = oSNotification;
                    oSNotificationOpenResult.action = new OSNotificationAction();
                    oSNotificationOpenResult.action.actionID = string2;
                    OSNotificationAction oSNotificationAction = oSNotificationOpenResult.action;
                    OSNotificationAction.ActionType actionType = string2 != null ? OSNotificationAction.ActionType.ActionTaken : OSNotificationAction.ActionType.Opened;
                    oSNotificationAction.type = actionType;
                    if (bl2) {
                        oSNotificationOpenResult.notification.displayType = OSNotification.DisplayType.InAppAlert;
                        return oSNotificationOpenResult;
                    }
                    oSNotificationOpenResult.notification.displayType = OSNotification.DisplayType.Notification;
                    return oSNotificationOpenResult;
                }
                if (bl3) {
                    bl3 = false;
                } else {
                    if (oSNotification.groupedNotifications == null) {
                        oSNotification.groupedNotifications = new ArrayList();
                    }
                    oSNotification.groupedNotifications.add((Object)oSNotification.payload);
                }
            }
            ++n2;
        } while (true);
    }

    private static AdvertisingIdentifierProvider getAdIdProvider() {
        Class<OneSignal> class_ = OneSignal.class;
        synchronized (OneSignal.class) {
            if (adIdProvider == null && OSUtils.isAndroidDeviceType()) {
                adIdProvider = new AdvertisingIdProviderGPS();
            }
            AdvertisingIdentifierProvider advertisingIdentifierProvider = adIdProvider;
            // ** MonitorExit[var2] (shouldn't be in output)
            return advertisingIdentifierProvider;
        }
    }

    static AppEntryAction getAppEntryState() {
        return appEntryState;
    }

    static boolean getClearGroupSummaryClick() {
        return OneSignalPrefs.getBool(OneSignalPrefs.PREFS_ONESIGNAL, "OS_CLEAR_GROUP_SUMMARY_CLICK", true);
    }

    static Activity getCurrentActivity() {
        ActivityLifecycleHandler activityLifecycleHandler = ActivityLifecycleListener.getActivityLifecycleHandler();
        if (activityLifecycleHandler != null) {
            return activityLifecycleHandler.getCurActivity();
        }
        return null;
    }

    private static OSEmailSubscriptionState getCurrentEmailSubscriptionState(Context context) {
        if (context == null) {
            return null;
        }
        if (currentEmailSubscriptionState == null) {
            OSEmailSubscriptionState oSEmailSubscriptionState;
            currentEmailSubscriptionState = oSEmailSubscriptionState = new OSEmailSubscriptionState(false);
            oSEmailSubscriptionState.observable.addObserverStrong(new OSEmailSubscriptionChangedInternalObserver());
        }
        return currentEmailSubscriptionState;
    }

    public static Builder getCurrentOrNewInitBuilder() {
        return mInitBuilder;
    }

    private static OSPermissionState getCurrentPermissionState(Context context) {
        if (context == null) {
            return null;
        }
        if (currentPermissionState == null) {
            OSPermissionState oSPermissionState;
            currentPermissionState = oSPermissionState = new OSPermissionState(false);
            oSPermissionState.observable.addObserverStrong(new OSPermissionChangedInternalObserver());
        }
        return currentPermissionState;
    }

    private static OSSubscriptionState getCurrentSubscriptionState(Context context) {
        if (context == null) {
            return null;
        }
        if (currentSubscriptionState == null) {
            currentSubscriptionState = new OSSubscriptionState(false, OneSignal.getCurrentPermissionState(context).getEnabled());
            OneSignal.getCurrentPermissionState((Context)context).observable.addObserver(currentSubscriptionState);
            OneSignal.currentSubscriptionState.observable.addObserverStrong(new OSSubscriptionChangedInternalObserver());
        }
        return currentSubscriptionState;
    }

    static OneSignalDbHelper getDBHelperInstance() {
        return OneSignalDbHelper.getInstance(appContext);
    }

    static String getEmailId() {
        if (emailId == null && appContext != null) {
            emailId = OneSignalPrefs.getString(OneSignalPrefs.PREFS_ONESIGNAL, "OS_EMAIL_ID", null);
        }
        if (TextUtils.isEmpty((CharSequence)emailId)) {
            return null;
        }
        return emailId;
    }

    static OSObservable<OSEmailSubscriptionObserver, OSEmailSubscriptionStateChanges> getEmailSubscriptionStateChangesObserver() {
        if (emailSubscriptionStateChangesObserver == null) {
            emailSubscriptionStateChangesObserver = new OSObservable("onOSEmailSubscriptionChanged", true);
        }
        return emailSubscriptionStateChangesObserver;
    }

    static boolean getFilterOtherGCMReceivers(Context context) {
        return OneSignalPrefs.getBool(OneSignalPrefs.PREFS_ONESIGNAL, "OS_FILTER_OTHER_GCM_RECEIVERS", false);
    }

    static boolean getFirebaseAnalyticsEnabled() {
        return OneSignalPrefs.getBool(OneSignalPrefs.PREFS_ONESIGNAL, "GT_FIREBASE_TRACKING_ENABLED", false);
    }

    static boolean getInAppAlertNotificationEnabled() {
        Builder builder = mInitBuilder;
        if (builder == null) {
            return false;
        }
        OSInFocusDisplayOption oSInFocusDisplayOption = builder.mDisplayOption;
        OSInFocusDisplayOption oSInFocusDisplayOption2 = OSInFocusDisplayOption.InAppAlert;
        boolean bl = false;
        if (oSInFocusDisplayOption == oSInFocusDisplayOption2) {
            bl = true;
        }
        return bl;
    }

    static OSInAppMessageController getInAppMessageController() {
        return inAppMessageControllerFactory.getController(OneSignal.getDBHelperInstance());
    }

    private static OSInFocusDisplayOption getInFocusDisplaying(int n) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    if (n < 0) {
                        return OSInFocusDisplayOption.None;
                    }
                    return OSInFocusDisplayOption.Notification;
                }
                return OSInFocusDisplayOption.Notification;
            }
            return OSInFocusDisplayOption.InAppAlert;
        }
        return OSInFocusDisplayOption.None;
    }

    private static OSEmailSubscriptionState getLastEmailSubscriptionState(Context context) {
        if (context == null) {
            return null;
        }
        if (lastEmailSubscriptionState == null) {
            lastEmailSubscriptionState = new OSEmailSubscriptionState(true);
        }
        return lastEmailSubscriptionState;
    }

    private static OSPermissionState getLastPermissionState(Context context) {
        if (context == null) {
            return null;
        }
        if (lastPermissionState == null) {
            lastPermissionState = new OSPermissionState(true);
        }
        return lastPermissionState;
    }

    private static long getLastSessionTime() {
        return OneSignalPrefs.getLong(OneSignalPrefs.PREFS_ONESIGNAL, "OS_LAST_SESSION_TIME", -31000L);
    }

    private static OSSubscriptionState getLastSubscriptionState(Context context) {
        if (context == null) {
            return null;
        }
        if (lastSubscriptionState == null) {
            lastSubscriptionState = new OSSubscriptionState(true, false);
        }
        return lastSubscriptionState;
    }

    private static LOG_LEVEL getLogLevel(int n) {
        switch (n) {
            default: {
                if (n >= 0) break;
                return LOG_LEVEL.NONE;
            }
            case 6: {
                return LOG_LEVEL.VERBOSE;
            }
            case 5: {
                return LOG_LEVEL.DEBUG;
            }
            case 4: {
                return LOG_LEVEL.INFO;
            }
            case 3: {
                return LOG_LEVEL.WARN;
            }
            case 2: {
                return LOG_LEVEL.ERROR;
            }
            case 1: {
                return LOG_LEVEL.FATAL;
            }
            case 0: {
                return LOG_LEVEL.NONE;
            }
        }
        return LOG_LEVEL.VERBOSE;
    }

    private static String getNotificationIdFromGCMJsonPayload(JSONObject jSONObject) {
        try {
            String string2 = new JSONObject(jSONObject.optString("custom")).optString("i", null);
            return string2;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    static boolean getNotificationsWhenActiveEnabled() {
        Builder builder = mInitBuilder;
        if (builder == null) {
            return true;
        }
        return builder.mDisplayOption == OSInFocusDisplayOption.Notification;
    }

    static OSObservable<OSPermissionObserver, OSPermissionStateChanges> getPermissionStateChangesObserver() {
        if (permissionStateChangesObserver == null) {
            permissionStateChangesObserver = new OSObservable("onOSPermissionChanged", true);
        }
        return permissionStateChangesObserver;
    }

    public static OSPermissionSubscriptionState getPermissionSubscriptionState() {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("getPermissionSubscriptionState()")) {
            return null;
        }
        if (appContext == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Could not get OSPermissionSubscriptionState");
            return null;
        }
        OSPermissionSubscriptionState oSPermissionSubscriptionState = new OSPermissionSubscriptionState();
        oSPermissionSubscriptionState.subscriptionStatus = OneSignal.getCurrentSubscriptionState(appContext);
        oSPermissionSubscriptionState.permissionStatus = OneSignal.getCurrentPermissionState(appContext);
        oSPermissionSubscriptionState.emailSubscriptionStatus = OneSignal.getCurrentEmailSubscriptionState(appContext);
        return oSPermissionSubscriptionState;
    }

    private static PushRegistrator getPushRegistrator() {
        PushRegistrator pushRegistrator = mPushRegistrator;
        if (pushRegistrator != null) {
            return pushRegistrator;
        }
        mPushRegistrator = OSUtils.isFireOSDeviceType() ? new PushRegistratorADM() : (OSUtils.isAndroidDeviceType() ? (OSUtils.hasFCMLibrary() ? new PushRegistratorFCM() : new PushRegistratorGCM()) : new PushRegistratorHMS());
        return mPushRegistrator;
    }

    static String getSavedAppId() {
        return OneSignal.getSavedAppId(appContext);
    }

    private static String getSavedAppId(Context context) {
        if (context == null) {
            return null;
        }
        return OneSignalPrefs.getString(OneSignalPrefs.PREFS_ONESIGNAL, "GT_APP_ID", null);
    }

    static boolean getSavedUserConsentStatus() {
        return OneSignalPrefs.getBool(OneSignalPrefs.PREFS_ONESIGNAL, "ONESIGNAL_USER_PROVIDED_CONSENT", false);
    }

    private static String getSavedUserId(Context context) {
        if (context == null) {
            return null;
        }
        return OneSignalPrefs.getString(OneSignalPrefs.PREFS_ONESIGNAL, "GT_PLAYER_ID", null);
    }

    static OSSessionManager.SessionListener getSessionListener() {
        return sessionListener;
    }

    static OSSessionManager getSessionManager() {
        return sessionManager;
    }

    static boolean getSoundEnabled() {
        return OneSignalPrefs.getBool(OneSignalPrefs.PREFS_ONESIGNAL, "GT_SOUND_ENABLED", true);
    }

    static OSObservable<OSSubscriptionObserver, OSSubscriptionStateChanges> getSubscriptionStateChangesObserver() {
        if (subscriptionStateChangesObserver == null) {
            subscriptionStateChangesObserver = new OSObservable("onOSSubscriptionChanged", true);
        }
        return subscriptionStateChangesObserver;
    }

    public static void getTags(final GetTagsHandler getTagsHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("getTags()")) {
            return;
        }
        if (getTagsHandler == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "getTagsHandler is null!");
            return;
        }
        new Thread(new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Converted monitor instructions to comments
             * Lifted jumps to return sites
             */
            public void run() {
                ArrayList arrayList;
                ArrayList arrayList2 = arrayList = pendingGetTagsHandlers;
                // MONITORENTER : arrayList2
                pendingGetTagsHandlers.add((Object)getTagsHandler);
                if (pendingGetTagsHandlers.size() > 1) {
                    // MONITOREXIT : arrayList2
                    return;
                }
                // MONITOREXIT : arrayList2
                if (OneSignal.appContext == null) {
                    OneSignal.Log(LOG_LEVEL.ERROR, "You must initialize OneSignal before getting tags! Moving this tag operation to a pending queue.");
                    OneSignal.taskQueueWaitingForInit.add((Object)new Runnable(){

                        public void run() {
                            OneSignal.runGetTags();
                        }
                    });
                    return;
                }
                OneSignal.runGetTags();
            }

        }, "OS_GETTAGS").start();
    }

    private static int getTimeZoneOffset() {
        TimeZone timeZone = Calendar.getInstance().getTimeZone();
        int n = timeZone.getRawOffset();
        if (timeZone.inDaylightTime(new Date())) {
            n += timeZone.getDSTSavings();
        }
        return n / 1000;
    }

    public static Object getTriggerValueForKey(String string2) {
        return OneSignal.getInAppMessageController().getTriggerValue(string2);
    }

    public static OSDevice getUserDevice() {
        if (userDevice == null) {
            userDevice = new OSDevice();
        }
        return userDevice;
    }

    static String getUserId() {
        Context context;
        if (userId == null && (context = appContext) != null) {
            userId = OneSignal.getSavedUserId(context);
        }
        return userId;
    }

    static boolean getVibrate() {
        return OneSignalPrefs.getBool(OneSignalPrefs.PREFS_ONESIGNAL, "GT_VIBRATE_ENABLED", true);
    }

    private static void handleActivityLifecycleHandler(Context context) {
        boolean bl;
        ActivityLifecycleHandler activityLifecycleHandler = ActivityLifecycleListener.getActivityLifecycleHandler();
        foreground = bl = OneSignal.isContextActivity(context);
        OneSignal.setInForeground(bl);
        if (foreground) {
            if (activityLifecycleHandler != null) {
                activityLifecycleHandler.setCurActivity((Activity)context);
            }
            NotificationRestorer.asyncRestore(appContext);
            FocusTimeController.getInstance().appForegrounded();
            return;
        }
        if (activityLifecycleHandler != null) {
            activityLifecycleHandler.setNextResumeIsFirstActivity(true);
        }
    }

    private static void handleAmazonPurchase() {
        try {
            Class.forName((String)"com.amazon.device.iap.PurchasingListener");
            trackAmazonPurchase = new TrackAmazonPurchase(appContext);
            return;
        }
        catch (ClassNotFoundException classNotFoundException) {
            return;
        }
    }

    private static void handleAppIdChange() {
        String string2 = OneSignal.getSavedAppId();
        if (string2 != null) {
            if (!string2.equals((Object)appId)) {
                OneSignal.Log(LOG_LEVEL.DEBUG, "APP ID changed, clearing user id as it is no longer valid.");
                OneSignal.saveAppId(appId);
                OneSignalStateSynchronizer.resetCurrentState();
                remoteParams = null;
                return;
            }
        } else {
            BadgeCountUpdater.updateCount(0, appContext);
            OneSignal.saveAppId(appId);
        }
    }

    static void handleFailedEmailLogout() {
        EmailUpdateHandler emailUpdateHandler = emailLogoutHandler;
        if (emailUpdateHandler != null) {
            emailUpdateHandler.onFailure(new EmailUpdateError(EmailErrorType.NETWORK, "Failed due to network failure. Will retry on next sync."));
            emailLogoutHandler = null;
        }
    }

    public static void handleNotificationOpen(Context context, JSONArray jSONArray, boolean bl, String string2) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName(null)) {
            return;
        }
        OneSignal.notificationOpenedRESTCall(context, jSONArray);
        if (trackFirebaseAnalytics != null && OneSignal.getFirebaseAnalyticsEnabled()) {
            trackFirebaseAnalytics.trackOpenedEvent(OneSignal.generateOsNotificationOpenResult(jSONArray, true, bl));
        }
        boolean bl2 = "DISABLE".equals((Object)OSUtils.getManifestMeta(context, "com.onesignal.NotificationOpened.DEFAULT"));
        boolean bl3 = false;
        if (!bl2) {
            bl3 = OneSignal.openURLFromNotification(context, jSONArray);
        }
        if (OneSignal.shouldInitDirectSessionFromNotificationOpen(context, bl, bl3, bl2)) {
            AppEntryAction appEntryAction;
            appEntryState = appEntryAction = AppEntryAction.NOTIFICATION_CLICK;
            sessionManager.onDirectInfluenceFromNotificationOpen(appEntryAction, string2);
        }
        OneSignal.runNotificationOpenedCallback(jSONArray, true, bl);
    }

    static void handleNotificationReceived(JSONArray jSONArray, boolean bl, boolean bl2) {
        Builder builder;
        OSNotificationOpenResult oSNotificationOpenResult = OneSignal.generateOsNotificationOpenResult(jSONArray, bl, bl2);
        if (trackFirebaseAnalytics != null && OneSignal.getFirebaseAnalyticsEnabled()) {
            trackFirebaseAnalytics.trackReceivedEvent(oSNotificationOpenResult);
        }
        if ((builder = mInitBuilder) != null) {
            if (builder.mNotificationReceivedHandler == null) {
                return;
            }
            OneSignal.mInitBuilder.mNotificationReceivedHandler.notificationReceived(oSNotificationOpenResult.notification);
            return;
        }
    }

    static void handleSuccessfulEmailLogout() {
        EmailUpdateHandler emailUpdateHandler = emailLogoutHandler;
        if (emailUpdateHandler != null) {
            emailUpdateHandler.onSuccess();
            emailLogoutHandler = null;
        }
    }

    static boolean hasEmailId() {
        return true ^ TextUtils.isEmpty((CharSequence)emailId);
    }

    static boolean hasUserId() {
        return OneSignal.getUserId() != null;
    }

    public static void idsAvailable(IdsAvailableHandler idsAvailableHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("idsAvailable()")) {
            return;
        }
        OneSignal.idsAvailableHandler = idsAvailableHandler;
        Runnable runnable = new Runnable(){

            public void run() {
                if (OneSignal.getUserId() != null) {
                    OSUtils.runOnMainUIThread(new Runnable(){

                        public void run() {
                            OneSignal.internalFireIdsAvailableCallback();
                        }
                    });
                }
            }

        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        OneSignal.Log(LOG_LEVEL.ERROR, "You must initialize OneSignal before getting tags! Moving this tag operation to a pending queue.");
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    public static void init(Context context, String string2, String string3) {
        OneSignal.init(context, string2, string3, null, null);
    }

    public static void init(Context context, String string2, String string3, NotificationOpenedHandler notificationOpenedHandler) {
        OneSignal.init(context, string2, string3, notificationOpenedHandler, null);
    }

    public static void init(Context context, String string2, String string3, NotificationOpenedHandler notificationOpenedHandler, NotificationReceivedHandler notificationReceivedHandler) {
        mInitBuilder = OneSignal.createInitBuilder(notificationOpenedHandler, notificationReceivedHandler);
        OneSignal.setAppContext(context);
        OneSignal.setupPrivacyConsent(context);
        if (OneSignal.requiresUserPrivacyConsent()) {
            DelayedConsentInitializationParameters delayedConsentInitializationParameters;
            OneSignal.Log(LOG_LEVEL.VERBOSE, "OneSignal SDK initialization delayed, user privacy consent is set to required for this application.");
            delayedInitParams = delayedConsentInitializationParameters = new DelayedConsentInitializationParameters(context, string2, string3, notificationOpenedHandler, notificationReceivedHandler);
            return;
        }
        mInitBuilder = OneSignal.createInitBuilder(notificationOpenedHandler, notificationReceivedHandler);
        if (!OneSignal.isGoogleProjectNumberRemote()) {
            mGoogleProjectNumber = string2;
        }
        subscribableStatus = osUtils.initializationChecker(context, string3);
        if (OneSignal.isSubscriptionStatusUninitializable()) {
            return;
        }
        String string4 = appId;
        if (string4 != null && !string4.equals((Object)string3)) {
            initDone = false;
        }
        if (initDone) {
            if (OneSignal.mInitBuilder.mNotificationOpenedHandler != null) {
                OneSignal.fireCallbackForOpenedNotifications();
            }
            return;
        }
        appId = string3;
        OneSignal.saveFilterOtherGCMReceivers(OneSignal.mInitBuilder.mFilterOtherGCMReceivers);
        OneSignal.handleActivityLifecycleHandler(context);
        OneSignalStateSynchronizer.initUserState();
        OneSignal.handleAmazonPurchase();
        OneSignal.handleAppIdChange();
        OSPermissionChangedInternalObserver.handleInternalChanges(OneSignal.getCurrentPermissionState(appContext));
        OneSignal.doSessionInit();
        if (OneSignal.mInitBuilder.mNotificationOpenedHandler != null) {
            OneSignal.fireCallbackForOpenedNotifications();
        }
        if (TrackGooglePurchase.CanTrack(appContext)) {
            trackGooglePurchase = new TrackGooglePurchase(appContext);
        }
        if (TrackFirebaseAnalytics.CanTrack()) {
            trackFirebaseAnalytics = new TrackFirebaseAnalytics(appContext);
        }
        PushRegistratorFCM.disableFirebaseInstanceIdService((Context)appContext);
        initDone = true;
        outcomeEventsController.sendSavedOutcomes();
        OneSignal.startPendingTasks();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void init(Builder builder) {
        if (OneSignal.mInitBuilder.mDisplayOptionCarryOver) {
            builder.mDisplayOption = OneSignal.mInitBuilder.mDisplayOption;
        }
        mInitBuilder = builder;
        Context context = builder.mContext;
        OneSignal.mInitBuilder.mContext = null;
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo((String)context.getPackageName(), (int)128).metaData;
            String string2 = bundle.getString("onesignal_google_project_number");
            if (string2 != null && string2.length() > 4) {
                string2 = string2.substring(4);
            }
            OneSignal.init(context, string2, bundle.getString("onesignal_app_id"), OneSignal.mInitBuilder.mNotificationOpenedHandler, OneSignal.mInitBuilder.mNotificationReceivedHandler);
            return;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void internalFireGetTagsCallbacks() {
        ArrayList<GetTagsHandler> arrayList;
        ArrayList<GetTagsHandler> arrayList2 = arrayList = pendingGetTagsHandlers;
        synchronized (arrayList2) {
            if (pendingGetTagsHandlers.size() == 0) {
                return;
            }
        }
        new Thread(new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                ArrayList arrayList;
                UserStateSynchronizer.GetTagsResult getTagsResult = OneSignalStateSynchronizer.getTags(true ^ getTagsCall);
                if (getTagsResult.serverSuccess) {
                    getTagsCall = true;
                }
                ArrayList arrayList2 = arrayList = pendingGetTagsHandlers;
                synchronized (arrayList2) {
                    Iterator iterator = pendingGetTagsHandlers.iterator();
                    do {
                        if (!iterator.hasNext()) {
                            pendingGetTagsHandlers.clear();
                            return;
                        }
                        GetTagsHandler getTagsHandler = (GetTagsHandler)iterator.next();
                        JSONObject jSONObject = getTagsResult.result != null && !getTagsResult.toString().equals((Object)"{}") ? getTagsResult.result : null;
                        getTagsHandler.tagsAvailable(jSONObject);
                    } while (true);
                }
            }
        }, "OS_GETTAGS_CALLBACK").start();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void internalFireIdsAvailableCallback() {
        Class<OneSignal> class_ = OneSignal.class;
        synchronized (OneSignal.class) {
            String string2;
            IdsAvailableHandler idsAvailableHandler = OneSignal.idsAvailableHandler;
            if (idsAvailableHandler == null) {
                // ** MonitorExit[var4] (shouldn't be in output)
                return;
            }
            String string3 = OneSignalStateSynchronizer.getRegistrationId();
            if (!OneSignalStateSynchronizer.getSubscribed()) {
                string3 = null;
            }
            if ((string2 = OneSignal.getUserId()) == null) {
                // ** MonitorExit[var4] (shouldn't be in output)
                return;
            }
            OneSignal.idsAvailableHandler.idsAvailable(string2, string3);
            if (string3 != null) {
                OneSignal.idsAvailableHandler = null;
            }
            // ** MonitorExit[var4] (shouldn't be in output)
            return;
        }
    }

    static boolean isAppActive() {
        return initDone && OneSignal.isForeground();
    }

    private static boolean isContextActivity(Context context) {
        return context instanceof Activity;
    }

    private static boolean isDuplicateNotification(String string2, Context context) {
        if (string2 != null) {
            if ("".equals((Object)string2)) {
                return false;
            }
            Cursor cursor = OneSignalDbHelper.getInstance(context).query("notification", new String[]{"notification_id"}, "notification_id = ?", new String[]{string2}, null, null, null);
            boolean bl = cursor.moveToFirst();
            cursor.close();
            if (bl) {
                LOG_LEVEL lOG_LEVEL = LOG_LEVEL.DEBUG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Duplicate GCM message received, skip processing of ");
                stringBuilder.append(string2);
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                return true;
            }
            return false;
        }
        return false;
    }

    static boolean isForeground() {
        return foreground;
    }

    private static boolean isGoogleProjectNumberRemote() {
        OneSignalRemoteParams.Params params = remoteParams;
        return params != null && params.googleProjectNumber != null;
    }

    static boolean isInForeground() {
        return inForeground;
    }

    static boolean isInitDone() {
        return initDone;
    }

    private static boolean isPastOnSessionTime() {
        return System.currentTimeMillis() - OneSignal.getLastSessionTime() >= 30000L;
    }

    private static boolean isSubscriptionStatusUninitializable() {
        return subscribableStatus == -999;
    }

    private static boolean isValidOutcomeEntry(String string2) {
        if (string2 != null && !string2.isEmpty()) {
            return true;
        }
        OneSignal.Log(LOG_LEVEL.ERROR, "Outcome name must not be empty");
        return false;
    }

    private static boolean isValidOutcomeValue(float f) {
        if (f <= 0.0f) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Outcome value must be greater than 0");
            return false;
        }
        return true;
    }

    static void logHttpError(String string2, int n, Throwable throwable, String string3) {
        String string4 = "";
        if (string3 != null && OneSignal.atLogLevel(LOG_LEVEL.INFO)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("\n");
            stringBuilder.append(string3);
            stringBuilder.append("\n");
            string4 = stringBuilder.toString();
        }
        LOG_LEVEL lOG_LEVEL = LOG_LEVEL.WARN;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HTTP code: ");
        stringBuilder.append(n);
        stringBuilder.append(" ");
        stringBuilder.append(string2);
        stringBuilder.append(string4);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString(), throwable);
    }

    public static void logoutEmail() {
        OneSignal.logoutEmail(null);
    }

    public static void logoutEmail(EmailUpdateHandler emailUpdateHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("logoutEmail()")) {
            return;
        }
        if (OneSignal.getEmailId() == null) {
            if (emailUpdateHandler != null) {
                emailUpdateHandler.onFailure(new EmailUpdateError(EmailErrorType.INVALID_OPERATION, "logoutEmail not valid as email was not set or already logged out!"));
            }
            OneSignal.Log(LOG_LEVEL.ERROR, "logoutEmail not valid as email was not set or already logged out!");
            return;
        }
        emailLogoutHandler = emailUpdateHandler;
        Runnable runnable = new Runnable(){

            public void run() {
                OneSignalStateSynchronizer.logoutEmail();
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        OneSignal.Log(LOG_LEVEL.ERROR, "You should initialize OneSignal before calling logoutEmail! Moving this operation to a pending task queue.");
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    private static void makeAndroidParamsRequest() {
        if (remoteParams != null) {
            OneSignal.registerForPushToken();
            return;
        }
        OneSignalRemoteParams.makeAndroidParamsRequest(new OneSignalRemoteParams.CallBack(){

            @Override
            public void complete(OneSignalRemoteParams.Params params) {
                OneSignal.remoteParams = params;
                if (OneSignal.remoteParams.googleProjectNumber != null) {
                    mGoogleProjectNumber = OneSignal.remoteParams.googleProjectNumber;
                }
                OneSignalPrefs.saveBool(OneSignalPrefs.PREFS_ONESIGNAL, "GT_FIREBASE_TRACKING_ENABLED", OneSignal.remoteParams.firebaseAnalytics);
                OneSignalPrefs.saveBool(OneSignalPrefs.PREFS_ONESIGNAL, "OS_RESTORE_TTL_FILTER", OneSignal.remoteParams.restoreTTLFilter);
                OneSignalPrefs.saveBool(OneSignalPrefs.PREFS_ONESIGNAL, "OS_CLEAR_GROUP_SUMMARY_CLICK", OneSignal.remoteParams.clearGroupOnSummaryClick);
                OneSignalPrefs.saveBool(OneSignalPrefs.PREFS_ONESIGNAL, "PREFS_OS_RECEIVE_RECEIPTS_ENABLED", OneSignal.remoteParams.receiveReceiptEnabled);
                OneSignalPrefs.saveBool(OneSignalPrefs.PREFS_ONESIGNAL, preferences.getOutcomesV2KeyName(), params.influenceParams.outcomesV2ServiceEnabled);
                OSLogger oSLogger = logger;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("OneSignal saveInfluenceParams: ");
                stringBuilder.append(params.influenceParams.toString());
                oSLogger.debug(stringBuilder.toString());
                trackerFactory.saveInfluenceParams(params.influenceParams);
                NotificationChannelManager.processChannelList(OneSignal.appContext, params.notificationChannels);
                OneSignal.registerForPushToken();
            }
        });
    }

    static boolean notValidOrDuplicated(Context context, JSONObject jSONObject) {
        String string2 = OSNotificationFormatHelper.getOSNotificationIdFromJson(jSONObject);
        return string2 == null || OneSignal.isDuplicateNotification(string2, context);
        {
        }
    }

    private static void notificationOpenedRESTCall(Context context, JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); ++i) {
            try {
                String string2 = new JSONObject(jSONArray.getJSONObject(i).optString("custom", null)).optString("i", null);
                if (postedOpenedNotifIds.contains((Object)string2)) continue;
                postedOpenedNotifIds.add((Object)string2);
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("app_id", (Object)OneSignal.getSavedAppId(context));
                jSONObject.put("player_id", (Object)OneSignal.getSavedUserId(context));
                jSONObject.put("opened", true);
                jSONObject.put("device_type", osUtils.getDeviceType());
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("notifications/");
                stringBuilder.append(string2);
                OneSignalRestClient.put(stringBuilder.toString(), jSONObject, new OneSignalRestClient.ResponseHandler(){

                    @Override
                    void onFailure(int n, String string2, Throwable throwable) {
                        OneSignal.logHttpError("sending Notification Opened Failed", n, throwable, string2);
                    }
                });
                continue;
            }
            catch (Throwable throwable) {
                OneSignal.Log(LOG_LEVEL.ERROR, "Failed to generate JSON to send notification opened.", throwable);
            }
        }
    }

    static void onAppFocus() {
        OneSignal.Log(LOG_LEVEL.DEBUG, "Application on focus");
        OneSignal.setInForeground(true);
        foreground = true;
        if (!appEntryState.equals((Object)AppEntryAction.NOTIFICATION_CLICK)) {
            appEntryState = AppEntryAction.APP_OPEN;
        }
        LocationController.onFocusChange();
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("onAppFocus")) {
            return;
        }
        if (OSUtils.shouldLogMissingAppIdError(appId)) {
            return;
        }
        FocusTimeController.getInstance().appForegrounded();
        OneSignal.doSessionInit();
        TrackGooglePurchase trackGooglePurchase = OneSignal.trackGooglePurchase;
        if (trackGooglePurchase != null) {
            trackGooglePurchase.trackIAP();
        }
        NotificationRestorer.asyncRestore(appContext);
        OneSignal.getCurrentPermissionState(appContext).refreshAsTo();
        if (trackFirebaseAnalytics != null && OneSignal.getFirebaseAnalyticsEnabled()) {
            trackFirebaseAnalytics.trackInfluenceOpenEvent();
        }
        OneSignalSyncServiceUtils.cancelSyncTask(appContext);
    }

    static void onAppLostFocus() {
        OneSignal.Log(LOG_LEVEL.DEBUG, "Application lost focus");
        OneSignal.setInForeground(false);
        foreground = false;
        appEntryState = AppEntryAction.APP_CLOSE;
        OneSignal.setLastSessionTime(System.currentTimeMillis());
        LocationController.onFocusChange();
        if (!initDone) {
            return;
        }
        TrackAmazonPurchase trackAmazonPurchase = OneSignal.trackAmazonPurchase;
        if (trackAmazonPurchase != null) {
            trackAmazonPurchase.checkListener();
        }
        if (appContext == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Android Context not found, please call OneSignal.init when your app starts.");
            return;
        }
        FocusTimeController.getInstance().appBackgrounded();
        OneSignal.scheduleSyncService();
    }

    private static void onTaskRan(long l) {
        if (lastTaskId.get() == l) {
            OneSignal.Log(LOG_LEVEL.INFO, "Last Pending Task has ran, shutting down");
            pendingTaskExecutor.shutdown();
        }
    }

    public static void onesignalLog(LOG_LEVEL lOG_LEVEL, String string2) {
        OneSignal.Log(lOG_LEVEL, string2);
    }

    private static boolean openURLFromNotification(Context context, JSONArray jSONArray) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName(null)) {
            return false;
        }
        int n = jSONArray.length();
        boolean bl = false;
        for (int i = 0; i < n; ++i) {
            String string2;
            JSONObject jSONObject;
            JSONObject jSONObject2 = jSONArray.getJSONObject(i);
            if (!jSONObject2.has("custom") || !(jSONObject = new JSONObject(jSONObject2.optString("custom"))).has("u") || (string2 = jSONObject.optString("u", null)) == null) continue;
            try {
                OSUtils.openURLInBrowser(string2);
                bl = true;
                continue;
            }
            catch (Throwable throwable) {
                LOG_LEVEL lOG_LEVEL = LOG_LEVEL.ERROR;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Error parsing JSON item ");
                stringBuilder.append(i);
                stringBuilder.append("/");
                stringBuilder.append(n);
                stringBuilder.append(" for launching a web URL.");
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString(), throwable);
            }
        }
        return bl;
    }

    public static void pauseInAppMessages(boolean bl) {
        OneSignal.getInAppMessageController().setInAppMessagingEnabled(bl ^ true);
    }

    public static void postNotification(String string2, PostNotificationResponseHandler postNotificationResponseHandler) {
        try {
            OneSignal.postNotification(new JSONObject(string2), postNotificationResponseHandler);
            return;
        }
        catch (JSONException jSONException) {
            LOG_LEVEL lOG_LEVEL = LOG_LEVEL.ERROR;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid postNotification JSON format: ");
            stringBuilder.append(string2);
            OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void postNotification(JSONObject jSONObject, final PostNotificationResponseHandler postNotificationResponseHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("postNotification()")) {
            return;
        }
        try {
            if (!jSONObject.has("app_id")) {
                jSONObject.put("app_id", (Object)OneSignal.getSavedAppId());
            }
            if (!jSONObject.has("app_id")) {
                if (postNotificationResponseHandler == null) return;
                postNotificationResponseHandler.onFailure(new JSONObject().put("error", (Object)"Missing app_id"));
                return;
            }
            OneSignalRestClient.post("notifications/", jSONObject, new OneSignalRestClient.ResponseHandler(){

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                @Override
                void onFailure(int n, String string2, Throwable throwable) {
                    OneSignal.logHttpError("create notification failed", n, throwable, string2);
                    PostNotificationResponseHandler postNotificationResponseHandler2 = postNotificationResponseHandler;
                    if (postNotificationResponseHandler2 != null) {
                        if (n == 0) {
                            string2 = "{\"error\": \"HTTP no response error\"}";
                        }
                        try {
                            postNotificationResponseHandler2.onFailure(new JSONObject(string2));
                            return;
                        }
                        catch (Throwable throwable2) {}
                        try {
                            postNotificationResponseHandler.onFailure(new JSONObject("{\"error\": \"Unknown response!\"}"));
                            return;
                        }
                        catch (JSONException jSONException) {
                            jSONException.printStackTrace();
                        }
                    }
                }

                @Override
                public void onSuccess(String string2) {
                    LOG_LEVEL lOG_LEVEL = LOG_LEVEL.DEBUG;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("HTTP create notification success: ");
                    String string3 = string2 != null ? string2 : "null";
                    stringBuilder.append(string3);
                    OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                    if (postNotificationResponseHandler != null) {
                        try {
                            JSONObject jSONObject = new JSONObject(string2);
                            if (jSONObject.has("errors")) {
                                postNotificationResponseHandler.onFailure(jSONObject);
                            } else {
                                postNotificationResponseHandler.onSuccess(new JSONObject(string2));
                            }
                            return;
                        }
                        catch (Throwable throwable) {
                            throwable.printStackTrace();
                        }
                    }
                }
            });
            return;
        }
        catch (JSONException jSONException) {
            OneSignal.Log(LOG_LEVEL.ERROR, "HTTP create notification json exception!", jSONException);
            if (postNotificationResponseHandler == null) return;
            try {
                postNotificationResponseHandler.onFailure(new JSONObject("{'error': 'HTTP create notification json exception!'}"));
                return;
            }
            catch (JSONException jSONException2) {
                jSONException2.printStackTrace();
            }
            return;
        }
    }

    public static void promptLocation() {
        OneSignal.promptLocation(null, false);
    }

    static void promptLocation(final OSPromptActionCompletionCallback oSPromptActionCompletionCallback, final boolean bl) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("promptLocation()")) {
            return;
        }
        Runnable runnable = new Runnable(){

            public void run() {
                1 var1_1 = new 1(this);
                LocationController.getLocation(OneSignal.appContext, true, bl, (LocationController.LocationHandler)var1_1);
                promptedLocation = true;
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Could not prompt for location at this time - moving this operation to awaiting queue.");
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    public static void provideUserConsent(boolean bl) {
        DelayedConsentInitializationParameters delayedConsentInitializationParameters;
        boolean bl2 = OneSignal.userProvidedPrivacyConsent();
        OneSignal.saveUserConsentStatus(bl);
        if (!bl2 && bl && (delayedConsentInitializationParameters = delayedInitParams) != null) {
            OneSignal.init(delayedConsentInitializationParameters.context, OneSignal.delayedInitParams.googleProjectNumber, OneSignal.delayedInitParams.appId, OneSignal.delayedInitParams.openedHandler, OneSignal.delayedInitParams.receivedHandler);
            delayedInitParams = null;
        }
    }

    private static boolean pushStatusRuntimeError(int n) {
        return n < -6;
    }

    private static void registerForPushToken() {
        OneSignal.getPushRegistrator().registerForPush(appContext, mGoogleProjectNumber, new PushRegistrator.RegisteredHandler(){

            @Override
            public void complete(String string2, int n) {
                if (n < 1) {
                    if (OneSignalStateSynchronizer.getRegistrationId() == null && (subscribableStatus == 1 || OneSignal.pushStatusRuntimeError(subscribableStatus))) {
                        subscribableStatus = n;
                    }
                } else if (OneSignal.pushStatusRuntimeError(subscribableStatus)) {
                    subscribableStatus = n;
                }
                lastRegistrationId = string2;
                registerForPushFired = true;
                OneSignal.getCurrentSubscriptionState(OneSignal.appContext).setPushToken(string2);
                OneSignal.registerUser();
            }
        });
    }

    private static void registerUser() {
        LOG_LEVEL lOG_LEVEL = LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("registerUser:registerForPushFired:");
        stringBuilder.append(registerForPushFired);
        stringBuilder.append(", locationFired: ");
        stringBuilder.append(locationFired);
        stringBuilder.append(", remoteParams: ");
        stringBuilder.append((Object)remoteParams);
        stringBuilder.append(", appId: ");
        stringBuilder.append(appId);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
        if (registerForPushFired && locationFired && remoteParams != null) {
            if (appId == null) {
                return;
            }
            new Thread(new Runnable(){

                public void run() {
                    try {
                        OneSignal.registerUserTask();
                        OneSignalChromeTabAndroidFrame.setup(OneSignal.appId, userId, AdvertisingIdProviderGPS.getLastValue());
                        return;
                    }
                    catch (JSONException jSONException) {
                        OneSignal.Log(LOG_LEVEL.FATAL, "FATAL Error registering device!", jSONException);
                        return;
                    }
                }
            }, "OS_REG_USER").start();
            return;
        }
    }

    private static void registerUserTask() throws JSONException {
        String string2;
        LocationController.LocationPoint locationPoint;
        String string3 = appContext.getPackageName();
        PackageManager packageManager = appContext.getPackageManager();
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("app_id", (Object)OneSignal.getSavedAppId());
        if (OneSignal.getAdIdProvider() != null && (string2 = OneSignal.getAdIdProvider().getIdentifier(appContext)) != null) {
            jSONObject.put("ad_id", (Object)string2);
        }
        jSONObject.put("device_os", (Object)Build.VERSION.RELEASE);
        jSONObject.put("timezone", OneSignal.getTimeZoneOffset());
        jSONObject.put("language", (Object)OSUtils.getCorrectedLanguage());
        jSONObject.put("sdk", (Object)VERSION);
        jSONObject.put("sdk_type", (Object)sdkType);
        jSONObject.put("android_package", (Object)string3);
        jSONObject.put("device_model", (Object)Build.MODEL);
        try {
            jSONObject.put("game_version", packageManager.getPackageInfo((String)string3, (int)0).versionCode);
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            // empty catch block
        }
        jSONObject.put("net_type", (Object)osUtils.getNetType());
        jSONObject.put("carrier", (Object)osUtils.getCarrierName());
        jSONObject.put("rooted", RootToolsInternalMethods.isRooted());
        OneSignalStateSynchronizer.updateDeviceInfo(jSONObject);
        JSONObject jSONObject2 = new JSONObject();
        jSONObject2.put("identifier", (Object)lastRegistrationId);
        jSONObject2.put("subscribableStatus", subscribableStatus);
        jSONObject2.put("androidPermission", OneSignal.areNotificationsEnabledForSubscribedState());
        jSONObject2.put("device_type", osUtils.getDeviceType());
        OneSignalStateSynchronizer.updatePushState(jSONObject2);
        if (shareLocation && (locationPoint = lastLocationPoint) != null) {
            OneSignalStateSynchronizer.updateLocation(locationPoint);
        }
        OneSignalStateSynchronizer.readyToUpdate(true);
        waitingToPostStateSync = false;
    }

    public static void removeEmailSubscriptionObserver(OSEmailSubscriptionObserver oSEmailSubscriptionObserver) {
        if (appContext == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Could not modify email subscription observer");
            return;
        }
        OneSignal.getEmailSubscriptionStateChangesObserver().removeObserver(oSEmailSubscriptionObserver);
    }

    public static void removeExternalUserId() {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("removeExternalUserId()")) {
            return;
        }
        OneSignal.removeExternalUserId(null);
    }

    public static void removeExternalUserId(OSExternalUserIdUpdateCompletionHandler oSExternalUserIdUpdateCompletionHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("removeExternalUserId()")) {
            return;
        }
        OneSignal.setExternalUserId("", oSExternalUserIdUpdateCompletionHandler);
    }

    public static void removeInAppMessageClickHandler() {
        OneSignal.mInitBuilder.mInAppMessageClickHandler = null;
    }

    public static void removeNotificationOpenedHandler() {
        OneSignal.mInitBuilder.mNotificationOpenedHandler = null;
    }

    public static void removeNotificationReceivedHandler() {
        OneSignal.mInitBuilder.mNotificationReceivedHandler = null;
    }

    public static void removePermissionObserver(OSPermissionObserver oSPermissionObserver) {
        if (appContext == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Could not modify permission observer");
            return;
        }
        OneSignal.getPermissionStateChangesObserver().removeObserver(oSPermissionObserver);
    }

    public static void removeSubscriptionObserver(OSSubscriptionObserver oSSubscriptionObserver) {
        if (appContext == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Could not modify subscription observer");
            return;
        }
        OneSignal.getSubscriptionStateChangesObserver().removeObserver(oSSubscriptionObserver);
    }

    public static void removeTriggerForKey(String string2) {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)string2);
        OneSignal.getInAppMessageController().removeTriggersForKeys((Collection<String>)arrayList);
    }

    public static void removeTriggersForKeys(Collection<String> collection) {
        OneSignal.getInAppMessageController().removeTriggersForKeys(collection);
    }

    public static void removeTriggersForKeysFromJsonArrayString(String string2) {
        try {
            JSONArray jSONArray = new JSONArray(string2);
            Collection<String> collection = OSUtils.extractStringsFromCollection(JSONUtils.jsonArrayToList(jSONArray));
            if (jSONArray.length() != collection.size()) {
                OneSignal.Log(LOG_LEVEL.WARN, "removeTriggersForKeysFromJsonArrayString: Skipped removing non-String type keys ");
            }
            OneSignal.getInAppMessageController().removeTriggersForKeys(collection);
            return;
        }
        catch (JSONException jSONException) {
            OneSignal.Log(LOG_LEVEL.ERROR, "removeTriggersForKeysFromJsonArrayString, invalid json", jSONException);
            return;
        }
    }

    public static boolean requiresUserPrivacyConsent() {
        return requiresUserPrivacyConsent && !OneSignal.userProvidedPrivacyConsent();
    }

    private static void runGetTags() {
        if (OneSignal.getUserId() == null) {
            return;
        }
        OneSignal.internalFireGetTagsCallbacks();
    }

    private static void runNotificationOpenedCallback(JSONArray jSONArray, boolean bl, boolean bl2) {
        Builder builder = mInitBuilder;
        if (builder != null && builder.mNotificationOpenedHandler != null) {
            OneSignal.fireNotificationOpenedHandler(OneSignal.generateOsNotificationOpenResult(jSONArray, bl, bl2));
            return;
        }
        unprocessedOpenedNotifis.add((Object)jSONArray);
    }

    private static void saveAppId(String string2) {
        if (appContext == null) {
            return;
        }
        OneSignalPrefs.saveString(OneSignalPrefs.PREFS_ONESIGNAL, "GT_APP_ID", string2);
    }

    static void saveEmailId(String string2) {
        emailId = string2;
        if (appContext == null) {
            return;
        }
        String string3 = OneSignalPrefs.PREFS_ONESIGNAL;
        String string4 = "".equals((Object)emailId) ? null : emailId;
        OneSignalPrefs.saveString(string3, "OS_EMAIL_ID", string4);
    }

    static void saveFilterOtherGCMReceivers(boolean bl) {
        if (appContext == null) {
            return;
        }
        OneSignalPrefs.saveBool(OneSignalPrefs.PREFS_ONESIGNAL, "OS_FILTER_OTHER_GCM_RECEIVERS", bl);
    }

    static void saveUserConsentStatus(boolean bl) {
        OneSignalPrefs.saveBool(OneSignalPrefs.PREFS_ONESIGNAL, "ONESIGNAL_USER_PROVIDED_CONSENT", bl);
    }

    static void saveUserId(String string2) {
        userId = string2;
        if (appContext == null) {
            return;
        }
        OneSignalPrefs.saveString(OneSignalPrefs.PREFS_ONESIGNAL, "GT_PLAYER_ID", userId);
    }

    private static boolean scheduleSyncService() {
        boolean bl = OneSignalStateSynchronizer.persist();
        if (bl) {
            OneSignalSyncServiceUtils.scheduleSyncTask(appContext);
        }
        return LocationController.scheduleUpdate(appContext) || bl;
        {
        }
    }

    static void sendClickActionOutcomes(List<OSInAppMessageOutcome> list) {
        OSOutcomeEventsController oSOutcomeEventsController = outcomeEventsController;
        if (oSOutcomeEventsController == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Make sure OneSignal.init is called first");
            return;
        }
        oSOutcomeEventsController.sendClickActionOutcomes(list);
    }

    public static void sendOutcome(String string2) {
        OneSignal.sendOutcome(string2, null);
    }

    public static void sendOutcome(String string2, OutcomeCallback outcomeCallback) {
        if (!OneSignal.isValidOutcomeEntry(string2)) {
            return;
        }
        OSOutcomeEventsController oSOutcomeEventsController = outcomeEventsController;
        if (oSOutcomeEventsController == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Make sure OneSignal.init is called first");
            return;
        }
        oSOutcomeEventsController.sendOutcomeEvent(string2, outcomeCallback);
    }

    public static void sendOutcomeWithValue(String string2, float f) {
        OneSignal.sendOutcomeWithValue(string2, f, null);
    }

    public static void sendOutcomeWithValue(String string2, float f, OutcomeCallback outcomeCallback) {
        if (OneSignal.isValidOutcomeEntry(string2)) {
            if (!OneSignal.isValidOutcomeValue(f)) {
                return;
            }
            OSOutcomeEventsController oSOutcomeEventsController = outcomeEventsController;
            if (oSOutcomeEventsController == null) {
                OneSignal.Log(LOG_LEVEL.ERROR, "Make sure OneSignal.init is called first");
                return;
            }
            oSOutcomeEventsController.sendOutcomeEventWithValue(string2, f, outcomeCallback);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void sendPurchases(JSONArray jSONArray, boolean bl, OneSignalRestClient.ResponseHandler responseHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("sendPurchases()")) {
            return;
        }
        if (OneSignal.getUserId() == null) {
            IAPUpdateJob iAPUpdateJob;
            iapUpdateJob = iAPUpdateJob = new IAPUpdateJob(jSONArray);
            iAPUpdateJob.newAsExisting = bl;
            OneSignal.iapUpdateJob.restResponseHandler = responseHandler;
            return;
        }
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("app_id", (Object)OneSignal.getSavedAppId());
            if (bl) {
                jSONObject.put("existing", true);
            }
            jSONObject.put("purchases", (Object)jSONArray);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("players/");
            stringBuilder.append(OneSignal.getUserId());
            stringBuilder.append("/on_purchase");
            OneSignalRestClient.post(stringBuilder.toString(), jSONObject, responseHandler);
            if (OneSignal.getEmailId() != null) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("players/");
                stringBuilder2.append(OneSignal.getEmailId());
                stringBuilder2.append("/on_purchase");
                OneSignalRestClient.post(stringBuilder2.toString(), jSONObject, null);
            }
            return;
        }
        catch (Throwable throwable) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Failed to generate JSON for sendPurchases.", throwable);
            return;
        }
    }

    public static void sendTag(String string2, String string3) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("sendTag()")) {
            return;
        }
        try {
            OneSignal.sendTags(new JSONObject().put(string2, (Object)string3));
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    public static void sendTags(String string2) {
        try {
            OneSignal.sendTags(new JSONObject(string2));
            return;
        }
        catch (JSONException jSONException) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Generating JSONObject for sendTags failed!", jSONException);
            return;
        }
    }

    public static void sendTags(JSONObject jSONObject) {
        OneSignal.sendTags(jSONObject, null);
    }

    public static void sendTags(final JSONObject jSONObject, final ChangeTagsUpdateHandler changeTagsUpdateHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("sendTags()")) {
            return;
        }
        Runnable runnable = new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                if (jSONObject == null) {
                    ChangeTagsUpdateHandler changeTagsUpdateHandler2 = changeTagsUpdateHandler;
                    if (changeTagsUpdateHandler2 != null) {
                        changeTagsUpdateHandler2.onFailure(new SendTagsError(-1, "Attempted to send null tags"));
                    }
                    return;
                }
                JSONObject jSONObject3 = OneSignalStateSynchronizer.getTags((boolean)false).result;
                JSONObject jSONObject2 = new JSONObject();
                Iterator iterator = jSONObject.keys();
                while (iterator.hasNext()) {
                    String string2 = (String)iterator.next();
                    try {
                        Object object = jSONObject.opt(string2);
                        if (!(object instanceof JSONArray) && !(object instanceof JSONObject)) {
                            boolean bl = jSONObject.isNull(string2);
                            if (!bl && !"".equals(object)) {
                                jSONObject2.put(string2, (Object)object.toString());
                                continue;
                            }
                            if (jSONObject3 == null || !jSONObject3.has(string2)) continue;
                            jSONObject2.put(string2, (Object)"");
                            continue;
                        }
                        LOG_LEVEL lOG_LEVEL = LOG_LEVEL.ERROR;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Omitting key '");
                        stringBuilder.append(string2);
                        stringBuilder.append("'! sendTags DO NOT supported nested values!");
                        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
                    }
                    catch (Throwable throwable) {}
                }
                if (!jSONObject2.toString().equals((Object)"{}")) {
                    OneSignalStateSynchronizer.sendTags(jSONObject2, changeTagsUpdateHandler);
                    return;
                }
                ChangeTagsUpdateHandler changeTagsUpdateHandler3 = changeTagsUpdateHandler;
                if (changeTagsUpdateHandler3 != null) {
                    changeTagsUpdateHandler3.onSuccess(jSONObject3);
                }
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        OneSignal.Log(LOG_LEVEL.ERROR, "You must initialize OneSignal before modifying tags!Moving this operation to a pending task queue.");
        if (changeTagsUpdateHandler != null) {
            changeTagsUpdateHandler.onFailure(new SendTagsError(-1, "You must initialize OneSignal before modifying tags!Moving this operation to a pending task queue."));
        }
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    public static void sendUniqueOutcome(String string2) {
        OneSignal.sendUniqueOutcome(string2, null);
    }

    public static void sendUniqueOutcome(String string2, OutcomeCallback outcomeCallback) {
        if (!OneSignal.isValidOutcomeEntry(string2)) {
            return;
        }
        OSOutcomeEventsController oSOutcomeEventsController = outcomeEventsController;
        if (oSOutcomeEventsController == null) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Make sure OneSignal.init is called first");
            return;
        }
        oSOutcomeEventsController.sendUniqueOutcomeEvent(string2, outcomeCallback);
    }

    public static void setAppContext(Context context) {
        Context context2;
        if (context == null) {
            OneSignal.Log(LOG_LEVEL.WARN, "setAppContext(null) is not valid, ignoring!");
            return;
        }
        boolean bl = appContext == null;
        appContext = context2 = context.getApplicationContext();
        ActivityLifecycleListener.registerActivityLifecycleCallbacks((Application)context2);
        if (bl) {
            if (outcomeEventsFactory == null) {
                outcomeEventsFactory = new OSOutcomeEventsFactory(logger, apiClient, OneSignal.getDBHelperInstance(), preferences);
            }
            sessionManager.initSessionFromCache();
            outcomeEventsController = new OSOutcomeEventsController(sessionManager, outcomeEventsFactory);
            OneSignalPrefs.startDelayedWrite();
            OneSignalCacheCleaner.cleanOldCachedData(context);
        }
    }

    public static void setEmail(String string2) {
        OneSignal.setEmail(string2, null, null);
    }

    public static void setEmail(String string2, EmailUpdateHandler emailUpdateHandler) {
        OneSignal.setEmail(string2, null, emailUpdateHandler);
    }

    public static void setEmail(String string2, String string3) {
        OneSignal.setEmail(string2, string3, null);
    }

    public static void setEmail(final String string2, final String string3, EmailUpdateHandler emailUpdateHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("setEmail()")) {
            return;
        }
        if (!OSUtils.isValidEmail(string2)) {
            if (emailUpdateHandler != null) {
                emailUpdateHandler.onFailure(new EmailUpdateError(EmailErrorType.VALIDATION, "Email is invalid"));
            }
            OneSignal.Log(LOG_LEVEL.ERROR, "Email is invalid");
            return;
        }
        OneSignalRemoteParams.Params params = remoteParams;
        if (params != null && params.useEmailAuth && (string3 == null || string3.length() == 0)) {
            if (emailUpdateHandler != null) {
                emailUpdateHandler.onFailure(new EmailUpdateError(EmailErrorType.REQUIRES_EMAIL_AUTH, "Email authentication (auth token) is set to REQUIRED for this application. Please provide an auth token from your backend server or change the setting in the OneSignal dashboard."));
            }
            OneSignal.Log(LOG_LEVEL.ERROR, "Email authentication (auth token) is set to REQUIRED for this application. Please provide an auth token from your backend server or change the setting in the OneSignal dashboard.");
            return;
        }
        OneSignal.emailUpdateHandler = emailUpdateHandler;
        Runnable runnable = new Runnable(){

            public void run() {
                String string22 = string2.trim();
                String string32 = string3;
                if (string32 != null) {
                    string32.toLowerCase();
                }
                OneSignal.getCurrentEmailSubscriptionState(OneSignal.appContext).setEmailAddress(string22);
                OneSignalStateSynchronizer.setEmail(string22.toLowerCase(), string32);
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        OneSignal.Log(LOG_LEVEL.ERROR, "You should initialize OneSignal before calling setEmail! Moving this operation to a pending task queue.");
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    public static void setExternalUserId(String string2) {
        OneSignal.setExternalUserId(string2, null, null);
    }

    public static void setExternalUserId(String string2, OSExternalUserIdUpdateCompletionHandler oSExternalUserIdUpdateCompletionHandler) {
        OneSignal.setExternalUserId(string2, null, oSExternalUserIdUpdateCompletionHandler);
    }

    public static void setExternalUserId(String string2, String string3) {
        OneSignal.setExternalUserId(string2, string3, null);
    }

    public static void setExternalUserId(final String string2, final String string3, final OSExternalUserIdUpdateCompletionHandler oSExternalUserIdUpdateCompletionHandler) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("setExternalUserId()")) {
            return;
        }
        Runnable runnable = new Runnable(){

            public void run() {
                String string22;
                String string32 = string2;
                if (string32 == null) {
                    OneSignal.Log(LOG_LEVEL.WARN, "External id can't be null, set an empty string to remove an external id");
                    return;
                }
                if (!string32.isEmpty() && string2.length() > 0 && OneSignal.remoteParams != null && OneSignal.remoteParams.useUserIdAuth && ((string22 = string3) == null || string22.length() == 0)) {
                    OneSignal.Log(LOG_LEVEL.ERROR, "External Id authentication (auth token) is set to REQUIRED for this application. Please provide an auth token from your backend server or change the setting in the OneSignal dashboard.");
                    return;
                }
                String string4 = string3;
                if (string4 != null) {
                    string4 = string3.toLowerCase();
                }
                try {
                    OneSignalStateSynchronizer.setExternalUserId(string2, string4, oSExternalUserIdUpdateCompletionHandler);
                    return;
                }
                catch (JSONException jSONException) {
                    String string5 = string2.equals((Object)"") ? "remove" : "set";
                    LOG_LEVEL lOG_LEVEL = LOG_LEVEL.ERROR;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Attempted to ");
                    stringBuilder.append(string5);
                    stringBuilder.append(" external ID but encountered a JSON exception");
                    OneSignal.onesignalLog(lOG_LEVEL, stringBuilder.toString());
                    jSONException.printStackTrace();
                    return;
                }
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    public static void setInFocusDisplaying(int n) {
        OneSignal.setInFocusDisplaying(OneSignal.getInFocusDisplaying(n));
    }

    public static void setInFocusDisplaying(OSInFocusDisplayOption oSInFocusDisplayOption) {
        OneSignal.mInitBuilder.mDisplayOptionCarryOver = true;
        OneSignal.mInitBuilder.mDisplayOption = oSInFocusDisplayOption;
    }

    static void setInForeground(boolean bl) {
        inForeground = bl;
    }

    static void setLastSessionTime(long l) {
        OneSignalPrefs.saveLong(OneSignalPrefs.PREFS_ONESIGNAL, "OS_LAST_SESSION_TIME", l);
    }

    public static void setLocationShared(boolean bl) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("setLocationShared()")) {
            return;
        }
        shareLocation = bl;
        if (!bl) {
            OneSignalStateSynchronizer.clearLocation();
        }
        LOG_LEVEL lOG_LEVEL = LOG_LEVEL.DEBUG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("shareLocation:");
        stringBuilder.append(shareLocation);
        OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
    }

    public static void setLogLevel(int n, int n2) {
        OneSignal.setLogLevel(OneSignal.getLogLevel(n), OneSignal.getLogLevel(n2));
    }

    public static void setLogLevel(LOG_LEVEL lOG_LEVEL, LOG_LEVEL lOG_LEVEL2) {
        logCatLevel = lOG_LEVEL;
        visualLogLevel = lOG_LEVEL2;
    }

    public static void setRequiresUserPrivacyConsent(boolean bl) {
        if (requiresUserPrivacyConsent && !bl) {
            OneSignal.Log(LOG_LEVEL.ERROR, "Cannot change requiresUserPrivacyConsent() from TRUE to FALSE");
            return;
        }
        requiresUserPrivacyConsent = bl;
    }

    static void setSessionManager(OSSessionManager oSSessionManager) {
        sessionManager = oSSessionManager;
    }

    static void setSharedPreferences(OSSharedPreferences oSSharedPreferences) {
        preferences = oSSharedPreferences;
    }

    public static void setSubscription(final boolean bl) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("setSubscription()")) {
            return;
        }
        Runnable runnable = new Runnable(){

            public void run() {
                OneSignal.getCurrentSubscriptionState(OneSignal.appContext).setUserSubscriptionSetting(bl);
                OneSignalStateSynchronizer.setSubscription(bl);
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        OneSignal.Log(LOG_LEVEL.ERROR, "OneSignal.init has not been called. Moving subscription action to a waiting task queue.");
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    static void setTrackerFactory(OSTrackerFactory oSTrackerFactory) {
        trackerFactory = oSTrackerFactory;
    }

    private static void setupPrivacyConsent(Context context) {
        try {
            OneSignal.setRequiresUserPrivacyConsent("ENABLE".equalsIgnoreCase(context.getPackageManager().getApplicationInfo((String)context.getPackageName(), (int)128).metaData.getString("com.onesignal.PrivacyConsent")));
            return;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return;
        }
    }

    private static boolean shouldInitDirectSessionFromNotificationOpen(Context context, boolean bl, boolean bl2, boolean bl3) {
        return !bl && !bl2 && !bl3 && !foreground && OneSignal.startOrResumeApp(context);
    }

    static boolean shouldLogUserPrivacyConsentErrorMessageForMethodName(String string2) {
        if (OneSignal.requiresUserPrivacyConsent()) {
            if (string2 != null) {
                LOG_LEVEL lOG_LEVEL = LOG_LEVEL.WARN;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Method ");
                stringBuilder.append(string2);
                stringBuilder.append(" was called before the user provided privacy consent. Your application is set to require the user's privacy consent before the OneSignal SDK can be initialized. Please ensure the user has provided consent before calling this method. You can check the latest OneSignal consent status by calling OneSignal.userProvidedPrivacyConsent()");
                OneSignal.Log(lOG_LEVEL, stringBuilder.toString());
            }
            return true;
        }
        return false;
    }

    private static boolean shouldRunTaskThroughQueue() {
        boolean bl = initDone;
        if (bl && pendingTaskExecutor == null) {
            return false;
        }
        if (!bl && pendingTaskExecutor == null) {
            return true;
        }
        ExecutorService executorService = pendingTaskExecutor;
        return executorService != null && !executorService.isShutdown();
    }

    public static Builder startInit(Context context) {
        return new Builder(context);
    }

    private static void startLocationUpdate() {
        LocationController.LocationHandler locationHandler = new LocationController.LocationHandler(){

            @Override
            public LocationController.PermissionType getType() {
                return LocationController.PermissionType.STARTUP;
            }

            @Override
            public void onComplete(LocationController.LocationPoint locationPoint) {
                lastLocationPoint = locationPoint;
                locationFired = true;
                OneSignal.registerUser();
            }
        };
        boolean bl = OneSignal.mInitBuilder.mPromptLocation;
        boolean bl2 = true;
        boolean bl3 = bl && !promptedLocation;
        if (!promptedLocation && !OneSignal.mInitBuilder.mPromptLocation) {
            bl2 = false;
        }
        promptedLocation = bl2;
        LocationController.getLocation(appContext, bl3, false, locationHandler);
    }

    static boolean startOrResumeApp(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (intent != null) {
            intent.setFlags(268566528);
            context.startActivity(intent);
            return true;
        }
        return false;
    }

    private static void startPendingTasks() {
        if (!taskQueueWaitingForInit.isEmpty()) {
            pendingTaskExecutor = Executors.newSingleThreadExecutor((ThreadFactory)new ThreadFactory(){

                public Thread newThread(Runnable runnable) {
                    Thread thread = new Thread(runnable);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("OS_PENDING_EXECUTOR_");
                    stringBuilder.append(thread.getId());
                    thread.setName(stringBuilder.toString());
                    return thread;
                }
            });
            while (!taskQueueWaitingForInit.isEmpty()) {
                pendingTaskExecutor.submit((Runnable)taskQueueWaitingForInit.poll());
            }
        }
    }

    private static void startRegistrationOrOnSession() {
        if (waitingToPostStateSync) {
            return;
        }
        waitingToPostStateSync = true;
        if (OneSignalStateSynchronizer.getSyncAsNewSession()) {
            locationFired = false;
        }
        OneSignal.startLocationUpdate();
        registerForPushFired = false;
        OneSignal.makeAndroidParamsRequest();
    }

    @Deprecated
    public static void syncHashedEmail(final String string2) {
        if (OneSignal.shouldLogUserPrivacyConsentErrorMessageForMethodName("SyncHashedEmail()")) {
            return;
        }
        if (!OSUtils.isValidEmail(string2)) {
            return;
        }
        Runnable runnable = new Runnable(){

            public void run() {
                OneSignalStateSynchronizer.syncHashedEmail(string2.trim().toLowerCase());
            }
        };
        if (appContext != null && !OneSignal.shouldRunTaskThroughQueue()) {
            runnable.run();
            return;
        }
        OneSignal.Log(LOG_LEVEL.ERROR, "You should initialize OneSignal before calling syncHashedEmail! Moving this operation to a pending task queue.");
        OneSignal.addTaskToQueue(new PendingTaskRunnable(runnable));
    }

    static void updateEmailIdDependents(String string2) {
        OneSignal.saveEmailId(string2);
        OneSignal.getCurrentEmailSubscriptionState(appContext).setEmailUserId(string2);
        try {
            OneSignalStateSynchronizer.updatePushState(new JSONObject().put("parent_player_id", (Object)string2));
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    static void updateUserIdDependents(String string2) {
        OneSignal.saveUserId(string2);
        OneSignal.fireIdsAvailableCallback();
        OneSignal.internalFireGetTagsCallbacks();
        OneSignal.getCurrentSubscriptionState(appContext).setUserId(string2);
        IAPUpdateJob iAPUpdateJob = iapUpdateJob;
        if (iAPUpdateJob != null) {
            OneSignal.sendPurchases(iAPUpdateJob.toReport, OneSignal.iapUpdateJob.newAsExisting, OneSignal.iapUpdateJob.restResponseHandler);
            iapUpdateJob = null;
        }
        OneSignalStateSynchronizer.refreshEmailState();
        OneSignalChromeTabAndroidFrame.setup(appId, string2, AdvertisingIdProviderGPS.getLastValue());
    }

    public static boolean userProvidedPrivacyConsent() {
        return OneSignal.getSavedUserConsentStatus();
    }

    public static final class AppEntryAction
    extends Enum<AppEntryAction> {
        private static final /* synthetic */ AppEntryAction[] $VALUES;
        public static final /* enum */ AppEntryAction APP_CLOSE;
        public static final /* enum */ AppEntryAction APP_OPEN;
        public static final /* enum */ AppEntryAction NOTIFICATION_CLICK;

        static {
            AppEntryAction appEntryAction;
            AppEntryAction appEntryAction2;
            AppEntryAction appEntryAction3;
            NOTIFICATION_CLICK = appEntryAction = new AppEntryAction();
            APP_OPEN = appEntryAction2 = new AppEntryAction();
            APP_CLOSE = appEntryAction3 = new AppEntryAction();
            $VALUES = new AppEntryAction[]{appEntryAction, appEntryAction2, appEntryAction3};
        }

        public static AppEntryAction valueOf(String string2) {
            return (AppEntryAction)Enum.valueOf(AppEntryAction.class, (String)string2);
        }

        public static AppEntryAction[] values() {
            return (AppEntryAction[])$VALUES.clone();
        }

        public boolean isAppClose() {
            return this.equals((Object)APP_CLOSE);
        }

        public boolean isAppOpen() {
            return this.equals((Object)APP_OPEN);
        }

        public boolean isNotificationClick() {
            return this.equals((Object)NOTIFICATION_CLICK);
        }
    }

    public static class Builder {
        Context mContext;
        boolean mDisableGmsMissingPrompt;
        OSInFocusDisplayOption mDisplayOption = OSInFocusDisplayOption.InAppAlert;
        boolean mDisplayOptionCarryOver;
        boolean mFilterOtherGCMReceivers;
        InAppMessageClickHandler mInAppMessageClickHandler;
        NotificationOpenedHandler mNotificationOpenedHandler;
        NotificationReceivedHandler mNotificationReceivedHandler;
        boolean mPromptLocation;
        boolean mUnsubscribeWhenNotificationsAreDisabled;

        private Builder() {
        }

        private Builder(Context context) {
            this.mContext = context;
        }

        private void setDisplayOptionCarryOver(boolean bl) {
            this.mDisplayOptionCarryOver = bl;
        }

        public Builder autoPromptLocation(boolean bl) {
            this.mPromptLocation = bl;
            return this;
        }

        public Builder disableGmsMissingPrompt(boolean bl) {
            this.mDisableGmsMissingPrompt = bl;
            return this;
        }

        public Builder filterOtherGCMReceivers(boolean bl) {
            this.mFilterOtherGCMReceivers = bl;
            return this;
        }

        public Builder inFocusDisplaying(OSInFocusDisplayOption oSInFocusDisplayOption) {
            this.mDisplayOptionCarryOver = false;
            this.mDisplayOption = oSInFocusDisplayOption;
            return this;
        }

        public void init() {
            OneSignal.init(this);
        }

        public Builder setInAppMessageClickHandler(InAppMessageClickHandler inAppMessageClickHandler) {
            this.mInAppMessageClickHandler = inAppMessageClickHandler;
            return this;
        }

        public Builder setNotificationOpenedHandler(NotificationOpenedHandler notificationOpenedHandler) {
            this.mNotificationOpenedHandler = notificationOpenedHandler;
            return this;
        }

        public Builder setNotificationReceivedHandler(NotificationReceivedHandler notificationReceivedHandler) {
            this.mNotificationReceivedHandler = notificationReceivedHandler;
            return this;
        }

        public Builder unsubscribeWhenNotificationsAreDisabled(boolean bl) {
            this.mUnsubscribeWhenNotificationsAreDisabled = bl;
            return this;
        }
    }

    public static interface ChangeTagsUpdateHandler {
        public void onFailure(SendTagsError var1);

        public void onSuccess(JSONObject var1);
    }

    public static final class EmailErrorType
    extends Enum<EmailErrorType> {
        private static final /* synthetic */ EmailErrorType[] $VALUES;
        public static final /* enum */ EmailErrorType INVALID_OPERATION;
        public static final /* enum */ EmailErrorType NETWORK;
        public static final /* enum */ EmailErrorType REQUIRES_EMAIL_AUTH;
        public static final /* enum */ EmailErrorType VALIDATION;

        static {
            EmailErrorType emailErrorType;
            EmailErrorType emailErrorType2;
            EmailErrorType emailErrorType3;
            EmailErrorType emailErrorType4;
            VALIDATION = emailErrorType3 = new EmailErrorType();
            REQUIRES_EMAIL_AUTH = emailErrorType4 = new EmailErrorType();
            INVALID_OPERATION = emailErrorType2 = new EmailErrorType();
            NETWORK = emailErrorType = new EmailErrorType();
            $VALUES = new EmailErrorType[]{emailErrorType3, emailErrorType4, emailErrorType2, emailErrorType};
        }

        public static EmailErrorType valueOf(String string2) {
            return (EmailErrorType)Enum.valueOf(EmailErrorType.class, (String)string2);
        }

        public static EmailErrorType[] values() {
            return (EmailErrorType[])$VALUES.clone();
        }
    }

    public static class EmailUpdateError {
        private String message;
        private EmailErrorType type;

        EmailUpdateError(EmailErrorType emailErrorType, String string2) {
            this.type = emailErrorType;
            this.message = string2;
        }

        public String getMessage() {
            return this.message;
        }

        public EmailErrorType getType() {
            return this.type;
        }
    }

    public static interface EmailUpdateHandler {
        public void onFailure(EmailUpdateError var1);

        public void onSuccess();
    }

    public static interface GetTagsHandler {
        public void tagsAvailable(JSONObject var1);
    }

    private static class IAPUpdateJob {
        boolean newAsExisting;
        OneSignalRestClient.ResponseHandler restResponseHandler;
        JSONArray toReport;

        IAPUpdateJob(JSONArray jSONArray) {
            this.toReport = jSONArray;
        }
    }

    public static interface IdsAvailableHandler {
        public void idsAvailable(String var1, String var2);
    }

    public static interface InAppMessageClickHandler {
        public void inAppMessageClicked(OSInAppMessageAction var1);
    }

    public static final class LOG_LEVEL
    extends Enum<LOG_LEVEL> {
        private static final /* synthetic */ LOG_LEVEL[] $VALUES;
        public static final /* enum */ LOG_LEVEL DEBUG;
        public static final /* enum */ LOG_LEVEL ERROR;
        public static final /* enum */ LOG_LEVEL FATAL;
        public static final /* enum */ LOG_LEVEL INFO;
        public static final /* enum */ LOG_LEVEL NONE;
        public static final /* enum */ LOG_LEVEL VERBOSE;
        public static final /* enum */ LOG_LEVEL WARN;

        static {
            LOG_LEVEL lOG_LEVEL;
            LOG_LEVEL lOG_LEVEL2;
            LOG_LEVEL lOG_LEVEL3;
            LOG_LEVEL lOG_LEVEL4;
            LOG_LEVEL lOG_LEVEL5;
            LOG_LEVEL lOG_LEVEL6;
            LOG_LEVEL lOG_LEVEL7;
            NONE = lOG_LEVEL3 = new LOG_LEVEL();
            FATAL = lOG_LEVEL2 = new LOG_LEVEL();
            ERROR = lOG_LEVEL6 = new LOG_LEVEL();
            WARN = lOG_LEVEL4 = new LOG_LEVEL();
            INFO = lOG_LEVEL7 = new LOG_LEVEL();
            DEBUG = lOG_LEVEL = new LOG_LEVEL();
            VERBOSE = lOG_LEVEL5 = new LOG_LEVEL();
            $VALUES = new LOG_LEVEL[]{lOG_LEVEL3, lOG_LEVEL2, lOG_LEVEL6, lOG_LEVEL4, lOG_LEVEL7, lOG_LEVEL, lOG_LEVEL5};
        }

        public static LOG_LEVEL valueOf(String string2) {
            return (LOG_LEVEL)Enum.valueOf(LOG_LEVEL.class, (String)string2);
        }

        public static LOG_LEVEL[] values() {
            return (LOG_LEVEL[])$VALUES.clone();
        }
    }

    public static interface NotificationOpenedHandler {
        public void notificationOpened(OSNotificationOpenResult var1);
    }

    public static interface NotificationReceivedHandler {
        public void notificationReceived(OSNotification var1);
    }

    public static interface OSExternalUserIdUpdateCompletionHandler {
        public void onComplete(JSONObject var1);
    }

    public static final class OSInFocusDisplayOption
    extends Enum<OSInFocusDisplayOption> {
        private static final /* synthetic */ OSInFocusDisplayOption[] $VALUES;
        public static final /* enum */ OSInFocusDisplayOption InAppAlert;
        public static final /* enum */ OSInFocusDisplayOption None;
        public static final /* enum */ OSInFocusDisplayOption Notification;

        static {
            OSInFocusDisplayOption oSInFocusDisplayOption;
            OSInFocusDisplayOption oSInFocusDisplayOption2;
            OSInFocusDisplayOption oSInFocusDisplayOption3;
            None = oSInFocusDisplayOption = new OSInFocusDisplayOption();
            InAppAlert = oSInFocusDisplayOption2 = new OSInFocusDisplayOption();
            Notification = oSInFocusDisplayOption3 = new OSInFocusDisplayOption();
            $VALUES = new OSInFocusDisplayOption[]{oSInFocusDisplayOption, oSInFocusDisplayOption2, oSInFocusDisplayOption3};
        }

        public static OSInFocusDisplayOption valueOf(String string2) {
            return (OSInFocusDisplayOption)Enum.valueOf(OSInFocusDisplayOption.class, (String)string2);
        }

        public static OSInFocusDisplayOption[] values() {
            return (OSInFocusDisplayOption[])$VALUES.clone();
        }
    }

    static interface OSInternalExternalUserIdUpdateCompletionHandler {
        public void onComplete(String var1, boolean var2);
    }

    static interface OSPromptActionCompletionCallback {
        public void onCompleted(PromptActionResult var1);
    }

    public static interface OutcomeCallback {
        public void onSuccess(OutcomeEvent var1);
    }

    private static class PendingTaskRunnable
    implements Runnable {
        private Runnable innerTask;
        private long taskId;

        PendingTaskRunnable(Runnable runnable) {
            this.innerTask = runnable;
        }

        public void run() {
            this.innerTask.run();
            OneSignal.onTaskRan(this.taskId);
        }
    }

    public static interface PostNotificationResponseHandler {
        public void onFailure(JSONObject var1);

        public void onSuccess(JSONObject var1);
    }

    static final class PromptActionResult
    extends Enum<PromptActionResult> {
        private static final /* synthetic */ PromptActionResult[] $VALUES;
        public static final /* enum */ PromptActionResult ERROR;
        public static final /* enum */ PromptActionResult LOCATION_PERMISSIONS_MISSING_MANIFEST;
        public static final /* enum */ PromptActionResult PERMISSION_DENIED;
        public static final /* enum */ PromptActionResult PERMISSION_GRANTED;

        static {
            PromptActionResult promptActionResult;
            PromptActionResult promptActionResult2;
            PromptActionResult promptActionResult3;
            PromptActionResult promptActionResult4;
            PERMISSION_GRANTED = promptActionResult2 = new PromptActionResult();
            PERMISSION_DENIED = promptActionResult4 = new PromptActionResult();
            LOCATION_PERMISSIONS_MISSING_MANIFEST = promptActionResult = new PromptActionResult();
            ERROR = promptActionResult3 = new PromptActionResult();
            $VALUES = new PromptActionResult[]{promptActionResult2, promptActionResult4, promptActionResult, promptActionResult3};
        }

        public static PromptActionResult valueOf(String string2) {
            return (PromptActionResult)Enum.valueOf(PromptActionResult.class, (String)string2);
        }

        public static PromptActionResult[] values() {
            return (PromptActionResult[])$VALUES.clone();
        }
    }

    public static class SendTagsError {
        private int code;
        private String message;

        SendTagsError(int n, String string2) {
            this.message = string2;
            this.code = n;
        }

        public int getCode() {
            return this.code;
        }

        public String getMessage() {
            return this.message;
        }
    }

}

