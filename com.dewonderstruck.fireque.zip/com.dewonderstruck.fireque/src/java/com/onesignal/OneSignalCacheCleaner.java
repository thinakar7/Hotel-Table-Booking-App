/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 */
package com.onesignal;

import android.content.Context;
import com.onesignal.OSInAppMessageRepository;
import com.onesignal.OneSignal;
import com.onesignal.OneSignalDbHelper;
import com.onesignal.influence.model.OSInfluenceChannel;

class OneSignalCacheCleaner {
    private static final long NOTIFICATION_CACHE_DATA_LIFETIME = 604800L;
    private static final String OS_DELETE_CACHED_NOTIFICATIONS_THREAD = "OS_DELETE_CACHED_NOTIFICATIONS_THREAD";
    private static final String OS_DELETE_CACHED_REDISPLAYED_IAMS_THREAD = "OS_DELETE_CACHED_REDISPLAYED_IAMS_THREAD";

    OneSignalCacheCleaner() {
    }

    static void cleanCachedInAppMessages(final OneSignalDbHelper oneSignalDbHelper) {
        Class<OneSignalCacheCleaner> class_ = OneSignalCacheCleaner.class;
        synchronized (OneSignalCacheCleaner.class) {
            new Thread(new Runnable(){

                public void run() {
                    Thread.currentThread().setPriority(10);
                    OneSignal.getInAppMessageController().getInAppMessageRepository(oneSignalDbHelper).cleanCachedInAppMessages();
                }
            }, OS_DELETE_CACHED_REDISPLAYED_IAMS_THREAD).start();
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return;
        }
    }

    private static void cleanCachedNotifications(OneSignalDbHelper oneSignalDbHelper) {
        oneSignalDbHelper.delete("notification", "created_time < ?", new String[]{String.valueOf((long)(System.currentTimeMillis() / 1000L - 604800L))});
    }

    private static void cleanCachedUniqueOutcomeEventNotifications(OneSignalDbHelper oneSignalDbHelper) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NOT EXISTS(SELECT NULL FROM notification n WHERE n.notification_id = channel_influence_id AND channel_type = \"");
        stringBuilder.append(OSInfluenceChannel.NOTIFICATION.toString().toLowerCase());
        stringBuilder.append("\")");
        oneSignalDbHelper.delete("cached_unique_outcome", stringBuilder.toString(), null);
    }

    static void cleanNotificationCache(final OneSignalDbHelper oneSignalDbHelper) {
        Class<OneSignalCacheCleaner> class_ = OneSignalCacheCleaner.class;
        synchronized (OneSignalCacheCleaner.class) {
            new Thread(new Runnable(){

                public void run() {
                    Thread.currentThread().setPriority(10);
                    OneSignalCacheCleaner.cleanCachedNotifications(oneSignalDbHelper);
                    OneSignalCacheCleaner.cleanCachedUniqueOutcomeEventNotifications(oneSignalDbHelper);
                }
            }, OS_DELETE_CACHED_NOTIFICATIONS_THREAD).start();
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return;
        }
    }

    static void cleanOldCachedData(Context context) {
        OneSignalDbHelper oneSignalDbHelper = OneSignalDbHelper.getInstance(context);
        OneSignalCacheCleaner.cleanNotificationCache(oneSignalDbHelper);
        OneSignalCacheCleaner.cleanCachedInAppMessages(oneSignalDbHelper);
    }

}

