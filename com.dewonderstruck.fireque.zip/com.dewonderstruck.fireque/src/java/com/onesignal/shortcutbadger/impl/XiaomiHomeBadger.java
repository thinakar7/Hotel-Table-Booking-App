/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  android.app.NotificationManager
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.os.Build
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  java.util.Arrays
 *  java.util.List
 */
package com.onesignal.shortcutbadger.impl;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import com.onesignal.shortcutbadger.Badger;
import com.onesignal.shortcutbadger.ShortcutBadgeException;
import com.onesignal.shortcutbadger.util.BroadcastHelper;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

@Deprecated
public class XiaomiHomeBadger
implements Badger {
    public static final String EXTRA_UPDATE_APP_COMPONENT_NAME = "android.intent.extra.update_application_component_name";
    public static final String EXTRA_UPDATE_APP_MSG_TEXT = "android.intent.extra.update_application_message_text";
    public static final String INTENT_ACTION = "android.intent.action.APPLICATION_MESSAGE_UPDATE";
    private ResolveInfo resolveInfo;

    private void tryNewMiuiBadge(Context context, int n) throws ShortcutBadgeException {
        if (this.resolveInfo == null) {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.HOME");
            this.resolveInfo = context.getPackageManager().resolveActivity(intent, 65536);
        }
        if (this.resolveInfo != null) {
            NotificationManager notificationManager = (NotificationManager)context.getSystemService("notification");
            Notification notification = new Notification.Builder(context).setContentTitle((CharSequence)"").setContentText((CharSequence)"").setSmallIcon(this.resolveInfo.getIconResource()).build();
            try {
                Object object = notification.getClass().getDeclaredField("extraNotification").get((Object)notification);
                Class class_ = object.getClass();
                Class[] arrclass = new Class[]{Integer.TYPE};
                Method method = class_.getDeclaredMethod("setMessageCount", arrclass);
                Object[] arrobject = new Object[]{n};
                method.invoke(object, arrobject);
                notificationManager.notify(0, notification);
                return;
            }
            catch (Exception exception) {
                throw new ShortcutBadgeException("not able to set badge", exception);
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public void executeBadge(Context var1_1, ComponentName var2_2, int var3_3) throws ShortcutBadgeException {
        block7 : {
            block6 : {
                var4_4 = "";
                var13_5 = Class.forName((String)"android.app.MiuiNotification").newInstance();
                var14_6 = var13_5.getClass().getDeclaredField("messageCount");
                var14_6.setAccessible(true);
                if (var3_3 != 0) break block6;
                var16_7 = var4_4;
                ** GOTO lbl12
            }
            try {
                var16_7 = Integer.valueOf((int)var3_3);
lbl12: // 2 sources:
                var14_6.set(var13_5, (Object)String.valueOf((Object)var16_7));
            }
            catch (Exception var15_8) {
                try {
                    var14_6.set(var13_5, (Object)var3_3);
                }
                catch (Exception var5_9) {
                    var6_10 = new Intent("android.intent.action.APPLICATION_MESSAGE_UPDATE");
                    var7_11 = new StringBuilder();
                    var7_11.append(var2_2.getPackageName());
                    var7_11.append("/");
                    var7_11.append(var2_2.getClassName());
                    var6_10.putExtra("android.intent.extra.update_application_component_name", var7_11.toString());
                    if (var3_3 != 0) {
                        var4_4 = Integer.valueOf((int)var3_3);
                    }
                    var6_10.putExtra("android.intent.extra.update_application_message_text", String.valueOf((Object)var4_4));
                    if (!BroadcastHelper.canResolveBroadcast(var1_1, var6_10)) break block7;
                    var1_1.sendBroadcast(var6_10);
                }
            }
        }
        if (Build.MANUFACTURER.equalsIgnoreCase("Xiaomi") == false) return;
        this.tryNewMiuiBadge(var1_1, var3_3);
    }

    @Override
    public List<String> getSupportLaunchers() {
        return Arrays.asList((Object[])new String[]{"com.miui.miuilite", "com.miui.home", "com.miui.miuihome", "com.miui.miuihome2", "com.miui.mihome", "com.miui.mihome2", "com.i.miui.launcher"});
    }
}

