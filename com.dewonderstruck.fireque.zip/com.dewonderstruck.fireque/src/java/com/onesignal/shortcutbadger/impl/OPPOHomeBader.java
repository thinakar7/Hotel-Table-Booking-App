/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  java.io.BufferedReader
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Process
 *  java.lang.Runtime
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.Collections
 *  java.util.List
 */
package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.onesignal.shortcutbadger.Badger;
import com.onesignal.shortcutbadger.ShortcutBadgeException;
import com.onesignal.shortcutbadger.util.BroadcastHelper;
import com.onesignal.shortcutbadger.util.CloseHelper;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;

public class OPPOHomeBader
implements Badger {
    private static final String INTENT_ACTION = "com.oppo.unsettledevent";
    private static final String INTENT_EXTRA_BADGEUPGRADE_COUNT = "app_badge_count";
    private static final String INTENT_EXTRA_BADGE_COUNT = "number";
    private static final String INTENT_EXTRA_BADGE_UPGRADENUMBER = "upgradeNumber";
    private static final String INTENT_EXTRA_PACKAGENAME = "pakeageName";
    private static final String PROVIDER_CONTENT_URI = "content://com.android.badge/badge";
    private static int ROMVERSION = -1;

    private boolean checkObjExists(Object object) {
        return object == null || object.toString().equals((Object)"") || object.toString().trim().equals((Object)"null");
        {
        }
    }

    private Object executeClassLoad(Class class_, String string2, Class[] arrclass, Object[] arrobject) {
        Method method;
        if (class_ != null && !this.checkObjExists(string2) && (method = this.getMethod(class_, string2, arrclass)) != null) {
            method.setAccessible(true);
            try {
                Object object = method.invoke(null, arrobject);
                return object;
            }
            catch (InvocationTargetException invocationTargetException) {
                invocationTargetException.printStackTrace();
                return null;
            }
            catch (IllegalAccessException illegalAccessException) {
                illegalAccessException.printStackTrace();
                return null;
            }
        }
        return null;
    }

    private Class getClass(String string2) {
        try {
            Class class_ = Class.forName((String)string2);
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            return null;
        }
    }

    private Method getMethod(Class class_, String string2, Class[] arrclass) {
        if (class_ != null) {
            if (this.checkObjExists(string2)) {
                return null;
            }
            try {
                class_.getMethods();
                class_.getDeclaredMethods();
                Method method = class_.getDeclaredMethod(string2, arrclass);
                return method;
            }
            catch (Exception exception) {
                try {
                    Method method = class_.getMethod(string2, arrclass);
                    return method;
                }
                catch (Exception exception2) {
                    if (class_.getSuperclass() != null) {
                        return this.getMethod(class_.getSuperclass(), string2, arrclass);
                    }
                    return null;
                }
            }
        }
        return null;
    }

    private int getSupportVersion() {
        int n;
        if (ROMVERSION >= 0) {
            return ROMVERSION;
        }
        try {
            int n2;
            n = n2 = ((Integer)this.executeClassLoad(this.getClass("com.color.os.ColorBuild"), "getColorOSVERSION", null, null)).intValue();
        }
        catch (Exception exception) {
            n = 0;
        }
        if (n == 0) {
            String string2;
            block10 : {
                block9 : {
                    string2 = this.getSystemProperty("ro.build.version.opporom");
                    if (!string2.startsWith("V1.4")) break block9;
                    return 3;
                }
                if (!string2.startsWith("V2.0")) break block10;
                return 4;
            }
            try {
                boolean bl = string2.startsWith("V2.1");
                if (bl) {
                    return 5;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        ROMVERSION = n;
        return n;
    }

    private String getSystemProperty(String string2) {
        String string3;
        BufferedReader bufferedReader = null;
        try {
            Runtime runtime = Runtime.getRuntime();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("getprop ");
            stringBuilder.append(string2);
            bufferedReader = new BufferedReader((Reader)new InputStreamReader(runtime.exec(stringBuilder.toString()).getInputStream()), 1024);
            string3 = bufferedReader.readLine();
            bufferedReader.close();
        }
        catch (Throwable throwable) {
            CloseHelper.closeQuietly(bufferedReader);
            throw throwable;
        }
        catch (IOException iOException) {
            CloseHelper.closeQuietly(bufferedReader);
            return null;
        }
        CloseHelper.closeQuietly((Closeable)bufferedReader);
        return string3;
    }

    @Override
    public void executeBadge(Context context, ComponentName componentName, int n) throws ShortcutBadgeException {
        if (n == 0) {
            n = -1;
        }
        Intent intent = new Intent(INTENT_ACTION);
        intent.putExtra(INTENT_EXTRA_PACKAGENAME, componentName.getPackageName());
        intent.putExtra(INTENT_EXTRA_BADGE_COUNT, n);
        intent.putExtra(INTENT_EXTRA_BADGE_UPGRADENUMBER, n);
        if (BroadcastHelper.canResolveBroadcast(context, intent)) {
            context.sendBroadcast(intent);
            return;
        }
        if (this.getSupportVersion() == 6) {
            try {
                Bundle bundle = new Bundle();
                bundle.putInt(INTENT_EXTRA_BADGEUPGRADE_COUNT, n);
                context.getContentResolver().call(Uri.parse((String)PROVIDER_CONTENT_URI), "setAppBadgeCount", null, bundle);
                return;
            }
            catch (Throwable throwable) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("unable to resolve intent: ");
                stringBuilder.append(intent.toString());
                throw new ShortcutBadgeException(stringBuilder.toString());
            }
        }
    }

    @Override
    public List<String> getSupportLaunchers() {
        return Collections.singletonList((Object)"com.oppo.launcher");
    }
}

