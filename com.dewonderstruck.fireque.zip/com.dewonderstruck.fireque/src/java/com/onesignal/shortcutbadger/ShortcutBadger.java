/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.os.Build
 *  android.util.Log
 *  com.onesignal.shortcutbadger.impl.ApexHomeBadger
 *  com.onesignal.shortcutbadger.impl.AsusHomeBadger
 *  com.onesignal.shortcutbadger.impl.DefaultBadger
 *  com.onesignal.shortcutbadger.impl.EverythingMeHomeBadger
 *  com.onesignal.shortcutbadger.impl.HuaweiHomeBadger
 *  com.onesignal.shortcutbadger.impl.NewHtcHomeBadger
 *  com.onesignal.shortcutbadger.impl.NovaHomeBadger
 *  com.onesignal.shortcutbadger.impl.OPPOHomeBader
 *  com.onesignal.shortcutbadger.impl.SamsungHomeBadger
 *  com.onesignal.shortcutbadger.impl.SonyHomeBadger
 *  com.onesignal.shortcutbadger.impl.VivoHomeBadger
 *  com.onesignal.shortcutbadger.impl.ZukHomeBadger
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  java.util.LinkedList
 *  java.util.List
 */
package com.onesignal.shortcutbadger;

import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.util.Log;
import com.onesignal.shortcutbadger.Badger;
import com.onesignal.shortcutbadger.ShortcutBadgeException;
import com.onesignal.shortcutbadger.impl.AdwHomeBadger;
import com.onesignal.shortcutbadger.impl.ApexHomeBadger;
import com.onesignal.shortcutbadger.impl.AsusHomeBadger;
import com.onesignal.shortcutbadger.impl.DefaultBadger;
import com.onesignal.shortcutbadger.impl.EverythingMeHomeBadger;
import com.onesignal.shortcutbadger.impl.HuaweiHomeBadger;
import com.onesignal.shortcutbadger.impl.NewHtcHomeBadger;
import com.onesignal.shortcutbadger.impl.NovaHomeBadger;
import com.onesignal.shortcutbadger.impl.OPPOHomeBader;
import com.onesignal.shortcutbadger.impl.SamsungHomeBadger;
import com.onesignal.shortcutbadger.impl.SonyHomeBadger;
import com.onesignal.shortcutbadger.impl.VivoHomeBadger;
import com.onesignal.shortcutbadger.impl.ZukHomeBadger;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;

public final class ShortcutBadger {
    private static final List<Class<? extends Badger>> BADGERS;
    private static final String LOG_TAG = "ShortcutBadger";
    private static final int SUPPORTED_CHECK_ATTEMPTS = 3;
    private static ComponentName sComponentName;
    private static final Object sCounterSupportedLock;
    private static volatile Boolean sIsBadgeCounterSupported;
    private static Badger sShortcutBadger;

    static {
        LinkedList linkedList;
        BADGERS = linkedList = new LinkedList();
        sCounterSupportedLock = new Object();
        linkedList.add(AdwHomeBadger.class);
        linkedList.add(ApexHomeBadger.class);
        linkedList.add(NewHtcHomeBadger.class);
        linkedList.add(NovaHomeBadger.class);
        linkedList.add(SonyHomeBadger.class);
        linkedList.add(AsusHomeBadger.class);
        linkedList.add(HuaweiHomeBadger.class);
        linkedList.add(OPPOHomeBader.class);
        linkedList.add(SamsungHomeBadger.class);
        linkedList.add(ZukHomeBadger.class);
        linkedList.add(VivoHomeBadger.class);
        linkedList.add(EverythingMeHomeBadger.class);
    }

    private ShortcutBadger() {
    }

    public static boolean applyCount(Context context, int n) {
        try {
            ShortcutBadger.applyCountOrThrow(context, n);
            return true;
        }
        catch (ShortcutBadgeException shortcutBadgeException) {
            if (Log.isLoggable((String)LOG_TAG, (int)3)) {
                Log.d((String)LOG_TAG, (String)"Unable to execute badge", (Throwable)shortcutBadgeException);
            }
            return false;
        }
    }

    public static void applyCountOrThrow(Context context, int n) throws ShortcutBadgeException {
        if (sShortcutBadger == null && !ShortcutBadger.initBadger(context)) {
            throw new ShortcutBadgeException("No default launcher available");
        }
        try {
            sShortcutBadger.executeBadge(context, sComponentName, n);
            return;
        }
        catch (Exception exception) {
            throw new ShortcutBadgeException("Unable to execute badge", exception);
        }
    }

    public static void applyNotification(Context context, Notification notification, int n) {
        block3 : {
            if (Build.MANUFACTURER.equalsIgnoreCase("Xiaomi")) {
                try {
                    Object object = notification.getClass().getDeclaredField("extraNotification").get((Object)notification);
                    Class class_ = object.getClass();
                    Class[] arrclass = new Class[]{Integer.TYPE};
                    Method method = class_.getDeclaredMethod("setMessageCount", arrclass);
                    Object[] arrobject = new Object[]{n};
                    method.invoke(object, arrobject);
                    return;
                }
                catch (Exception exception) {
                    if (!Log.isLoggable((String)LOG_TAG, (int)3)) break block3;
                    Log.d((String)LOG_TAG, (String)"Unable to execute badge", (Throwable)exception);
                }
            }
        }
    }

    private static boolean initBadger(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (intent == null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to find launch intent for package ");
            stringBuilder.append(context.getPackageName());
            Log.e((String)LOG_TAG, (String)stringBuilder.toString());
            return false;
        }
        sComponentName = intent.getComponent();
        Intent intent2 = new Intent("android.intent.action.MAIN");
        intent2.addCategory("android.intent.category.HOME");
        ResolveInfo resolveInfo = context.getPackageManager().resolveActivity(intent2, 65536);
        if (resolveInfo != null) {
            if (resolveInfo.activityInfo.name.toLowerCase().contains((CharSequence)"resolver")) {
                return false;
            }
            String string2 = resolveInfo.activityInfo.packageName;
            for (Class class_ : BADGERS) {
                Badger badger = null;
                try {
                    Badger badger2;
                    badger = badger2 = (Badger)class_.newInstance();
                }
                catch (Exception exception) {
                    // empty catch block
                }
                if (badger == null || !badger.getSupportLaunchers().contains((Object)string2)) continue;
                sShortcutBadger = badger;
                break;
            }
            if (sShortcutBadger == null) {
                sShortcutBadger = Build.MANUFACTURER.equalsIgnoreCase("ZUK") ? new ZukHomeBadger() : (Build.MANUFACTURER.equalsIgnoreCase("OPPO") ? new OPPOHomeBader() : (Build.MANUFACTURER.equalsIgnoreCase("VIVO") ? new VivoHomeBadger() : new DefaultBadger()));
            }
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean isBadgeCounterSupported(Context context) {
        if (sIsBadgeCounterSupported == null) {
            Object object;
            Object object2 = object = sCounterSupportedLock;
            synchronized (object2) {
                Boolean bl = sIsBadgeCounterSupported;
                if (bl == null) {
                    String string2 = null;
                    for (int i = 0; i < 3; ++i) {
                        try {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Checking if platform supports badge counters, attempt ");
                            Object[] arrobject = new Object[]{i + 1, 3};
                            stringBuilder.append(String.format((String)"%d/%d.", (Object[])arrobject));
                            Log.i((String)LOG_TAG, (String)stringBuilder.toString());
                            if (ShortcutBadger.initBadger(context)) {
                                sShortcutBadger.executeBadge(context, sComponentName, 0);
                                sIsBadgeCounterSupported = true;
                                Log.i((String)LOG_TAG, (String)"Badge counter is supported in this platform.");
                                break;
                            }
                            string2 = "Failed to initialize the badge counter.";
                            continue;
                        }
                        catch (Exception exception) {
                            string2 = exception.getMessage();
                        }
                    }
                    if (sIsBadgeCounterSupported == null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Badge counter seems not supported for this platform: ");
                        stringBuilder.append(string2);
                        Log.w((String)LOG_TAG, (String)stringBuilder.toString());
                        sIsBadgeCounterSupported = false;
                    }
                }
            }
        }
        return sIsBadgeCounterSupported;
    }

    public static boolean removeCount(Context context) {
        return ShortcutBadger.applyCount(context, 0);
    }

    public static void removeCountOrThrow(Context context) throws ShortcutBadgeException {
        ShortcutBadger.applyCountOrThrow(context, 0);
    }
}

