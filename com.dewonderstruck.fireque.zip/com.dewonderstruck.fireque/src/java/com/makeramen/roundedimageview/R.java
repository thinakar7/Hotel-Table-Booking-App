/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.makeramen.roundedimageview;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int riv_border_color = 2130903495;
        public static final int riv_border_width = 2130903496;
        public static final int riv_corner_radius = 2130903497;
        public static final int riv_corner_radius_bottom_left = 2130903498;
        public static final int riv_corner_radius_bottom_right = 2130903499;
        public static final int riv_corner_radius_top_left = 2130903500;
        public static final int riv_corner_radius_top_right = 2130903501;
        public static final int riv_mutate_background = 2130903502;
        public static final int riv_oval = 2130903503;
        public static final int riv_tile_mode = 2130903504;
        public static final int riv_tile_mode_x = 2130903505;
        public static final int riv_tile_mode_y = 2130903506;

        private attr() {
        }
    }

    public static final class id {
        public static final int clamp = 2131230839;
        public static final int mirror = 2131230974;
        public static final int repeat = 2131231031;

        private id() {
        }
    }

    public static final class string {
        public static final int define_roundedimageview = 2131689562;
        public static final int library_roundedimageview_author = 2131689592;
        public static final int library_roundedimageview_authorWebsite = 2131689593;
        public static final int library_roundedimageview_isOpenSource = 2131689594;
        public static final int library_roundedimageview_libraryDescription = 2131689595;
        public static final int library_roundedimageview_libraryName = 2131689596;
        public static final int library_roundedimageview_libraryVersion = 2131689597;
        public static final int library_roundedimageview_libraryWebsite = 2131689598;
        public static final int library_roundedimageview_licenseId = 2131689599;
        public static final int library_roundedimageview_repositoryLink = 2131689600;

        private string() {
        }
    }

    public static final class styleable {
        public static final int[] RoundedImageView = new int[]{16843037, 2130903495, 2130903496, 2130903497, 2130903498, 2130903499, 2130903500, 2130903501, 2130903502, 2130903503, 2130903504, 2130903505, 2130903506};
        public static final int RoundedImageView_android_scaleType = 0;
        public static final int RoundedImageView_riv_border_color = 1;
        public static final int RoundedImageView_riv_border_width = 2;
        public static final int RoundedImageView_riv_corner_radius = 3;
        public static final int RoundedImageView_riv_corner_radius_bottom_left = 4;
        public static final int RoundedImageView_riv_corner_radius_bottom_right = 5;
        public static final int RoundedImageView_riv_corner_radius_top_left = 6;
        public static final int RoundedImageView_riv_corner_radius_top_right = 7;
        public static final int RoundedImageView_riv_mutate_background = 8;
        public static final int RoundedImageView_riv_oval = 9;
        public static final int RoundedImageView_riv_tile_mode = 10;
        public static final int RoundedImageView_riv_tile_mode_x = 11;
        public static final int RoundedImageView_riv_tile_mode_y = 12;

        private styleable() {
        }
    }

}

