/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  com.squareup.picasso.Transformation
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 */
package com.makeramen.roundedimageview;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.ImageView;
import com.makeramen.roundedimageview.RoundedDrawable;
import com.squareup.picasso.Transformation;
import java.util.Arrays;

public final class RoundedTransformationBuilder {
    private ColorStateList mBorderColor = ColorStateList.valueOf((int)-16777216);
    private float mBorderWidth = 0.0f;
    private float[] mCornerRadii = new float[]{0.0f, 0.0f, 0.0f, 0.0f};
    private final DisplayMetrics mDisplayMetrics = Resources.getSystem().getDisplayMetrics();
    private boolean mOval = false;
    private ImageView.ScaleType mScaleType = ImageView.ScaleType.FIT_CENTER;

    public RoundedTransformationBuilder borderColor(int n) {
        this.mBorderColor = ColorStateList.valueOf((int)n);
        return this;
    }

    public RoundedTransformationBuilder borderColor(ColorStateList colorStateList) {
        this.mBorderColor = colorStateList;
        return this;
    }

    public RoundedTransformationBuilder borderWidth(float f) {
        this.mBorderWidth = f;
        return this;
    }

    public RoundedTransformationBuilder borderWidthDp(float f) {
        this.mBorderWidth = TypedValue.applyDimension((int)1, (float)f, (DisplayMetrics)this.mDisplayMetrics);
        return this;
    }

    public Transformation build() {
        return new Transformation(){

            public String key() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("r:");
                stringBuilder.append(Arrays.toString((float[])RoundedTransformationBuilder.this.mCornerRadii));
                stringBuilder.append("b:");
                stringBuilder.append(RoundedTransformationBuilder.this.mBorderWidth);
                stringBuilder.append("c:");
                stringBuilder.append((Object)RoundedTransformationBuilder.this.mBorderColor);
                stringBuilder.append("o:");
                stringBuilder.append(RoundedTransformationBuilder.this.mOval);
                return stringBuilder.toString();
            }

            public Bitmap transform(Bitmap bitmap) {
                Bitmap bitmap2 = RoundedDrawable.fromBitmap(bitmap).setScaleType(RoundedTransformationBuilder.this.mScaleType).setCornerRadius(RoundedTransformationBuilder.this.mCornerRadii[0], RoundedTransformationBuilder.this.mCornerRadii[1], RoundedTransformationBuilder.this.mCornerRadii[2], RoundedTransformationBuilder.this.mCornerRadii[3]).setBorderWidth(RoundedTransformationBuilder.this.mBorderWidth).setBorderColor(RoundedTransformationBuilder.this.mBorderColor).setOval(RoundedTransformationBuilder.this.mOval).toBitmap();
                if (!bitmap.equals((Object)bitmap2)) {
                    bitmap.recycle();
                }
                return bitmap2;
            }
        };
    }

    public RoundedTransformationBuilder cornerRadius(float f) {
        float[] arrf = this.mCornerRadii;
        arrf[0] = f;
        arrf[1] = f;
        arrf[2] = f;
        arrf[3] = f;
        return this;
    }

    public RoundedTransformationBuilder cornerRadius(int n, float f) {
        this.mCornerRadii[n] = f;
        return this;
    }

    public RoundedTransformationBuilder cornerRadiusDp(float f) {
        return this.cornerRadius(TypedValue.applyDimension((int)1, (float)f, (DisplayMetrics)this.mDisplayMetrics));
    }

    public RoundedTransformationBuilder cornerRadiusDp(int n, float f) {
        return this.cornerRadius(n, TypedValue.applyDimension((int)1, (float)f, (DisplayMetrics)this.mDisplayMetrics));
    }

    public RoundedTransformationBuilder oval(boolean bl) {
        this.mOval = bl;
        return this;
    }

    public RoundedTransformationBuilder scaleType(ImageView.ScaleType scaleType) {
        this.mScaleType = scaleType;
        return this;
    }

}

