/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.drawable.shapes.Shape
 */
package fr.castorflex.android.smoothprogressbar;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.shapes.Shape;

public class ColorsShape
extends Shape {
    private int[] mColors;
    private float mStrokeWidth;

    public ColorsShape(float f, int[] arrn) {
        this.mStrokeWidth = f;
        this.mColors = arrn;
    }

    public void draw(Canvas canvas, Paint paint) {
        float f = 1.0f / (float)this.mColors.length;
        int n = 0;
        paint.setStrokeWidth(this.mStrokeWidth);
        int[] arrn = this.mColors;
        int n2 = arrn.length;
        for (int i = 0; i < n2; ++i) {
            paint.setColor(arrn[i]);
            float f2 = f * (float)n * this.getWidth();
            float f3 = this.getHeight() / 2.0f;
            int n3 = n + 1;
            canvas.drawLine(f2, f3, f * (float)n3 * this.getWidth(), this.getHeight() / 2.0f, paint);
            n = n3;
        }
    }

    public int[] getColors() {
        return this.mColors;
    }

    public float getStrokeWidth() {
        return this.mStrokeWidth;
    }

    public void setColors(int[] arrn) {
        this.mColors = arrn;
    }

    public void setStrokeWidth(float f) {
        this.mStrokeWidth = f;
    }
}

