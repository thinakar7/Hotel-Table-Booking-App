/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package fr.castorflex.android.smoothprogressbar;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int spbStyle = 2130903537;
        public static final int spb_background = 2130903538;
        public static final int spb_color = 2130903539;
        public static final int spb_colors = 2130903540;
        public static final int spb_generate_background_with_colors = 2130903541;
        public static final int spb_gradients = 2130903542;
        public static final int spb_interpolator = 2130903543;
        public static final int spb_mirror_mode = 2130903544;
        public static final int spb_progressiveStart_activated = 2130903545;
        public static final int spb_progressiveStart_speed = 2130903546;
        public static final int spb_progressiveStop_speed = 2130903547;
        public static final int spb_reversed = 2130903548;
        public static final int spb_sections_count = 2130903549;
        public static final int spb_speed = 2130903550;
        public static final int spb_stroke_separator_length = 2130903551;
        public static final int spb_stroke_width = 2130903552;

        private attr() {
        }
    }

    public static final class bool {
        public static final int spb_default_mirror_mode = 2130968580;
        public static final int spb_default_progressiveStart_activated = 2130968581;
        public static final int spb_default_reversed = 2130968582;

        private bool() {
        }
    }

    public static final class color {
        public static final int spb_default_color = 2131034288;

        private color() {
        }
    }

    public static final class dimen {
        public static final int spb_default_stroke_separator_length = 2131099860;
        public static final int spb_default_stroke_width = 2131099861;

        private dimen() {
        }
    }

    public static final class id {
        public static final int spb_interpolator_accelerate = 2131231072;
        public static final int spb_interpolator_acceleratedecelerate = 2131231073;
        public static final int spb_interpolator_decelerate = 2131231074;
        public static final int spb_interpolator_linear = 2131231075;

        private id() {
        }
    }

    public static final class integer {
        public static final int spb_default_interpolator = 2131296271;
        public static final int spb_default_sections_count = 2131296272;

        private integer() {
        }
    }

    public static final class string {
        public static final int define_smoothprogressbar = 2131689563;
        public static final int library_smoothprogressbar_author = 2131689601;
        public static final int library_smoothprogressbar_authorWebsite = 2131689602;
        public static final int library_smoothprogressbar_isOpenSource = 2131689603;
        public static final int library_smoothprogressbar_libraryDescription = 2131689604;
        public static final int library_smoothprogressbar_libraryName = 2131689605;
        public static final int library_smoothprogressbar_libraryVersion = 2131689606;
        public static final int library_smoothprogressbar_libraryWebsite = 2131689607;
        public static final int library_smoothprogressbar_licenseId = 2131689608;
        public static final int library_smoothprogressbar_repositoryLink = 2131689609;
        public static final int spb_default_speed = 2131689680;

        private string() {
        }
    }

    public static final class style {
        public static final int SPB = 2131755248;
        public static final int SmoothProgressBar = 2131755249;
        public static final int Theme_SmoothProgressBarDefaults = 2131755386;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] SmoothProgressBar = new int[]{2130903537, 2130903538, 2130903539, 2130903540, 2130903541, 2130903542, 2130903543, 2130903544, 2130903545, 2130903546, 2130903547, 2130903548, 2130903549, 2130903550, 2130903551, 2130903552};
        public static final int SmoothProgressBar_spbStyle = 0;
        public static final int SmoothProgressBar_spb_background = 1;
        public static final int SmoothProgressBar_spb_color = 2;
        public static final int SmoothProgressBar_spb_colors = 3;
        public static final int SmoothProgressBar_spb_generate_background_with_colors = 4;
        public static final int SmoothProgressBar_spb_gradients = 5;
        public static final int SmoothProgressBar_spb_interpolator = 6;
        public static final int SmoothProgressBar_spb_mirror_mode = 7;
        public static final int SmoothProgressBar_spb_progressiveStart_activated = 8;
        public static final int SmoothProgressBar_spb_progressiveStart_speed = 9;
        public static final int SmoothProgressBar_spb_progressiveStop_speed = 10;
        public static final int SmoothProgressBar_spb_reversed = 11;
        public static final int SmoothProgressBar_spb_sections_count = 12;
        public static final int SmoothProgressBar_spb_speed = 13;
        public static final int SmoothProgressBar_spb_stroke_separator_length = 14;
        public static final int SmoothProgressBar_spb_stroke_width = 15;

        private styleable() {
        }
    }

}

