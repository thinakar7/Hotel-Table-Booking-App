/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.ShapeDrawable
 *  android.graphics.drawable.shapes.Shape
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package fr.castorflex.android.smoothprogressbar;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.Shape;
import fr.castorflex.android.smoothprogressbar.ColorsShape;

public final class SmoothProgressBarUtils {
    private SmoothProgressBarUtils() {
    }

    static void checkAngle(int n) {
        if (n >= 0 && n <= 360) {
            return;
        }
        Object[] arrobject = new Object[]{n};
        throw new IllegalArgumentException(String.format((String)"Illegal angle %d: must be >=0 and <= 360", (Object[])arrobject));
    }

    static void checkColors(int[] arrn) {
        if (arrn != null && arrn.length != 0) {
            return;
        }
        throw new IllegalArgumentException("You must provide at least 1 color");
    }

    static void checkNotNull(Object object, String string2) {
        if (object != null) {
            return;
        }
        throw new IllegalArgumentException(String.format((String)"%s must be not null", (Object[])new Object[]{string2}));
    }

    static void checkPositive(int n, String string2) {
        if (n > 0) {
            return;
        }
        throw new IllegalArgumentException(String.format((String)"%s must not be null", (Object[])new Object[]{string2}));
    }

    static void checkPositiveOrZero(float f, String string2) {
        if (!(f < 0.0f)) {
            return;
        }
        Object[] arrobject = new Object[]{string2, Float.valueOf((float)f)};
        throw new IllegalArgumentException(String.format((String)"%s %d must be positive", (Object[])arrobject));
    }

    static void checkSpeed(float f) {
        if (!(f <= 0.0f)) {
            return;
        }
        throw new IllegalArgumentException("Speed must be >= 0");
    }

    public static Drawable generateDrawableWithColors(int[] arrn, float f) {
        if (arrn != null && arrn.length != 0) {
            return new ShapeDrawable((Shape)new ColorsShape(f, arrn));
        }
        return null;
    }
}

