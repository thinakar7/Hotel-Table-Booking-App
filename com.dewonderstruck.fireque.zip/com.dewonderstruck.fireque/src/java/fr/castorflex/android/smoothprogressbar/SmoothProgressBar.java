/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.util.AttributeSet
 *  android.view.animation.AccelerateDecelerateInterpolator
 *  android.view.animation.AccelerateInterpolator
 *  android.view.animation.DecelerateInterpolator
 *  android.view.animation.Interpolator
 *  android.view.animation.LinearInterpolator
 *  android.widget.ProgressBar
 *  fr.castorflex.android.smoothprogressbar.R
 *  fr.castorflex.android.smoothprogressbar.R$attr
 *  fr.castorflex.android.smoothprogressbar.R$bool
 *  fr.castorflex.android.smoothprogressbar.R$color
 *  fr.castorflex.android.smoothprogressbar.R$dimen
 *  fr.castorflex.android.smoothprogressbar.R$integer
 *  fr.castorflex.android.smoothprogressbar.R$string
 *  fr.castorflex.android.smoothprogressbar.R$styleable
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package fr.castorflex.android.smoothprogressbar;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.ProgressBar;
import fr.castorflex.android.smoothprogressbar.R;
import fr.castorflex.android.smoothprogressbar.SmoothProgressBarUtils;
import fr.castorflex.android.smoothprogressbar.SmoothProgressDrawable;

public class SmoothProgressBar
extends ProgressBar {
    private static final int INTERPOLATOR_ACCELERATE = 0;
    private static final int INTERPOLATOR_ACCELERATEDECELERATE = 2;
    private static final int INTERPOLATOR_DECELERATE = 3;
    private static final int INTERPOLATOR_LINEAR = 1;

    public SmoothProgressBar(Context context) {
        this(context, null);
    }

    public SmoothProgressBar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.spbStyle);
    }

    public SmoothProgressBar(Context context, AttributeSet attributeSet, int n) {
        Drawable drawable2;
        int n2;
        super(context, attributeSet, n);
        if (this.isInEditMode()) {
            this.setIndeterminateDrawable((Drawable)new SmoothProgressDrawable.Builder(context, true).build());
            return;
        }
        Resources resources = context.getResources();
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, R.styleable.SmoothProgressBar, n, 0);
        int n3 = typedArray.getColor(R.styleable.SmoothProgressBar_spb_color, resources.getColor(R.color.spb_default_color));
        int n4 = typedArray.getInteger(R.styleable.SmoothProgressBar_spb_sections_count, resources.getInteger(R.integer.spb_default_sections_count));
        int n5 = typedArray.getDimensionPixelSize(R.styleable.SmoothProgressBar_spb_stroke_separator_length, resources.getDimensionPixelSize(R.dimen.spb_default_stroke_separator_length));
        float f = typedArray.getDimension(R.styleable.SmoothProgressBar_spb_stroke_width, resources.getDimension(R.dimen.spb_default_stroke_width));
        float f2 = typedArray.getFloat(R.styleable.SmoothProgressBar_spb_speed, Float.parseFloat((String)resources.getString(R.string.spb_default_speed)));
        float f3 = typedArray.getFloat(R.styleable.SmoothProgressBar_spb_progressiveStart_speed, f2);
        float f4 = typedArray.getFloat(R.styleable.SmoothProgressBar_spb_progressiveStop_speed, f2);
        int n6 = typedArray.getInteger(R.styleable.SmoothProgressBar_spb_interpolator, -1);
        boolean bl = typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_reversed, resources.getBoolean(R.bool.spb_default_reversed));
        boolean bl2 = typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_mirror_mode, resources.getBoolean(R.bool.spb_default_mirror_mode));
        int n7 = typedArray.getResourceId(R.styleable.SmoothProgressBar_spb_colors, 0);
        boolean bl3 = typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_progressiveStart_activated, resources.getBoolean(R.bool.spb_default_progressiveStart_activated));
        Drawable drawable3 = typedArray.getDrawable(R.styleable.SmoothProgressBar_spb_background);
        boolean bl4 = typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_generate_background_with_colors, false);
        boolean bl5 = typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_gradients, false);
        typedArray.recycle();
        Object object = null;
        if (n6 == -1) {
            object = this.getInterpolator();
        }
        if (object == null) {
            object = n6 != 1 ? (n6 != 2 ? (n6 != 3 ? new AccelerateInterpolator() : new DecelerateInterpolator()) : new AccelerateDecelerateInterpolator()) : new LinearInterpolator();
        }
        int[] arrn = null;
        if (n7 != 0) {
            arrn = resources.getIntArray(n7);
        }
        SmoothProgressDrawable.Builder builder = new SmoothProgressDrawable.Builder(context).speed(f2).progressiveStartSpeed(f3).progressiveStopSpeed(f4).interpolator((Interpolator)object).sectionsCount(n4).separatorLength(n5).strokeWidth(f).reversed(bl).mirrorMode(bl2).progressiveStart(bl3).gradients(bl5);
        if (drawable3 != null) {
            drawable2 = drawable3;
            builder.backgroundDrawable(drawable2);
        } else {
            drawable2 = drawable3;
        }
        if (bl4) {
            builder.generateBackgroundUsingColors();
        }
        if (arrn != null && arrn.length > 0) {
            builder.colors(arrn);
            n2 = n3;
        } else {
            n2 = n3;
            builder.color(n2);
        }
        this.setIndeterminateDrawable((Drawable)builder.build());
    }

    private SmoothProgressDrawable checkIndeterminateDrawable() {
        Drawable drawable2 = this.getIndeterminateDrawable();
        if (drawable2 != null && drawable2 instanceof SmoothProgressDrawable) {
            return (SmoothProgressDrawable)drawable2;
        }
        throw new RuntimeException("The drawable is not a SmoothProgressDrawable");
    }

    public void applyStyle(int n) {
        int n2;
        int[] arrn;
        TypedArray typedArray = this.getContext().obtainStyledAttributes(null, R.styleable.SmoothProgressBar, 0, n);
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_color)) {
            this.setSmoothProgressDrawableColor(typedArray.getColor(R.styleable.SmoothProgressBar_spb_color, 0));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_colors) && (n2 = typedArray.getResourceId(R.styleable.SmoothProgressBar_spb_colors, 0)) != 0 && (arrn = this.getResources().getIntArray(n2)) != null && arrn.length > 0) {
            this.setSmoothProgressDrawableColors(arrn);
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_sections_count)) {
            this.setSmoothProgressDrawableSectionsCount(typedArray.getInteger(R.styleable.SmoothProgressBar_spb_sections_count, 0));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_stroke_separator_length)) {
            this.setSmoothProgressDrawableSeparatorLength(typedArray.getDimensionPixelSize(R.styleable.SmoothProgressBar_spb_stroke_separator_length, 0));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_stroke_width)) {
            this.setSmoothProgressDrawableStrokeWidth(typedArray.getDimension(R.styleable.SmoothProgressBar_spb_stroke_width, 0.0f));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_speed)) {
            this.setSmoothProgressDrawableSpeed(typedArray.getFloat(R.styleable.SmoothProgressBar_spb_speed, 0.0f));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_progressiveStart_speed)) {
            this.setSmoothProgressDrawableProgressiveStartSpeed(typedArray.getFloat(R.styleable.SmoothProgressBar_spb_progressiveStart_speed, 0.0f));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_progressiveStop_speed)) {
            this.setSmoothProgressDrawableProgressiveStopSpeed(typedArray.getFloat(R.styleable.SmoothProgressBar_spb_progressiveStop_speed, 0.0f));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_reversed)) {
            this.setSmoothProgressDrawableReversed(typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_reversed, false));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_mirror_mode)) {
            this.setSmoothProgressDrawableMirrorMode(typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_mirror_mode, false));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_progressiveStart_activated)) {
            this.setProgressiveStartActivated(typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_progressiveStart_activated, false));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_progressiveStart_activated)) {
            this.setProgressiveStartActivated(typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_progressiveStart_activated, false));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_gradients)) {
            this.setSmoothProgressDrawableUseGradients(typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_gradients, false));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_generate_background_with_colors) && typedArray.getBoolean(R.styleable.SmoothProgressBar_spb_generate_background_with_colors, false)) {
            this.setSmoothProgressDrawableBackgroundDrawable(SmoothProgressBarUtils.generateDrawableWithColors(this.checkIndeterminateDrawable().getColors(), this.checkIndeterminateDrawable().getStrokeWidth()));
        }
        if (typedArray.hasValue(R.styleable.SmoothProgressBar_spb_interpolator)) {
            int n3 = typedArray.getInteger(R.styleable.SmoothProgressBar_spb_interpolator, -1);
            Object object = n3 != 0 ? (n3 != 1 ? (n3 != 2 ? (n3 != 3 ? null : new DecelerateInterpolator()) : new AccelerateDecelerateInterpolator()) : new LinearInterpolator()) : new AccelerateInterpolator();
            if (object != null) {
                this.setInterpolator((Interpolator)object);
            }
        }
        typedArray.recycle();
    }

    protected void onDraw(Canvas canvas) {
        SmoothProgressBar smoothProgressBar = this;
        synchronized (smoothProgressBar) {
            super.onDraw(canvas);
            if (this.isIndeterminate() && this.getIndeterminateDrawable() instanceof SmoothProgressDrawable && !((SmoothProgressDrawable)this.getIndeterminateDrawable()).isRunning()) {
                this.getIndeterminateDrawable().draw(canvas);
            }
            return;
        }
    }

    public void progressiveStart() {
        this.checkIndeterminateDrawable().progressiveStart();
    }

    public void progressiveStop() {
        this.checkIndeterminateDrawable().progressiveStop();
    }

    public void setInterpolator(Interpolator interpolator) {
        super.setInterpolator(interpolator);
        Drawable drawable2 = this.getIndeterminateDrawable();
        if (drawable2 != null && drawable2 instanceof SmoothProgressDrawable) {
            ((SmoothProgressDrawable)drawable2).setInterpolator(interpolator);
        }
    }

    public void setProgressiveStartActivated(boolean bl) {
        this.checkIndeterminateDrawable().setProgressiveStartActivated(bl);
    }

    public void setSmoothProgressDrawableBackgroundDrawable(Drawable drawable2) {
        this.checkIndeterminateDrawable().setBackgroundDrawable(drawable2);
    }

    public void setSmoothProgressDrawableCallbacks(SmoothProgressDrawable.Callbacks callbacks) {
        this.checkIndeterminateDrawable().setCallbacks(callbacks);
    }

    public void setSmoothProgressDrawableColor(int n) {
        this.checkIndeterminateDrawable().setColor(n);
    }

    public void setSmoothProgressDrawableColors(int[] arrn) {
        this.checkIndeterminateDrawable().setColors(arrn);
    }

    public void setSmoothProgressDrawableInterpolator(Interpolator interpolator) {
        this.checkIndeterminateDrawable().setInterpolator(interpolator);
    }

    public void setSmoothProgressDrawableMirrorMode(boolean bl) {
        this.checkIndeterminateDrawable().setMirrorMode(bl);
    }

    public void setSmoothProgressDrawableProgressiveStartSpeed(float f) {
        this.checkIndeterminateDrawable().setProgressiveStartSpeed(f);
    }

    public void setSmoothProgressDrawableProgressiveStopSpeed(float f) {
        this.checkIndeterminateDrawable().setProgressiveStopSpeed(f);
    }

    public void setSmoothProgressDrawableReversed(boolean bl) {
        this.checkIndeterminateDrawable().setReversed(bl);
    }

    public void setSmoothProgressDrawableSectionsCount(int n) {
        this.checkIndeterminateDrawable().setSectionsCount(n);
    }

    public void setSmoothProgressDrawableSeparatorLength(int n) {
        this.checkIndeterminateDrawable().setSeparatorLength(n);
    }

    public void setSmoothProgressDrawableSpeed(float f) {
        this.checkIndeterminateDrawable().setSpeed(f);
    }

    public void setSmoothProgressDrawableStrokeWidth(float f) {
        this.checkIndeterminateDrawable().setStrokeWidth(f);
    }

    public void setSmoothProgressDrawableUseGradients(boolean bl) {
        this.checkIndeterminateDrawable().setUseGradients(bl);
    }
}

