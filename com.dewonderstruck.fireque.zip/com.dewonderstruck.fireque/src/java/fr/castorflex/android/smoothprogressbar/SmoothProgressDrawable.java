/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.LinearGradient
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Rect
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.drawable.Animatable
 *  android.graphics.drawable.Drawable
 *  android.os.SystemClock
 *  android.view.animation.AccelerateInterpolator
 *  android.view.animation.Interpolator
 *  fr.castorflex.android.smoothprogressbar.R
 *  fr.castorflex.android.smoothprogressbar.R$bool
 *  fr.castorflex.android.smoothprogressbar.R$color
 *  fr.castorflex.android.smoothprogressbar.R$dimen
 *  fr.castorflex.android.smoothprogressbar.R$integer
 *  fr.castorflex.android.smoothprogressbar.R$string
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package fr.castorflex.android.smoothprogressbar;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Interpolator;
import fr.castorflex.android.smoothprogressbar.R;
import fr.castorflex.android.smoothprogressbar.SmoothProgressBarUtils;

public class SmoothProgressDrawable
extends Drawable
implements Animatable {
    private static final long FRAME_DURATION = 16L;
    private static final float OFFSET_PER_FRAME = 0.01f;
    private final Rect fBackgroundRect = new Rect();
    private Drawable mBackgroundDrawable;
    private Rect mBounds;
    private Callbacks mCallbacks;
    private int[] mColors;
    private int mColorsIndex;
    private float mCurrentOffset;
    private int mCurrentSections;
    private boolean mFinishing;
    private float mFinishingOffset;
    private Interpolator mInterpolator;
    private int[] mLinearGradientColors;
    private float[] mLinearGradientPositions;
    private float mMaxOffset;
    private boolean mMirrorMode;
    private boolean mNewTurn;
    private Paint mPaint;
    private boolean mProgressiveStartActivated;
    private float mProgressiveStartSpeed;
    private float mProgressiveStopSpeed;
    private boolean mReversed;
    private boolean mRunning = false;
    private int mSectionsCount;
    private int mSeparatorLength;
    private float mSpeed;
    private int mStartSection;
    private float mStrokeWidth;
    private final Runnable mUpdater = new Runnable(){

        public void run() {
            if (SmoothProgressDrawable.this.isFinishing()) {
                SmoothProgressDrawable smoothProgressDrawable = SmoothProgressDrawable.this;
                smoothProgressDrawable.mFinishingOffset = smoothProgressDrawable.mFinishingOffset + 0.01f * SmoothProgressDrawable.this.mProgressiveStopSpeed;
                SmoothProgressDrawable smoothProgressDrawable2 = SmoothProgressDrawable.this;
                smoothProgressDrawable2.mCurrentOffset = smoothProgressDrawable2.mCurrentOffset + 0.01f * SmoothProgressDrawable.this.mProgressiveStopSpeed;
                if (SmoothProgressDrawable.this.mFinishingOffset >= 1.0f) {
                    SmoothProgressDrawable.this.stop();
                }
            } else if (SmoothProgressDrawable.this.isStarting()) {
                SmoothProgressDrawable smoothProgressDrawable = SmoothProgressDrawable.this;
                smoothProgressDrawable.mCurrentOffset = smoothProgressDrawable.mCurrentOffset + 0.01f * SmoothProgressDrawable.this.mProgressiveStartSpeed;
            } else {
                SmoothProgressDrawable smoothProgressDrawable = SmoothProgressDrawable.this;
                smoothProgressDrawable.mCurrentOffset = smoothProgressDrawable.mCurrentOffset + 0.01f * SmoothProgressDrawable.this.mSpeed;
            }
            if (SmoothProgressDrawable.this.mCurrentOffset >= SmoothProgressDrawable.this.mMaxOffset) {
                SmoothProgressDrawable.this.mNewTurn = true;
                SmoothProgressDrawable smoothProgressDrawable = SmoothProgressDrawable.this;
                smoothProgressDrawable.mCurrentOffset = smoothProgressDrawable.mCurrentOffset - SmoothProgressDrawable.this.mMaxOffset;
            }
            if (SmoothProgressDrawable.this.isRunning()) {
                SmoothProgressDrawable smoothProgressDrawable = SmoothProgressDrawable.this;
                smoothProgressDrawable.scheduleSelf(smoothProgressDrawable.mUpdater, 16L + SystemClock.uptimeMillis());
            }
            SmoothProgressDrawable.this.invalidateSelf();
        }
    };
    private boolean mUseGradients;

    private SmoothProgressDrawable(Interpolator interpolator, int n, int n2, int[] arrn, float f, float f2, float f3, float f4, boolean bl, boolean bl2, Callbacks callbacks, boolean bl3, Drawable drawable2, boolean bl4) {
        Paint paint;
        this.mInterpolator = interpolator;
        this.mSectionsCount = n;
        this.mStartSection = 0;
        this.mCurrentSections = n;
        this.mSeparatorLength = n2;
        this.mSpeed = f2;
        this.mProgressiveStartSpeed = f3;
        this.mProgressiveStopSpeed = f4;
        this.mReversed = bl;
        this.mColors = arrn;
        this.mColorsIndex = 0;
        this.mMirrorMode = bl2;
        this.mFinishing = false;
        this.mBackgroundDrawable = drawable2;
        this.mStrokeWidth = f;
        this.mMaxOffset = 1.0f / (float)n;
        this.mPaint = paint = new Paint();
        paint.setStrokeWidth(f);
        this.mPaint.setStyle(Paint.Style.STROKE);
        this.mPaint.setDither(false);
        this.mPaint.setAntiAlias(false);
        this.mProgressiveStartActivated = bl3;
        this.mCallbacks = callbacks;
        this.mUseGradients = bl4;
        this.refreshLinearGradientOptions();
    }

    private void checkColorIndex(int n) {
        if (n >= 0 && n < this.mColors.length) {
            return;
        }
        Object[] arrobject = new Object[]{n};
        throw new IllegalArgumentException(String.format((String)"Index %d not valid", (Object[])arrobject));
    }

    private int decrementColor(int n) {
        int n2 = n - 1;
        if (n2 < 0) {
            n2 = -1 + this.mColors.length;
        }
        return n2;
    }

    private void drawBackground(Canvas canvas, float f, float f2) {
        int n = canvas.save();
        canvas.clipRect(f, (float)((int)(((float)canvas.getHeight() - this.mStrokeWidth) / 2.0f)), f2, (float)((int)(((float)canvas.getHeight() + this.mStrokeWidth) / 2.0f)));
        this.mBackgroundDrawable.draw(canvas);
        canvas.restoreToCount(n);
    }

    private void drawBackgroundIfNeeded(Canvas canvas, float f, float f2) {
        if (this.mBackgroundDrawable == null) {
            return;
        }
        this.fBackgroundRect.top = (int)(((float)canvas.getHeight() - this.mStrokeWidth) / 2.0f);
        this.fBackgroundRect.bottom = (int)(((float)canvas.getHeight() + this.mStrokeWidth) / 2.0f);
        this.fBackgroundRect.left = 0;
        Rect rect = this.fBackgroundRect;
        int n = this.mMirrorMode ? canvas.getWidth() / 2 : canvas.getWidth();
        rect.right = n;
        this.mBackgroundDrawable.setBounds(this.fBackgroundRect);
        if (!this.isRunning()) {
            if (this.mMirrorMode) {
                canvas.save();
                canvas.translate((float)(canvas.getWidth() / 2), 0.0f);
                this.drawBackground(canvas, 0.0f, this.fBackgroundRect.width());
                canvas.scale(-1.0f, 1.0f);
                this.drawBackground(canvas, 0.0f, this.fBackgroundRect.width());
                canvas.restore();
                return;
            }
            this.drawBackground(canvas, 0.0f, this.fBackgroundRect.width());
            return;
        }
        if (!this.isFinishing() && !this.isStarting()) {
            return;
        }
        if (f > f2) {
            float f3 = f;
            f = f2;
            f2 = f3;
        }
        if (f > 0.0f) {
            if (this.mMirrorMode) {
                canvas.save();
                canvas.translate((float)(canvas.getWidth() / 2), 0.0f);
                if (this.mReversed) {
                    this.drawBackground(canvas, 0.0f, f);
                    canvas.scale(-1.0f, 1.0f);
                    this.drawBackground(canvas, 0.0f, f);
                } else {
                    this.drawBackground(canvas, (float)(canvas.getWidth() / 2) - f, canvas.getWidth() / 2);
                    canvas.scale(-1.0f, 1.0f);
                    this.drawBackground(canvas, (float)(canvas.getWidth() / 2) - f, canvas.getWidth() / 2);
                }
                canvas.restore();
            } else {
                this.drawBackground(canvas, 0.0f, f);
            }
        }
        if (f2 <= (float)canvas.getWidth()) {
            if (this.mMirrorMode) {
                canvas.save();
                canvas.translate((float)(canvas.getWidth() / 2), 0.0f);
                if (this.mReversed) {
                    this.drawBackground(canvas, f2, canvas.getWidth() / 2);
                    canvas.scale(-1.0f, 1.0f);
                    this.drawBackground(canvas, f2, canvas.getWidth() / 2);
                } else {
                    this.drawBackground(canvas, 0.0f, (float)(canvas.getWidth() / 2) - f2);
                    canvas.scale(-1.0f, 1.0f);
                    this.drawBackground(canvas, 0.0f, (float)(canvas.getWidth() / 2) - f2);
                }
                canvas.restore();
                return;
            }
            this.drawBackground(canvas, f2, canvas.getWidth());
        }
    }

    private void drawGradient(Canvas canvas) {
        float f = 1.0f / (float)this.mSectionsCount;
        int n = this.mColorsIndex;
        float[] arrf = this.mLinearGradientPositions;
        arrf[0] = 0.0f;
        arrf[-1 + arrf.length] = 1.0f;
        int n2 = n - 1;
        if (n2 < 0) {
            n2 += this.mColors.length;
        }
        this.mLinearGradientColors[0] = this.mColors[n2];
        for (int i = 0; i < this.mSectionsCount; ++i) {
            float f2;
            this.mLinearGradientPositions[i + 1] = f2 = this.mInterpolator.getInterpolation(f * (float)i + this.mCurrentOffset);
            int[] arrn = this.mLinearGradientColors;
            int n3 = i + 1;
            int[] arrn2 = this.mColors;
            arrn[n3] = arrn2[n];
            n = (n + 1) % arrn2.length;
        }
        int[] arrn = this.mLinearGradientColors;
        arrn[-1 + arrn.length] = this.mColors[n];
        int n4 = this.mReversed ? (this.mMirrorMode ? Math.abs((int)(this.mBounds.left - this.mBounds.right)) / 2 : this.mBounds.left) : this.mBounds.left;
        float f3 = n4;
        int n5 = this.mMirrorMode ? (this.mReversed ? this.mBounds.left : Math.abs((int)(this.mBounds.left - this.mBounds.right)) / 2) : this.mBounds.right;
        float f4 = n5;
        float f5 = (float)this.mBounds.centerY() - this.mStrokeWidth / 2.0f;
        float f6 = (float)this.mBounds.centerY() + this.mStrokeWidth / 2.0f;
        int[] arrn3 = this.mLinearGradientColors;
        float[] arrf2 = this.mLinearGradientPositions;
        Shader.TileMode tileMode = this.mMirrorMode ? Shader.TileMode.MIRROR : Shader.TileMode.CLAMP;
        LinearGradient linearGradient = new LinearGradient(f3, f5, f4, f6, arrn3, arrf2, tileMode);
        this.mPaint.setShader((Shader)linearGradient);
    }

    private void drawLine(Canvas canvas, int n, float f, float f2, float f3, float f4, int n2) {
        this.mPaint.setColor(this.mColors[n2]);
        if (!this.mMirrorMode) {
            canvas.drawLine(f, f2, f3, f4, this.mPaint);
            return;
        }
        if (this.mReversed) {
            canvas.drawLine(f + (float)n, f2, f3 + (float)n, f4, this.mPaint);
            canvas.drawLine((float)n - f, f2, (float)n - f3, f4, this.mPaint);
            return;
        }
        canvas.drawLine(f, f2, f3, f4, this.mPaint);
        canvas.drawLine((float)(n * 2) - f, f2, (float)(n * 2) - f3, f4, this.mPaint);
    }

    private void drawStrokes(Canvas canvas) {
        boolean bl = this.mReversed;
        float f = 1.0f;
        if (bl) {
            canvas.translate((float)this.mBounds.width(), 0.0f);
            canvas.scale(-1.0f, f);
        }
        int n = this.mBounds.width();
        if (this.mMirrorMode) {
            n /= 2;
        }
        int n2 = n;
        int n3 = n2 + this.mSeparatorLength + this.mSectionsCount;
        int n4 = this.mBounds.centerY();
        int n5 = this.mSectionsCount;
        float f2 = f / (float)n5;
        int n6 = this.mColorsIndex;
        int n7 = this.mStartSection;
        int n8 = this.mCurrentSections;
        float f3 = 0.0f;
        if (n7 == n8) {
            f3 = 0.0f;
            if (n8 == n5) {
                f3 = canvas.getWidth();
            }
        }
        float f4 = 0.0f;
        int n9 = 0;
        float f5 = f3;
        float f6 = 0.0f;
        int n10 = n6;
        while (n9 <= this.mCurrentSections) {
            int n11;
            float f7;
            float f8;
            float f9;
            int n12;
            float f10;
            float f11;
            int n13;
            int n14;
            block8 : {
                float f12;
                block7 : {
                    float f13;
                    int n15;
                    float f14;
                    block5 : {
                        block6 : {
                            float f15 = f2 * (float)n9 + this.mCurrentOffset;
                            float f16 = Math.max((float)0.0f, (float)(f15 - f2));
                            float f17 = this.mInterpolator.getInterpolation(f16);
                            Interpolator interpolator = this.mInterpolator;
                            n15 = n10;
                            f10 = (f13 = (float)((int)(Math.abs((float)(f17 - interpolator.getInterpolation(Math.min((float)f15, (float)f)))) * (float)n3))) + f16 < (float)n3 ? Math.min((float)f13, (float)this.mSeparatorLength) : 0.0f;
                            float f18 = f13 > f10 ? f13 - f10 : 0.0f;
                            f14 = f4 + f18;
                            if (!(f14 > f4)) break block5;
                            if (n9 < this.mStartSection) break block6;
                            float f19 = Math.max((float)(this.mInterpolator.getInterpolation(Math.min((float)this.mFinishingOffset, (float)1.0f)) * (float)n3), (float)Math.min((float)n2, (float)f4));
                            float f20 = Math.min((float)n2, (float)f14);
                            float f21 = n4;
                            float f22 = n4;
                            f7 = f14;
                            int n16 = n2;
                            n11 = n15;
                            f11 = f13;
                            f8 = f6;
                            n14 = n2;
                            f12 = f5;
                            n13 = n3;
                            n12 = n9;
                            f9 = f4;
                            this.drawLine(canvas, n16, f19, f21, f20, f22, n11);
                            if (n12 != this.mStartSection) break block7;
                            f5 = f19 - (float)this.mSeparatorLength;
                            break block8;
                        }
                        f7 = f14;
                        f9 = f4;
                        n14 = n2;
                        n13 = n3;
                        n11 = n15;
                        f11 = f13;
                        f8 = f6;
                        f12 = f5;
                        n12 = n9;
                        break block7;
                    }
                    f7 = f14;
                    f9 = f4;
                    n14 = n2;
                    n13 = n3;
                    n11 = n15;
                    f11 = f13;
                    f8 = f6;
                    f12 = f5;
                    n12 = n9;
                }
                f5 = f12;
            }
            f6 = n12 == this.mCurrentSections ? f9 + f11 : f8;
            f4 = f7 + f10;
            n10 = this.incrementColor(n11);
            n9 = n12 + 1;
            n2 = n14;
            n3 = n13;
            f = 1.0f;
        }
        float f23 = f6;
        this.drawBackgroundIfNeeded(canvas, f5, f23);
    }

    private int incrementColor(int n) {
        int n2 = n + 1;
        if (n2 >= this.mColors.length) {
            n2 = 0;
        }
        return n2;
    }

    private void resetProgressiveStart(int n) {
        this.checkColorIndex(n);
        this.mCurrentOffset = 0.0f;
        this.mFinishing = false;
        this.mFinishingOffset = 0.0f;
        this.mStartSection = 0;
        this.mCurrentSections = 0;
        this.mColorsIndex = n;
    }

    public void draw(Canvas canvas) {
        Rect rect;
        this.mBounds = rect = this.getBounds();
        canvas.clipRect(rect);
        if (this.mNewTurn) {
            int n;
            this.mColorsIndex = this.decrementColor(this.mColorsIndex);
            this.mNewTurn = false;
            if (this.isFinishing()) {
                int n2;
                this.mStartSection = n2 = 1 + this.mStartSection;
                if (n2 > this.mSectionsCount) {
                    this.stop();
                    return;
                }
            }
            if ((n = this.mCurrentSections) < this.mSectionsCount) {
                this.mCurrentSections = n + 1;
            }
        }
        if (this.mUseGradients) {
            this.drawGradient(canvas);
        }
        this.drawStrokes(canvas);
    }

    public Drawable getBackgroundDrawable() {
        return this.mBackgroundDrawable;
    }

    public int[] getColors() {
        return this.mColors;
    }

    public int getOpacity() {
        return -2;
    }

    public float getStrokeWidth() {
        return this.mStrokeWidth;
    }

    public boolean isFinishing() {
        return this.mFinishing;
    }

    public boolean isRunning() {
        return this.mRunning;
    }

    public boolean isStarting() {
        return this.mCurrentSections < this.mSectionsCount;
    }

    public void progressiveStart() {
        this.progressiveStart(0);
    }

    public void progressiveStart(int n) {
        this.resetProgressiveStart(n);
        this.start();
    }

    public void progressiveStop() {
        this.mFinishing = true;
        this.mStartSection = 0;
    }

    protected void refreshLinearGradientOptions() {
        if (this.mUseGradients) {
            int n = this.mSectionsCount;
            this.mLinearGradientColors = new int[n + 2];
            this.mLinearGradientPositions = new float[n + 2];
            return;
        }
        this.mPaint.setShader(null);
        this.mLinearGradientColors = null;
        this.mLinearGradientPositions = null;
    }

    public void scheduleSelf(Runnable runnable, long l) {
        this.mRunning = true;
        super.scheduleSelf(runnable, l);
    }

    public void setAlpha(int n) {
        this.mPaint.setAlpha(n);
    }

    public void setBackgroundDrawable(Drawable drawable2) {
        if (this.mBackgroundDrawable == drawable2) {
            return;
        }
        this.mBackgroundDrawable = drawable2;
        this.invalidateSelf();
    }

    public void setCallbacks(Callbacks callbacks) {
        this.mCallbacks = callbacks;
    }

    public void setColor(int n) {
        this.setColors(new int[]{n});
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.mPaint.setColorFilter(colorFilter);
    }

    public void setColors(int[] arrn) {
        if (arrn != null && arrn.length != 0) {
            this.mColorsIndex = 0;
            this.mColors = arrn;
            this.refreshLinearGradientOptions();
            this.invalidateSelf();
            return;
        }
        throw new IllegalArgumentException("Colors cannot be null or empty");
    }

    public void setInterpolator(Interpolator interpolator) {
        if (interpolator != null) {
            this.mInterpolator = interpolator;
            this.invalidateSelf();
            return;
        }
        throw new IllegalArgumentException("Interpolator cannot be null");
    }

    public void setMirrorMode(boolean bl) {
        if (this.mMirrorMode == bl) {
            return;
        }
        this.mMirrorMode = bl;
        this.invalidateSelf();
    }

    public void setProgressiveStartActivated(boolean bl) {
        this.mProgressiveStartActivated = bl;
    }

    public void setProgressiveStartSpeed(float f) {
        if (!(f < 0.0f)) {
            this.mProgressiveStartSpeed = f;
            this.invalidateSelf();
            return;
        }
        throw new IllegalArgumentException("SpeedProgressiveStart must be >= 0");
    }

    public void setProgressiveStopSpeed(float f) {
        if (!(f < 0.0f)) {
            this.mProgressiveStopSpeed = f;
            this.invalidateSelf();
            return;
        }
        throw new IllegalArgumentException("SpeedProgressiveStop must be >= 0");
    }

    public void setReversed(boolean bl) {
        if (this.mReversed == bl) {
            return;
        }
        this.mReversed = bl;
        this.invalidateSelf();
    }

    public void setSectionsCount(int n) {
        if (n > 0) {
            float f;
            this.mSectionsCount = n;
            this.mMaxOffset = f = 1.0f / (float)n;
            this.mCurrentOffset %= f;
            this.refreshLinearGradientOptions();
            this.invalidateSelf();
            return;
        }
        throw new IllegalArgumentException("SectionsCount must be > 0");
    }

    public void setSeparatorLength(int n) {
        if (n >= 0) {
            this.mSeparatorLength = n;
            this.invalidateSelf();
            return;
        }
        throw new IllegalArgumentException("SeparatorLength must be >= 0");
    }

    public void setSpeed(float f) {
        if (!(f < 0.0f)) {
            this.mSpeed = f;
            this.invalidateSelf();
            return;
        }
        throw new IllegalArgumentException("Speed must be >= 0");
    }

    public void setStrokeWidth(float f) {
        if (!(f < 0.0f)) {
            this.mPaint.setStrokeWidth(f);
            this.invalidateSelf();
            return;
        }
        throw new IllegalArgumentException("The strokeWidth must be >= 0");
    }

    public void setUseGradients(boolean bl) {
        if (this.mUseGradients == bl) {
            return;
        }
        this.mUseGradients = bl;
        this.refreshLinearGradientOptions();
        this.invalidateSelf();
    }

    public void start() {
        if (this.mProgressiveStartActivated) {
            this.resetProgressiveStart(0);
        }
        if (this.isRunning()) {
            return;
        }
        Callbacks callbacks = this.mCallbacks;
        if (callbacks != null) {
            callbacks.onStart();
        }
        this.scheduleSelf(this.mUpdater, 16L + SystemClock.uptimeMillis());
        this.invalidateSelf();
    }

    public void stop() {
        if (!this.isRunning()) {
            return;
        }
        Callbacks callbacks = this.mCallbacks;
        if (callbacks != null) {
            callbacks.onStop();
        }
        this.mRunning = false;
        this.unscheduleSelf(this.mUpdater);
    }

    public static class Builder {
        private Drawable mBackgroundDrawableWhenHidden;
        private int[] mColors;
        private boolean mGenerateBackgroundUsingColors;
        private boolean mGradients;
        private Interpolator mInterpolator;
        private boolean mMirrorMode;
        private Callbacks mOnProgressiveStopEndedListener;
        private boolean mProgressiveStartActivated;
        private float mProgressiveStartSpeed;
        private float mProgressiveStopSpeed;
        private boolean mReversed;
        private int mSectionsCount;
        private float mSpeed;
        private int mStrokeSeparatorLength;
        private float mStrokeWidth;

        public Builder(Context context) {
            this(context, false);
        }

        public Builder(Context context, boolean bl) {
            this.initValues(context, bl);
        }

        private void initValues(Context context, boolean bl) {
            float f;
            Resources resources = context.getResources();
            this.mInterpolator = new AccelerateInterpolator();
            if (!bl) {
                this.mSectionsCount = resources.getInteger(R.integer.spb_default_sections_count);
                this.mSpeed = Float.parseFloat((String)resources.getString(R.string.spb_default_speed));
                this.mReversed = resources.getBoolean(R.bool.spb_default_reversed);
                this.mProgressiveStartActivated = resources.getBoolean(R.bool.spb_default_progressiveStart_activated);
                int[] arrn = new int[]{resources.getColor(R.color.spb_default_color)};
                this.mColors = arrn;
                this.mStrokeSeparatorLength = resources.getDimensionPixelSize(R.dimen.spb_default_stroke_separator_length);
                this.mStrokeWidth = resources.getDimensionPixelOffset(R.dimen.spb_default_stroke_width);
            } else {
                this.mSectionsCount = 4;
                this.mSpeed = 1.0f;
                this.mReversed = false;
                this.mProgressiveStartActivated = false;
                this.mColors = new int[]{-13388315};
                this.mStrokeSeparatorLength = 4;
                this.mStrokeWidth = 4.0f;
            }
            this.mProgressiveStartSpeed = f = this.mSpeed;
            this.mProgressiveStopSpeed = f;
            this.mGradients = false;
        }

        public Builder backgroundDrawable(Drawable drawable2) {
            this.mBackgroundDrawableWhenHidden = drawable2;
            return this;
        }

        public SmoothProgressDrawable build() {
            if (this.mGenerateBackgroundUsingColors) {
                this.mBackgroundDrawableWhenHidden = SmoothProgressBarUtils.generateDrawableWithColors(this.mColors, this.mStrokeWidth);
            }
            SmoothProgressDrawable smoothProgressDrawable = new SmoothProgressDrawable(this.mInterpolator, this.mSectionsCount, this.mStrokeSeparatorLength, this.mColors, this.mStrokeWidth, this.mSpeed, this.mProgressiveStartSpeed, this.mProgressiveStopSpeed, this.mReversed, this.mMirrorMode, this.mOnProgressiveStopEndedListener, this.mProgressiveStartActivated, this.mBackgroundDrawableWhenHidden, this.mGradients);
            return smoothProgressDrawable;
        }

        public Builder callbacks(Callbacks callbacks) {
            this.mOnProgressiveStopEndedListener = callbacks;
            return this;
        }

        public Builder color(int n) {
            this.mColors = new int[]{n};
            return this;
        }

        public Builder colors(int[] arrn) {
            SmoothProgressBarUtils.checkColors(arrn);
            this.mColors = arrn;
            return this;
        }

        public Builder generateBackgroundUsingColors() {
            this.mGenerateBackgroundUsingColors = true;
            return this;
        }

        public Builder gradients() {
            return this.gradients(true);
        }

        public Builder gradients(boolean bl) {
            this.mGradients = bl;
            return this;
        }

        public Builder interpolator(Interpolator interpolator) {
            SmoothProgressBarUtils.checkNotNull((Object)interpolator, "Interpolator");
            this.mInterpolator = interpolator;
            return this;
        }

        public Builder mirrorMode(boolean bl) {
            this.mMirrorMode = bl;
            return this;
        }

        public Builder progressiveStart(boolean bl) {
            this.mProgressiveStartActivated = bl;
            return this;
        }

        public Builder progressiveStartSpeed(float f) {
            SmoothProgressBarUtils.checkSpeed(f);
            this.mProgressiveStartSpeed = f;
            return this;
        }

        public Builder progressiveStopSpeed(float f) {
            SmoothProgressBarUtils.checkSpeed(f);
            this.mProgressiveStopSpeed = f;
            return this;
        }

        public Builder reversed(boolean bl) {
            this.mReversed = bl;
            return this;
        }

        public Builder sectionsCount(int n) {
            SmoothProgressBarUtils.checkPositive(n, "Sections count");
            this.mSectionsCount = n;
            return this;
        }

        public Builder separatorLength(int n) {
            SmoothProgressBarUtils.checkPositiveOrZero(n, "Separator length");
            this.mStrokeSeparatorLength = n;
            return this;
        }

        public Builder speed(float f) {
            SmoothProgressBarUtils.checkSpeed(f);
            this.mSpeed = f;
            return this;
        }

        public Builder strokeWidth(float f) {
            SmoothProgressBarUtils.checkPositiveOrZero(f, "Width");
            this.mStrokeWidth = f;
            return this;
        }
    }

    public static interface Callbacks {
        public void onStart();

        public void onStop();
    }

}

