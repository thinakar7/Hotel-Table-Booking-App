/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  java.lang.Runnable
 *  java.lang.System
 */
package fr.castorflex.android.smoothprogressbar;

import android.content.Context;
import android.util.AttributeSet;
import fr.castorflex.android.smoothprogressbar.ContentLoadingSmoothProgressBar;
import fr.castorflex.android.smoothprogressbar.SmoothProgressBar;

public class ContentLoadingSmoothProgressBar
extends SmoothProgressBar {
    private static final int MIN_DELAY = 500;
    private static final int MIN_SHOW_TIME = 500;
    private final Runnable mDelayedHide = new Runnable(this){
        final /* synthetic */ ContentLoadingSmoothProgressBar this$0;
        {
            this.this$0 = contentLoadingSmoothProgressBar;
        }

        public void run() {
            ContentLoadingSmoothProgressBar.access$002(this.this$0, false);
            ContentLoadingSmoothProgressBar.access$102(this.this$0, -1L);
            this.this$0.setVisibility(8);
        }
    };
    private final Runnable mDelayedShow = new Runnable(this){
        final /* synthetic */ ContentLoadingSmoothProgressBar this$0;
        {
            this.this$0 = contentLoadingSmoothProgressBar;
        }

        public void run() {
            ContentLoadingSmoothProgressBar.access$202(this.this$0, false);
            if (!ContentLoadingSmoothProgressBar.access$300(this.this$0)) {
                ContentLoadingSmoothProgressBar.access$102(this.this$0, System.currentTimeMillis());
                this.this$0.setVisibility(0);
            }
        }
    };
    private boolean mDismissed = false;
    private boolean mPostedHide = false;
    private boolean mPostedShow = false;
    private long mStartTime = -1L;

    public ContentLoadingSmoothProgressBar(Context context) {
        this(context, null);
    }

    public ContentLoadingSmoothProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
    }

    static /* synthetic */ boolean access$002(ContentLoadingSmoothProgressBar contentLoadingSmoothProgressBar, boolean bl) {
        contentLoadingSmoothProgressBar.mPostedHide = bl;
        return bl;
    }

    static /* synthetic */ long access$102(ContentLoadingSmoothProgressBar contentLoadingSmoothProgressBar, long l) {
        contentLoadingSmoothProgressBar.mStartTime = l;
        return l;
    }

    static /* synthetic */ boolean access$202(ContentLoadingSmoothProgressBar contentLoadingSmoothProgressBar, boolean bl) {
        contentLoadingSmoothProgressBar.mPostedShow = bl;
        return bl;
    }

    static /* synthetic */ boolean access$300(ContentLoadingSmoothProgressBar contentLoadingSmoothProgressBar) {
        return contentLoadingSmoothProgressBar.mDismissed;
    }

    private void removeCallbacks() {
        this.removeCallbacks(this.mDelayedHide);
        this.removeCallbacks(this.mDelayedShow);
    }

    public void hide() {
        this.mDismissed = true;
        this.removeCallbacks(this.mDelayedShow);
        long l = System.currentTimeMillis();
        long l2 = this.mStartTime;
        long l3 = l - l2;
        if (l3 < 500L && l2 != -1L) {
            if (!this.mPostedHide) {
                this.postDelayed(this.mDelayedHide, 500L - l3);
                this.mPostedHide = true;
                return;
            }
        } else {
            this.setVisibility(8);
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.removeCallbacks();
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.removeCallbacks();
    }

    public void show() {
        this.mStartTime = -1L;
        this.mDismissed = false;
        this.removeCallbacks(this.mDelayedHide);
        if (!this.mPostedShow) {
            this.postDelayed(this.mDelayedShow, 500L);
            this.mPostedShow = true;
        }
    }
}

